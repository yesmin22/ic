<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ageing_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	function generate_payable_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_payable_ageing');
		$this->webspice->permission_verify('generate_payable_ageing');

		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		
		$max_ageing_date = date("Y-m-d");
		$initialSQL = "
		    SELECT 
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 30
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS NOT_DUE,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 30
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 60
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_30,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 60
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 90
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_60,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 90
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 120
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_90,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 120
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 150
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_120,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 150
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 180
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_150,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 180
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 365
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_365,
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 365
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_YR_1_3,
        OPERATOR_NAME,OPERATOR_TYPE
        FROM TBL_PAYABLE_AGEING
        GROUP BY OPERATOR_NAME
		";


   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_PAYABLE_AGEING',
				$InputField = array('OPERATOR_NAME'),
				$Keyword = array(),
				$AdditionalWhere = " EXTRACT (YEAR FROM TBL_PAYABLE_AGEING.CREATED_DATE) = 2017 /*EXTRACT (YEAR FROM SYSDATE)*/ AND EXTRACT (MONTH FROM TBL_PAYMENT_HISTORY_FOR_AGEING.CREATED_DATE) = 11 /*EXTRACT (MONTH FROM SYSDATE)*/ ",
				$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
			$initialSQL;
		}

    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql_ageing']) || !$_SESSION['sql_ageing'] ){
				$_SESSION['sql_ageing'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql_ageing'] );
			$data['get_record'] = $record->result();
			$data['filter_by'] = $_SESSION['filter_by'];

			$this->load->view('ageing/print_payable_ageing',$data);
			return false;
			break;

			case 'approve':
			$this->webspice->action_executer($TableName='TBL_BUNDLE', $KeyField='BUNDLE_ID', $key, $RedirectURL='manage_bundle', $PermissionName='manage_bundle', $StatusCheck=1, $ChangeStatus=2, $RemoveCache='bundle', $Log='approve_bundle');
			return false;
			break;

			case 'remove':
					# delete permanently bundle and bundle item related information
			$this->db->trans_off();
			$this->db->trans_begin();

			$key = $this->webspice->encrypt_decrypt($key, 'decrypt');

			$delete_sql = "DELETE FROM TBL_BUNDLE WHERE BUNDLE_ID = ? AND ROWNUM = 1";
			$this->db->query($delete_sql, $key);

			$delete_sql = "DELETE FROM TBL_BUNDLE_ITEM WHERE BUNDLE_ID = ? ";
			$this->db->query($delete_sql, $key);

			if ($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return FALSE;

			}else{
				$this->db->trans_commit();
			}
			$this->db->trans_off();

					# remove cache
			$this->webspice->remove_cache('bundle');

			$this->webspice->force_redirect($url_prefix.'manage_bundle');
			return false;
			break;
		}

    # default
		$sql = $initialSQL;
    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql_bundle']) || !$_SESSION['sql_bundle'] ){
    		$sql = substr($sql, 0, strpos($sql,'LIMIT'));
    	}else{
    		$sql = substr($_SESSION['sql_bundle'], 0, strpos($_SESSION['sql_bundle'],'LIMIT'));
    	}

    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = $sql . $limit;
    }*/

		# load all records
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_bundle/page/', 10 );
		}*/

		$_SESSION['sql_ageing'] = $sql;
		$_SESSION['filter_by'] = $filter_by;
		$result = $this->db->query($sql)->result();
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('ageing/generate_payable_ageing', $data);
	}
	
	
	function generate_recevable_payable_net_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_recevable_ageing');
		$this->webspice->permission_verify('generate_recevable_ageing');
		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		
		$max_ageing_date = date("Y-m-d");
		$initialSQL = "
		    SELECT TBL_OPERATOR.OPERATOR_NAME AS OPERATOR_NAME, TBL_OPERATOR.OPERATOR_TYPE AS OPERATOR_TYPE,
		    SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD)  <= 1
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS NOT_DUE,
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD)  > 1
        AND DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) <= 30
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_1,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) > 30
        AND DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) <= 60
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_30,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) > 60
        AND DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) <= 90
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_60,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) > 90
        AND DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) <= 120
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_90,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) > 120
        AND DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) <= 150
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_120,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) > 150
        AND DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) <= 180
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_150,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) > 180
        AND DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) <= 365
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_365,
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_INVOICE_DETAIL.BILL_PERIOD) > 365
        THEN
        TBL_INVOICE_DETAIL.REMAINING_AMOUNT
        END)
        AS SLAB_YR_1_3
        FROM TBL_OPERATOR 
        LEFT JOIN TBL_INVOICE_DETAIL ON TBL_OPERATOR.OPERATOR_NAME= TBL_INVOICE_DETAIL.OPERATOR_NAME
	      GROUP BY TBL_OPERATOR.OPERATOR_NAME
		";

		$initialSQL_for_payable = "
		    SELECT TBL_OPERATOR.OPERATOR_NAME AS OPERATOR_NAME, TBL_OPERATOR.OPERATOR_TYPE AS OPERATOR_TYPE,
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 1
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS NOT_DUE,
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 1
        AND DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 30
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_1,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 30
        AND DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 60
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_30,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 60
        AND DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 90
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_60,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 90
        AND DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 120
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_90,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 120
        AND DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 150
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_120,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 150
        AND DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 180
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_150,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 180
        AND DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) <= 365
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_365,
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', TBL_PAYABLE_AGEING.BILL_MONTH) > 365
        THEN
        TBL_PAYABLE_AGEING.INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_YR_1_3
        FROM TBL_OPERATOR 
        LEFT JOIN TBL_PAYABLE_AGEING ON TBL_OPERATOR.OPERATOR_NAME= TBL_PAYABLE_AGEING.OPERATOR_NAME
	      GROUP BY TBL_OPERATOR.OPERATOR_NAME
		";
		$sql_for_net='SELECT DATA_SET.OPERATOR_NAME, DATA_SET.OPERATOR_TYPE, 
		SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM DATA_SET.BILL_MONTH) =
	                           EXTRACT(MONTH FROM NOW())
	                    AND EXTRACT(YEAR FROM DATA_SET.BILL_MONTH) =
	                           EXTRACT(YEAR FROM NOW())
	               THEN
	                   DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS NOT_DUE,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM DATA_SET.BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM DATA_SET.BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	               
	               THEN
	                    DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_30,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM DATA_SET.BILL_MONTH) =
	                           EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM DATA_SET.BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	    
	               THEN
	                    DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_60,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM DATA_SET.BILL_MONTH) =
	                              EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM DATA_SET.BILL_MONTH) =
	                              EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                 
	                  THEN
	                       DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_90,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM DATA_SET.BILL_MONTH) =
	                                 EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM DATA_SET.BILL_MONTH) =
	                                 EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                     
	                     THEN
	                           DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_120,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM DATA_SET.BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM DATA_SET.BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	              
	                      THEN
	                            DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM DATA_SET.BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM DATA_SET.BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	              
	                      THEN
	                            DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_180,
	                           SUM(
	                              CASE
	                                 WHEN DATA_SET.BILL_MONTH BETWEEN DATE_ADD(NOW(), INTERVAL -181 DAY)
	                                                               AND DATE_ADD(NOW(), INTERVAL -365 DAY)
	                               
	                                 THEN
	                                   DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	                                ELSE
	                                  0
	                              END)
	                              AS SLAB_181_365,

	                                    SUM(
	                                      CASE
	                                          WHEN DATA_SET.BILL_MONTH < DATE_ADD(NOW(), INTERVAL -365 DAY)
	                                    
	                                          THEN
	                                            DATA_SET.INVOICE_AMOUNT_AFTER_VAT_TAX - DATA_SET.REMAINING_AMOUNT
	                                         ELSE
	                                           0
	                                       END)
	                                       AS SLAB_365_more
	 FROM ( SELECT TP.`OPERATOR_NAME`, TP.`OPERATOR_TYPE`, TBA.`BILL_MONTH`, TBA.`INVOICE_AMOUNT_AFTER_VAT_TAX` , TID.`REMAINING_AMOUNT`
	 FROM tbl_operator TP
	 LEFT JOIN tbl_payable_ageing TBA ON TP.`OPERATOR_NAME` = TBA.`OPERATOR_NAME`
	 LEFT JOIN tbl_invoice_detail TID ON TP.`OPERATOR_NAME` = TID.`OPERATOR_NAME`) DATA_SET

	 GROUP BY DATA_SET.OPERATOR_NAME
   ORDER BY DATA_SET.OPERATOR_NAME';
	

    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql_ageing']) || !$_SESSION['sql_ageing'] ){
				$_SESSION['sql_ageing'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql_ageing'] );
			$data['get_record'] = $record->result();
			$data['filter_by'] = $_SESSION['filter_by'];
			$this->load->view('ageing/print_receivable_ageing',$data);
			return false;
			break;
		}

    # 
	
		$sql = $initialSQL;
		//$_SESSION['sql_ageing'] = $sql;
		//$_SESSION['filter_by'] = $filter_by;
		$result = $this->db->query($sql)->result();
		$result_for_payable = $this->db->query($initialSQL_for_payable)->result();
		$result_for_net = $this->db->query($sql_for_net)->result();
		$result_for_net=array();
		
		$data['get_record'] = $result;
		$data['get_record_for_payable'] = $result_for_payable;
		$data['result_for_net'] = $result_for_net;
		$data['filter_by'] = $filter_by;
		$this->load->view('ageing/generate_receivable_ageing', $data);
	}
	

	function generate_recevable_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_recevable_ageing');
		$this->webspice->permission_verify('generate_recevable_ageing');
		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}											 
		$initialSQL = "
		    SELECT TBL_OPERATOR.OPERATOR_NAME AS OPERATOR_NAME, TBL_OPERATOR.OPERATOR_TYPE AS OPERATOR_TYPE,
				SUM(
                          CASE
                             WHEN     EXTRACT(MONTH FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                        EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
                                  AND EXTRACT(YEAR FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                         EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
                             THEN
                                  TBL_INVOICE_DETAIL.REMAINING_AMOUNT
                             ELSE
                              0
                          END)
                           AS NOT_DUE,
				SUM(
                          CASE
                             WHEN     EXTRACT(MONTH FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                        EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
                                  AND EXTRACT(YEAR FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                         EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
                             THEN
                                  TBL_INVOICE_DETAIL.REMAINING_AMOUNT
                             ELSE
                              0
                          END)
                           AS SLAB_0_30,
				SUM(
                          CASE
                             WHEN     EXTRACT(MONTH FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                        EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
                                  AND EXTRACT(YEAR FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                         EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
                             THEN
                                  TBL_INVOICE_DETAIL.REMAINING_AMOUNT
                             ELSE
                              0
                          END)
                           AS SLAB_31_60,
				SUM(
                          CASE
                             WHEN     EXTRACT(MONTH FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                        EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
                                  AND EXTRACT(YEAR FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                         EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
                             THEN
                                  TBL_INVOICE_DETAIL.REMAINING_AMOUNT
                             ELSE
                              0
                          END)
                           AS SLAB_61_90,
						   
				SUM(
                          CASE
                             WHEN     EXTRACT(MONTH FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                        EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
                                  AND EXTRACT(YEAR FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                         EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
                             THEN
                                  TBL_INVOICE_DETAIL.REMAINING_AMOUNT
                             ELSE
                              0
                          END)
                           AS SLAB_91_120,
						   
				SUM(
                          CASE
                             WHEN     EXTRACT(MONTH FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                        EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
                                  AND EXTRACT(YEAR FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                         EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
                             THEN
                                  TBL_INVOICE_DETAIL.REMAINING_AMOUNT
                             ELSE
                              0
                          END)
                           AS SLAB_121_150,
				SUM(
                          CASE
                             WHEN     EXTRACT(MONTH FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                        EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
                                  AND EXTRACT(YEAR FROM TBL_INVOICE_DETAIL.BILL_PERIOD) =
                                         EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
                             THEN
                                  TBL_INVOICE_DETAIL.REMAINING_AMOUNT
                             ELSE
                              0
                          END)
                           AS SLAB_151_180,
						   
						   
				SUM(
						CASE 
							WHEN TBL_INVOICE_DETAIL.BILL_PERIOD BETWEEN DATE_ADD(NOW(), INTERVAL -10 MONTH) AND DATE_ADD(NOW(), INTERVAL -8 MONTH)
						THEN
							TBL_INVOICE_DETAIL.REMAINING_AMOUNT
						ELSE 
							0
						END
				) AS    SLAB_180_365,
				
				
						   
				SUM(
						CASE 
							WHEN TBL_INVOICE_DETAIL.BILL_PERIOD > DATE_ADD(NOW(), INTERVAL -12 MONTH)
						THEN
							TBL_INVOICE_DETAIL.REMAINING_AMOUNT 
						ELSE 
							0
						END
				) AS    SLAB_365_MORE	   
						   
        FROM TBL_OPERATOR 
        LEFT JOIN TBL_INVOICE_DETAIL ON TBL_OPERATOR.OPERATOR_NAME= TBL_INVOICE_DETAIL.OPERATOR_NAME
	      GROUP BY TBL_OPERATOR.OPERATOR_NAME
		";

		
	

    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql_ageing']) || !$_SESSION['sql_ageing'] ){
				$_SESSION['sql_ageing'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql_ageing'] );
			$data['get_record'] = $record->result();
			$data['filter_by'] = $_SESSION['filter_by'];
			$this->load->view('ageing/print_receivable_ageing',$data);
			return false;
			break;
		}

    # 
	
		$sql = $initialSQL;
		$_SESSION['sql_ageing'] = $sql;
		$_SESSION['filter_by'] = $filter_by;
		$result = $this->db->query($sql)->result();
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('ageing/generate_receivable_ageing', $data);
	}
	

		
	function trade_debitors_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 1;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'trade_debitors_report');
		$this->webspice->permission_verify('trade_debitors_report');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/trade_debitors_report', $data);
			return FALSE;
		}
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('xlsx'), 'sap_file', $data, 'uploader/trade_debitors_report');
		}
		
		$sheet_columns = array("Period", "Account", "Currency", "YTD");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'trade_debitors_report');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time_from_excel = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time=$this->webspice->date_excel_to_real($date_time);
			$account = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$currency = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$ytd = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));

			$values[] = array("PERIOD" => $date_time, "ACCOUNT" => $account, "CURRENCY" => $currency, "YTD" => $ytd, "CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			
			
		
			# must have column value - column offset started from 1
		##	if( !isset($date_time) || !isset($operator) || !isset($calltype) || !isset($prepost_flag) || !isset($calls) || !isset($rate_per_event) || !isset($netamount) ){
		#		$data_error .= 'Row #'.$k.' is incomplete.<br />';
		#	}

		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/trade_debitors_report', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_DEBITORS_DATA";
		$input = $this->webspice->get_input();
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('trade_debitors_report'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('trade_debitors_report', true) ){
			$this->webspice->force_redirect($url_prefix.'trade_debitors_report');
		}
		
		$this->webspice->force_redirect($url_prefix);
	 }
	
 }
	

}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */