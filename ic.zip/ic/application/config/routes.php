<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = 'parent_controller';
$route['confirmation'] = "parent_controller/show_confirmation";
$route['test'] = "parent_controller/test";

$route['ajax_edit'] = "master_controller/ajax_edit";

# user authentication
$route['login'] = 'parent_controller/login';
$route['logout'] = 'parent_controller/logout';
$route['change_password'] = 'parent_controller/change_password';
$route['change_password/:any'] = 'parent_controller/change_password';
$route['forgot_password'] = 'parent_controller/forgot_password';

#configuration
$route['view_configuration_data']='master_controller/view_configuration_data';
$route['view_configuration_data/:any']='master_controller/view_configuration_data';
$route['update_configuration_data']='master_controller/update_configuration_data';
$route['update_configuration_data/:any']='master_controller/update_configuration_data';

# user management
$route['create_user']='master_controller/create_user';
$route['manage_user']='master_controller/manage_user';
$route['manage_user/:any']='master_controller/manage_user';
$route['create_role']='master_controller/create_role';
$route['manage_role']='master_controller/manage_role';
$route['manage_role/:any']='master_controller/manage_role';

#All Uploader
$route['upload_ro_dom_sms_data']='upload_controller/upload_ro_dom_sms_data';
$route['manage_ro_dom_sms_data']='upload_controller/manage_ro_dom_sms_data';
$route['manage_ro_dom_sms_data/:any']='upload_controller/manage_ro_dom_sms_data';

$route['upload_moid_daily_ro_data']='upload_controller/upload_moid_daily_ro_data';
$route['manage_moid_daily_ro_data']='upload_controller/manage_moid_daily_ro_data';
$route['manage_moid_daily_ro_data/:any']='upload_controller/manage_moid_daily_ro_data';

$route['upload_ro_daily_a2p_sms_data']='upload_controller/upload_ro_daily_a2p_sms_data';
$route['manage_ro_daily_a2p_sms_data']='upload_controller/manage_ro_daily_a2p_sms_data';
$route['manage_ro_daily_a2p_sms_data/:any']='upload_controller/manage_ro_daily_a2p_sms_data';

$route['upload_ro_daily_data']='upload_controller/upload_ro_daily_data';
$route['manage_ro_daily_data_local']='upload_controller/manage_ro_daily_data_local';
$route['manage_ro_daily_data_local/:any']='upload_controller/manage_ro_daily_data_local';
$route['manage_ro_daily_data_int']='upload_controller/manage_ro_daily_data_int';
$route['manage_ro_daily_data_int/:any']='upload_controller/manage_ro_daily_data_int';

$route['upload_ro_daily_ios_data']='upload_controller/upload_ro_daily_ios_data';
$route['manage_ro_daily_ios_data']='upload_controller/manage_ro_daily_ios_data';
$route['manage_ro_daily_ios_data/:any']='upload_controller/manage_ro_daily_ios_data';

$route['upload_ro_daily_video_data']='upload_controller/upload_ro_daily_video_data';
$route['manage_ro_daily_video_data']='upload_controller/manage_ro_daily_video_data';
$route['manage_ro_daily_video_data/:any']='upload_controller/manage_ro_daily_video_data';

$route['upload_ro_dom_icx_daily_data']='upload_controller/upload_ro_dom_icx_daily_data';
$route['manage_ro_dom_icx_daily_data']='upload_controller/manage_ro_dom_icx_daily_data';
$route['manage_ro_dom_icx_daily_data/:any']='upload_controller/manage_ro_dom_icx_daily_data';

$route['upload_ro_daily_ltfs_data']='upload_controller/upload_ro_daily_ltfs_data';
$route['manage_ro_daily_ltfs_data']='upload_controller/manage_ro_daily_ltfs_data';
$route['manage_ro_daily_ltfs_data/:any']='upload_controller/manage_ro_daily_ltfs_data';

$route['upload_ro_daily_itfs_data']='upload_controller/upload_ro_daily_itfs_data';
$route['manage_ro_daily_itfs_data']='upload_controller/manage_ro_daily_itfs_data';
$route['manage_ro_daily_itfs_data/:any']='upload_controller/manage_ro_daily_itfs_data';

$route['upload_no_cli']='upload_controller/upload_no_cli';
$route['manage_no_cli']='upload_controller/manage_no_cli';
$route['manage_no_cli/:any']='upload_controller/manage_no_cli';

#Reprot
$route['domestic_sms_jv']='report_controller/domestic_sms_jv';
$route['domestic_mms_jv']='report_controller/domestic_mms_jv';
$route['domestic_voice_jv']='report_controller/domestic_voice_jv';
$route['international_voice_in_jv']='report_controller/international_voice_in_jv';
$route['domestic_toll_free_jv']='report_controller/domestic_toll_free_jv';
$route['international_voice_out_jv']='report_controller/international_voice_out_jv';
$route['international_toll_free_jv']='report_controller/international_toll_free_jv';
#ISMS JOURNAL

$route['isms_summery_report']='report_controller/isms_summery_report';
$route['journal_sybase_mobile']='report_controller/journal_sybase_mobile';
#customer
$route['create_name_alternative'] = 'master_controller/create_name_alternative';
$route['manage_name_alternative'] = 'master_controller/manage_name_alternative';
$route['manage_name_alternative/:any'] = 'master_controller/manage_name_alternative';

#operator
$route['create_operator'] = 'master_controller/create_operator';
$route['manage_operator'] = 'master_controller/manage_operator';
$route['manage_operator/:any'] = 'master_controller/manage_operator';

#gl_mapping
$route['create_gl_mapping'] = 'master_controller/create_gl_mapping';
$route['manage_gl_mapping'] = 'master_controller/manage_gl_mapping';
$route['manage_gl_mapping/:any'] = 'master_controller/manage_gl_mapping';
#$route['test'] = 'master_controller/test';
/* End of file routes.php */

#full month uploader
$route['upload_full_month_itfs'] = 'upload_controller/upload_full_month_itfs';
$route['upload_full_month_ltfs'] = 'upload_controller/upload_full_month_ltfs';
$route['upload_full_month_moid'] = 'upload_controller/upload_full_month_moid';
$route['upload_full_month_mosms'] = 'upload_controller/upload_full_month_mosms';
$route['upload_full_month_mtsms'] = 'upload_controller/upload_full_month_mtsms';
$route['upload_full_month_momms'] = 'upload_controller/upload_full_month_momms';
$route['upload_full_month_mtmms'] = 'upload_controller/upload_full_month_mtmms';
$route['upload_full_month_videomoc'] = 'upload_controller/upload_full_month_videomoc';
$route['upload_full_month_videomtc'] = 'upload_controller/upload_full_month_videomtc';
$route['upload_full_month_videomoc'] = 'upload_controller/upload_full_month_videomoc';
$route['upload_full_month_videomtc'] = 'upload_controller/upload_full_month_videomtc';
$route['upload_full_month_iptsp'] = 'upload_controller/upload_full_month_iptsp';
$route['upload_full_month_iptsp'] = 'upload_controller/upload_full_month_iptsp';
$route['upload_full_month_mtid'] = 'upload_controller/upload_full_month_mtid';
$route['upload_icx_invoice_report'] = 'upload_controller/upload_icx_invoice_report';
$route['upload_ios_invoice_report'] = 'upload_controller/upload_ios_invoice_report';
$route['upload_icx_moc'] = 'upload_controller/upload_icx_moc';
$route['upload_icx_videomoc'] = 'upload_controller/upload_icx_videomoc';
$route['upload_icx_videomtc'] = 'upload_controller/upload_icx_videomtc';
$route['upload_a2p_sms_incomming'] = 'upload_controller/upload_a2p_sms_incomming';
$route['upload_op_moc'] = 'upload_controller/upload_op_moc';
$route['upload_op_mtc'] = 'upload_controller/upload_op_mtc';
$route['upload_operator_wise_mtc'] = 'upload_controller/upload_operator_wise_mtc';
$route['upload_operator_wise_moc'] = 'upload_controller/upload_operator_wise_moc';

#full month manage
$route['manage_full_month_itfs'] = 'upload_controller/manage_full_month_itfs';
$route['manage_full_month_itfs/:any'] = 'upload_controller/manage_full_month_itfs';
$route['manage_full_month_ltfs'] = 'upload_controller/manage_full_month_ltfs';
$route['manage_full_month_ltfs/:any'] = 'upload_controller/manage_full_month_ltfs';
$route['manage_full_month_moid'] = 'upload_controller/manage_full_month_moid';
$route['manage_full_month_moid/:any'] = 'upload_controller/manage_full_month_moid';
$route['manage_full_month_mosms'] = 'upload_controller/manage_full_month_mosms';
$route['manage_full_month_mosms/:any'] = 'upload_controller/manage_full_month_mosms';
$route['manage_full_month_mtsms'] = 'upload_controller/manage_full_month_mtsms';
$route['manage_full_month_mtsms/:any'] = 'upload_controller/manage_full_month_mtsms';
$route['manage_full_month_momms'] = 'upload_controller/manage_full_month_momms';
$route['manage_full_month_momms/:any'] = 'upload_controller/manage_full_month_momms';
$route['manage_full_month_mtmms'] = 'upload_controller/manage_full_month_mtmms';
$route['manage_full_month_mtmms/:any'] = 'upload_controller/manage_full_month_mtmms';
$route['manage_full_month_videomoc'] = 'upload_controller/manage_full_month_videomoc';
$route['manage_full_month_videomoc/:any'] = 'upload_controller/manage_full_month_videomoc';
$route['manage_full_month_videomtc'] = 'upload_controller/manage_full_month_videomtc';
$route['manage_full_month_videomtc/:any'] = 'upload_controller/manage_full_month_videomtc';
$route['manage_full_month_iptsp'] = 'upload_controller/manage_full_month_iptsp';
$route['manage_full_month_iptsp/:any'] = 'upload_controller/manage_full_month_iptsp';
$route['manage_full_month_mtid'] = 'upload_controller/manage_full_month_mtid';
$route['manage_full_month_mtid/:any'] = 'upload_controller/manage_full_month_mtid';
$route['manage_icx_invoice_report'] = 'upload_controller/manage_icx_invoice_report';
$route['manage_icx_invoice_report/:any'] = 'upload_controller/manage_icx_invoice_report';
$route['manage_ios_invoice_report'] = 'upload_controller/manage_ios_invoice_report';
$route['manage_ios_invoice_report/:any'] = 'upload_controller/manage_ios_invoice_report';
$route['manage_icx_moc'] = 'upload_controller/manage_icx_moc';
$route['manage_icx_moc/:any'] = 'upload_controller/manage_icx_moc';
$route['manage_icx_videomoc'] = 'upload_controller/manage_icx_videomoc';
$route['manage_icx_videomoc/:any'] = 'upload_controller/manage_icx_videomoc';
$route['manage_icx_videomtc'] = 'upload_controller/manage_icx_videomtc';
$route['manage_icx_videomtc/:any'] = 'upload_controller/manage_icx_videomtc';
$route['manage_a2p_sms_incomming'] = 'upload_controller/manage_a2p_sms_incomming';
$route['manage_a2p_sms_incomming/:any'] = 'upload_controller/manage_a2p_sms_incomming';
$route['manage_op_moc'] = 'upload_controller/manage_op_moc';
$route['manage_op_moc/:any'] = 'upload_controller/manage_op_moc';
$route['manage_op_mtc'] = 'upload_controller/manage_op_mtc';
$route['manage_op_mtc/:any'] = 'upload_controller/manage_op_mtc';
$route['manage_operator_wise_moc'] = 'upload_controller/manage_operator_wise_moc';
$route['manage_operator_wise_moc/:any'] = 'upload_controller/manage_operator_wise_moc';
$route['manage_operator_wise_mtc'] = 'upload_controller/manage_operator_wise_mtc';
$route['manage_operator_wise_mtc/:any'] = 'upload_controller/manage_operator_wise_mtc';

#
$route['actual_journal_for_momms'] = 'master_controller/actual_journal_for_momms';
$route['actual_journal_for_mosms'] = 'master_controller/actual_journal_for_mosms';
$route['actual_journal_for_moid'] = 'master_controller/actual_journal_for_moid';
$route['actual_journal_for_mtmms'] = 'master_controller/actual_journal_for_mtmms';
$route['actual_journal_for_mtsms'] = 'master_controller/actual_journal_for_mtsms';
$route['actual_journal_for_ltfs'] = 'master_controller/actual_journal_for_ltfs';
$route['actual_journal_for_itfs'] = 'master_controller/actual_journal_for_itfs';
$route['actual_journal_for_mtid'] = 'master_controller/actual_journal_for_mtid';
$route['actual_journal_for_operator_wise_mtc'] = 'master_controller/actual_journal_for_operator_wise_mtc';
$route['actual_journal_for_operator_wise_moc'] = 'master_controller/actual_journal_for_operator_wise_moc';


#gl mapping
$route['domestic_cost_gl_mapping'] = 'master_controller/domestic_cost_gl_mapping';
$route['manage_domestic_cost_gl_mapping'] = 'master_controller/manage_domestic_cost_gl_mapping';
$route['manage_domestic_cost_gl_mapping/:any'] = 'master_controller/manage_domestic_cost_gl_mapping';
$route['domestic_rev_gl_mapping'] = 'master_controller/domestic_rev_gl_mapping';
$route['manage_domestic_rev_gl_mapping'] = 'master_controller/manage_domestic_rev_gl_mapping';
$route['manage_domestic_rev_gl_mapping/:any'] = 'master_controller/manage_domestic_rev_gl_mapping';
$route['common_gl_mapping'] = 'master_controller/common_gl_mapping';
$route['manage_common_gl_mapping'] = 'master_controller/manage_common_gl_mapping';
$route['manage_common_gl_mapping/:any'] = 'master_controller/manage_common_gl_mapping';

#invoice
$route['invoice_for_mobile_pstn_iptsp'] = 'master_controller/invoice_for_mobile_pstn_iptsp';
$route['invoice_icx'] = 'collection_controller/invoice_icx'; 
$route['invoice_ios'] = 'master_controller/invoice_ios';
$route['collection_module'] = 'collection_controller/collection_module';
$route['get_receiveable'] = 'collection_controller/get_receiveable';
$route['create_collection'] = 'collection_controller/create_collection';
$route['create_collection/:any'] = 'collection_controller/create_collection';
$route['payable_invoice_icx'] = 'collection_controller/payable_invoice_icx';
$route['get_supplier_code'] = 'collection_controller/get_supplier_code';
$route['manage_payable_invoice_icx'] = 'collection_controller/manage_payable_invoice_icx';
$route['manage_payable_invoice_icx/:any'] = 'collection_controller/manage_payable_invoice_icx';

#Payment
$route['payable_invoice_icx_report'] = 'collection_controller/payable_invoice_icx_report';
$route['payable_invoic_mobile_pstn_iptsp_report'] = 'collection_controller/payable_invoic_mobile_pstn_iptsp_report';
$route['upload_ait_gl'] = 'upload_controller/upload_ait_gl';
$route['upload_vendor_liability'] = 'upload_controller/upload_vendor_liability';
$route['create_vendor_type'] = 'master_controller/create_vendor_type';
$route['manage_vendor_type'] = 'master_controller/manage_vendor_type';
$route['manage_vendor_type/:any'] = 'master_controller/manage_vendor_type';
$route['create_corporate_exchange_rate'] = 'master_controller/create_corporate_exchange_rate';
$route['manage_corporate_exchange_rate'] = 'master_controller/manage_corporate_exchange_rate';
$route['manage_corporate_exchange_rate/:any'] = 'master_controller/manage_corporate_exchange_rate';
$route['create_sonali_bank_rate'] = 'master_controller/create_sonali_bank_rate';
$route['manage_sonali_bank_rate'] = 'master_controller/manage_sonali_bank_rate';
$route['manage_sonali_bank_rate/:any'] = 'master_controller/manage_sonali_bank_rate';
$route['create_citi_bank_rate'] = 'master_controller/create_citi_bank_rate';
$route['manage_citi_bank_rate'] = 'master_controller/manage_citi_bank_rate';
$route['manage_citi_bank_rate/:any'] = 'master_controller/manage_citi_bank_rate';
$route['mt_rate'] = 'master_controller/mt_rate';
$route['manage_mt_rate'] = 'master_controller/manage_mt_rate';
$route['manage_mt_rate/:any'] = 'master_controller/manage_mt_rate';
$route['manage_trial_balance'] = 'upload_controller/manage_trial_balance';
$route['manage_trial_balance/:any'] = 'upload_controller/manage_trial_balance';
$route['manage_vendor_liability'] = 'upload_controller/manage_vendor_liability';
$route['manage_vendor_liability/:any'] = 'upload_controller/manage_vendor_liability';
/* trial balance*/
$route['subscriber_and_cost'] = 'btrc_controller/subscriber_and_cost';
$route['create_tb_gl'] = 'btrc_controller/create_tb_gl';
$route['manage_tb_gl'] = 'btrc_controller/manage_tb_gl';
$route['manage_tb_gl/:any'] = 'btrc_controller/manage_tb_gl';
$route['MIS_Rev_and_Y_Value'] = 'btrc_controller/MIS_Rev_and_Y_Value';
$route['manage_MIS_Rev_and_Y_Value'] = 'btrc_controller/manage_MIS_Rev_and_Y_Value';
$route['manage_MIS_Rev_and_Y_Value/:any'] = 'btrc_controller/manage_MIS_Rev_and_Y_Value';
$route['subscriber_and_iig_cost'] = 'btrc_controller/subscriber_and_iig_cost';
$route['manage_subscriber_and_iig_cost'] = 'btrc_controller/manage_subscriber_and_iig_cost';
$route['manage_subscriber_and_iig_cost/:any'] = 'btrc_controller/manage_subscriber_and_iig_cost';
$route['upload_igw_collection'] = 'btrc_controller/upload_igw_collection';
$route['upload_cnc_revenue'] = 'btrc_controller/upload_cnc_revenue';
$route['upload_postpaid_data'] = 'btrc_controller/upload_postpaid_data';
$route['manage_igw_collection'] = 'btrc_controller/manage_igw_collection';
$route['manage_cnc_revenue'] = 'btrc_controller/manage_cnc_revenue';
$route['manage_cnc_revenue/:any'] = 'btrc_controller/manage_cnc_revenue';
$route['create_cnc_revenue'] = 'btrc_controller/create_cnc_revenue';
$route['manage_igw_collection'] = 'btrc_controller/manage_igw_collection';
$route['manage_igw_collection/:any'] = 'btrc_controller/manage_igw_collection';
$route['create_igw_collection'] = 'btrc_controller/create_igw_collection';
$route['manage_postpaid_data'] = 'btrc_controller/manage_postpaid_data';
$route['manage_postpaid_data/:any'] = 'btrc_controller/manage_postpaid_data';
$route['create_postpaid_data'] = 'btrc_controller/create_postpaid_data';
$route['manage_postpaid_data'] = 'btrc_controller/manage_postpaid_data';
$route['upload_trial_balance'] = 'btrc_controller/upload_trial_balance';
$route['manage_trial_balance'] = 'btrc_controller/manage_trial_balance';
$route['manage_trial_balance/:any'] = 'btrc_controller/manage_trial_balance';
$route['oracle_collection'] = 'btrc_controller/oracle_collection';
$route['btrc_revenue_sharing'] = 'btrc_controller/btrc_revenue_sharing';
$route['summary_data'] = 'btrc_controller/summary_data';
$route['btrc_revenue'] = 'btrc_controller/btrc_revenue';
$route['manage_ait_gl'] = 'upload_controller/manage_ait_gl';
$route['manage_ait_gl/:any'] = 'upload_controller/manage_ait_gl';
$route['ait_gl'] = 'report_controller/ait_gl';
#forwarding
$route['international_invoice_forwarding'] = 'master_controller/international_invoice_forwarding';
$route['domestic_invoice_forwarding'] = 'master_controller/domestic_invoice_forwarding';
/* Location: ./application/config/routes.php */
#icx data
$route['upload_domestic_icx_data'] = 'upload_controller/upload_domestic_icx_data';
$route['upload_igw_data'] = 'upload_controller/upload_igw_data';
$route['upload_icx_data'] = 'upload_controller/upload_icx_data';
$route['igw_summery_data'] = 'upload_controller/igw_summery_data';
$route['igw_report'] = 'upload_controller/igw_report';
$route['icx_report'] = 'upload_controller/icx_report';
$route['igw_payment_report'] = 'upload_controller/igw_payment_report';
$route['icx_payment_report'] = 'upload_controller/icx_payment_report';
$route['short_summery'] = 'upload_controller/short_summery';
$route['bl_vs_ios_reconciliation'] = 'upload_controller/bl_vs_ios_reconciliation';
$route['btcl_data'] = 'upload_controller/btcl_data';
$route['ios_reconciliation_report'] = 'upload_controller/ios_reconciliation_report';
$route['payable_invoice_mobile'] = 'collection_controller/payable_invoice_mobile';
$route['manage_payable_invoice_mobile'] = 'collection_controller/manage_payable_invoice_mobile';
$route['manage_payable_invoice_mobile/:any'] = 'collection_controller/manage_payable_invoice_mobile';
$route['payable_invoice_mobile_report'] = 'collection_controller/payable_invoice_mobile_report';
$route['get_bl_amount'] = 'collection_controller/get_bl_amount';
$route['get_short_name'] = 'collection_controller/get_short_name';
$route['get_bl_amount_for_icx'] = 'collection_controller/get_bl_amount_for_icx';
$route['get_bl_amount_for_igw'] = 'collection_controller/get_bl_amount_for_igw';
$route['a2p_configeration'] = 'master_controller/a2p_configeration';
$route['manage_a2p_configeration'] = 'master_controller/manage_a2p_configeration';
$route['manage_a2p_configeration/:any'] = 'master_controller/manage_a2p_configeration';
$route['a2p_fixed_monthly_journal'] = 'master_controller/a2p_fixed_monthly_journal';
$route['a2p_additional_provision_journal'] = 'master_controller/a2p_additional_provision_journal';
$route['a2p_full_month_journal'] = 'master_controller/a2p_full_month_journal';
$route['a2p_provision_report'] = 'master_controller/a2p_provision_report';
$route['a2p_actual_report'] = 'master_controller/a2p_actual_report';
$route['a2p_invoice'] = 'master_controller/a2p_invoice';
$route['payable_invoice_igw'] = 'collection_controller/payable_invoice_igw';
$route['manage_payable_invoice_igw'] = 'collection_controller/manage_payable_invoice_igw';
$route['manage_payable_invoice_igw/:any'] = 'collection_controller/manage_payable_invoice_igw';
$route['payable_invoice_igw_report'] = 'collection_controller/payable_invoice_igw_report';
$route['payable_invoice_isms'] = 'collection_controller/payable_invoice_isms';
$route['manage_payable_invoice_isms'] = 'collection_controller/manage_payable_invoice_isms';
$route['manage_payable_invoice_isms/:any'] = 'collection_controller/manage_payable_invoice_isms';
$route['payable_invoice_isms_report'] = 'collection_controller/payable_invoice_isms_report';
$route['data_uploader_for_isms_journal'] = 'collection_controller/data_uploader_for_isms_journal';
$route['manage_data_for_isms_journal'] = 'collection_controller/manage_data_for_isms_journal';
$route['isms_journal'] = 'collection_controller/isms_journal';
//$route['generate_ageing'] = 'master_controller/generate_ageing_';
$route['dispute_management'] = 'dispute_controller/dispute_management';
$route['trade_debitors_report'] = 'ageing_controller/trade_debitors_report';
$route['ic_invoice_vs_full_month_recon_domestic'] = 'report_controller/ic_invoice_vs_full_month_recon_domestic';
$route['report_full_month_momms'] = 'upload_controller/report_full_month_momms';
$route['report_full_month_mosms'] = 'upload_controller/report_full_month_mosms';
$route['report_full_month_moid'] = 'upload_controller/report_full_month_moid';
$route['report_full_month_itfs'] = 'upload_controller/report_full_month_itfs';
$route['report_full_month_mtid'] = 'upload_controller/report_full_month_mtid';
$route['report_full_month_ltfs'] = 'upload_controller/report_full_month_ltfs';
$route['report_full_month_mtsms'] = 'upload_controller/report_full_month_mtsms';
$route['report_full_month_operator_wise_moc'] = 'upload_controller/report_full_month_operator_wise_moc';
$route['report_full_month_icx_moc'] = 'upload_controller/report_full_month_icx_moc';
$route['report_full_month_moc'] = 'upload_controller/report_full_month_moc';
$route['report_full_month_operator_wise_mtc'] = 'upload_controller/report_full_month_operator_wise_mtc';
$route['report_full_month_mtmms'] = 'upload_controller/report_full_month_mtmms';
$route['provision_report_for_itfs'] = 'upload_controller/provision_report_for_itfs';
$route['provision_report_for_ltfs'] = 'upload_controller/provision_report_for_ltfs';
$route['provision_report_for_ios'] = 'upload_controller/provision_report_for_ios';
$route['provision_report_for_mtmms'] = 'upload_controller/provision_report_for_mtmms';
$route['provision_report_for_mtsms'] = 'upload_controller/provision_report_for_mtsms';
$route['provision_report_for_moid'] = 'upload_controller/provision_report_for_moid';
$route['upload_isms_data'] = 'collection_controller/upload_isms_data';
$route['report_full_month_mtmms'] = 'upload_controller/report_full_month_mtmms';
$route['collection_with_dispute'] = 'collection_controller/collection_with_dispute';
$route['tax_configuration'] = 'master_controller/tax_configuration';
$route['manage_tax_configuration'] = 'master_controller/manage_tax_configuration';
$route['manage_tax_configuration/:any'] = 'master_controller/manage_tax_configuration';
$route['provision_report_for_moc'] = 'upload_controller/provision_report_for_moc';
$route['manage_data_for_isms_journal'] = 'master_controller/manage_data_for_isms_journal';
$route['manage_data_for_isms_journal/:any'] = 'master_controller/manage_data_for_isms_journal';
$route['collection_without_dispute'] = 'collection_controller/collection_without_dispute';
$route['get_invoice_amount_for_collection_with_dispute'] = 'collection_controller/get_invoice_amount_for_collection_with_dispute';
$route['generate_payable_ageing'] = 'ageing_controller/generate_payable_ageing';
$route['generate_payable_ageing/:any'] = 'ageing_controller/generate_payable_ageing';
$route['generate_recevable_ageing'] = 'ageing_controller/generate_recevable_ageing';
$route['generate_recevable_ageing/:any'] = 'ageing_controller/generate_recevable_ageing';
$route['generate_new_payable_ageing'] = 'ageing_controller/generate_new_payable_ageing';
$route['new_receiveable_ageing'] = 'ageing_controller/new_receiveable_ageing';
$route['new_receiveable_ageing/:any'] = 'ageing_controller/new_receiveable_ageing';
$route['ait_report'] = 'collection_controller/ait_report';
//ss
$route['provision_report_for_mtc'] = 'upload_controller/provision_report_for_mtc';
$route['provision_report_for_mosms'] = 'upload_controller/provision_report_for_mosms';
$route['provision_report_for_momms'] = 'upload_controller/provision_report_for_momms';
$route['get_ic_data'] = 'parent_controller/data_sharing';

$route['payment_summery_report'] = 'ageing_controller/payment_summery_report';
$route['payment_summery_report/:any'] = 'ageing_controller/payment_summery_report';
$route['upload_register'] = 'upload_controller/upload_register';

$route['net_ageing'] = 'ageing_controller/net_ageing';
$route['ranks_pstn_vat_rate'] = 'ageing_controller/ranks_pstn_vat_rate';
$route['manage_ranks_pstn_vat_rate'] = 'ageing_controller/manage_ranks_pstn_vat_rate';
$route['manage_ranks_pstn_vat_rate/:any'] = 'ageing_controller/manage_ranks_pstn_vat_rate';
$route['ranks_pstn_accrued_data'] = 'ageing_controller/ranks_pstn_accrued_data';
$route['manage_ranks_pstn_accrued_data'] = 'ageing_controller/manage_ranks_pstn_accrued_data';
$route['manage_ranks_pstn_accrued_data/:any'] = 'ageing_controller/manage_ranks_pstn_accrued_data';
$route['ranks_ageing'] = 'ageing_controller/ranks_ageing';





