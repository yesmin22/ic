<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-09-14 07:16:21 --> Config Class Initialized
DEBUG - 2014-09-14 07:16:21 --> Hooks Class Initialized
DEBUG - 2014-09-14 07:16:21 --> Utf8 Class Initialized
DEBUG - 2014-09-14 07:16:21 --> UTF-8 Support Enabled
DEBUG - 2014-09-14 07:16:21 --> URI Class Initialized
DEBUG - 2014-09-14 07:16:21 --> Router Class Initialized
DEBUG - 2014-09-14 07:16:21 --> No URI present. Default controller set.
DEBUG - 2014-09-14 07:16:21 --> Output Class Initialized
DEBUG - 2014-09-14 07:16:21 --> Security Class Initialized
DEBUG - 2014-09-14 07:16:21 --> Input Class Initialized
DEBUG - 2014-09-14 07:16:21 --> CRSF cookie Set
DEBUG - 2014-09-14 07:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-14 07:16:21 --> Language Class Initialized
DEBUG - 2014-09-14 07:16:21 --> Loader Class Initialized
DEBUG - 2014-09-14 07:16:21 --> Database Driver Class Initialized
DEBUG - 2014-09-14 11:16:21 --> Session Class Initialized
DEBUG - 2014-09-14 11:16:21 --> Helper loaded: string_helper
DEBUG - 2014-09-14 11:16:21 --> A session cookie was not found.
DEBUG - 2014-09-14 11:16:21 --> Session routines successfully run
DEBUG - 2014-09-14 11:16:21 --> Controller Class Initialized
DEBUG - 2014-09-14 11:16:21 --> DB Transaction Failure
ERROR - 2014-09-14 11:16:21 --> Query error: Unknown column 'product.product_start_date' in 'where clause'
DEBUG - 2014-09-14 11:16:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-09-14 07:16:27 --> Config Class Initialized
DEBUG - 2014-09-14 07:16:27 --> Hooks Class Initialized
DEBUG - 2014-09-14 07:16:27 --> Utf8 Class Initialized
DEBUG - 2014-09-14 07:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-09-14 07:16:27 --> URI Class Initialized
DEBUG - 2014-09-14 07:16:27 --> Router Class Initialized
DEBUG - 2014-09-14 07:16:27 --> No URI present. Default controller set.
DEBUG - 2014-09-14 07:16:27 --> Output Class Initialized
DEBUG - 2014-09-14 07:16:27 --> Security Class Initialized
DEBUG - 2014-09-14 07:16:27 --> Input Class Initialized
DEBUG - 2014-09-14 07:16:27 --> XSS Filtering completed
DEBUG - 2014-09-14 07:16:27 --> XSS Filtering completed
DEBUG - 2014-09-14 07:16:27 --> XSS Filtering completed
DEBUG - 2014-09-14 07:16:27 --> CRSF cookie Set
DEBUG - 2014-09-14 07:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-14 07:16:27 --> Language Class Initialized
DEBUG - 2014-09-14 07:16:27 --> Loader Class Initialized
DEBUG - 2014-09-14 07:16:27 --> Database Driver Class Initialized
DEBUG - 2014-09-14 11:16:27 --> Session Class Initialized
DEBUG - 2014-09-14 11:16:27 --> Helper loaded: string_helper
DEBUG - 2014-09-14 11:16:27 --> Session routines successfully run
DEBUG - 2014-09-14 11:16:27 --> Controller Class Initialized
DEBUG - 2014-09-14 11:16:27 --> DB Transaction Failure
ERROR - 2014-09-14 11:16:27 --> Query error: Unknown column 'product.product_start_date' in 'where clause'
DEBUG - 2014-09-14 11:16:27 --> Language file loaded: language/english/db_lang.php
