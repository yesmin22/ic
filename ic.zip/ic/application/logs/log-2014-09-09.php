<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-09-09 12:06:23 --> Config Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Hooks Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Utf8 Class Initialized
DEBUG - 2014-09-09 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2014-09-09 12:06:23 --> URI Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Router Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Output Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Security Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Input Class Initialized
DEBUG - 2014-09-09 12:06:23 --> XSS Filtering completed
DEBUG - 2014-09-09 12:06:23 --> CRSF cookie Set
DEBUG - 2014-09-09 12:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-09 12:06:23 --> Language Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Loader Class Initialized
DEBUG - 2014-09-09 12:06:23 --> Database Driver Class Initialized
DEBUG - 2014-09-09 16:06:23 --> Session Class Initialized
DEBUG - 2014-09-09 16:06:23 --> Helper loaded: string_helper
DEBUG - 2014-09-09 16:06:23 --> A session cookie was not found.
DEBUG - 2014-09-09 16:06:24 --> Session routines successfully run
DEBUG - 2014-09-09 16:06:24 --> Controller Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Config Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Hooks Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Utf8 Class Initialized
DEBUG - 2014-09-09 12:08:57 --> UTF-8 Support Enabled
DEBUG - 2014-09-09 12:08:57 --> URI Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Router Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Output Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Security Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Input Class Initialized
DEBUG - 2014-09-09 12:08:57 --> XSS Filtering completed
DEBUG - 2014-09-09 12:08:57 --> XSS Filtering completed
DEBUG - 2014-09-09 12:08:57 --> XSS Filtering completed
DEBUG - 2014-09-09 12:08:57 --> XSS Filtering completed
DEBUG - 2014-09-09 12:08:57 --> CRSF cookie Set
DEBUG - 2014-09-09 12:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-09 12:08:57 --> Language Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Loader Class Initialized
DEBUG - 2014-09-09 12:08:57 --> Database Driver Class Initialized
DEBUG - 2014-09-09 16:08:57 --> Session Class Initialized
DEBUG - 2014-09-09 16:08:57 --> Helper loaded: string_helper
DEBUG - 2014-09-09 16:08:57 --> Session routines successfully run
DEBUG - 2014-09-09 16:08:57 --> Controller Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Config Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Hooks Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Utf8 Class Initialized
DEBUG - 2014-09-09 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-09 12:11:24 --> URI Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Router Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Output Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Security Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Input Class Initialized
DEBUG - 2014-09-09 12:11:24 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:24 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:24 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:24 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:24 --> CRSF cookie Set
DEBUG - 2014-09-09 12:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-09 12:11:24 --> Language Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Loader Class Initialized
DEBUG - 2014-09-09 12:11:24 --> Database Driver Class Initialized
DEBUG - 2014-09-09 16:11:24 --> Session Class Initialized
DEBUG - 2014-09-09 16:11:24 --> Helper loaded: string_helper
DEBUG - 2014-09-09 16:11:24 --> Session routines successfully run
DEBUG - 2014-09-09 16:11:24 --> Controller Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Config Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Hooks Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Utf8 Class Initialized
DEBUG - 2014-09-09 12:11:32 --> UTF-8 Support Enabled
DEBUG - 2014-09-09 12:11:32 --> URI Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Router Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Output Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Security Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Input Class Initialized
DEBUG - 2014-09-09 12:11:32 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:32 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:32 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:32 --> XSS Filtering completed
DEBUG - 2014-09-09 12:11:32 --> CRSF cookie Set
DEBUG - 2014-09-09 12:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-09 12:11:32 --> Language Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Loader Class Initialized
DEBUG - 2014-09-09 12:11:32 --> Database Driver Class Initialized
DEBUG - 2014-09-09 16:11:32 --> Session Class Initialized
DEBUG - 2014-09-09 16:11:32 --> Helper loaded: string_helper
DEBUG - 2014-09-09 16:11:32 --> Session routines successfully run
DEBUG - 2014-09-09 16:11:32 --> Controller Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Config Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Hooks Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Utf8 Class Initialized
DEBUG - 2014-09-09 12:18:14 --> UTF-8 Support Enabled
DEBUG - 2014-09-09 12:18:14 --> URI Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Router Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Output Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Security Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Input Class Initialized
DEBUG - 2014-09-09 12:18:14 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:14 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:14 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:14 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:14 --> CRSF cookie Set
DEBUG - 2014-09-09 12:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-09 12:18:14 --> Language Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Loader Class Initialized
DEBUG - 2014-09-09 12:18:14 --> Database Driver Class Initialized
DEBUG - 2014-09-09 16:18:14 --> Session Class Initialized
DEBUG - 2014-09-09 16:18:14 --> Helper loaded: string_helper
DEBUG - 2014-09-09 16:18:14 --> Session routines successfully run
DEBUG - 2014-09-09 16:18:14 --> Controller Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Config Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Hooks Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Utf8 Class Initialized
DEBUG - 2014-09-09 12:18:51 --> UTF-8 Support Enabled
DEBUG - 2014-09-09 12:18:51 --> URI Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Router Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Output Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Security Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Input Class Initialized
DEBUG - 2014-09-09 12:18:51 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:51 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:51 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:51 --> XSS Filtering completed
DEBUG - 2014-09-09 12:18:51 --> CRSF cookie Set
DEBUG - 2014-09-09 12:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-09 12:18:51 --> Language Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Loader Class Initialized
DEBUG - 2014-09-09 12:18:51 --> Database Driver Class Initialized
DEBUG - 2014-09-09 16:18:51 --> Session Class Initialized
DEBUG - 2014-09-09 16:18:51 --> Helper loaded: string_helper
DEBUG - 2014-09-09 16:18:51 --> Session routines successfully run
DEBUG - 2014-09-09 16:18:51 --> Controller Class Initialized
