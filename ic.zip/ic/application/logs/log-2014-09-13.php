<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-09-13 07:50:59 --> Config Class Initialized
DEBUG - 2014-09-13 07:50:59 --> Hooks Class Initialized
DEBUG - 2014-09-13 07:50:59 --> Utf8 Class Initialized
DEBUG - 2014-09-13 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 07:50:59 --> URI Class Initialized
DEBUG - 2014-09-13 07:50:59 --> Router Class Initialized
DEBUG - 2014-09-13 07:50:59 --> No URI present. Default controller set.
DEBUG - 2014-09-13 07:50:59 --> Output Class Initialized
DEBUG - 2014-09-13 07:50:59 --> Security Class Initialized
DEBUG - 2014-09-13 07:50:59 --> Input Class Initialized
DEBUG - 2014-09-13 07:50:59 --> CRSF cookie Set
DEBUG - 2014-09-13 07:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 07:50:59 --> Language Class Initialized
DEBUG - 2014-09-13 07:50:59 --> Loader Class Initialized
DEBUG - 2014-09-13 07:50:59 --> Database Driver Class Initialized
DEBUG - 2014-09-13 11:51:00 --> Session Class Initialized
DEBUG - 2014-09-13 11:51:00 --> Helper loaded: string_helper
DEBUG - 2014-09-13 11:51:00 --> A session cookie was not found.
DEBUG - 2014-09-13 11:51:00 --> Session routines successfully run
DEBUG - 2014-09-13 11:51:00 --> Controller Class Initialized
DEBUG - 2014-09-13 11:51:00 --> File loaded: application/views/index.php
DEBUG - 2014-09-13 11:51:00 --> Final output sent to browser
DEBUG - 2014-09-13 11:51:00 --> Total execution time: 1.3824
DEBUG - 2014-09-13 07:51:01 --> Config Class Initialized
DEBUG - 2014-09-13 07:51:01 --> Hooks Class Initialized
DEBUG - 2014-09-13 07:51:01 --> Utf8 Class Initialized
DEBUG - 2014-09-13 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 07:51:01 --> URI Class Initialized
DEBUG - 2014-09-13 07:51:01 --> Router Class Initialized
ERROR - 2014-09-13 07:51:01 --> 404 Page Not Found --> global
DEBUG - 2014-09-13 07:51:01 --> Config Class Initialized
DEBUG - 2014-09-13 07:51:01 --> Hooks Class Initialized
DEBUG - 2014-09-13 07:51:01 --> Utf8 Class Initialized
DEBUG - 2014-09-13 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 07:51:01 --> URI Class Initialized
DEBUG - 2014-09-13 07:51:01 --> Router Class Initialized
ERROR - 2014-09-13 07:51:01 --> 404 Page Not Found --> global
DEBUG - 2014-09-13 07:51:03 --> Config Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Hooks Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Utf8 Class Initialized
DEBUG - 2014-09-13 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 07:51:03 --> URI Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Router Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Output Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Security Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Input Class Initialized
DEBUG - 2014-09-13 07:51:03 --> XSS Filtering completed
DEBUG - 2014-09-13 07:51:03 --> XSS Filtering completed
DEBUG - 2014-09-13 07:51:03 --> XSS Filtering completed
DEBUG - 2014-09-13 07:51:03 --> CRSF cookie Set
DEBUG - 2014-09-13 07:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 07:51:03 --> Language Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Loader Class Initialized
DEBUG - 2014-09-13 07:51:03 --> Database Driver Class Initialized
DEBUG - 2014-09-13 11:51:03 --> Session Class Initialized
DEBUG - 2014-09-13 11:51:03 --> Helper loaded: string_helper
DEBUG - 2014-09-13 11:51:03 --> Session routines successfully run
DEBUG - 2014-09-13 11:51:03 --> Controller Class Initialized
DEBUG - 2014-09-13 11:51:03 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 11:51:03 --> Final output sent to browser
DEBUG - 2014-09-13 11:51:03 --> Total execution time: 0.5014
DEBUG - 2014-09-13 12:12:46 --> Config Class Initialized
DEBUG - 2014-09-13 12:12:46 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:12:46 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:12:46 --> URI Class Initialized
DEBUG - 2014-09-13 12:12:46 --> Router Class Initialized
DEBUG - 2014-09-13 12:12:47 --> No URI present. Default controller set.
DEBUG - 2014-09-13 12:12:47 --> Output Class Initialized
DEBUG - 2014-09-13 12:12:47 --> Security Class Initialized
DEBUG - 2014-09-13 12:12:47 --> Input Class Initialized
DEBUG - 2014-09-13 12:12:47 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:47 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:47 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:47 --> CRSF cookie Set
DEBUG - 2014-09-13 12:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:12:47 --> Language Class Initialized
DEBUG - 2014-09-13 12:12:47 --> Loader Class Initialized
DEBUG - 2014-09-13 12:12:47 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:12:47 --> Session Class Initialized
DEBUG - 2014-09-13 16:12:47 --> Helper loaded: string_helper
ERROR - 2014-09-13 16:12:47 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2014-09-13 16:12:47 --> Session routines successfully run
DEBUG - 2014-09-13 16:12:47 --> Controller Class Initialized
DEBUG - 2014-09-13 16:12:48 --> File loaded: application/views/index.php
DEBUG - 2014-09-13 16:12:48 --> Final output sent to browser
DEBUG - 2014-09-13 16:12:48 --> Total execution time: 1.7605
DEBUG - 2014-09-13 12:12:50 --> Config Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:12:50 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:12:50 --> URI Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Router Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Output Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Security Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Input Class Initialized
DEBUG - 2014-09-13 12:12:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:50 --> CRSF cookie Set
DEBUG - 2014-09-13 12:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:12:50 --> Language Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Loader Class Initialized
DEBUG - 2014-09-13 12:12:50 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:12:50 --> Session Class Initialized
DEBUG - 2014-09-13 16:12:50 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:12:50 --> Session routines successfully run
DEBUG - 2014-09-13 16:12:50 --> Controller Class Initialized
DEBUG - 2014-09-13 16:12:51 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:12:51 --> Final output sent to browser
DEBUG - 2014-09-13 16:12:51 --> Total execution time: 0.2723
DEBUG - 2014-09-13 12:12:53 --> Config Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:12:53 --> URI Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Router Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Output Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Security Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Input Class Initialized
DEBUG - 2014-09-13 12:12:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:12:53 --> CRSF cookie Set
DEBUG - 2014-09-13 12:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:12:53 --> Language Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Loader Class Initialized
DEBUG - 2014-09-13 12:12:53 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:12:53 --> Session Class Initialized
DEBUG - 2014-09-13 16:12:53 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:12:53 --> Session routines successfully run
DEBUG - 2014-09-13 16:12:53 --> Controller Class Initialized
DEBUG - 2014-09-13 16:12:53 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:12:53 --> Final output sent to browser
DEBUG - 2014-09-13 16:12:53 --> Total execution time: 0.1105
DEBUG - 2014-09-13 12:13:34 --> Config Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:13:34 --> URI Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Router Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Output Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Security Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Input Class Initialized
DEBUG - 2014-09-13 12:13:34 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:34 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:34 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:34 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:34 --> CRSF cookie Set
DEBUG - 2014-09-13 12:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:13:34 --> Language Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Loader Class Initialized
DEBUG - 2014-09-13 12:13:34 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:13:34 --> Session Class Initialized
DEBUG - 2014-09-13 16:13:34 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:13:34 --> Session routines successfully run
DEBUG - 2014-09-13 16:13:34 --> Controller Class Initialized
DEBUG - 2014-09-13 16:13:34 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:13:34 --> Final output sent to browser
DEBUG - 2014-09-13 16:13:34 --> Total execution time: 0.4246
DEBUG - 2014-09-13 12:13:43 --> Config Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:13:43 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:13:43 --> URI Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Router Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Output Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Security Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Input Class Initialized
DEBUG - 2014-09-13 12:13:43 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:43 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:43 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:43 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:43 --> CRSF cookie Set
DEBUG - 2014-09-13 12:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:13:43 --> Language Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Loader Class Initialized
DEBUG - 2014-09-13 12:13:43 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:13:43 --> Session Class Initialized
DEBUG - 2014-09-13 16:13:43 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:13:43 --> Session routines successfully run
DEBUG - 2014-09-13 16:13:43 --> Controller Class Initialized
DEBUG - 2014-09-13 16:13:43 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:13:43 --> Final output sent to browser
DEBUG - 2014-09-13 16:13:43 --> Total execution time: 0.4620
DEBUG - 2014-09-13 12:13:49 --> Config Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:13:49 --> URI Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Router Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Output Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Security Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Input Class Initialized
DEBUG - 2014-09-13 12:13:49 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:49 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:49 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:49 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:49 --> CRSF cookie Set
DEBUG - 2014-09-13 12:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:13:49 --> Language Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Loader Class Initialized
DEBUG - 2014-09-13 12:13:49 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:13:49 --> Session Class Initialized
DEBUG - 2014-09-13 16:13:49 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:13:49 --> Session routines successfully run
DEBUG - 2014-09-13 16:13:49 --> Controller Class Initialized
DEBUG - 2014-09-13 16:13:49 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:13:49 --> Final output sent to browser
DEBUG - 2014-09-13 16:13:49 --> Total execution time: 0.1136
DEBUG - 2014-09-13 12:13:50 --> Config Class Initialized
DEBUG - 2014-09-13 12:13:50 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:13:50 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:13:50 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:13:50 --> URI Class Initialized
DEBUG - 2014-09-13 12:13:50 --> Router Class Initialized
DEBUG - 2014-09-13 12:13:50 --> No URI present. Default controller set.
DEBUG - 2014-09-13 12:13:50 --> Output Class Initialized
DEBUG - 2014-09-13 12:13:50 --> Security Class Initialized
DEBUG - 2014-09-13 12:13:50 --> Input Class Initialized
DEBUG - 2014-09-13 12:13:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:50 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:50 --> CRSF cookie Set
DEBUG - 2014-09-13 12:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:13:50 --> Language Class Initialized
DEBUG - 2014-09-13 12:13:50 --> Loader Class Initialized
DEBUG - 2014-09-13 12:13:50 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:13:50 --> Session Class Initialized
DEBUG - 2014-09-13 16:13:50 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:13:50 --> Session routines successfully run
DEBUG - 2014-09-13 16:13:50 --> Controller Class Initialized
DEBUG - 2014-09-13 16:13:50 --> File loaded: application/views/index.php
DEBUG - 2014-09-13 16:13:50 --> Final output sent to browser
DEBUG - 2014-09-13 16:13:50 --> Total execution time: 0.1228
DEBUG - 2014-09-13 12:13:51 --> Config Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:13:51 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:13:51 --> URI Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Router Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Output Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Security Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Input Class Initialized
DEBUG - 2014-09-13 12:13:51 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:51 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:51 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:51 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:51 --> CRSF cookie Set
DEBUG - 2014-09-13 12:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:13:51 --> Language Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Loader Class Initialized
DEBUG - 2014-09-13 12:13:51 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:13:51 --> Session Class Initialized
DEBUG - 2014-09-13 16:13:51 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:13:51 --> Session routines successfully run
DEBUG - 2014-09-13 16:13:51 --> Controller Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Config Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:13:53 --> URI Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Router Class Initialized
DEBUG - 2014-09-13 12:13:53 --> No URI present. Default controller set.
DEBUG - 2014-09-13 12:13:53 --> Output Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Security Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Input Class Initialized
DEBUG - 2014-09-13 12:13:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:53 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:53 --> CRSF cookie Set
DEBUG - 2014-09-13 12:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:13:53 --> Language Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Loader Class Initialized
DEBUG - 2014-09-13 12:13:53 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:13:54 --> Session Class Initialized
DEBUG - 2014-09-13 16:13:54 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:13:54 --> Session routines successfully run
DEBUG - 2014-09-13 16:13:54 --> Controller Class Initialized
DEBUG - 2014-09-13 16:13:54 --> File loaded: application/views/index.php
DEBUG - 2014-09-13 16:13:54 --> Final output sent to browser
DEBUG - 2014-09-13 16:13:54 --> Total execution time: 0.4647
DEBUG - 2014-09-13 12:13:55 --> Config Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:13:55 --> URI Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Router Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Output Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Security Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Input Class Initialized
DEBUG - 2014-09-13 12:13:55 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:55 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:55 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:55 --> XSS Filtering completed
DEBUG - 2014-09-13 12:13:55 --> CRSF cookie Set
DEBUG - 2014-09-13 12:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:13:55 --> Language Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Loader Class Initialized
DEBUG - 2014-09-13 12:13:55 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:13:55 --> Session Class Initialized
DEBUG - 2014-09-13 16:13:55 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:13:55 --> Session routines successfully run
DEBUG - 2014-09-13 16:13:55 --> Controller Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:06 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:06 --> No URI present. Default controller set.
DEBUG - 2014-09-13 12:14:06 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:06 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:06 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:06 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:06 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:06 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:06 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:06 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:06 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:06 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:06 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:06 --> Controller Class Initialized
DEBUG - 2014-09-13 16:14:06 --> File loaded: application/views/index.php
DEBUG - 2014-09-13 16:14:06 --> Final output sent to browser
DEBUG - 2014-09-13 16:14:06 --> Total execution time: 0.1264
DEBUG - 2014-09-13 12:14:10 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:10 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:10 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:10 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:10 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:10 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:10 --> No URI present. Default controller set.
DEBUG - 2014-09-13 12:14:10 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:10 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:10 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:10 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:10 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:10 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:10 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:10 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:10 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:10 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:10 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:10 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:10 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:10 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:10 --> Controller Class Initialized
DEBUG - 2014-09-13 16:14:10 --> File loaded: application/views/index.php
DEBUG - 2014-09-13 16:14:10 --> Final output sent to browser
DEBUG - 2014-09-13 16:14:10 --> Total execution time: 0.1099
DEBUG - 2014-09-13 12:14:11 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:11 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:11 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:11 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:11 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:11 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:11 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:11 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:11 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:11 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:11 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:11 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:11 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:11 --> Controller Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:13 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:13 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:13 --> No URI present. Default controller set.
DEBUG - 2014-09-13 12:14:13 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:13 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:13 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:13 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:13 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:13 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:13 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:13 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:13 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:13 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:13 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:13 --> Controller Class Initialized
DEBUG - 2014-09-13 16:14:13 --> File loaded: application/views/index.php
DEBUG - 2014-09-13 16:14:13 --> Final output sent to browser
DEBUG - 2014-09-13 16:14:13 --> Total execution time: 0.1089
DEBUG - 2014-09-13 12:14:14 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:14 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:14 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:14 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:14 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:14 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:14 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:14 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:14 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:14 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:14 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:14 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:14 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:14 --> Controller Class Initialized
DEBUG - 2014-09-13 16:14:14 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:14:14 --> Final output sent to browser
DEBUG - 2014-09-13 16:14:14 --> Total execution time: 0.1250
DEBUG - 2014-09-13 12:14:15 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:15 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:15 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:15 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:15 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:15 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:15 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:15 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:15 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:15 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:15 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:15 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:15 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:15 --> Controller Class Initialized
DEBUG - 2014-09-13 16:14:15 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:14:15 --> Final output sent to browser
DEBUG - 2014-09-13 16:14:15 --> Total execution time: 0.1246
DEBUG - 2014-09-13 12:14:18 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:18 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:18 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:18 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:18 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:18 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:18 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:18 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:18 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:18 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:18 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:18 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:18 --> Controller Class Initialized
DEBUG - 2014-09-13 16:14:18 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:14:18 --> Final output sent to browser
DEBUG - 2014-09-13 16:14:18 --> Total execution time: 0.1905
DEBUG - 2014-09-13 12:14:21 --> Config Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Hooks Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Utf8 Class Initialized
DEBUG - 2014-09-13 12:14:21 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 12:14:21 --> URI Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Router Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Output Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Security Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Input Class Initialized
DEBUG - 2014-09-13 12:14:21 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:21 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:21 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:21 --> XSS Filtering completed
DEBUG - 2014-09-13 12:14:21 --> CRSF cookie Set
DEBUG - 2014-09-13 12:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 12:14:21 --> Language Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Loader Class Initialized
DEBUG - 2014-09-13 12:14:21 --> Database Driver Class Initialized
DEBUG - 2014-09-13 16:14:21 --> Session Class Initialized
DEBUG - 2014-09-13 16:14:21 --> Helper loaded: string_helper
DEBUG - 2014-09-13 16:14:21 --> Session routines successfully run
DEBUG - 2014-09-13 16:14:21 --> Controller Class Initialized
DEBUG - 2014-09-13 16:14:21 --> File loaded: application/views/product_details.php
DEBUG - 2014-09-13 16:14:21 --> Final output sent to browser
DEBUG - 2014-09-13 16:14:21 --> Total execution time: 0.4715
DEBUG - 2014-09-13 14:09:18 --> Config Class Initialized
DEBUG - 2014-09-13 14:09:18 --> Hooks Class Initialized
DEBUG - 2014-09-13 14:09:19 --> Utf8 Class Initialized
DEBUG - 2014-09-13 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2014-09-13 14:09:19 --> URI Class Initialized
DEBUG - 2014-09-13 14:09:19 --> Router Class Initialized
DEBUG - 2014-09-13 14:09:19 --> Output Class Initialized
DEBUG - 2014-09-13 14:09:19 --> Security Class Initialized
DEBUG - 2014-09-13 14:09:19 --> Input Class Initialized
DEBUG - 2014-09-13 14:09:19 --> XSS Filtering completed
DEBUG - 2014-09-13 14:09:19 --> XSS Filtering completed
DEBUG - 2014-09-13 14:09:19 --> XSS Filtering completed
DEBUG - 2014-09-13 14:09:19 --> CRSF cookie Set
DEBUG - 2014-09-13 14:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-13 14:09:19 --> Language Class Initialized
DEBUG - 2014-09-13 14:09:19 --> Loader Class Initialized
DEBUG - 2014-09-13 14:09:19 --> Database Driver Class Initialized
DEBUG - 2014-09-13 18:09:20 --> Session Class Initialized
DEBUG - 2014-09-13 18:09:20 --> Helper loaded: string_helper
DEBUG - 2014-09-13 18:09:20 --> Session routines successfully run
DEBUG - 2014-09-13 18:09:20 --> Controller Class Initialized
DEBUG - 2014-09-13 18:09:20 --> DB Transaction Failure
ERROR - 2014-09-13 18:09:20 --> Query error: Unknown column 'product.product_type' in 'where clause'
DEBUG - 2014-09-13 18:09:20 --> Language file loaded: language/english/db_lang.php
