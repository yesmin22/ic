DEBUG - 2014-09-08 12:16:24 --> Config Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Hooks Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Utf8 Class Initialized
DEBUG - 2014-09-08 12:16:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 12:16:24 --> URI Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Router Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Output Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Security Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Input Class Initialized
DEBUG - 2014-09-08 12:16:24 --> XSS Filtering completed
DEBUG - 2014-09-08 12:16:24 --> XSS Filtering completed
DEBUG - 2014-09-08 12:16:24 --> XSS Filtering completed
DEBUG - 2014-09-08 12:16:24 --> CRSF cookie Set
DEBUG - 2014-09-08 12:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 12:16:24 --> Language Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Loader Class Initialized
DEBUG - 2014-09-08 12:16:24 --> Database Driver Class Initialized
DEBUG - 2014-09-08 16:16:24 --> Session Class Initialized
DEBUG - 2014-09-08 16:16:24 --> Helper loaded: string_helper
DEBUG - 2014-09-08 16:16:24 --> Session routines successfully run
DEBUG - 2014-09-08 16:16:24 --> Controller Class Initialized
ERROR - 2014-09-08 16:16:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecom\application\controllers\mssql_controller.php 26
DEBUG - 2014-09-08 12:17:25 --> Config Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Hooks Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Utf8 Class Initialized
DEBUG - 2014-09-08 12:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 12:17:25 --> URI Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Router Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Output Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Security Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Input Class Initialized
DEBUG - 2014-09-08 12:17:25 --> XSS Filtering completed
DEBUG - 2014-09-08 12:17:25 --> XSS Filtering completed
DEBUG - 2014-09-08 12:17:25 --> XSS Filtering completed
DEBUG - 2014-09-08 12:17:25 --> CRSF cookie Set
DEBUG - 2014-09-08 12:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 12:17:25 --> Language Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Loader Class Initialized
DEBUG - 2014-09-08 12:17:25 --> Database Driver Class Initialized
DEBUG - 2014-09-08 16:17:25 --> Session Class Initialized
DEBUG - 2014-09-08 16:17:25 --> Helper loaded: string_helper
DEBUG - 2014-09-08 16:17:25 --> Session routines successfully run
DEBUG - 2014-09-08 16:17:25 --> Controller Class Initialized
ERROR - 2014-09-08 16:17:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecom\application\controllers\mssql_controller.php 26
DEBUG - 2014-09-08 12:33:39 --> Config Class Initialized
DEBUG - 2014-09-08 12:33:39 --> Hooks Class Initialized
DEBUG - 2014-09-08 12:33:39 --> Utf8 Class Initialized
DEBUG - 2014-09-08 12:33:39 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 12:33:39 --> URI Class Initialized
DEBUG - 2014-09-08 12:33:39 --> Router Class Initialized
DEBUG - 2014-09-08 12:33:39 --> Output Class Initialized
DEBUG - 2014-09-08 12:33:39 --> Security Class Initialized
DEBUG - 2014-09-08 12:33:39 --> Input Class Initialized
DEBUG - 2014-09-08 12:33:39 --> XSS Filtering completed
DEBUG - 2014-09-08 12:33:39 --> XSS Filtering completed
DEBUG - 2014-09-08 12:33:39 --> XSS Filtering completed
DEBUG - 2014-09-08 12:33:39 --> CRSF cookie Set
DEBUG - 2014-09-08 12:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 12:33:39 --> Language Class Initialized
DEBUG - 2014-09-08 12:33:39 --> Loader Class Initialized
DEBUG - 2014-09-08 12:33:40 --> Database Driver Class Initialized
DEBUG - 2014-09-08 16:33:40 --> Session Class Initialized
DEBUG - 2014-09-08 16:33:40 --> Helper loaded: string_helper
DEBUG - 2014-09-08 16:33:40 --> Session routines successfully run
DEBUG - 2014-09-08 16:33:40 --> Controller Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Config Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Hooks Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Utf8 Class Initialized
DEBUG - 2014-09-08 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 12:35:37 --> URI Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Router Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Output Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Security Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Input Class Initialized
DEBUG - 2014-09-08 12:35:37 --> XSS Filtering completed
DEBUG - 2014-09-08 12:35:37 --> XSS Filtering completed
DEBUG - 2014-09-08 12:35:37 --> XSS Filtering completed
DEBUG - 2014-09-08 12:35:37 --> CRSF cookie Set
DEBUG - 2014-09-08 12:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 12:35:37 --> Language Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Loader Class Initialized
DEBUG - 2014-09-08 12:35:37 --> Database Driver Class Initialized
DEBUG - 2014-09-08 16:35:37 --> Session Class Initialized
DEBUG - 2014-09-08 16:35:37 --> Helper loaded: string_helper
DEBUG - 2014-09-08 16:35:37 --> Session routines successfully run
DEBUG - 2014-09-08 16:35:37 --> Controller Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Config Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Hooks Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Utf8 Class Initialized
DEBUG - 2014-09-08 12:35:38 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 12:35:38 --> URI Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Router Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Output Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Security Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Input Class Initialized
DEBUG - 2014-09-08 12:35:38 --> XSS Filtering completed
DEBUG - 2014-09-08 12:35:38 --> XSS Filtering completed
DEBUG - 2014-09-08 12:35:38 --> XSS Filtering completed
DEBUG - 2014-09-08 12:35:38 --> CRSF cookie Set
DEBUG - 2014-09-08 12:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 12:35:38 --> Language Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Loader Class Initialized
DEBUG - 2014-09-08 12:35:38 --> Database Driver Class Initialized
DEBUG - 2014-09-08 16:35:38 --> Session Class Initialized
DEBUG - 2014-09-08 16:35:38 --> Helper loaded: string_helper
DEBUG - 2014-09-08 16:35:38 --> Session routines successfully run
DEBUG - 2014-09-08 16:35:38 --> Controller Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Config Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Hooks Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Utf8 Class Initialized
DEBUG - 2014-09-08 14:22:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 14:22:24 --> URI Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Router Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Output Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Security Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Input Class Initialized
DEBUG - 2014-09-08 14:22:24 --> XSS Filtering completed
DEBUG - 2014-09-08 14:22:24 --> XSS Filtering completed
DEBUG - 2014-09-08 14:22:24 --> XSS Filtering completed
DEBUG - 2014-09-08 14:22:24 --> CRSF cookie Set
DEBUG - 2014-09-08 14:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 14:22:24 --> Language Class Initialized
DEBUG - 2014-09-08 14:22:24 --> Loader Class Initialized
DEBUG - 2014-09-08 14:22:25 --> Database Driver Class Initialized
DEBUG - 2014-09-08 18:22:25 --> Session Class Initialized
DEBUG - 2014-09-08 18:22:25 --> Helper loaded: string_helper
DEBUG - 2014-09-08 18:22:25 --> Session routines successfully run
DEBUG - 2014-09-08 18:22:25 --> Controller Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Config Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Hooks Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Utf8 Class Initialized
DEBUG - 2014-09-08 14:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 14:26:24 --> URI Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Router Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Output Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Security Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Input Class Initialized
DEBUG - 2014-09-08 14:26:24 --> XSS Filtering completed
DEBUG - 2014-09-08 14:26:24 --> XSS Filtering completed
DEBUG - 2014-09-08 14:26:24 --> XSS Filtering completed
DEBUG - 2014-09-08 14:26:24 --> CRSF cookie Set
DEBUG - 2014-09-08 14:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 14:26:24 --> Language Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Loader Class Initialized
DEBUG - 2014-09-08 14:26:24 --> Database Driver Class Initialized
DEBUG - 2014-09-08 18:26:24 --> Session Class Initialized
DEBUG - 2014-09-08 18:26:24 --> Helper loaded: string_helper
DEBUG - 2014-09-08 18:26:24 --> Session routines successfully run
DEBUG - 2014-09-08 18:26:24 --> Controller Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Config Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Hooks Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Utf8 Class Initialized
DEBUG - 2014-09-08 14:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 14:27:39 --> URI Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Router Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Output Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Security Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Input Class Initialized
DEBUG - 2014-09-08 14:27:39 --> XSS Filtering completed
DEBUG - 2014-09-08 14:27:39 --> XSS Filtering completed
DEBUG - 2014-09-08 14:27:39 --> XSS Filtering completed
DEBUG - 2014-09-08 14:27:39 --> CRSF cookie Set
DEBUG - 2014-09-08 14:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 14:27:39 --> Language Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Loader Class Initialized
DEBUG - 2014-09-08 14:27:39 --> Database Driver Class Initialized
DEBUG - 2014-09-08 18:27:39 --> Session Class Initialized
DEBUG - 2014-09-08 18:27:39 --> Helper loaded: string_helper
DEBUG - 2014-09-08 18:27:39 --> Session routines successfully run
DEBUG - 2014-09-08 18:27:39 --> Controller Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Config Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Hooks Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Utf8 Class Initialized
DEBUG - 2014-09-08 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2014-09-08 14:31:36 --> URI Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Router Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Output Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Security Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Input Class Initialized
DEBUG - 2014-09-08 14:31:36 --> XSS Filtering completed
DEBUG - 2014-09-08 14:31:36 --> XSS Filtering completed
DEBUG - 2014-09-08 14:31:36 --> XSS Filtering completed
DEBUG - 2014-09-08 14:31:36 --> CRSF cookie Set
DEBUG - 2014-09-08 14:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-08 14:31:36 --> Language Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Loader Class Initialized
DEBUG - 2014-09-08 14:31:36 --> Database Driver Class Initialized
DEBUG - 2014-09-08 18:31:36 --> Session Class Initialized
DEBUG - 2014-09-08 18:31:36 --> Helper loaded: string_helper
DEBUG - 2014-09-08 18:31:36 --> Session routines successfully run
DEBUG - 2014-09-08 18:31:36 --> Controller Class Initialized
