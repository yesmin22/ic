<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ageing_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	function generate_payable_ageings(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_payable_ageing');
		$this->webspice->permission_verify('generate_payable_ageing');

		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		
		$max_ageing_date = date("Y-m-d");
		$initialSQL = "
		    SELECT 
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 30
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS NOT_DUE,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 30
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 60
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_30,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 60
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 90
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_60,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 90
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 120
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_90,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 120
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 150
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_120,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 150
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 180
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_150,
        
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 180
        AND DATEDIFF('".$max_ageing_date."', BILL_MONTH) <= 365
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_365,
        SUM(
        CASE
        WHEN DATEDIFF('".$max_ageing_date."', BILL_MONTH) > 365
        THEN
        INVOICE_AMOUNT_AFTER_VAT_TAX
        END)
        AS SLAB_YR_1_3,
        OPERATOR_NAME,OPERATOR_TYPE
        FROM TBL_PAYABLE_AGEING
        GROUP BY OPERATOR_NAME
		";


   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_PAYABLE_AGEING',
				$InputField = array('OPERATOR_NAME'),
				$Keyword = array(),
				$AdditionalWhere = " EXTRACT (YEAR FROM TBL_PAYABLE_AGEING.CREATED_DATE) = 2017 /*EXTRACT (YEAR FROM SYSDATE)*/ AND EXTRACT (MONTH FROM TBL_PAYMENT_HISTORY_FOR_AGEING.CREATED_DATE) = 11 /*EXTRACT (MONTH FROM SYSDATE)*/ ",
				$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
			$initialSQL;
		}

    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql_ageing']) || !$_SESSION['sql_ageing'] ){
				$_SESSION['sql_ageing'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql_ageing'] );
			$data['get_record'] = $record->result();
			$data['filter_by'] = $_SESSION['filter_by'];

			$this->load->view('ageing/print_payable_ageing',$data);
			return false;
			break;

			case 'approve':
			$this->webspice->action_executer($TableName='TBL_BUNDLE', $KeyField='BUNDLE_ID', $key, $RedirectURL='manage_bundle', $PermissionName='manage_bundle', $StatusCheck=1, $ChangeStatus=2, $RemoveCache='bundle', $Log='approve_bundle');
			return false;
			break;

			case 'remove':
					# delete permanently bundle and bundle item related information
			$this->db->trans_off();
			$this->db->trans_begin();

			$key = $this->webspice->encrypt_decrypt($key, 'decrypt');

			$delete_sql = "DELETE FROM TBL_BUNDLE WHERE BUNDLE_ID = ? AND ROWNUM = 1";
			$this->db->query($delete_sql, $key);

			$delete_sql = "DELETE FROM TBL_BUNDLE_ITEM WHERE BUNDLE_ID = ? ";
			$this->db->query($delete_sql, $key);

			if ($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return FALSE;

			}else{
				$this->db->trans_commit();
			}
			$this->db->trans_off();

					# remove cache
			$this->webspice->remove_cache('bundle');

			$this->webspice->force_redirect($url_prefix.'manage_bundle');
			return false;
			break;
		}

    # default
		$sql = $initialSQL;
    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql_bundle']) || !$_SESSION['sql_bundle'] ){
    		$sql = substr($sql, 0, strpos($sql,'LIMIT'));
    	}else{
    		$sql = substr($_SESSION['sql_bundle'], 0, strpos($_SESSION['sql_bundle'],'LIMIT'));
    	}

    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = $sql . $limit;
    }*/

		# load all records
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_bundle/page/', 10 );
		}*/

		$_SESSION['sql_ageing'] = $sql;
		$_SESSION['filter_by'] = $filter_by;
		$result = $this->db->query($sql)->result();
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('ageing/generate_payable_ageing', $data);
	}
	function generate_recevable_ageing_(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_recevable_ageing');
		$this->webspice->permission_verify('generate_recevable_ageing');

		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		
		$max_ageing_date = date("Y-m-d");
		






		$initialSQL = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                          EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                           EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                           EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                          EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                              EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                              EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                  THEN
	                       REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                 EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                 EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                     THEN
	                          REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) = EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) = EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_PERIOD BETWEEN  
	                       DATE_ADD(DATE_FORMAT(NOW(),'%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD(NOW(),INTERVAL -8 MONTH))
	                     
	                       THEN
	                         REMAINING_AMOUNT
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_PERIOD  < DATE_ADD(DATE_FORMAT(NOW(),'%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          REMAINING_AMOUNT
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_INVOICE_DETAIL GROUP BY OPERATOR_NAME ORDER BY OPERATOR_NAME";











    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql_ageing']) || !$_SESSION['sql_ageing'] ){
				$_SESSION['sql_ageing'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql_ageing'] );
			$data['get_record'] = $record->result();
			$data['filter_by'] = $_SESSION['filter_by'];

			$this->load->view('ageing/print_receivable_ageing',$data);
			return false;
			break;
		}

    # default
		$sql = $initialSQL;
    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql_bundle']) || !$_SESSION['sql_bundle'] ){
    		$sql = substr($sql, 0, strpos($sql,'LIMIT'));
    	}else{
    		$sql = substr($_SESSION['sql_bundle'], 0, strpos($_SESSION['sql_bundle'],'LIMIT'));
    	}

    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = $sql . $limit;
    }*/

		# load all records
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_bundle/page/', 10 );
		}*/

		$_SESSION['sql_ageing'] = $sql;
		$_SESSION['filter_by'] = $filter_by;
		$result = $this->db->query($sql)->result();
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('ageing/generate_receivable_ageing', $data);
	}
	

	function generate_recevable_ageing____($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_recevable_ageing');
		$this->webspice->permission_verify('generate_recevable_ageing');
		
		$initialSQL = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                          EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                           EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                           EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                          EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                              EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                              EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                  THEN
	                       REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                 EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                 EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                     THEN
	                          REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) = EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) = EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_PERIOD BETWEEN  
	                       DATE_ADD(DATE_FORMAT(NOW(),'%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD(NOW(),INTERVAL -8 MONTH))
	                     
	                       THEN
	                         REMAINING_AMOUNT
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_PERIOD  < DATE_ADD(DATE_FORMAT(NOW(),'%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          REMAINING_AMOUNT
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_INVOICE_DETAIL GROUP BY OPERATOR_NAME ORDER BY OPERATOR_NAME";
		
		if( !$_POST ){
			$this->load->view('ageing/generate_recevable_ageing', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		


		//if(isset($calculative_month)){
		//	 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
		//	 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
		//	 $data['date']=date('M-Y', $calculative_month);
		//}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;	
		$data["get_record"] = $this->db->query($sql)->result();
		if(empty($data["get_record"])){
    $this->webspice->message_board('Record is not found!');
			$this->load->view('report/international_toll_free_jv', $data);
			return false;
			}
		$this->load->view('report/print_international_toll_free_jv', $data);
	}
	

	
	function trade_debitors_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 1;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'trade_debitors_report');
		$this->webspice->permission_verify('trade_debitors_report');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/trade_debitors_report', $data);
			return FALSE;
		}
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('xlsx'), 'sap_file', $data, 'uploader/trade_debitors_report');
		}
		
		$sheet_columns = array("Period", "Account", "Currency", "YTD");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'trade_debitors_report');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time_from_excel = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time=$this->webspice->date_excel_to_real($date_time);
			$account = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$currency = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$ytd = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));

			$values[] = array("PERIOD" => $date_time, "ACCOUNT" => $account, "CURRENCY" => $currency, "YTD" => $ytd, "CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			
			
		
			# must have column value - column offset started from 1
		##	if( !isset($date_time) || !isset($operator) || !isset($calltype) || !isset($prepost_flag) || !isset($calls) || !isset($rate_per_event) || !isset($netamount) ){
		#		$data_error .= 'Row #'.$k.' is incomplete.<br />';
		#	}

		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/trade_debitors_report', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_DEBITORS_DATA";
		$input = $this->webspice->get_input();
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('trade_debitors_report'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('trade_debitors_report', true) ){
			$this->webspice->force_redirect($url_prefix.'trade_debitors_report');
		}
		
		$this->webspice->force_redirect($url_prefix);
	 }
	
 }
	
	
	
	
	
	
	
	
	
	
	
	
	function generate_payable_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_payable_ageing');
		$this->webspice->permission_verify('generate_payable_ageing');

		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		
		$max_ageing_date = date("Y-m-d");
		






		$initialSQL = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -1 MONTH))
	               THEN
	                    INVOICE_AMOUNT_AFTER_VAT_TAX
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                           EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -2 MONTH))
	               THEN
	                    INVOICE_AMOUNT_AFTER_VAT_TAX
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                              EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_MONTH) =
	                              EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -3 MONTH))
	                  THEN
	                       INVOICE_AMOUNT_AFTER_VAT_TAX
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                 EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                 EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -4 MONTH))
	                     THEN
	                          INVOICE_AMOUNT_AFTER_VAT_TAX
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -5 MONTH))
	                      THEN
	                            INVOICE_AMOUNT_AFTER_VAT_TAX
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -6 MONTH))
	                      THEN
	                            INVOICE_AMOUNT_AFTER_VAT_TAX
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) = EXTRACT(MONTH FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) = EXTRACT(YEAR FROM DATE_ADD(NOW(),INTERVAL -7 MONTH))
	                      THEN
	                            INVOICE_AMOUNT_AFTER_VAT_TAX
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_MONTH BETWEEN  
	                       DATE_ADD(DATE_FORMAT(NOW(),'%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD(NOW(),INTERVAL -8 MONTH))
	                     
	                       THEN
	                         INVOICE_AMOUNT_AFTER_VAT_TAX
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_MONTH  < DATE_ADD(DATE_FORMAT(NOW(),'%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          INVOICE_AMOUNT_AFTER_VAT_TAX
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_PAYABLE_AGEING GROUP BY OPERATOR_NAME ORDER BY OPERATOR_NAME";











    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql_ageing']) || !$_SESSION['sql_ageing'] ){
				$_SESSION['sql_ageing'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			
			$record = $this->db->query( $_SESSION['sql_ageing'] );
			$data['get_record'] = $record->result();
			$data['filter_by'] = $_SESSION['filter_by'];

			$this->load->view('ageing/print_payable_ageing',$data);
			return false;
			break;
		}

    # default
		$sql = $initialSQL;
		$_SESSION['sql_ageing'] = $sql;
		$_SESSION['filter_by'] = $filter_by;
///dd($sql);
		$result = $this->db->query($sql)->result();
	
	//	dd($this->db->last_query());
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('ageing/generate_payable_ageing', $data);
	}
	
	
		
		
		
		
		
		
		
		
		function net_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'net_ageing  ');
		$this->webspice->permission_verify('net_ageing');
		 if(!$_POST){
			$this->load->view('ageing/net_ageing');
			return false;
		}

		 $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$ageing_date = date("Y-m-d",$calculative_month);
        $initialSQL = "
	  SELECT SUPPLIER_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                           EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                              EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_MONTH) =
	                              EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                  THEN
	                       NET_BALANCE
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                 EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                 EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                     THEN
	                          NET_BALANCE
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                      THEN
	                            NET_BALANCE
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                      THEN
	                            NET_BALANCE
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) = EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) = EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                      THEN
	                            NET_BALANCE
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_MONTH BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         NET_BALANCE
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_MONTH  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          NET_BALANCE
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_VENDOR_LIABILITY GROUP BY SUPPLIER_NAME,OPERATOR_TYPE ORDER BY SUPPLIER_NAME
	    
	    ";           
$accrued_sql="
SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MO'
  UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT' 

   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MO'
    UNION

    
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MOMMS' || a.CALLTYPE='MOSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 

";






$initialSQL_receiveable="SELECT 
  T1.OPERATOR_NAME,
  T1.OPERATOR_TYPE,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_UNEXPIRED,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_0_30 ,
   SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_31_60 ,
  
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_61_90,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_91_120, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_121_150, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_151_180, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 8 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 8 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 9 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 9 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 10 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 10 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 11 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 11 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 12 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 12 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      ELSE 0 
    END
  ) AS SLAB_181_365
  
FROM
  TBL_INVOICE T1
GROUP BY 
  T1.OPERATOR_NAME,
  T1.OPERATOR_TYPE";
  
$data['receiveable_result_big_365'] = $this->db->query("SELECT 
										  SUM(REMAINING_AMOUNT) AS SLAB_BIG_365,
										  TBL_RESULT.OPERATOR_NAME,
										  TBL_RESULT.OPERATOR_TYPE 
										FROM
										  (SELECT 
											MAX(ID) AS MAX_ID,
											T1.REMAINING_AMOUNT,
											T1.OPERATOR_NAME,
											T1.OPERATOR_TYPE 
										  FROM
											TBL_INVOICE T1 
										  WHERE T1.BILL_PERIOD < DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH) 
										  GROUP BY T1.BILL_PERIOD,
											T1.OPERATOR_NAME,
											T1.OPERATOR_TYPE) TBL_RESULT 
										GROUP BY TBL_RESULT.OPERATOR_NAME,
										  TBL_RESULT.OPERATOR_TYPE ")->result();

//dd($data['receiveable_result_big_365']);										  
  $accrued_sql_receivable="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MT'
   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MT'
    UNION
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT'
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MTMMS' || a.CALLTYPE='MTSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 
";

$initialSQL_NAT="SELECT 
 OPERATOR_NAME,OPERATOR_TYPE,
 SUM(SLAB_UNEXPIRED_REC - SLAB_UNEXPIRED_PAY) AS VALUE_UNEXPECTED_DIFF,
  SUM(SLAB_0_30_REC - SLAB_0_30_PAY) AS VALUE_0_30_DIFF,
  SUM(SLAB_31_60_REC - SLAB_31_60_PAY) AS VALUE_31_60_DIFF,
  SUM(SLAB_61_90_REC - SLAB_61_90_PAY) AS VALUE_61_90_DIFF,
  SUM(SLAB_91_120_REC - SLAB_91_120_PAY) AS VALUE_91_120_DIFF,
  SUM(SLAB_121_150_REC - SLAB_121_150_PAY) AS VALUE_121_150_DIFF,
  SUM(SLAB_151_180_REC - SLAB_151_180_PAY) AS VALUE_151_180_DIFF,
  SUM(SLAB_181_365_REC - SLAB_181_365_PAY) AS VALUE_181_365_DIFF,
  SUM(SLAB_365_MORE_REC - SLAB_365_MORE_PAY) AS VALUE_365_MORE_DIFF
FROM
((SELECT SUPPLIER_NAME AS OPERATOR_NAME,
OPERATOR_TYPE, 0 AS SLAB_UNEXPIRED_REC ,0 AS SLAB_0_30_REC ,0 AS SLAB_31_60_REC ,0 AS SLAB_61_90_REC ,0 AS SLAB_91_120_REC ,0 AS SLAB_121_150_REC ,0 AS SLAB_151_180_REC ,0 AS SLAB_181_365_REC ,0 AS SLAB_365_MORE_REC ,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED_PAY,
				SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_0_30_PAY,
				SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_31_60_PAY,
				SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_61_90_PAY,
				SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_91_120_PAY,
				SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_121_150_PAY,
				SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_151_180_PAY,
				 SUM(
	                    CASE
	                       WHEN  BILL_MONTH BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         NET_BALANCE
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365_PAY,

	                  SUM(
	                    CASE
	                        WHEN BILL_MONTH  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          NET_BALANCE
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_MORE_PAY
	             FROM TBL_VENDOR_LIABILITY GROUP BY SUPPLIER_NAME ORDER BY SUPPLIER_NAME)
	             UNION ALL
	             (SELECT 
   T1.OPERATOR_NAME,
   T1.OPERATOR_TYPE,
  
     SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_UNEXPIRED_REC,
   0 AS SLAB_UNEXPIRED_PAY,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  )  AS SLAB_0_30_REC,
   0 AS SLAB_0_30_PAY,
   SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_31_60_REC,
   0 AS SLAB_31_60_PAY,
  
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  )AS SLAB_61_90_REC,
   0 AS SLAB_UNEXPIRED_PAY,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_91_120_REC,
   0 AS SLAB_91_120_PAY,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_121_150_REC,
   0 AS SLAB_121_150_PAY,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_151_180_REC,
   0 AS SLAB_151_180_PAY,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 8 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 8 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 9 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 9 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 10 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 10 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 11 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 11 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 12 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 12 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      ELSE 0 
    END
  ) AS SLAB_181_365_REC,
   0 AS SLAB_181_365_PAY,
    0 AS SLAB_365_MORE_REC,
   0 AS SLAB_365_MORE_PAY
   
   FROM
  TBL_INVOICE T1
GROUP BY T1.OPERATOR_NAME,
  T1.OPERATOR_TYPE )) AS TEMP GROUP BY OPERATOR_NAME,OPERATOR_TYPE";  







		  $data['get_record'] = $this->db->query($initialSQL)->result();
          $data['accrude_result'] = $this->db->query($accrued_sql)->result();
		  $data['get_record_receiveable'] = $this->db->query($initialSQL_receiveable)->result();
          $data['accrude_result_receiveable'] = $this->db->query($accrued_sql_receivable)->result();
		  $data['get_record_nat'] = $this->db->query($initialSQL_NAT)->result();
		 
	
		if( ! $data['get_record']){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'nat_ageiing');
			return false;
		}
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		 $this->load->view('ageing/generate_receivable_payable_net_ageing', $data);
	}
	
		
		function net_ageing_______(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'net_ageing');
		$this->webspice->permission_verify('net_ageing');

		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		
		
		$ageing_date = date("Y-m-d",$calculative_month);
$ageing_date='2018-07-01';
               $initialSQL_for_receiveable = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                           EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                          EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                              EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                              EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                  THEN
	                       REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                 EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                 EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                     THEN
	                          REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) = EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) = EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_PERIOD BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         REMAINING_AMOUNT
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_PERIOD  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          REMAINING_AMOUNT
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_INVOICE_DETAIL GROUP BY OPERATOR_NAME ORDER BY OPERATOR_TYPE,OPERATOR_TYPE DESC
	    
	    ";
           
$accrued_sql_for_receiveable="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MT'
   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MT'
    UNION
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT'
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MTMMS' || a.CALLTYPE='MTSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 
";


        
		
		  $data['receiveable_get_record'] = $this->db->query($initialSQL_for_receiveable)->result();
		 
          $data['receiveable_accrude_result'] = $this->db->query($accrued_sql_for_receiveable)->result();
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  $initialSQL = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                           EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                              EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_MONTH) =
	                              EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                  THEN
	                       REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                 EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                 EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                     THEN
	                          REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) = EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) = EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_MONTH BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         REMAINING_AMOUNT
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_MONTH  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          REMAINING_AMOUNT
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_PAYABLE_AGEING_FROM_VENDOR_LIABILITY GROUP BY OPERATOR_NAME ORDER BY OPERATOR_NAME
	    
	    ";
            
$accrued_sql="
SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MO'
  UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT' 

   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MO'
    UNION

    
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MOMMS' || a.CALLTYPE='MOSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 

";


        
		
		  $data['get_record'] = $this->db->query($initialSQL)->result();
		  
		  
          $data['accrude_result'] = $this->db->query($accrued_sql)->result();


		$this->load->view('ageing/generate_receivable_payable_net_ageing', $data);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	 function new_receiveable_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'new_receiveable_ageing');
		$this->webspice->permission_verify('new_receiveable_ageing');
		//$orderby = ' ORDER BY TBL_FULL_MONTH_LTFS.REPORT_DATE DESC';
    //$groupby = null;
		if(!$_POST){
			$this->load->view('ageing/new_receiveable_ageing');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$ageing_date = date("Y-m-d",$calculative_month);



  /*$initialSQL="SELECT 
  OPERATOR_NAME,
  OPERATOR_TYPE,
  SUM(
    CASE
      WHEN BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH) 
      AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2 ,TBL_INVOICE
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH)) 
      THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_UNEXPIRED,
  SUM(
    CASE
      WHEN BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH) 
      AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2 ,TBL_INVOICE
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH)) 
      THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_0_30 ,
   SUM(
    CASE
      WHEN BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH) 
      AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2,TBL_INVOICE 
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH)) 
      THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_31_60 ,
  
  SUM(
    CASE
      WHEN BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH) 
      AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2,TBL_INVOICE 
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH)) 
      THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_61_90,
  SUM(
    CASE
      WHEN BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH) 
      AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2,TBL_INVOICE 
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH)) 
      THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_91_120, 
  SUM(
    CASE
      WHEN BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH) 
      AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2 ,TBL_INVOICE
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH)) 
      THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_121_150, 
  SUM(
    CASE
      WHEN BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH) 
      AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2 ,TBL_INVOICE
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH)) 
      THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_151_180, 
   SUM(
	CASE
	WHEN  BILL_PERIOD  BETWEEN  DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH) 
	 AND 
        DATE_ADD('".$ageing_date."', INTERVAL - 8 MONTH) 
	AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2 ,TBL_INVOICE
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD  BETWEEN  DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH) 
	 AND 
        DATE_ADD('".$ageing_date."', INTERVAL - 8 MONTH) ) 
         THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_181_365, 
  SUM(
   CASE
  WHEN BILL_PERIOD  < DATE_ADD('".$ageing_date."', INTERVAL -13 MONTH)
  AND ID = 
      (SELECT 
        MAX(TBL_INVOICE.ID) 
      FROM
        TBL_INVOICE T2,TBL_INVOICE 
      WHERE T2.`OPERATOR_NAME` = TBL_INVOICE.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = TBL_INVOICE.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH)) 
         THEN REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_365_more
  
FROM
  TBL_INVOICE 
GROUP BY OPERATOR_NAME,
  OPERATOR_TYPE ";         
$accrued_sql="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MT'
   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MT'
    UNION
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT'
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MTMMS' || a.CALLTYPE='MTSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 
";*/
$initialSQL="SELECT 
  T1.OPERATOR_NAME,
  T1.OPERATOR_TYPE,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 1 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_UNEXPIRED,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_0_30 ,
   SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_31_60 ,
  
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_61_90,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_91_120, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_121_150, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_151_180, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 8 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 8 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 9 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 9 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 10 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 10 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 11 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 11 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 12 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 12 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 13 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE_DETAIL T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 13 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      ELSE 0 
    END
  ) AS SLAB_181_365
  
FROM
  TBL_INVOICE_DETAIL T1
GROUP BY T1.BILL_PERIOD,
  T1.OPERATOR_NAME,
  T1.OPERATOR_TYPE";
  
$data['receiveable_result_big_365'] = $this->db->query("SELECT 
										  SUM(REMAINING_AMOUNT) AS SLAB_BIG_365,
										  TBL_RESULT.OPERATOR_NAME,
										  TBL_RESULT.OPERATOR_TYPE 
										FROM
										  (SELECT 
											MAX(ID) AS MAX_ID,
											T1.REMAINING_AMOUNT,
											T1.OPERATOR_NAME,
											T1.OPERATOR_TYPE 
										  FROM
											TBL_INVOICE_DETAIL T1 
										  WHERE T1.BILL_PERIOD < DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH) 
										  GROUP BY T1.BILL_PERIOD,
											T1.OPERATOR_NAME,
											T1.OPERATOR_TYPE) TBL_RESULT 
										GROUP BY TBL_RESULT.OPERATOR_NAME,
										  TBL_RESULT.OPERATOR_TYPE ")->result();	
$accrued_sql="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MT'
   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MT'
    UNION
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT'
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MTMMS' || a.CALLTYPE='MTSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 
";


		  $data['get_record'] = $this->db->query($initialSQL)->result();
          $data['accrude_result'] = $this->db->query($accrued_sql)->result();
		if( ! $data['get_record']){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'new_receiveable_ageing');
			return false;
		}
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		 $this->load->view('ageing/generate_receivable_ageing', $data);
	}
	
	
	
	 function new_receiveable_ageing_most_imp(){
          $url_prefix = $this->webspice->settings()->site_url_prefix;
          
          $this->webspice->user_verify($url_prefix.'login', $url_prefix.'new_receiveable_ageing');
          $this->webspice->permission_verify('new_receiveable_ageing');

          $this->load->database();
          $orderby = null;
          $groupby = null;
          $where = null;
          $page_index = 0;
          $no_of_record = 30;
          $limit = null;
          $filter_by = 'Last Created';
          $criteria = $this->uri->segment(2);
		  
		  
		  
		  
		  
		  if(!$_POST){
			$this->load->view('ageing/new_receiveable_ageing');
			return false;
		}

		 $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		
		
		
		$ageing_date = date("Y-m-d",$calculative_month);


               $initialSQL = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                           EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                          EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                              EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                              EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                  THEN
	                       REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                 EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                 EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                     THEN
	                          REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_PERIOD) = EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_PERIOD) = EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_PERIOD BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         REMAINING_AMOUNT
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_PERIOD  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          REMAINING_AMOUNT
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_INVOICE_DETAIL GROUP BY OPERATOR_NAME ORDER BY OPERATOR_NAME
	    
	    ";
            
$accrued_sql="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MT'
   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MT'
    UNION
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT'
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MTMMS' || a.CALLTYPE='MTSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 
";


          # filtering records
         // if( $this->input->post('filter') ){
         //   $result = $this->webspice->filter_generator(
         //     $TableName = 'IOTPAY', 
         //     $InputField = array('PLMN'), 
         //     $Keyword = array(),
         //     $AdditionalWhere = null,
         //     $DateBetween = array()
        //    );
         //   $result['where'] ? $where = $result['where'] : $where=$where;
         //   $result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
         // }

          # action area
          switch ($criteria) {
            case 'print':
            case 'csv':
            if( !isset($_SESSION['rec_ageing']) || !$_SESSION['rec_ageing'] ){
              $_SESSION['rec_ageing'] = $initialSQL;
              $_SESSION['filter_by'] = $filter_by;
            }

            if( !isset($_SESSION['acc_sql']) || !$_SESSION['acc_sql'] ){
              $_SESSION['acc_sql'] = $accrued_sql;
            }
            $record = $this->db->query( $_SESSION['rec_ageing'] );
            $data['get_record'] = $record->result();
            $record = $this->db->query( $_SESSION['acc_sql'] );
            $data['accrude_result'] = $record->result();
            //$data['filter_by'] = $_SESSION['filter_by'];

            $this->load->view('ageing/print_generate_receivable_ageing',$data);
            return false;
            break;        
          }

            # default
          
          $_SESSION['rec_ageing'] =  $initialSQL;
          $_SESSION['acc_sql'] =  $accrued_sql;
         
         // $_SESSION['filter_by'] = $filter_by;
          $data['get_record'] = $this->db->query($initialSQL)->result();
          $data['accrude_result'] = $this->db->query($accrued_sql)->result();
          $this->load->view('ageing/generate_receivable_ageing', $data);
        }

function generate_new_payable_ageing_IMP(){
          $url_prefix = $this->webspice->settings()->site_url_prefix;
          
          $this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_new_payable_ageing');
          $this->webspice->permission_verify('generate_new_payable_ageing');

          $this->load->database();
          $orderby = null;
          $groupby = null;
          $where = null;
          $page_index = 0;
          $no_of_record = 30;
          $limit = null;
          $filter_by = 'Last Created';
          $criteria = $this->uri->segment(2);
		  
		  
		  
		  
		  
		  if(!$_POST){
			$this->load->view('ageing/generate_new_payable_ageing');
			return false;
		}

		 $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		
		
		
		$ageing_date = date("Y-m-d",$calculative_month);


               $initialSQL = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                           EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                              EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_MONTH) =
	                              EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                  THEN
	                       REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                 EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                 EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                     THEN
	                          REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) = EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) = EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_MONTH BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         REMAINING_AMOUNT
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_MONTH  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          REMAINING_AMOUNT
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_PAYABLE_AGEING_FROM_VENDOR_LIABILITY GROUP BY OPERATOR_NAME ORDER BY OPERATOR_NAME
	    
	    ";
           


          # action area
          switch ($criteria) {
            case 'print':
            case 'csv':
            if( !isset($_SESSION['rec_ageing']) || !$_SESSION['rec_ageing'] ){
              $_SESSION['rec_ageing'] = $initialSQL;
              $_SESSION['filter_by'] = $filter_by;
            }

            if( !isset($_SESSION['acc_sql']) || !$_SESSION['acc_sql'] ){
              $_SESSION['acc_sql'] = $accrued_sql;
            }
            $record = $this->db->query( $_SESSION['rec_ageing'] );
            $data['get_record'] = $record->result();
            $record = $this->db->query( $_SESSION['acc_sql'] );
            $data['accrude_result'] = $record->result();
            //$data['filter_by'] = $_SESSION['filter_by'];

            $this->load->view('ageing/print_generate_new_payable_ageing',$data);
            return false;
            break;        
          }

            # default
          
          $_SESSION['rec_ageing'] =  $initialSQL;
         // $_SESSION['acc_sql'] =  $accrued_sql;
         
         // $_SESSION['filter_by'] = $filter_by;
		 $data['accrude_result']=0;
          $data['get_record'] = $this->db->query($initialSQL)->result();
          //$data['accrude_result'] = $this->db->query($accrued_sql)->result();
          $this->load->view('ageing/generate_payable_ageing_new.php', $data);
        }

 function generate_new_payable_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_new_payable_ageing  ');
		$this->webspice->permission_verify('generate_new_payable_ageing');
		 if(!$_POST){
			$this->load->view('ageing/generate_new_payable_ageing');
			return false;
		}

		 $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$ageing_date = date("Y-m-d",$calculative_month);


               /* this is correct for ageing.updated before create custom ageing
			   $initialSQL = "
	  SELECT OPERATOR_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                           EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    REMAINING_AMOUNT
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                              EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_MONTH) =
	                              EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                  THEN
	                       REMAINING_AMOUNT
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                 EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                 EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                     THEN
	                          REMAINING_AMOUNT
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) = EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) = EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                      THEN
	                            REMAINING_AMOUNT
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_MONTH BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         REMAINING_AMOUNT
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_MONTH  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          REMAINING_AMOUNT
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_PAYABLE_AGEING_FROM_VENDOR_LIABILITY GROUP BY OPERATOR_NAME ORDER BY OPERATOR_NAME
	    
	    ";*/
		
		
	//THIS IS FOR HISTORY AGEING	
  $initialSQL = "
	  SELECT SUPPLIER_NAME,OPERATOR_TYPE, 
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                          EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                           EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -1 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_UNEXPIRED,
	         SUM(
	            CASE
	               WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                           EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	                    AND EXTRACT(YEAR FROM BILL_MONTH) =
	                          EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -2 MONTH))
	               THEN
	                    NET_BALANCE
	               ELSE
	                0
	            END)
	            AS SLAB_0_30,
	            SUM(
	               CASE
	                  WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                              EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                       AND EXTRACT(YEAR FROM BILL_MONTH) =
	                              EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -3 MONTH))
	                  THEN
	                       NET_BALANCE
	                  ELSE
	                   0
	               END)
	               AS SLAB_31_60,
	               SUM(
	                  CASE
	                     WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                 EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                          AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                 EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -4 MONTH))
	                     THEN
	                          NET_BALANCE
	                    ELSE
	                      0
	                  END)
	                  AS SLAB_61_90,
	                SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -5 MONTH))
	                      THEN
	                            NET_BALANCE
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_91_120,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) =
	                                  EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) =
	                                  EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -6 MONTH))
	                      THEN
	                            NET_BALANCE
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_121_150,
	                   SUM(
	                   CASE
	                      WHEN     EXTRACT(MONTH FROM BILL_MONTH) = EXTRACT(MONTH FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                           AND EXTRACT(YEAR FROM BILL_MONTH) = EXTRACT(YEAR FROM DATE_ADD('".$ageing_date."',INTERVAL -7 MONTH))
	                      THEN
	                            NET_BALANCE
	                      ELSE
	                       0
	                   END)
	                   AS SLAB_151_180,

	                    SUM(
	                    CASE
	                       WHEN  BILL_MONTH BETWEEN  
	                       DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH) AND 
	                       LAST_DAY(DATE_ADD('".$ageing_date."',INTERVAL -8 MONTH))
	                     
	                       THEN
	                         NET_BALANCE
	                      ELSE
	                        0
	                    END)
	                    AS SLAB_181_365,

	                  SUM(
	                    CASE
	                        WHEN BILL_MONTH  < DATE_ADD(DATE_FORMAT('".$ageing_date."','%Y-%m-01'), INTERVAL -13 MONTH)
	                      
	                        THEN
	                          NET_BALANCE
	                       ELSE
	                         0
	                     END)
	                     AS SLAB_365_more
	    FROM TBL_VENDOR_LIABILITY WHERE REPORT_DATE='".$ageing_date."' GROUP BY SUPPLIER_NAME,OPERATOR_TYPE ORDER BY SUPPLIER_NAME
	    
	    ";   
dd($initialSQL);        
$accrued_sql="
SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MO'
  UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT' 

   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MO'
    UNION

    
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MOMMS' || a.CALLTYPE='MOSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 

";


        
		
		  $data['get_record'] = $this->db->query($initialSQL)->result();
          $data['accrude_result'] = $this->db->query($accrued_sql)->result();
	
		if( ! $data['get_record']){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'generate_new_payable_ageing');
			return false;
		}
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		  $this->load->view('ageing/generate_payable_ageing_new.php', $data);
	}
	
	
	
	function payment_summery_report(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payment_summery_report');
		$this->webspice->permission_verify('payment_summery_report');
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		$activity = $this->uri->segment(4);
		if( !$_POST && $criteria==''){
			$this->load->view('ageing/payment_summery_report');
			return false;
		}

		
		$input = $this->webspice->get_input();
		$report_month = $input->report_date;
		$report_date = date("Y-m-d",$report_month );
		$data['report_month'] = $report_date;
		if($criteria!=''){
			$vendor_name = $this->webspice->encrypt_decrypt($criteria,'decrypt');
			$report_date = $this->webspice->encrypt_decrypt($key,'decrypt');
			$sql = "SELECT * FROM TBL_REGISTER WHERE VENDOR_TYPE='INTERCONNECTION' AND VENDOR_NAME='".$vendor_name."' AND REPORT_DATE='".$report_date."'";
			$records = $this->db->query($sql)->result();
			$data['data'] = $records;
			if($activity==''){
			$this->load->view('ageing/payment_summery_details', $data);
			}else{
			$this->load->view('ageing/print_payment_summery_details', $data);
			}
			return false;

		}
		$sql = "SELECT * FROM TBL_REGISTER WHERE VENDOR_TYPE='INTERCONNECTION' AND REPORT_DATE='".$report_date."'";
		$records = $this->db->query($sql)->result();
		$data['data'] = $records;

		if( !$data['data'] ){
			$this->webspice->message_board('There is no data found according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payment_summery_report');
			return false;
		}
		$data['current_date']= date("d-M-Y");
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		}

		//$data['filter_by'] = 'Filter By: '.$this->webspice->month_convert( date('m',$report_month) ).', '.date('Y',$report_month);
		$this->load->view('ageing/print_payment_summery_report', $data);
	}


	function ranks_pstn_vat_rate($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'ranks_pstn_vat_rate');
			$this->webspice->permission_verify('ranks_pstn_vat_rate,manage_ranks_pstn_vat_rate');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'RANKS_PSTN_VAT_RATE'=> null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('ranks_pstn_vat_rate','Ranks PSTN VAT Rate','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
				$this->load->view('master/ranks_pstn_vat_rate', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			$vat_rate = $this->input->post("ranks_pstn_vat_rate");
			$calculative_month = $this->input->post("calculative_month");
		    $report_date=date("Y-m-d",$calculative_month);
			#duplicate test
		    $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_RANKS_PSTN_VAT_RATE WHERE BILL_MONTH=? ", array( $report_date), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/ranks_pstn_vat_rate');
	
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_RANKS_PSTN_VAT_RATE SET RATE=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($vat_rate,$this->webspice->get_user_id(), $this->webspice->now(),$input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->force_redirect($url_prefix.'manage_ranks_pstn_vat_rate');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_RANKS_PSTN_VAT_RATE
			(RATE,BILL_MONTH, CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($vat_rate,$report_date, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('ranks_pstn_vat_rate', true) ){
				$this->webspice->force_redirect($url_prefix.'ranks_pstn_vat_rate');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_ranks_pstn_vat_rate(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ranks_pstn_vat_rate');
		$this->webspice->permission_verify('manage_ranks_pstn_vat_rate');
		$this->load->database();
		$orderby = ' ORDER BY ID DESC '; 
		$groupby = null;
		$where = '';
		$page_index = 0;
		$no_of_record = 10;
		$additional_where = null;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$report_date = $this->input->post("BILL_MONTH");
		$report_date = date("Y-m-d",$report_date);
		if( $report_date ){
			$additional_where = " TBL_RANKS_PSTN_VAT_RATE.BILL_MONTH='".$report_date."'";
		}
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		$initialSQL = "SELECT * FROM TBL_RANKS_PSTN_VAT_RATE ";
	   	# filtering records
		if( $this->input->post('filter') ){
			
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_RANKS_PSTN_VAT_RATE',
				$InputField = array(),
				$Keyword = array('ID', 'RATE'),
				$AdditionalWhere = $additional_where,
				$DateBetween = array()  
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
		}
	    # action area
		switch ($criteria) {
			/*case 'print':
			case 'csv':
			if( !isset($_SESSION['vat_sql']) || !$_SESSION['vat_sql'] ){
				$_SESSION['vat_sql'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['vat_sql'] );
			$data['get_record'] = $record->result();
			$this->load->view('master/print_',$data);
			return false;
			break;*/
			
			case 'edit':
			$this->webspice->edit_generator($TableName='TBL_RANKS_PSTN_VAT_RATE', $KeyField='ID', $key, $RedirectController='ageing_controller', $RedirectFunction='ranks_pstn_vat_rate', $PermissionName='ranks_pstn_vat_rate', $StatusCheck=null, $Log='edit_ranks_pstn_vat_rate');          
			return false;
			break;
			
		
		}
	    # default
		$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		#dd($sql);
	    	# only for pager
		if( $criteria == 'page' && !$this->input->post('filter') ){
			$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
			$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		}
			# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( $initialSQL .$groupby );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ranks_pstn_vat_rate/page/', 10 );
		}
		$result = $this->db->query($sql)->result();
		$_SESSION['sonali_sql']=$sql;
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('master/manage_ranks_pstn_vat_rate', $data);
	}

	function ranks_pstn_accrued_data($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'ranks_pstn_accrued_data');
			$this->webspice->permission_verify('ranks_pstn_accrued_data,manage_ranks_pstn_accrued_data');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'ELECTRICITY_RATE'=> null,
				'NUMBER_OF_SITE'=> null,
				'ELECTRICITY_AMOUNT'=> null,
				'BTS_DATA'=> null,
				'ACCRUED_DATA'=> null,
				'PSTN_FIXED'=> null,
				'BILL_MONTH'=> null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('electricity_rate','Electricity Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('number_of_site','Number of Site','required|trim|xss_clean');
			$this->form_validation->set_rules('pstn_fixed','PSTN Fixed','required|trim|xss_clean');
			$this->form_validation->set_rules('electricity_amount','Electricity Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('bts_data','Bts Data','required|trim|xss_clean');
			$this->form_validation->set_rules('ranks_pstn_accrued_data','Ranks PSTN Accrued Data','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
				$this->load->view('master/ranks_pstn_accrued_data', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			$electricity_rate_actual = $this->input->post("electricity_rate");
			$electricity_rate=str_replace( ',', '', $electricity_rate_actual );
			$number_of_site_actual = $this->input->post("number_of_site");
			$number_of_site=str_replace( ',', '', $number_of_site_actual );
			$electricity_amount_actual = $this->input->post("electricity_amount");
			$electricity_amount=str_replace( ',', '', $electricity_amount_actual );
			$bts_data_actual = $this->input->post("bts_data");
			$bts_data=str_replace( ',', '', $bts_data_actual );
			$accrued_data_actual = $this->input->post("ranks_pstn_accrued_data");
			$accrued_data=str_replace( ',', '', $accrued_data_actual );
			$pstn_fixed_actual = $this->input->post("pstn_fixed");
			$pstn_fixed=str_replace( ',', '', $pstn_fixed_actual );
			$calculative_month = $this->input->post("calculative_month");
		    $report_date=date("Y-m-d",$calculative_month);
			
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_RANKS_PSTN_DATA SET PSTN_FIXED=?,ELECTRICITY_RATE=?,NUMBER_OF_SITE=?,ELECTRICITY_AMOUNT=?,BTS_DATA=?,ACCRUED_DATA=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($pstn_fixed,$electricity_rate,$number_of_site,$electricity_amount,$bts_data,$accrued_data,$this->webspice->get_user_id(), $this->webspice->now(),$input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->force_redirect($url_prefix.'manage_ranks_pstn_accrued_data');
				return false;
			}
			#duplicate test
		    $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_RANKS_PSTN_DATA WHERE BILL_MONTH=? ", array( $report_date), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/ranks_pstn_accrued_data');
	
			$sql = "
			INSERT INTO TBL_RANKS_PSTN_DATA
			(PSTN_FIXED,ELECTRICITY_RATE,NUMBER_OF_SITE,ELECTRICITY_AMOUNT,BTS_DATA,ACCRUED_DATA,BILL_MONTH, CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(? , ? , ? , ? , ? ,?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($pstn_fixed,$electricity_rate,$number_of_site,$electricity_amount,$bts_data,$accrued_data,$report_date, $this->webspice->get_user_id(), $this->webspice->now()));
			
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('ranks_pstn_accrued_data', true) ){
				$this->webspice->force_redirect($url_prefix.'ranks_pstn_accrued_data');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_ranks_pstn_accrued_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ranks_pstn_accrued_data');
		$this->webspice->permission_verify('manage_ranks_pstn_accrued_data');
		$this->load->database();
		$orderby = ' ORDER BY ID DESC '; 
		$groupby = null;
		$where = '';
		$page_index = 0;
		$no_of_record = 10;
		$additional_where = null;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$report_date = $this->input->post("BILL_MONTH");
		$report_date = date("Y-m-d",$report_date);
		if( $report_date ){
			$additional_where = " TBL_RANKS_PSTN_DATA.BILL_MONTH='".$report_date."'";
		}
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		$initialSQL = "SELECT * FROM TBL_RANKS_PSTN_DATA ";
	   	# filtering records
		if( $this->input->post('filter') ){
			
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_RANKS_PSTN_DATA',
				$InputField = array(),
				$Keyword = array('ID', 'ACCRUED_DATA','ELECTRICITY_RATE','NUMBER_OF_SITE','ELECTRICITY_AMOUNT','PSTN_FIXED'),
				$AdditionalWhere = $additional_where,
				$DateBetween = array()  
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
		}
	    # action area
		switch ($criteria) {
			case 'edit':
			$this->webspice->edit_generator($TableName='TBL_RANKS_PSTN_DATA', $KeyField='ID', $key, $RedirectController='ageing_controller', $RedirectFunction='ranks_pstn_accrued_data', $PermissionName='ranks_pstn_accrued_data', $StatusCheck=null, $Log='edit_ranks_pstn_accrued_data');          
			return false;
			break;
			
		
		}
	    # default
		$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		#dd($sql);
	    	# only for pager
		if( $criteria == 'page' && !$this->input->post('filter') ){
			$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
			$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		}
			# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( $initialSQL .$groupby );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ranks_pstn_accrued_data/page/', 10 );
		}
		$result = $this->db->query($sql)->result();
		$_SESSION['sonali_sql']=$sql;
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('master/manage_ranks_pstn_accrued_data', $data);
	}


	function ranks_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'ranks_ageing');
		$this->webspice->permission_verify('ranks_ageing');
		if(!$_POST){
			$this->load->view('ageing/ranks_ageing');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$ageing_date = date("Y-m-d",$calculative_month);

$initialSQL="SELECT 
  SUM(
    CASE
      WHEN T1.BILL_MONTH = DATE_ADD('".$ageing_date."', INTERVAL  0 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_RANKS_PSTN_DATA T2
      WHERE 
       T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL  0 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_UNEXPIRED,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 2 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_0_30 ,
   SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 3 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_31_60 ,
  
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 4 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_61_90,
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 5 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_91_120, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 6 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_121_150, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('".$ageing_date."', INTERVAL - 7 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      ELSE 0 
    END
  ) AS SLAB_151_180, 
  SUM(
    CASE
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 8 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 8 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 9 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 9 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 10 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 10 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 11 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 11 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 12 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 12 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      WHEN T1.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 13 MONTH) 
      AND T1.ID = 
      (SELECT 
        MAX(T2.ID) 
      FROM
        TBL_INVOICE T2 
      WHERE T2.`OPERATOR_NAME` = T1.OPERATOR_NAME 
        AND T2.`OPERATOR_TYPE` = T1.OPERATOR_TYPE 
        AND T2.BILL_PERIOD = DATE_ADD('2018-05-01', INTERVAL - 13 MONTH)) 
      THEN T1.REMAINING_AMOUNT 
      
      ELSE 0 
    END
  ) AS SLAB_181_365
  
FROM
  TBL_INVOICE T1
GROUP BY T1.BILL_PERIOD,
  T1.OPERATOR_NAME,
  T1.OPERATOR_TYPE";
  
$data['receiveable_result_big_365'] = $this->db->query("SELECT 
										  SUM(REMAINING_AMOUNT) AS SLAB_BIG_365,
										  TBL_RESULT.OPERATOR_NAME,
										  TBL_RESULT.OPERATOR_TYPE 
										FROM
										  (SELECT 
											MAX(ID) AS MAX_ID,
											T1.REMAINING_AMOUNT,
											T1.OPERATOR_NAME,
											T1.OPERATOR_TYPE 
										  FROM
											TBL_INVOICE T1 
										  WHERE T1.BILL_PERIOD < DATE_ADD('".$ageing_date."', INTERVAL - 13 MONTH) 
										  GROUP BY T1.BILL_PERIOD,
											T1.OPERATOR_NAME,
											T1.OPERATOR_TYPE) TBL_RESULT 
										GROUP BY TBL_RESULT.OPERATOR_NAME,
										  TBL_RESULT.OPERATOR_TYPE ")->result();	
$accrued_sql="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM(AMOUNT) AS AMOUNT
FROM
 (SELECT
   s.IOS AS OPERATOR_NAME,
   s.OPERATOR_TYPE AS OPERATOR_TYPE,
   s.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   s.DATE_TIME AS REPORT_DATE
   
 FROM
   TBL_VOICE_CALL_INT_IN s WHERE s.CALL_TYPE='MT'
   UNION
   SELECT
   i.OPERATOR AS OPERATOR_NAME,
   i.OPERATOR_TYPE AS OPERATOR_TYPE,
   i.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   i.DATE_TIME AS REPORT_DATE
 FROM
   TBL_ICX_DAILY_DATA i WHERE i.CALL_TYPE='MT'
    UNION
   SELECT
   l.OPERATOR_NAME AS OPERATOR_NAME,
   l.OPERATOR_TYPE AS OPERATOR_TYPE,
   l.TOTAL AS AMOUNT,
   l.DATE_TIME AS REPORT_DATE
 FROM
   TBL_LOCAL_TOLL_FREE_DATA l
   UNION
   SELECT
   it.OPERATOR_NAME AS OPERATOR_NAME,
   it.OPERATOR_TYPE AS OPERATOR_TYPE,
   it.BL_REVENUE AS AMOUNT,
   it.DATE_TIME AS REPORT_DATE
 FROM
   TBL_INT_TOLL_FREE_DATA it
   UNION
   SELECT
   vl.OPERATOR AS OPERATOR_NAME,
   vl.OPERATOR_TYPE AS OPERATOR_TYPE,
   vl.AMOUNT_EXCLUDING_VAT AS AMOUNT,
   vl.DATE_TIME AS REPORT_DATE
 FROM
   TBL_VOICE_CALL_LOCAL vl WHERE vl.CALL_TYPE='MT'
 UNION
 SELECT
   a.OPERATOR AS OPERATOR_NAME,
   a.OPERATOR_TYPE AS OPERATOR_TYPE,
   a.NETAMOUNT AS AMOUNT,
   a.DATE_TIME AS REPORT_DATE
 FROM
   TBL_DOMESTIC_SMS_MMS a WHERE a.CALLTYPE='MTMMS' || a.CALLTYPE='MTSMS') AS TBL_NEW_TEMP 
 WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
GROUP BY OPERATOR_NAME,OPERATOR_TYPE 
";
dd($initialSQL);

		  $data['get_record'] = $this->db->query($initialSQL)->result();
          $data['accrude_result'] = $this->db->query($accrued_sql)->result();
		if( ! $data['get_record']){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'new_receiveable_ageing');
			return false;
		}
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		 $this->load->view('ageing/generate_receivable_ageing', $data);
	}
	
	
	
	
	}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */