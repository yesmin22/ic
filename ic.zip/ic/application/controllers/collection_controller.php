<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Collection_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	function collection_module(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'collection_module');
		$this->webspice->permission_verify('collection_module');

    $orderby = ' ORDER BY DATE_FORMAT(TBL_ICX_REPORT_DATA.REPORT_DATE,"%Y%m") DESC';
    $groupby = ' GROUP BY TBL_ICX_REPORT_DATA.OPERATOR_NAME, DATE_FORMAT(TBL_ICX_REPORT_DATA.REPORT_DATE,"%Y%m") ';
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = "
			SELECT TBL_ICX_REPORT_DATA.OPERATOR_NAME, 
			DATE_FORMAT(TBL_ICX_REPORT_DATA.REPORT_DATE,'%M %Y') AS BILL_MONTH,
			DATE_FORMAT(TBL_ICX_REPORT_DATA.REPORT_DATE,'%Y-%m-%d') AS TEMP_BILL_MONTH,
			SUM(TBL_ICX_REPORT_DATA.TOTAL) AS RECEIVABLE, 
			IFNULL((SELECT SUM(TBL_COLLECTION.AMOUNT) FROM TBL_COLLECTION WHERE TBL_COLLECTION.OPERATOR=TBL_ICX_REPORT_DATA.OPERATOR_NAME),0) COLLECTION
			FROM TBL_ICX_REPORT_DATA 
			LEFT JOIN TBL_COLLECTION ON TBL_ICX_REPORT_DATA.OPERATOR_NAME = TBL_COLLECTION.OPERATOR
		";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_USER', 
			$InputField = array(), 
			$Keyword = array('USER_ID','USER_NAME','USER_EMAIL','USER_PHONE'),
			$AdditionalWhere = null,
			$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('collection/print_collection_module',$data);
				return false;
        break;
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'collection_module/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
    
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;

		$this->load->view('collection/collection_module', $data);
	}
	
	function create_collection($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'collection_module');
		$this->webspice->permission_verify('collection_module');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'ID'=>null,
			'OPERATOR' => $this->webspice->encrypt_decrypt($this->uri->segment(2),"decrypt"),
			'CHECQUE_NO' => null,  
			'BANK_NAME' => null,
			'CURRENT_AMOUNT' => $this->webspice->encrypt_decrypt($this->uri->segment(4),"decrypt"),
			'AMOUNT' => null,
			'BILL_MONTH' => $this->webspice->encrypt_decrypt($this->uri->segment(3),"decrypt")
			);
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('OPERATOR','Operator','required|trim|xss_clean');
		$this->form_validation->set_rules('CHECQUE_NO','Checque No','required|trim|xss_clean');
		$this->form_validation->set_rules('BANK_NAME','Bank Name','required|trim|xss_clean');
		$this->form_validation->set_rules('AMOUNT','Amount','required|trim|xss_clean');
		$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
		
		if( !$this->form_validation->run() ){ 
			$this->load->view('collection/create_collection', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('ID');
		#duplicate test	
		
		# update process
		if( $input->ID ){
			#update query
			$sql = " UPDATE TBL_COLLECTION SET OPERATOR=?, CHECQUE_NO=?, BANK=?, CURRENT_AMOUNT=?, AMOUNT=?, BILL_MONTH=?, UPDATED_BY=?, UPDATED_DATE=? WHERE ID=? ";
			$this->db->query($sql, array($input->OPERATOR, $input->CHECQUE_NO, $input->BANK_NAME, $input->CURRENT_AMOUNT, $input->AMOUNT, $input->BILL_MONTH, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID)); 
			
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('user_updated - '.$input->ID); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_collection');
			return false;
		}
		
		#create user
		$sql = " INSERT INTO TBL_COLLECTION
		(OPERATOR, CHECQUE_NO, BANK_NAME, CURRENT_AMOUNT, AMOUNT, BILL_MONTH, CREATED_BY, CREATED_DATE, STATUS)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, 7) ";
		$this->db->query($sql, array($input->OPERATOR, $input->CHECQUE_NO, $input->BANK_NAME, $input->CURRENT_AMOUNT, $input->AMOUNT, $input->BILL_MONTH, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->message_board('Record has been inserted!.');
		$this->webspice->force_redirect($url_prefix.'collection_module');
	}
	
	function get_receiveable(){
		$bill_month = $this->input->post("bill_month");
		$bill_month = date("Ym",$bill_month);
		$operator = $this->input->post("operator");
		
		$receivable = $this->db->query(" 
			SELECT SUM(TOTAL) AS TOTAL FROM TBL_ICX_REPORT_DATA 
			WHERE DATE_FORMAT(REPORT_DATE,'%Y%m') = $bill_month
			AND OPERATOR_NAME = '".$operator."'
			GROUP BY OPERATOR_NAME
		");
		
		if( $receivable->num_rows() <= 0 ){
			echo "no-data";
			exit;
		}elseif( $receivable->num_rows() >= 0 ){
			echo $receivable->row()->TOTAL;
			exit;
		}
		
	}
	
	function payment_module($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payment_module');
		$this->webspice->permission_verify('payment_module');
		
		$this->webspice->display_error();
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
				'ID'=> null,
				'OPERATOR' => null,
				'CHECQUE_NO' => null,  
				'BANK_NAME' => null,
				'CURRENT_AMOUNT' => null,
				'AMOUNT' => null,
				'BILL_MONTH' => null
			);
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('OPERATOR','Operator','required|trim|xss_clean');
		$this->form_validation->set_rules('CHECQUE_NO','Checque No','required|trim|xss_clean');
		$this->form_validation->set_rules('BANK_NAME','Bank Name','required|trim|xss_clean');
		$this->form_validation->set_rules('AMOUNT','Amount','required|trim|xss_clean');
		$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
		
		if( !$this->form_validation->run() ){ 
			$this->load->view('collection/collection_module', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('ID');
		#duplicate test	
		
		# update process
		if( $input->ID ){
			#update query
			$sql = " UPDATE TBL_COLLECTION SET OPERATOR=?, CHECQUE_NO=?, BANK=?, CURRENT_AMOUNT=?, AMOUNT=?, BILL_MONTH=?, UPDATED_BY=?, UPDATED_DATE=? WHERE ID=? ";
			$this->db->query($sql, array($input->OPERATOR, $input->CHECQUE_NO, $input->BANK_NAME, $input->CURRENT_AMOUNT, $input->AMOUNT, date("Y-m-d",$input->BILL_MONTH), $this->webspice->get_user_id(), $this->webspice->now(), $input->ID)); 
			
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('user_updated - '.$input->ID); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_collection');
			return false;
		}
		
		#create user
		$sql = " INSERT INTO TBL_COLLECTION
		(OPERATOR, CHECQUE_NO, BANK_NAME, CURRENT_AMOUNT, AMOUNT, BILL_MONTH, CREATED_BY, CREATED_DATE, STATUS)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, 7) ";
		$this->db->query($sql, array($input->OPERATOR, $input->CHECQUE_NO, $input->BANK_NAME, $input->CURRENT_AMOUNT, $input->AMOUNT, date("Y-m-d",$input->BILL_MONTH), $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->message_board('Record has been inserted!.');
		$this->webspice->force_redirect($url_prefix.'collection_module');
	}
	
	function get_payable(){
		$bill_month = $this->input->post("bill_month");
		$bill_month = date("Ym",$bill_month);
		$operator = $this->input->post("operator");
		
		$receivable = $this->db->query(" 
			SELECT SUM(TOTAL) AS TOTAL FROM TBL_ICX_REPORT_DATA 
			WHERE DATE_FORMAT(REPORT_DATE,'%Y%m') = $bill_month
			AND OPERATOR_NAME = '".$operator."'
			GROUP BY OPERATOR_NAME
		");
		
		if( $receivable->num_rows() <= 0 ){
			echo "no-data";
			exit;
		}elseif( $receivable->num_rows() >= 0 ){
			echo $receivable->row()->TOTAL;
			exit;
		}
		
	}
	function payable_invoice_icx_($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_icx');
			$this->webspice->permission_verify('payable_invoice_icx');
			$table_name = "TBL_PAYABLE_INVOICE_ICX";
			
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATOR'=> null,
				'SUPPLIER_CODE'=> null,
				'BILL_MONTH' => null,
				'DOM_INT'=> null,
				'PARTICULARS'=> null,
				'INVOICE_NUMBER' => null,
				'INVOICE_AMOUNT'=> null,
				'INVOICE_DATE'=> null,
				'VAT_RATE'=> null,
				'TAX_RATE'=> null,
				'VAT_CODE'=> "WH/S-52AA/32",
				'TAX_CODE'=> "BL/S012/02",
				'INCLUDED_EXCLUDED'=> null,
				'ADJUSTMENT_VALUE'=> null,
				'TEMP_VALUE'=> null,
				'COLLECTION_DATE'=> date("Y-m-d"),
				'ADJUSTMENT_NOTE' => null,
				'ATTACHMENT'=> null,
				'REPORT_DATE'=>null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATOR','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('SUPPLIER_CODE','Supplier Code','trim|xss_clean');
			$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
			$this->form_validation->set_rules('DOM_INT','Dom Int','required|trim|xss_clean');
			$this->form_validation->set_rules('PARTICULARS','Particulars','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_NUMBER','Invoice Number','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_AMOUNT','Invoice Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_DATE','Invoice Date','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_RATE','Vat Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_RATE','Tax Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_CODE','Vat Code','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_CODE','Tax Code','required|trim|xss_clean');
			$this->form_validation->set_rules('INCLUDED_EXCLUDED','Included Excluded','required|trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_VALUE','Adjustment Value','required|trim|xss_clean');
			$this->form_validation->set_rules('TEMP_VALUE','Temp Value','required|trim|xss_clean');
			$this->form_validation->set_rules('COLLECTION_DATE','Collection Date','required|trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_NOTE','Adjustment Note','trim|xss_clean');
			
			if( !$this->form_validation->run() ){
				$this->load->view('payment/payable_invoice_icx', $data);
				return FALSE;
			}
			
			# get input post
			$input = $this->webspice->get_input('ID');
			
			#duplicate test
		  $this->webspice->db_field_duplicate_test(
			  "SELECT * FROM $table_name WHERE INVOICE_NUMBER=?", 
			  array($input->INVOICE_NUMBER), 
			  'You are not allowed to enter duplicate Invoice!', 
			  'ID', 
			  $input->ID, 
			  $data, 
			  'payment/payable_invoice_icx'
		  );
			
			$allowed_file_type = array('pdf','doc','docx','xls','xlsx','jpg','jpeg','png');
			
			# verify file type for profile picture
			if( $_FILES['ATTACHMENT']['tmp_name'] && file_exists($_FILES['ATTACHMENT']['tmp_name']) ){
		    $attachment_name = $this->webspice->get_safe_url($_FILES['ATTACHMENT']['name']);
				$this->webspice->check_file_type($allowed_file_type, 'ATTACHMENT', $data, 'payment/payable_invoice_icx');
			}else{
				$attachment_name = $data['edit']['ATTACHMENT'];
			}
			
			# update process
			if($input->ID ){
				if(!$_FILES['ATTACHMENT']['tmp_name']){
					$attachment_name = $data['edit']['ATTACHMENT'];
				}
				
				$update_records = array(
					'OPERATOR'=> $input->OPERATOR,
					'SUPPLIER_CODE'=> $input->SUPPLIER_CODE,
					
					'BILL_MONTH' => date("Y-m-d", $input->BILL_MONTH),
					'DOM_INT'=> $input->DOM_INT,
					'PARTICULARS'=> $input->PARTICULARS,
					
					'INVOICE_NUMBER' => $input->INVOICE_NUMBER,
					'INVOICE_AMOUNT'=> $input->INVOICE_AMOUNT,
					'INVOICE_DATE'=> $input->INVOICE_DATE,
					
					'VAT_RATE'=> $input->VAT_RATE,
					'TAX_RATE'=> $input->TAX_RATE,
					'VAT_CODE'=> $input->VAT_CODE,
					'TAX_CODE'=> $input->TAX_CODE,
					
					'INCLUDED_EXCLUDED'=> $input->INCLUDED_EXCLUDED,
					'ADJUSTMENT_VALUE'=> $input->ADJUSTMENT_VALUE,
					'TEMP_VALUE'=> $input->TEMP_VALUE,
					'COLLECTION_DATE'=> $input->COLLECTION_DATE,
					'ADJUSTMENT_NOTE' => $input->ADJUSTMENT_NOTE,
					'ATTACHMENT'=> $attachment_name,
					'UPDATED_BY' => $this->webspice->get_user_id(),
					'UPDATED_DATE' => $this->webspice->now()
				);
				
				$this->db->where('ID', $input->ID);
				$this->db->update($table_name, $update_records);
				
				#upload attachment
				if( $_FILES['ATTACHMENT']['tmp_name'] ){
					$this->webspice->upload_file('ATTACHMENT',$this->webspice->get_path('invoice_full'), $input->ID.'_');
				}
				
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('invoice_number_updated - '.$input->INVOICE_NUMBER);
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_icx');
				return false;
			}
			
			$insert_records = array(
				'OPERATOR'=> $input->OPERATOR,
				'SUPPLIER_CODE'=> $input->SUPPLIER_CODE,
				
				'BILL_MONTH' => date("Y-m-d", $input->BILL_MONTH),
				'DOM_INT'=> $input->DOM_INT,
				'PARTICULARS'=> $input->PARTICULARS,
				
				'INVOICE_NUMBER' => $input->INVOICE_NUMBER,
				'INVOICE_AMOUNT'=> $input->INVOICE_AMOUNT,
				'INVOICE_DATE'=> $input->INVOICE_DATE,
				
				'VAT_RATE'=> $input->VAT_RATE,
				'TAX_RATE'=> $input->TAX_RATE,
				'VAT_CODE'=> $input->VAT_CODE,
				'TAX_CODE'=> $input->TAX_CODE,
				
				'INCLUDED_EXCLUDED'=> $input->INCLUDED_EXCLUDED,
				'ADJUSTMENT_VALUE'=> $input->ADJUSTMENT_VALUE,
				'TEMP_VALUE'=> $input->TEMP_VALUE,
				'COLLECTION_DATE'=> $input->COLLECTION_DATE,
				'ADJUSTMENT_NOTE' => $input->ADJUSTMENT_NOTE,
				'ATTACHMENT'=> $attachment_name,
				'CREATED_BY' => $this->webspice->get_user_id(),
				'CREATED_DATE' => $this->webspice->now(),
				'STATUS' => 7
			);
			
			$this->db->insert($table_name, $insert_records);
			
			if( !$this->db->insert_id() ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			
			#upload profile_picture
			if( $_FILES['ATTACHMENT']['tmp_name'] ){
				$this->webspice->upload_file('ATTACHMENT',$this->webspice->get_path('invoice_full'),$this->db->insert_id().'_');
			}
			
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('manage_payable_invoice_icx', true) ){
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_icx');
			}
			$this->webspice->force_redirect($url_prefix);
	}

	
	function manage_payable_invoice_icx(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_payable_invoice_icx');
			$this->webspice->permission_verify('manage_payable_invoice_icx');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC ';
	    $groupby = null;
	    $no_of_record = 10;
	    $where = " ";
	    $page_index = 0;
	    $limit = " LIMIT $no_of_record ";
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			 if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    	
	    }
	    $data["page_index"] = $page_index;
	    
	    $initialSQL = " SELECT * FROM TBL_PAYABLE_INVOICE_ICX ";
	    
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
					$TableName = 'TBL_PAYABLE_INVOICE_ICX',
					$InputField = array(),
					$Keyword = array('OPERATOR','SUPPLIER_CODE','INVOICE_NUMBER','TAX_CODE'),
					$AdditionalWhere = null,
					$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('payment/print_payable_invoice_icx',$data);
					return false;
	        break;
	        
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_PAYABLE_INVOICE_ICX', $KeyField='ID', $key, $RedirectController='collection_controller', $RedirectFunction='payable_invoice_icx', $PermissionName='payable_invoice_icx', $StatusCheck=null, $Log='edit_payable_invoice_icx');          
					return false;
          break;
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    # only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_payable_invoice_icx/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('payment/manage_payable_invoice_icx', $data);
	}
	function get_supplier_code(){
		$op_name = $this->input->post("op_name");
		$result = $this->db->get_where('TBL_OPERATOR', array('OPERATOR_NAME' => $op_name, 'STATUS'=>7));
		$config= $result->result();
		if(empty($config)){
		$config[0]=0;	
		}
		//dd($config[0]);
		echo ($config[0]);
		exit;
	}
	function get_bl_amount(){
		$op_name_temp = $this->input->post("op_name");
		$name_type_array=explode("|",$op_name_temp);
		$op_name=$name_type_array[0];
		$year = $this->input->post("year");
		$month = $this->input->post("month");
	  $month=$month+1;
		$calculative_month=strtotime($month.'/01/'.$year);
		$report_date=date("Y-m-d",$calculative_month);
		$sql="SELECT A.OPERATOR_NAME,A.PRE_POST,SUM(A.AMOUNT) AS OP_MOC_AMOUNT ,(SELECT SUM(B.AMOUNT) AS MOMMS_AMOUNT FROM TBL_FULL_MONTH_MOMMS AS B WHERE B.REPORT_DATE='".$report_date."' AND B.OPERATOR_NAME=A.OPERATOR_NAME AND B.PRE_POST=A.PRE_POST GROUP BY B.OPERATOR_NAME) AS MOMMS_AMOUNT,(SELECT SUM(C.AMOUNT) AS MOSMS_AMOUNT FROM TBL_FULL_MONTH_MOSMS AS C WHERE C.REPORT_DATE='".$report_date."' AND C.OPERATOR_NAME=A.OPERATOR_NAME AND C.PRE_POST=A.PRE_POST GROUP BY C.OPERATOR_NAME) AS MOSMS_AMOUNT FROM TBL_OP_MOC AS A 
		
		WHERE A.REPORT_DATE='".$report_date."' AND A.OPERATOR_NAME='".$op_name."' GROUP BY A.OPERATOR_NAME,A.PRE_POST";
		$record=$this->db->query($sql);
		//dd($record);
		//dd($this->db->last_query() );
		//$SQL='LEFT JOIN TBL_FULL_MONTH_MOMMS AS B ON A.OPERATOR_NAME=B.OPERATOR_NAME LEFT JOIN TBL_FULL_MONTH_MOSMS AS C ON A.OPERATOR_NAME=C.OPERATOR_NAME';
		$config= $record->result();
		echo json_encode($config);
		exit;
	}
	function payable_invoice_mobile_($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_mobile');
			$this->webspice->permission_verify('payable_invoice_mobile');
			$table_name = "TBL_PAYABLE_INVOICE_MOBILE";
			
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATOR'=> null,
				'SUPPLIER_CODE'=> null,
				'BILL_MONTH' => null,
				'DOM_INT'=> null,
				'PARTICULARS'=> null,
				'INVOICE_NUMBER' => null,
				'INVOICE_AMOUNT'=> null,
				'INVOICE_DATE'=> null,
				'VAT_RATE'=> null,
				'TAX_RATE'=> null,
				'VAT_CODE'=> "WH/S-52AA/32",
				'TAX_CODE'=> "BL/S012/02",
				'INCLUDED_EXCLUDED'=> null,
				'ADJUSTMENT_VALUE'=> null,
				'TEMP_VALUE'=> null,
				'COLLECTION_DATE'=> date("Y-m-d"),
				'ADJUSTMENT_NOTE' => null,
				'ATTACHMENT'=> null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATOR','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('SUPPLIER_CODE','Supplier Code','trim|xss_clean');
			$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
			$this->form_validation->set_rules('DOM_INT','Dom Int','required|trim|xss_clean');
			$this->form_validation->set_rules('PARTICULARS','Particulars','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_NUMBER','Invoice Number','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_AMOUNT','Invoice Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_DATE','Invoice Date','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_RATE','Vat Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_RATE','Tax Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_CODE','Vat Code','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_CODE','Tax Code','required|trim|xss_clean');
			$this->form_validation->set_rules('INCLUDED_EXCLUDED','Included Excluded','required|trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_VALUE','Adjustment Value','required|trim|xss_clean');
			$this->form_validation->set_rules('TEMP_VALUE','Temp Value','required|trim|xss_clean');
			$this->form_validation->set_rules('COLLECTION_DATE','Collection Date','required|trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_NOTE','Adjustment Note','trim|xss_clean');
			
			if( !$this->form_validation->run() ){
				$this->load->view('payment/payable_invoice_icx', $data);
				return FALSE;
			}
			
			# get input post
			$input = $this->webspice->get_input('ID');
			
			#duplicate test
		  $this->webspice->db_field_duplicate_test(
			  "SELECT * FROM $table_name WHERE INVOICE_NUMBER=?", 
			  array($input->INVOICE_NUMBER), 
			  'You are not allowed to enter duplicate Invoice!', 
			  'ID', 
			  $input->ID, 
			  $data, 
			  'payment/payable_invoice_icx'
		  );
			
			$allowed_file_type = array('pdf','doc','docx','xls','xlsx','jpg','jpeg','png');
			
			# verify file type for profile picture
			if( $_FILES['ATTACHMENT']['tmp_name'] && file_exists($_FILES['ATTACHMENT']['tmp_name']) ){
		    $attachment_name = $this->webspice->get_safe_url($_FILES['ATTACHMENT']['name']);
				$this->webspice->check_file_type($allowed_file_type, 'ATTACHMENT', $data, 'payment/payable_invoice_icx');
			}else{
				$attachment_name = $data['edit']['ATTACHMENT'];
			}
			
			# update process
			if($input->ID ){
				if(!$_FILES['ATTACHMENT']['tmp_name']){
					$attachment_name = $data['edit']['ATTACHMENT'];
				}
				
				$update_records = array(
					'OPERATOR'=> $input->OPERATOR,
					'SUPPLIER_CODE'=> $input->SUPPLIER_CODE,
					
					'BILL_MONTH' => date("Y-m-d", $input->BILL_MONTH),
					'DOM_INT'=> $input->DOM_INT,
					'PARTICULARS'=> $input->PARTICULARS,
					
					'INVOICE_NUMBER' => $input->INVOICE_NUMBER,
					'INVOICE_AMOUNT'=> $input->INVOICE_AMOUNT,
					'INVOICE_DATE'=> $input->INVOICE_DATE,
					
					'VAT_RATE'=> $input->VAT_RATE,
					'TAX_RATE'=> $input->TAX_RATE,
					'VAT_CODE'=> $input->VAT_CODE,
					'TAX_CODE'=> $input->TAX_CODE,
					
					'INCLUDED_EXCLUDED'=> $input->INCLUDED_EXCLUDED,
					'ADJUSTMENT_VALUE'=> $input->ADJUSTMENT_VALUE,
					'TEMP_VALUE'=> $input->TEMP_VALUE,
					'COLLECTION_DATE'=> $input->COLLECTION_DATE,
					'ADJUSTMENT_NOTE' => $input->ADJUSTMENT_NOTE,
					'ATTACHMENT'=> $attachment_name,
					'UPDATED_BY' => $this->webspice->get_user_id(),
					'UPDATED_DATE' => $this->webspice->now()
				);
				
				$this->db->where('ID', $input->ID);
				$this->db->update($table_name, $update_records);
				
				#upload attachment
				if( $_FILES['ATTACHMENT']['tmp_name'] ){
					$this->webspice->upload_file('ATTACHMENT',$this->webspice->get_path('invoice_full'), $input->ID.'_');
				}
				
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('invoice_number_updated - '.$input->INVOICE_NUMBER);
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_icx');
				return false;
			}
			
			$insert_records = array(
				'OPERATOR'=> $input->OPERATOR,
				'SUPPLIER_CODE'=> $input->SUPPLIER_CODE,
				
				'BILL_MONTH' => date("Y-m-d", $input->BILL_MONTH),
				'DOM_INT'=> $input->DOM_INT,
				'PARTICULARS'=> $input->PARTICULARS,
				
				'INVOICE_NUMBER' => $input->INVOICE_NUMBER,
				'INVOICE_AMOUNT'=> $input->INVOICE_AMOUNT,
				'INVOICE_DATE'=> $input->INVOICE_DATE,
				
				'VAT_RATE'=> $input->VAT_RATE,
				'TAX_RATE'=> $input->TAX_RATE,
				'VAT_CODE'=> $input->VAT_CODE,
				'TAX_CODE'=> $input->TAX_CODE,
				
				'INCLUDED_EXCLUDED'=> $input->INCLUDED_EXCLUDED,
				'ADJUSTMENT_VALUE'=> $input->ADJUSTMENT_VALUE,
				'TEMP_VALUE'=> $input->TEMP_VALUE,
				'COLLECTION_DATE'=> $input->COLLECTION_DATE,
				'ADJUSTMENT_NOTE' => $input->ADJUSTMENT_NOTE,
				'ATTACHMENT'=> $attachment_name,
				'CREATED_BY' => $this->webspice->get_user_id(),
				'CREATED_DATE' => $this->webspice->now(),
				'STATUS' => 7
			);
			
			$this->db->insert($table_name, $insert_records);
			
			if( !$this->db->insert_id() ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			
			#upload profile_picture
			if( $_FILES['ATTACHMENT']['tmp_name'] ){
				$this->webspice->upload_file('ATTACHMENT',$this->webspice->get_path('invoice_full'),$this->db->insert_id().'_');
			}
			
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('manage_payable_invoice_icx', true) ){
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_icx');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	/**
	 * This method will generate Payable Invoice ICX Report 
	 * @return array of object
	 */
	function payable_invoice_icx_report_(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_icx_report');
		$this->webspice->permission_verify('payable_invoice_icx_report');

		if( !$_POST ){
			$this->load->view('payment/payable_invoice_icx_report');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$operator = $input->operator;
		$calculative_month = $input->calculative_month;

		$sql = "SELECT PII.OPERATOR, PII.SUPPLIER_CODE, PII.BILL_MONTH, PII.INVOICE_NUMBER, PII.INVOICE_AMOUNT, 
				PII.COLLECTION_DATE, PII.INVOICE_DATE, PII.VAT_RATE, PII.TAX_RATE, OP.OPERATOR_TYPE";
		$sql .= " FROM TBL_PAYABLE_INVOICE_ICX PII";	
		$sql .= " LEFT JOIN TBL_OPERATOR OP ON PII.OPERATOR = OP.OPERATOR_NAME";
		$sql .= " WHERE 1=1";
		$sql .= " AND PII.OPERATOR = '".$input->operator."'";
		$sql .= " AND DATE_FORMAT(PII.BILL_MONTH,'%Y-%m') = '".date("Y-m", $calculative_month)."'";
		$sql .= " LIMIT 1";

		$record = $this->db->query($sql)->row();

		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payable_invoice_icx_report');
			return false;
		}

		$data['postpaid'] =  370566.00;
		$data['prepaid'] =   2333142.00;

		$data['record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		}

		$this->load->view('payment/print_payable_invoice_icx_report', $data);
	}

	/**
	 * This method will generate Payable Invoice Mobile PSTN IPTSP Report 
	 * @return array of object
	 */
	function payable_invoic_mobile_pstn_iptsp_report____(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoic_mobile_pstn_iptsp_report');
		$this->webspice->permission_verify('payable_invoic_mobile_pstn_iptsp_report');

		if( !$_POST ){
			$this->load->view('payment/payable_invoic_mobile_pstn_iptsp_report');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();

		// var_dump($input); exit;

		$operator = $input->operator;
		$calculative_month = $input->calculative_month;

		
		$sql = "SELECT * FROM TBL_PAYABLE_INVOICE_MOBILE";
		$sql .= " WHERE OPERATOR = '".$input->operator."'";
		$sql .= " AND DATE_FORMAT(REPORT_DATE,'%Y-%m') = '".date("Y-m", $calculative_month)."'";
		$sql .= " GROUP BY INVOICE_NUMBER";
		$sql .= " ORDER BY INVOICE_NUMBER DESC";

		$records = $this->db->query($sql)->result();

		if( !$records ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payable_invoic_mobile_pstn_iptsp_report');
			return false;
		}
		$data['records'] = $records;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		}

		$this->load->view('payment/print_payable_invoic_mobile_pstn_iptsp_report', $data);
	}
	
	
	
	
	
	
	
	function payable_invoic_mobile_pstn_iptsp_report(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoic_mobile_pstn_iptsp_report');
		$this->webspice->permission_verify('payable_invoic_mobile_pstn_iptsp_report');

		if( !$_POST ){
			$this->load->view('payment/payable_invoic_mobile_pstn_iptsp_report');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();

		// var_dump($input); exit;

		$operator = $input->operator;
		$calculative_month = $input->calculative_month;


		$sql = "SELECT OPERATOR, SUPPLIER_CODE, BILL_MONTH, INVOICE_NUMBER, INVOICE_AMOUNT, 
				COLLECTION_DATE, INVOICE_DATE, VAT_RATE, TAX_RATE, PARTICULARS";
		$sql .= " FROM TBL_PAYABLE_INVOICE_ICX";	
		$sql .= " WHERE 1=1";
		$sql .= " AND OPERATOR = '".$input->operator."'";
		$sql .= " AND DATE_FORMAT(REPORT_DATE,'%Y-%m') = '".date("Y-m", $calculative_month)."'";
		$sql .= " GROUP BY PARTICULARS";
		$sql .= " ORDER BY PARTICULARS DESC";
		// $sql .= " LIMIT 1";

		$records = $this->db->query($sql)->result();

		if( !$records ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payable_invoic_mobile_pstn_iptsp_report');
			return false;
		}

		$data['record'] = $this->db->query(
			"SELECT OP.OPERATOR_TYPE, PII.REPORT_DATE, PII.OPERATOR, PII.INVOICE_NUMBER, PII.SUPPLIER_CODE, PII.VAT_RATE, PII.TAX_RATE
			FROM TBL_PAYABLE_INVOICE_ICX PII
			LEFT JOIN TBL_OPERATOR OP ON PII.OPERATOR = OP.OPERATOR_NAME
			WHERE PII.OPERATOR = '".$input->operator."' 
			AND DATE_FORMAT(PII.REPORT_DATE, '%Y-%m') = '".date("Y-m", $calculative_month)."' 
			LIMIT 1")->row();

		$data['voice_postpaid'] 	=  $this->db->query("SELECT SUM(AMOUNT) AMOUNT FROM TBL_OP_MOC WHERE OPERATOR_NAME = '".$input->operator."' AND DATE_FORMAT(REPORT_DATE, '%Y-%m') = '".date("Y-m", $calculative_month)."' AND PRE_POST = 'POST'")->row()->AMOUNT;
		$data['voice_prepaid'] 		=  $this->db->query("SELECT SUM(AMOUNT) AMOUNT FROM TBL_OP_MOC WHERE OPERATOR_NAME = '".$input->operator."' AND DATE_FORMAT(REPORT_DATE, '%Y-%m') = '".date("Y-m", $calculative_month)."' AND PRE_POST = 'PREP'")->row()->AMOUNT;
		$data['sms_postpaid'] 		=  $this->db->query("SELECT SUM(AMOUNT) AMOUNT FROM TBL_FULL_MONTH_MOSMS WHERE OPERATOR_NAME = '".$input->operator."' AND DATE_FORMAT(REPORT_DATE, '%Y-%m') = '".date("Y-m", $calculative_month)."' AND PRE_POST = 'POST'")->row()->AMOUNT;
		$data['sms_prepaid'] 		=  $this->db->query("SELECT SUM(AMOUNT) AMOUNT FROM TBL_FULL_MONTH_MOSMS WHERE OPERATOR_NAME = '".$input->operator."' AND DATE_FORMAT(REPORT_DATE, '%Y-%m') = '".date("Y-m", $calculative_month)."' AND PRE_POST = 'PREP'")->row()->AMOUNT;
		$data['mms_postpaid'] 		=  $this->db->query("SELECT SUM(AMOUNT) AMOUNT FROM TBL_FULL_MONTH_MOMMS WHERE OPERATOR_NAME = '".$input->operator."' AND DATE_FORMAT(REPORT_DATE, '%Y-%m') = '".date("Y-m", $calculative_month)."' AND PRE_POST = 'POST'")->row()->AMOUNT;
		$data['mms_prepaid'] 		=  $this->db->query("SELECT SUM(AMOUNT) AMOUNT FROM TBL_FULL_MONTH_MOMMS WHERE OPERATOR_NAME = '".$input->operator."' AND DATE_FORMAT(REPORT_DATE, '%Y-%m') = '".date("Y-m", $calculative_month)."' AND PRE_POST = 'PREP'")->row()->AMOUNT;
		$data['WITHOUT_VAT']		= 12;

		$data['records'] = $records;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		}

		$this->load->view('payment/print_payable_invoic_mobile_pstn_iptsp_report', $data);
	}
	
	function payable_invoice_mobile($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_mobile');
			$this->webspice->permission_verify('payable_invoice_mobile');
			$table_name = "TBL_PAYABLE_INVOICE_MOBILE";
			
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'ID'=> null,
				'OPERATOR'=> null,
				'SUPPLIER_CODE'=> null,
				'REPORT_DATE' => null,
				'DOM_INT'=> null,
				'INVOICE_UNIQUE_CODE' =>null,
				'INVOICE_NUMBER'=> null,
				'VAT_RATE' => null,
				'TAX_RATE'=> null,
				'VAT_CODE'=> "WH/S-52AA/32",
				'TAX_CODE'=> "BL/S012/02",
				'ACTUAL_INVOICE_AMOUNT_FOR_VOICE'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX'=> null,
				'TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_SMS'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX'=> null,
				'TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_MMS'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT'=> null,
				'ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX'=> null,
				'TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX'=> null,
				'PRE_VOICE_BL'=> null,
				'POST_VOICE_BL'=> null,
				'PRE_POST_VOICE_BL'=> null,
				'ADJUSTMENT_VOICE_BL'=> null,
				'PRE_SMS_BL'=> null,
				'POST_SMS_BL'=> null,
				'PRE_POST_SMS_BL'=> null,
				'ADJUSTMENT_SMS_BL'=> null,
				'PRE_MMS_BL'=> null,
				'POST_MMS_BL'=> null,
				'PRE_POST_MMS_BL'=> null,
				'ADJUSTMENT_MMS_BL'=> null	
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATOR','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('SUPPLIER_CODE','Supplier Code','trim|xss_clean');
			$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_RATE','Vat Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_RATE','Tax Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_CODE','Vat Code','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_CODE','Tax Code','required|trim|xss_clean');
			$this->form_validation->set_rules('DOM_INT','Dom Int','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_VOICE','Actual invoice amount for voice','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT','Actual invoice amount for voice after vat','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX','Actual invoice amount for voice after tax','required|trim|xss_clean');
			$this->form_validation->set_rules('TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX','Total invoice amount for voice after tax','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_SMS','Actual invoice amount for sms','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT','Actual invoice amount for sms after vat','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX','Actual invoice amount for sms after tax','required|trim|xss_clean');
			$this->form_validation->set_rules('TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX','Total invoice amount for sms after tax','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_MMS','Actual invoice amount for mms','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT','Actual invoice amount for mms after vat','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX','Actual invoice Amount for mms after tax','required|trim|xss_clean');
			$this->form_validation->set_rules('TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX','Total Invoice Amount for mms after tax','required|trim|xss_clean');
			$this->form_validation->set_rules('PRE_VOICE_BL','Pre voice Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('POST_VOICE_BL','Post voice Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('PRE_POST_VOICE_BL','Pre post voice Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_VOICE_BL','Adjustment voice Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('PRE_SMS_BL','Pre sms Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('POST_SMS_BL','Post sms Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('PRE_POST_SMS_BL','Pre Post sms Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_SMS_BL','Adjustment sms Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('PRE_MMS_BL','Pre mms Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('POST_MMS_BL','Post mms Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('PRE_POST_MMS_BL','Pre Post mms Bl','required|trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_MMS_BL','Adjustment mms Bl','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
				$this->load->view('payment/payable_invoice_mobile', $data);
				return FALSE;
			}

			# get input post
			$input = $this->webspice->get_input('ID');
			$operator_name_type=$input->OPERATOR;
			$operator_name_type_array=explode("|",$operator_name_type);
			$input->OPERATOR=$operator_name_type_array[0];
			$operator_type=$operator_name_type_array[1];
			$calculative_month = $this->input->post("BILL_MONTH");
		  $report_date=date("Y-m-d",$calculative_month);
		   $invoice_unique_code=$input->INVOICE_UNIQUE_CODE;
		  $invoice_number=$input->INVOICE_NUMBER;
		  $invoice_array=explode("/",$invoice_number);
		  $input->INVOICE_NUMBER=$invoice_array[0].'/'.html_entity_decode($invoice_array[1]).'/'.$invoice_unique_code.'/'.$invoice_array[2];
			#duplicate test
		  $this->webspice->db_field_duplicate_test(
			  "SELECT * FROM $table_name WHERE INVOICE_NUMBER=? AND OPERATOR=? AND REPORT_DATE=?", 
			  array($input->INVOICE_NUMBER,$input->OPERATOR,$report_date), 
			  'You are not allowed to enter duplicate Invoice!', 
			  'ID', 
			  $_POST['ID'], 
			  $data, 
			  'payment/payable_invoice_mobile'
		  );  			
			$this->webspice->remove_cache('payable_invoice_mobile');
			if($_POST['ID']){
				
				$sql = "UPDATE TBL_PAYABLE_INVOICE_MOBILE SET OPERATOR=?,SUPPLIER_CODE=?, DOM_INT=?, VAT_RATE=?, TAX_RATE=?, VAT_CODE=?, TAX_CODE=?, ACTUAL_INVOICE_AMOUNT_FOR_VOICE=?, ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT=?, ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX=?, TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX=?,ACTUAL_INVOICE_AMOUNT_FOR_SMS=?, ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT=?,ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX=?, TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX=?, ACTUAL_INVOICE_AMOUNT_FOR_MMS=?, ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT=?, ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX=?, TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX=?, PRE_VOICE_BL=?, POST_VOICE_BL=?, PRE_POST_VOICE_BL=?, ADJUSTMENT_VOICE_BL=?,PRE_SMS_BL=?, POST_SMS_BL=?,PRE_POST_SMS_BL=?, ADJUSTMENT_SMS_BL=?, PRE_MMS_BL=?, POST_MMS_BL=?, PRE_POST_MMS_BL=?, ADJUSTMENT_MMS_BL=?,UPDATED_BY=?, UPDATED_DATE=?,REPORT_DATE=?,INVOICE_NUMBER=?
				WHERE ID=?";
				$this->db->query($sql , array($input->OPERATOR,$input->SUPPLIER_CODE,$input->DOM_INT, $input->VAT_RATE, $input->TAX_RATE, $input->VAT_CODE, $input->TAX_CODE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX, $input->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX,$input->ACTUAL_INVOICE_AMOUNT_FOR_SMS, $input->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT,$input->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX, $input->TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX, $input->ACTUAL_INVOICE_AMOUNT_FOR_MMS, $input->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT, $input->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX, $input->TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX, $input->PRE_VOICE_BL, $input->POST_VOICE_BL, $input->PRE_POST_VOICE_BL, $input->ADJUSTMENT_VOICE_BL,$input->PRE_SMS_BL, $input->POST_SMS_BL,$input->PRE_POST_SMS_BL, $input->ADJUSTMENT_SMS_BL, $input->PRE_MMS_BL, $input->POST_MMS_BL, $input->PRE_POST_MMS_BL, $input->ADJUSTMENT_MMS_BL, $this->webspice->get_user_id(), $this->webspice->now(),$report_date,$input->INVOICE_NUMBER, $_POST['ID']));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('payable_invoice_mobile - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_mobile');
				return false;
			}
			$sql = "
			INSERT INTO TBL_PAYABLE_INVOICE_MOBILE
			(OPERATOR,OPERATOR_TYPE,SUPPLIER_CODE, DOM_INT, VAT_RATE, TAX_RATE, VAT_CODE, TAX_CODE, ACTUAL_INVOICE_AMOUNT_FOR_VOICE, ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT, ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX, TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX,ACTUAL_INVOICE_AMOUNT_FOR_SMS, ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT,ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX, TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX, ACTUAL_INVOICE_AMOUNT_FOR_MMS, ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT, ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX, TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX, PRE_VOICE_BL, POST_VOICE_BL, PRE_POST_VOICE_BL, ADJUSTMENT_VOICE_BL,PRE_SMS_BL, POST_SMS_BL,PRE_POST_SMS_BL, ADJUSTMENT_SMS_BL, PRE_MMS_BL, POST_MMS_BL, PRE_POST_MMS_BL, ADJUSTMENT_MMS_BL,CREATED_BY, CREATED_DATE,REPORT_DATE,INVOICE_NUMBER)
			VALUES
			(?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $this->db->query($sql, array($input->OPERATOR,$operator_type,$input->SUPPLIER_CODE,$input->DOM_INT, $input->VAT_RATE, $input->TAX_RATE, $input->VAT_CODE, $input->TAX_CODE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX, $input->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX,$input->ACTUAL_INVOICE_AMOUNT_FOR_SMS, $input->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT,$input->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX, $input->TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX, $input->ACTUAL_INVOICE_AMOUNT_FOR_MMS, $input->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT, $input->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX, $input->TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX, $input->PRE_VOICE_BL, $input->POST_VOICE_BL, $input->PRE_POST_VOICE_BL, $input->ADJUSTMENT_VOICE_BL,$input->PRE_SMS_BL, $input->POST_SMS_BL,$input->PRE_POST_SMS_BL, $input->ADJUSTMENT_SMS_BL, $input->PRE_MMS_BL, $input->POST_MMS_BL, $input->PRE_POST_MMS_BL, $input->ADJUSTMENT_MMS_BL, $this->webspice->get_user_id(), $this->webspice->now(),$report_date,$input->INVOICE_NUMBER));  
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('payable_invoice_mobile', true) ){
				$this->webspice->force_redirect($url_prefix.'payable_invoice_mobile');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	function manage_payable_invoice_mobile(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_payable_invoice_mobile');
			$this->webspice->permission_verify('manage_payable_invoice_mobile');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC ';
	    $groupby = null;
	    $no_of_record = 10;
	    $where = " ";
	    $page_index = 0;
	    $limit = " LIMIT $no_of_record ";
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			 if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    	
	    }
	    $data["page_index"] = $page_index;
	    
	    $initialSQL = " SELECT * FROM TBL_PAYABLE_INVOICE_MOBILE";
	    
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
					$TableName = 'TBL_PAYABLE_INVOICE_MOBILE',
					$InputField = array(),
					$Keyword = array('OPERATOR','SUPPLIER_CODE','DOM_INT', 'VAT_CODE','TAX_CODE'),
					$AdditionalWhere = null,
					$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('payment/print_payable_invoice_mobile',$data);
					return false;
	        break;
	        
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_PAYABLE_INVOICE_MOBILE', $KeyField='ID', $key, $RedirectController='collection_controller', $RedirectFunction='payable_invoice_mobile', $PermissionName='payable_invoice_mobile', $StatusCheck=null, $Log='edit_payable_invoice_mobile');          
					return false;
          break;
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    # only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_payable_invoice_mobile/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('payment/manage_payable_invoice_mobile', $data);
	}
	
	function payable_invoice_mobile_report(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_mobile_report');
		$this->webspice->permission_verify('payable_invoice_mobile_report');

		if( !$_POST ){
			$this->load->view('payment/payable_invoice_mobile_report');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$operator = $input->operator;
		$sql_for_gl="SELECT * FROM TBL_DOMESTIC_COST_GL_MAPPING WHERE OPERATOR_NAME='".$operator."'";
		$sql_for_type="SELECT * FROM TBL_OPERATOR WHERE OPERATOR_NAME='".$operator."'";
		$calculative_month = $input->calculative_month;
		$sql = "SELECT * FROM TBL_PAYABLE_INVOICE_MOBILE";
		$sql .= " WHERE OPERATOR = '".$input->operator."'";
		$sql .= " AND DATE_FORMAT(REPORT_DATE,'%Y-%m') = '".date("Y-m", $calculative_month)."'";
		
		$data['operator_info'] = $this->db->query($sql_for_type)->row();
		$data['gl_info'] = $this->db->query($sql_for_gl)->row();
		$record = $this->db->query($sql)->row();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payable_invoice_mobile_report');
			return false;
		}
		$data['record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		}
		$this->load->view('payment/print_payable_invoice_mobile_report', $data);
	}
	
	function get_short_name(){
		$type = $this->input->post("type");
		$op_name = $this->input->post("op_name");
		$year = $this->input->post("year");
		$month = $this->input->post("month");
		$sql="SELECT OPERATOR_SHORT_CODE FROM TBL_OPERATOR WHERE OPERATOR_NAME='".$op_name."' AND OPERATOR_TYPE='".$type."'";
		$record=$this->db->query($sql);
		$config= $record->result();
		echo json_encode($config);
		exit;
	}
	
	function get_bl_amount_for_icx(){
		$op_name = $this->input->post("op_name");
		$year = $this->input->post("year");
		$month = $this->input->post("month");
		$dom_int=$this->input->post("dom_int");
		
	    $month=$month+1;
		$calculative_month=strtotime($month.'/01/'.$year);
		$report_date=date("Y-m-d",$calculative_month);
		//$sql="SELECT OPERATOR_NAME,PRE_POST,SUM(AMOUNT) AS OP_MOC_AMOUNT FROM TBL_ICX_MOC WHERE REPORT_DATE='".$report_date."' AND ICX='".$op_name."' GROUP BY OPERATOR_NAME,PRE_POST";
		
		
		if($dom_int=='INT'){
		$sql="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT END ) AS  PRE_AMT,
 SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT END ) AS  POST_AMT
FROM
 (
 SELECT
    m.OPERATOR_NAME AS OPERATOR_NAME,
   m.OPERATOR_TYPE AS OPERATOR_TYPE,
   m.ICX_PORTION AS AMOUNT,
   m.PREP_POST AS PRE_POST,
   m.REPORT_DATE AS REPORT_DATE
 FROM
   TBL_FULL_MONTH_MOID m
   
   
   
   
   
   ) AS TBL_NEW_TEMP 
 WHERE REPORT_DATE='".$report_date."' AND OPERATOR_NAME='".$op_name."'
 
GROUP BY OPERATOR_NAME,OPERATOR_TYPE ";


		}else{
			
			$sql="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT END ) AS  PRE_AMT,
 SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT END ) AS  POST_AMT
FROM
 (

 SELECT
   ic.ICX AS OPERATOR_NAME,
   ic.OPERATOR_TYPE AS OPERATOR_TYPE,
   ic.AMOUNT AS AMOUNT,
   ic.PRE_POST AS PRE_POST,
   ic.REPORT_DATE AS REPORT_DATE
 FROM
   TBL_ICX_MOC ic
   ) AS TBL_NEW_TEMP 
 WHERE REPORT_DATE='".$report_date."' AND OPERATOR_NAME='".$op_name."'
 
GROUP BY OPERATOR_NAME,OPERATOR_TYPE ";
		
			
		}
//dd($sql);
		$record=$this->db->query($sql);
		//dd($this->db->last_query());
		$config= $record->result();
		echo json_encode($config);
		exit;
	}
	
	
	
	
	function get_bl_amount_for_igw(){
		$op_name = $this->input->post("op_name");
		$year = $this->input->post("year");
		$month = $this->input->post("month");
	    $month=$month+1;
		$calculative_month=strtotime($month.'/01/'.$year);
		$report_date=date("Y-m-d",$calculative_month);
		//$sql="SELECT OPERATOR_NAME,OPERATOR_TYPE,SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT END ) AS  PRE_AMT, SUM ( CASE WHEN PRE_POST = 'POST' THEN AMOUNT END ) AS  POST_AMT FROM (SELECT s.OPERATOR_NAME AS OPERATOR_NAME, s.OPERATOR_TYPE AS OPERATOR_TYPE,
  // s.TOTAL AS AMOUNT,
  // s.PRE_POST AS PRE_POST,
  // s.REPORT_DATE AS REPORT_DATE
   
 //FROM
//   TBL_OP_MOC s
// UNION
// SELECT
//   a.OPERATOR_NAME AS OPERATOR_NAME,
//   a.OPERATOR_TYPE AS OPERATOR_TYPE,
//   a.TOTAL_COST AS AMOUNT,
//   a.PREP_POST AS PRE_POST,
//   a.REPORT_DATE AS REPORT_DATE
// FROM
//   TBL_FULL_MONTH_MOID a ) AS TBL_NEW_TEMP 
//   ";
		
//dd($sql);
		$record=$this->db->query($sql);
		//dd($this->db->last_query());
		$config= $record->result();
		echo json_encode($config);
		exit;
	}
	
	
	function payable_invoice_icx__($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_icx');
			$this->webspice->permission_verify('payable_invoice_icx');
			$table_name = "TBL_PAYABLE_INVOICE_ICX";
			
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATOR'=> null,
				'SUPPLIER_CODE'=> null,
				'BILL_MONTH' => null,
				'DOM_INT'=> null,
				'INVOICE_NUMBER' => null,
				'VAT_RATE'=> null,
				'TAX_RATE'=> null,
				'VAT_CODE'=> "WH/S-52AA/32",
				'TAX_CODE'=> "BL/S012/02",
				'ACTUAL_INVOICE_AMOUNT_FOR_VOICE'=> null,
				'VAT'=> null,
				'TAX'=> null,
				//'COLLECTION_DATE'=> date("Y-m-d"),
				'TOTAL_AMOUNT' => null,
				'POST_VOICE_BL'=> null,
				'PRE_VOICE_BL'=>null,
				'TOTAL_BL_AMOUNT'=>null,
				'ADJUSTMENT'=>null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATOR','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('SUPPLIER_CODE','Supplier Code','trim|xss_clean');
			$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
			$this->form_validation->set_rules('DOM_INT','Dom Int','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_NUMBER','Invoice Number','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_RATE','Vat Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_RATE','Tax Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_CODE','Vat Code','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_CODE','Tax Code','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_VOICE','Actual Invoice Amount for Voice','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT','Vat','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX','Tax','required|trim|xss_clean');
			$this->form_validation->set_rules('TOTAL_AMOUNT','Total Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('POST_VOICE_BL','Post Voice BL','trim|xss_clean');
			$this->form_validation->set_rules('PRE_VOICE_BL','Pre Voice BL','trim|xss_clean');
			$this->form_validation->set_rules('TOTAL_BL_AMOUNT','Total BL Amount','trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT','adjustment','trim|xss_clean');
			
			if( !$this->form_validation->run() ){
				$this->load->view('payment/payable_invoice_icx', $data);
				return FALSE;
			}
			
			# get input post
			$input = $this->webspice->get_input('ID');
			
			#duplicate test
		  $this->webspice->db_field_duplicate_test(
			  "SELECT * FROM $table_name WHERE INVOICE_NUMBER=? AND OPERATOR=?", 
			  array($input->INVOICE_NUMBER,$input->OPERATOR), 
			  'You are not allowed to enter duplicate Invoice!', 
			  'ID', 
			  $input->ID, 
			  $data, 
			  'payment/payable_invoice_icx'
		  );
		  
		  
		  
		  
		  
		  
		  
		  
			# update process
			if($input->ID ){
				if(!$_FILES['ATTACHMENT']['tmp_name']){
					$attachment_name = $data['edit']['ATTACHMENT'];
				}
				
				$update_records = array(
					'OPERATOR'=> $input->OPERATOR,
					'SUPPLIER_CODE'=> $input->SUPPLIER_CODE,
					
					'BILL_MONTH' => date("Y-m-d", $input->BILL_MONTH),
					'DOM_INT'=> $input->DOM_INT,
					'PARTICULARS'=> $input->PARTICULARS,
					
					'INVOICE_NUMBER' => $input->INVOICE_NUMBER,
					'INVOICE_AMOUNT'=> $input->INVOICE_AMOUNT,
					'INVOICE_DATE'=> $input->INVOICE_DATE,
					
					'VAT_RATE'=> $input->VAT_RATE,
					'TAX_RATE'=> $input->TAX_RATE,
					'VAT_CODE'=> $input->VAT_CODE,
					'TAX_CODE'=> $input->TAX_CODE,
					
					'INCLUDED_EXCLUDED'=> $input->INCLUDED_EXCLUDED,
					'ADJUSTMENT_VALUE'=> $input->ADJUSTMENT_VALUE,
					'TEMP_VALUE'=> $input->TEMP_VALUE,
					'COLLECTION_DATE'=> $input->COLLECTION_DATE,
					'ADJUSTMENT_NOTE' => $input->ADJUSTMENT_NOTE,
					'ATTACHMENT'=> $attachment_name,
					'UPDATED_BY' => $this->webspice->get_user_id(),
					'UPDATED_DATE' => $this->webspice->now()
				);
				
				$this->db->where('ID', $input->ID);
				$this->db->update($table_name, $update_records);
				
				#upload attachment
				if( $_FILES['ATTACHMENT']['tmp_name'] ){
					$this->webspice->upload_file('ATTACHMENT',$this->webspice->get_path('invoice_full'), $input->ID.'_');
				}
				
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('invoice_number_updated - '.$input->INVOICE_NUMBER);
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_icx');
				return false;
			}
			
			$insert_records = array(
				'OPERATOR'=> $input->OPERATOR,
				'SUPPLIER_CODE'=> $input->SUPPLIER_CODE,
				
				'BILL_MONTH' => date("Y-m-d", $input->BILL_MONTH),
				'DOM_INT'=> $input->DOM_INT,
				'PARTICULARS'=> $input->PARTICULARS,
				
				'INVOICE_NUMBER' => $input->INVOICE_NUMBER,
				'INVOICE_AMOUNT'=> $input->INVOICE_AMOUNT,
				'INVOICE_DATE'=> $input->INVOICE_DATE,
				
				'VAT_RATE'=> $input->VAT_RATE,
				'TAX_RATE'=> $input->TAX_RATE,
				'VAT_CODE'=> $input->VAT_CODE,
				'TAX_CODE'=> $input->TAX_CODE,
				
				'INCLUDED_EXCLUDED'=> $input->INCLUDED_EXCLUDED,
				'ADJUSTMENT_VALUE'=> $input->ADJUSTMENT_VALUE,
				'TEMP_VALUE'=> $input->TEMP_VALUE,
				'COLLECTION_DATE'=> $input->COLLECTION_DATE,
				'ADJUSTMENT_NOTE' => $input->ADJUSTMENT_NOTE,
				'ATTACHMENT'=> $attachment_name,
				'CREATED_BY' => $this->webspice->get_user_id(),
				'CREATED_DATE' => $this->webspice->now(),
				'STATUS' => 7
			);
			
			$this->db->insert($table_name, $insert_records);
			
			if( !$this->db->insert_id() ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			
			#upload profile_picture
			if( $_FILES['ATTACHMENT']['tmp_name'] ){
				$this->webspice->upload_file('ATTACHMENT',$this->webspice->get_path('invoice_full'),$this->db->insert_id().'_');
			}
			
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('manage_payable_invoice_icx', true) ){
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_icx');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function payable_invoice_icx($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_icx');
			$this->webspice->permission_verify('payable_invoice_icx');
			$table_name = "TBL_PAYABLE_INVOICE_ICX";
			
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATOR'=> null,
				'SUPPLIER_CODE'=> null,
				'BILL_MONTH' => null,
				'DOM_INT'=> null,
				'INVOICE_NUMBER' => null,
				'INVOICE_UNIQUE_CODE' => null,
				'VAT_RATE'=> null,
				'TAX_RATE'=> null,
				'VAT_CODE'=> "WH/S-52AA/32",
				'TAX_CODE'=> "BL/S012/02",
				'ACTUAL_INVOICE_AMOUNT_FOR_VOICE'=> null,
				'VAT'=> null,
				'TAX'=> null,
				'ADJUSTMENT_BACKLOG'=> null,
				'TOTAL_AMOUNT' => null,
				'POST_VOICE_BL'=> null,
				'PRE_VOICE_BL'=>null,
				'TOTAL_BL_AMOUNT'=>null,
				'ADJUSTMENT'=>null,
				'REPORT_DATE'=>null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATOR','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('SUPPLIER_CODE','Supplier Code','trim|xss_clean');
			$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
			$this->form_validation->set_rules('DOM_INT','Dom Int','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_NUMBER','Invoice Number','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_RATE','Vat Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_RATE','Tax Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_CODE','Vat Code','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_CODE','Tax Code','required|trim|xss_clean');
			$this->form_validation->set_rules('ACTUAL_INVOICE_AMOUNT_FOR_VOICE','Actual Invoice Amount for Voice','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT','Vat','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX','Tax','required|trim|xss_clean');
			$this->form_validation->set_rules('TOTAL_AMOUNT','Total Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('POST_VOICE_BL','Post Voice BL','trim|xss_clean');
			$this->form_validation->set_rules('PRE_VOICE_BL','Pre Voice BL','trim|xss_clean');
			$this->form_validation->set_rules('TOTAL_BL_AMOUNT','Total BL Amount','trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT','adjustment','trim|xss_clean');
			$this->form_validation->set_rules('ADJUSTMENT_BACKLOG','adjustment backlog','trim|xss_clean');
			if( !$this->form_validation->run() ){
				$this->load->view('payment/payable_invoice_icx', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('ID');
			$calculative_month = $this->input->post("BILL_MONTH");
		  $report_date=date("Y-m-d",$calculative_month);
		  $invoice_unique_code=$input->INVOICE_UNIQUE_CODE;
		  $invoice_number=$input->INVOICE_NUMBER;
		  $invoice_array=explode("/",$invoice_number);
		  $input->INVOICE_NUMBER=$invoice_array[0].'/'.html_entity_decode($invoice_array[1]).'/'.$invoice_array[2].'/'.$invoice_unique_code.'/'.$invoice_array[3];
		 // $operator_cname=$input->OPERATOR;
		  $operator = $this->ft->search("name_alternative", null,html_entity_decode($input->OPERATOR));
		  if(empty($operator)){
				$data_error .= 'Operator Name "'.$ios.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}	
		 // dd();
			$existing_data = $this->db->get_where($table_name, array('OPERATOR' => $operator_cname,'REPORT_DATE'=>$report_date,'DOM_INT'=>$input->DOM_INT), $limit=1)->result();
		    if($existing_data){
				$this->webspice->message_board('Duplicate data found for this Date Range!');
				$this->webspice->force_redirect($url_prefix.'payable_invoice_icx');
				return false;
		    }
			$this->webspice->remove_cache('payable_invoice_icx');
     
           $operator_type=$this->db->query("SELECT * FROM TBL_OPERATOR WHERE OPERATOR_NAME='".html_entity_decode($operator_cname)."'")->row();
			if($_POST['ID']){
				
				$sql = "UPDATE TBL_PAYABLE_INVOICE_ICX SET OPERATOR=?,SUPPLIER_CODE=?, DOM_INT=?, VAT_RATE=?, TAX_RATE=?, VAT_CODE=?, TAX_CODE=?, ACTUAL_INVOICE_AMOUNT_FOR_VOICE=?, VAT=?, TAX=?, TOTAL_AMOUNT=?,POST_VOICE_BL=?, PRE_VOICE_BL=?,TOTAL_BL_AMOUNT=?, ADJUSTMENT=?,UPDATED_BY=?, UPDATED_DATE=?,REPORT_DATE=?,INVOICE_NUMBER=?,ADJUSTMENT_BACKLOG=?,STATUS=?
				WHERE ID=?";
				$this->db->query($sql , array($operator_cname,$input->SUPPLIER_CODE,$input->DOM_INT, $input->VAT_RATE, $input->TAX_RATE, $input->VAT_CODE, $input->TAX_CODE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE, $input->VAT, $input->TAX, $input->TOTAL_AMOUNT,$input->POST_VOICE_BL, $input->PRE_VOICE_BL,$input->TOTAL_BL_AMOUNT, $input->ADJUSTMENT, $this->webspice->get_user_id(), $this->webspice->now(),$report_date,$input->INVOICE_NUMBER,$input->ADJUSTMENT_BACKLOG,7, $_POST['ID']));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('payable_invoice_icx - '.$operator_cname);
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_icx');
				return false;
			}
				
			$sql = "
			INSERT INTO TBL_PAYABLE_INVOICE_ICX
			(OPERATOR,SUPPLIER_CODE, DOM_INT, VAT_RATE, TAX_RATE, VAT_CODE, TAX_CODE, ACTUAL_INVOICE_AMOUNT_FOR_VOICE, VAT, TAX, TOTAL_AMOUNT,POST_VOICE_BL, PRE_VOICE_BL,TOTAL_BL_AMOUNT, ADJUSTMENT,CREATED_BY, CREATED_DATE,REPORT_DATE,INVOICE_NUMBER,ADJUSTMENT_BACKLOG,STATUS)
			VALUES
			( ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $this->db->query($sql, array($operator_cname,$input->SUPPLIER_CODE,$input->DOM_INT, $input->VAT_RATE, $input->TAX_RATE, $input->VAT_CODE, $input->TAX_CODE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE, $input->VAT, $input->TAX, $input->TOTAL_AMOUNT,$input->POST_VOICE_BL, $input->PRE_VOICE_BL,$input->TOTAL_BL_AMOUNT, $input->ADJUSTMENT, $this->webspice->get_user_id(), $this->webspice->now(),$report_date,$input->INVOICE_NUMBER,$input->ADJUSTMENT_BACKLOG,7));  
			

			
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('payable_invoice_icx', true) ){
				$this->webspice->force_redirect($url_prefix.'payable_invoice_icx');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	function payable_invoice_icx_report(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_icx_report');
		$this->webspice->permission_verify('payable_invoice_icx_report');

		if( !$_POST ){
			$this->load->view('payment/payable_invoice_icx_report');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$operator_cname =$input->operator;
		$data['dom_int']= $input->DOM_INT;
		$calculative_month = $input->calculative_month;
		$sql = "SELECT * FROM TBL_PAYABLE_INVOICE_ICX";
		$sql .= " WHERE OPERATOR = '".html_entity_decode($operator_cname)."'";
		$sql .= " AND DATE_FORMAT(REPORT_DATE,'%Y-%m') = '".date("Y-m", $calculative_month)."'";
		$sql .= " AND DOM_INT='".$data['dom_int']."'";
		$record = $this->db->query($sql)->row();
		//dd($this->db->last_query());
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payable_invoice_icx_report');
			return false;
		}
		$project_code_sql="SELECT * FROM TBL_OPERATOR WHERE  OPERATOR_NAME='".html_entity_decode($operator_cname)."'";
		$data['operator_info'] = $this->db->query($project_code_sql)->row();
		$data['record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		}
		$this->load->view('payment/print_payable_invoice_icx_report', $data);
	}
	function payable_invoice_igw($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_igw');
			$this->webspice->permission_verify('payable_invoice_igw');
			$table_name = "TBL_PAYABLE_INVOICE_IGW";
			
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'ID'=> null,
				'OPERATOR'=> null,
				'SUPPLIER_CODE'=> null,
				'REPORT_DATE' => null,
				'VAT_RATE' =>0,
				'TAX_RATE'=>7.5,
				'VAT_CODE'=> "WH/S-52AA/32",
				'TAX_CODE'=> "BL/S012/02",
				'ACTUAL_INVOICE_AMOUNT_FOR_VOICE'=> null,
				'VAT' =>null,
				'TAX'=>null,
				'TOTAL_AMOUNT'=> null,
				'POST_VOICE_BL'=> null,
				'PRE_VOICE_BL'=> null,
				'TOTAL_BL_AMOUNT'=> null,
				'ADJUSTMENT'=> null,
				'INVOICE_NUMBER'=>null,
				'INVOICE_UNIQUE_CODE' =>null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATOR','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('SUPPLIER_CODE','Supplier Code','trim|xss_clean');
			$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_RATE','Vat Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_RATE','Tax Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('VAT_CODE','Vat Code','required|trim|xss_clean');
			$this->form_validation->set_rules('TAX_CODE','Tax Code','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
				$this->load->view('payment/payable_invoice_igw', $data);
				return FALSE;
			}

			# get input post
			$input = $this->webspice->get_input('ID');
			$calculative_month = $this->input->post("BILL_MONTH");
			$operator_name_type=explode("|",$input->OPERATOR);
			$input->OPERATOR=$operator_name_type[0];
			$operator_type=$operator_name_type[1];
		  $report_date=date("Y-m-d",$calculative_month);
		  $invoice_unique_code=$input->INVOICE_UNIQUE_CODE;
		  $invoice_number=$input->INVOICE_NUMBER;
		  $invoice_array=explode("/",$invoice_number);
		  $input->INVOICE_NUMBER=$invoice_array[0].'/'.$invoice_array[1].'/'.$invoice_array[2].'/'.$invoice_unique_code.'/'.$invoice_array[3];
			#duplicate test
		  $existing_data = $this->db->get_where($table_name, array('OPERATOR' => $input->OPERATOR,'REPORT_DATE'=>$report_date), $limit=1)->result();
		    if($existing_data){
				$this->webspice->message_board('Duplicate data found for this Date Range!');
				$this->webspice->force_redirect($url_prefix.'payable_invoice_igw');
				return false;
		    }		
			$this->webspice->remove_cache('payable_invoice_igw');
			if($_POST['ID']){
				
				$sql = "UPDATE TBL_PAYABLE_INVOICE_IGW SET OPERATOR=?,SUPPLIER_CODE=?,VAT_RATE=?, TAX_RATE=?, VAT_CODE=?, TAX_CODE=?, ACTUAL_INVOICE_AMOUNT_FOR_VOICE=?, VAT=?, TAX=?,TOTAL_AMOUNT=?, REPORT_DATE=?, INVOICE_NUMBER=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->OPERATOR,$input->SUPPLIER_CODE, $input->VAT_RATE, $input->TAX_RATE, $input->VAT_CODE, $input->TAX_CODE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE, $input->VAT, $input->TAX, $input->TOTAL_AMOUNT,$report_date ,$input->INVOICE_NUMBER,$this->webspice->get_user_id(), $this->webspice->now(), $_POST['ID']));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('payable_invoice_igw - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_igw');
				return false;
			}
			$sql = "
			INSERT INTO TBL_PAYABLE_INVOICE_IGW
			(OPERATOR,OPERATOR_TYPE,SUPPLIER_CODE, VAT_RATE, TAX_RATE, VAT_CODE, TAX_CODE, ACTUAL_INVOICE_AMOUNT_FOR_VOICE, VAT, TAX, TOTAL_AMOUNT,REPORT_DATE, INVOICE_NUMBER,CREATED_BY, CREATED_DATE)
			VALUES
			(?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $this->db->query($sql, array($input->OPERATOR,$operator_type,$input->SUPPLIER_CODE,$input->VAT_RATE, $input->TAX_RATE, $input->VAT_CODE, $input->TAX_CODE, $input->ACTUAL_INVOICE_AMOUNT_FOR_VOICE, $input->VAT, $input->TAX, $input->TOTAL_AMOUNT,$report_date,$input->INVOICE_NUMBER, $this->webspice->get_user_id(), $this->webspice->now()));  
			
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('payable_invoice_igw', true) ){
				$this->webspice->force_redirect($url_prefix.'payable_invoice_igw');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	function manage_payable_invoice_igw(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_payable_invoice_igw');
			$this->webspice->permission_verify('manage_payable_invoice_igw');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC ';
	    $groupby = null;
	    $no_of_record = 10;
	    $where = " ";
	    $page_index = 0;
	    $limit = " LIMIT $no_of_record ";
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			 if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    	
	    }
	    $data["page_index"] = $page_index;
	    
	    $initialSQL = " SELECT * FROM TBL_PAYABLE_INVOICE_IGW ";
	    
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
					$TableName = 'TBL_PAYABLE_INVOICE_IGW',
					$InputField = array(),
					$Keyword = array('OPERATOR','SUPPLIER_CODE','INVOICE_NUMBER','TAX_CODE'),
					$AdditionalWhere = null,
					$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('payment/print_payable_invoice_igw',$data);
					return false;
	        break;
	        
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_PAYABLE_INVOICE_IGW', $KeyField='ID', $key, $RedirectController='collection_controller', $RedirectFunction='payable_invoice_igw', $PermissionName='payable_invoice_igw', $StatusCheck=null, $Log='edit_payable_invoice_igw');          
					return false;
          break;
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    # only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_payable_invoice_igw/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('payment/manage_payable_invoice_igw', $data);
	}
	function payable_invoice_igw_report(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_igw_report');
		$this->webspice->permission_verify('payable_invoice_igw_report');

		if( !$_POST ){
			$this->load->view('payment/payable_invoice_igw_report');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$operator = $input->operator;
		$calculative_month = $input->calculative_month;
		$sql = "SELECT * FROM TBL_PAYABLE_INVOICE_IGW WHERE OPERATOR = '".$operator."'  AND DATE_FORMAT(REPORT_DATE,'%Y-%m') = '".date("Y-m", $calculative_month)."'";
		$project_code_sql="SELECT * FROM TBL_OPERATOR WHERE  OPERATOR_NAME='".$operator."' AND OPERATOR_TYPE='IGW'";
		$record = $this->db->query($sql)->row();
		$data['operator_info'] = $this->db->query($project_code_sql)->row();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payable_invoice_igw_report');
			return false;
		}
		$data['record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		}
		$this->load->view('payment/print_payable_invoice_igw_report', $data);
	}
	
	function payable_invoice_isms($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_isms');
			$this->webspice->permission_verify('payable_invoice_isms');
			$table_name = "TBL_PAYABLE_INVOICE_ISMS";
			
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'ID'=> null,
				'OPERATOR'=> null,
				'REPORT_DATE'=> null,
				'SUPPLIER_CODE' => null,
				'INVOICE_NUMBER' =>null,
				'EXPENSES_EURO'=>null,
				'REVENUE_EURO'=> null,
				'NET_EXPENSE_EURO'=> null,
				'EURO_TO_TK_COVERTION_RATE'=> null,
				'EXPENSES_TK' =>null,
				'REVENUE_TK'=>null,
				'NET_EXPENSE_TK'=> null,
				'USD_TO_TK_COVERTION_RATE'=> null,
				'EXPENSES_USD'=> null,
				'REVENUE_USD'=> null,
				'NET_EXPENSE_USD'=> null,
				'B2B_COST_RATIO'=>null,
				'B2B_REVENUE_RATIO'=> null,
				'B2C_COST_RATIO'=> null,
				'B2C_REVENUE_RATIO'=> null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATOR','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('REPORT_DATE','Report Date','trim|xss_clean');
			$this->form_validation->set_rules('SUPPLIER_CODE','Supplier Code','required|trim|xss_clean');
			$this->form_validation->set_rules('INVOICE_NUMBER','Invoice Number','required|trim|xss_clean');
			$this->form_validation->set_rules('EXPENSES_EURO','Expenses Euro','required|trim|xss_clean');
			$this->form_validation->set_rules('REVENUE_EURO','Revenue Euro','required|trim|xss_clean');
			$this->form_validation->set_rules('NET_EXPENSE_EURO','Net Expense Euro','required|trim|xss_clean');
			$this->form_validation->set_rules('EURO_TO_TK_COVERTION_RATE','Euro to tk Covertion Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('EXPENSES_TK','Expenses tk','required|trim|xss_clean');
			$this->form_validation->set_rules('REVENUE_TK','Revenue tk','required|trim|xss_clean');
			$this->form_validation->set_rules('NET_EXPENSE_TK','Net_Expense tk','required|trim|xss_clean');
			$this->form_validation->set_rules('USD_TO_TK_COVERTION_RATE','Usd to Tk Covertion Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('EXPENSES_USD','Expenses Usd','required|trim|xss_clean');
			$this->form_validation->set_rules('REVENUE_USD','Revenue Usd','required|trim|xss_clean');
			$this->form_validation->set_rules('NET_EXPENSE_USD','Net Expense Usd','required|trim|xss_clean');
			$this->form_validation->set_rules('B2B_COST_RATIO','B2B Cost Ratio','required|trim|xss_clean');
			$this->form_validation->set_rules('B2B_REVENUE_RATIO','B2B Revenue Ratio','required|trim|xss_clean');
			$this->form_validation->set_rules('B2C_COST_RATIO','B2C Cost Ratio','required|trim|xss_clean');
			$this->form_validation->set_rules('B2C_REVENUE_RATIO','B2C Revenue Ratio','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
				$this->load->view('payment/payable_invoice_isms', $data);
				return FALSE;
			}

			# get input post
			$input = $this->webspice->get_input('ID');
			$calculative_month = $this->input->post("BILL_MONTH");
		  $report_date=date("Y-m-d",$calculative_month);
			#duplicate test
		  $this->webspice->db_field_duplicate_test(
			  "SELECT * FROM $table_name WHERE INVOICE_NUMBER=?", 
			  array($input->INVOICE_NUMBER), 
			  'You are not allowed to enter duplicate Invoice!', 
			  'ID', 
			  $_POST['ID'], 
			  $data, 
			  'payment/payable_invoice_isms'
		  );  			
			$this->webspice->remove_cache('payable_invoice_isms');
			if($_POST['ID']){
				#update query
				$sql = "UPDATE TBL_PAYABLE_INVOICE_ISMS SET OPERATOR=?,REPORT_DATE=?,SUPPLIER_CODE=?, INVOICE_NUMBER=?, EXPENSES_EURO=?, REVENUE_EURO=?, NET_EXPENSE_EURO=?, EURO_TO_TK_COVERTION_RATE=?, EXPENSES_TK=?,REVENUE_TK=?, NET_EXPENSE_TK=?,USD_TO_TK_COVERTION_RATE=?, EXPENSES_USD=?, REVENUE_USD=?, NET_EXPENSE_USD=?, B2B_COST_RATIO=?,B2B_REVENUE_RATIO=?,B2C_COST_RATIO=?,B2C_REVENUE_RATIO=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->OPERATOR,$report_date,$input->SUPPLIER_CODE, $input->INVOICE_NUMBER, $input->EXPENSES_EURO, $input->REVENUE_EURO, $input->NET_EXPENSE_EURO, $input->EURO_TO_TK_COVERTION_RATE, $input->EXPENSES_TK, $input->REVENUE_TK, $input->NET_EXPENSE_TK,$input->USD_TO_TK_COVERTION_RATE, $input->EXPENSES_USD,$input->REVENUE_USD, $input->NET_EXPENSE_USD,$input->B2B_COST_RATIO,$input->B2B_REVENUE_RATIO,$input->B2C_COST_RATIO,$input->B2C_REVENUE_RATIO,$this->webspice->get_user_id(), $this->webspice->now(), $_POST['ID']));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('payable_invoice_isms - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_payable_invoice_isms');
				return false;
			}
			$sql = "
			INSERT INTO TBL_PAYABLE_INVOICE_ISMS
			(OPERATOR,SUPPLIER_CODE, EXPENSES_EURO, REVENUE_EURO, NET_EXPENSE_EURO, EURO_TO_TK_COVERTION_RATE, EXPENSES_TK, REVENUE_TK, NET_EXPENSE_TK, USD_TO_TK_COVERTION_RATE,EXPENSES_USD, REVENUE_USD,NET_EXPENSE_USD, B2B_COST_RATIO,B2B_REVENUE_RATIO,B2C_COST_RATIO,B2C_REVENUE_RATIO,STATUS, REPORT_DATE, INVOICE_NUMBER,CREATED_BY, CREATED_DATE)
			VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $this->db->query($sql, array($input->OPERATOR,$input->SUPPLIER_CODE,$input->EXPENSES_EURO, $input->REVENUE_EURO, $input->NET_EXPENSE_EURO, $input->EURO_TO_TK_COVERTION_RATE, $input->EXPENSES_TK, $input->REVENUE_TK, $input->NET_EXPENSE_TK, $input->USD_TO_TK_COVERTION_RATE, $input->EXPENSES_USD,$input->REVENUE_USD, $input->NET_EXPENSE_USD,$input->B2B_COST_RATIO,$input->B2B_REVENUE_RATIO,$input->B2C_COST_RATIO,$input->B2C_REVENUE_RATIO,7,$report_date,$input->INVOICE_NUMBER, $this->webspice->get_user_id(), $this->webspice->now()));  
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('payable_invoice_isms', true) ){
				$this->webspice->force_redirect($url_prefix.'payable_invoice_isms');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	function manage_payable_invoice_isms(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_payable_invoice_isms');
			$this->webspice->permission_verify('manage_payable_invoice_isms');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC ';
	    $groupby = null;
	    $no_of_record = 10;
	    $where = " ";
	    $page_index = 0;
	    $limit = " LIMIT $no_of_record ";
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			 if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    	
	    }
	    $data["page_index"] = $page_index;
	    
	    $initialSQL = " SELECT * FROM TBL_PAYABLE_INVOICE_ISMS ";
	    
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
					$TableName = 'TBL_PAYABLE_INVOICE_ISMS',
					$InputField = array(),
					$Keyword = array('OPERATOR','SUPPLIER_CODE','INVOICE_NUMBER'),
					$AdditionalWhere = null,
					$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('payment/print_payable_invoice_isms',$data);
					return false;
	        break;
	        
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_PAYABLE_INVOICE_ISMS', $KeyField='ID', $key, $RedirectController='collection_controller', $RedirectFunction='payable_invoice_isms', $PermissionName='payable_invoice_isms', $StatusCheck=null, $Log='edit_payable_invoice_isms');          
					return false;
          break;
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    # only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_payable_invoice_igw/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('payment/manage_payable_invoice_isms', $data);
	}
	function payable_invoice_isms_report(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'payable_invoice_isms_report');
		$this->webspice->permission_verify('payable_invoice_isms_report');

		if( !$_POST ){
			$this->load->view('payment/payable_invoice_isms_report');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$operator = $input->operator;
		$calculative_month = $input->calculative_month;
		$sql = "SELECT * FROM TBL_PAYABLE_INVOICE_ISMS";
		$sql .= " WHERE OPERATOR = '".$operator."'";
		$sql .= " AND DATE_FORMAT(REPORT_DATE,'%Y-%m') = '".date("Y-m", $calculative_month)."'";
		$project_code_sql="SELECT * FROM TBL_OPERATOR WHERE  OPERATOR_NAME='".$operator."' AND OPERATOR_TYPE='ISMS'";
		
		$record = $this->db->query($sql)->row();
		$data['operator_info'] = $this->db->query($project_code_sql)->row();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'payable_invoice_isms_report');
			return false;
		}
		$data['record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('payment/print_payable_invoice_isms_report', $data);
	}
	
	function data_uploader_for_isms_journal($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		#$config = $this->ft->get('config');
		#$config = $config->{'0'};
		#$usd_rate = $config->usd_rate;
		#$icx_portion = $config->icx_portion;
		#$igw_portion = $config->igw_portion;
		#$btrc_portion = $config->btrc_portion;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'data_uploader_for_isms_journal');
		$this->webspice->permission_verify('data_uploader_for_isms_journal');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('payment/data_uploader_for_isms_journal', $data);
			return FALSE;
		}		
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'payment/data_uploader_for_isms_journal');
		}
		$sheet_columns = array("Country", "Operator", "Customer Delivers To", "Zone","Unit Price (EUR)","Amount (EUR) to SAP","Customer Receives From","Zone","Unit Price (EUR)","Amount  (EUR) from SAP","MCC", "MNC", "TAP Code");
		$header_offset = 1;
		$column_offset = 1;
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_voice_call_int_out');
			return FALSE;
		}
		
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$duplicate_where = array();
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$country = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$operator = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$customer_delivers_to = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$zone = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$unit_price_eur = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$amount_eur_to_sap = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$customer_receives_from = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$zone2 = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$unit_price_eur_2 = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$amount_eur_from_sap = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			$mcc = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[10]));
			$mnc = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[11]));
			$tap_code = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[12]));
			$values[] = array(
				"COUNTRY" => $country, "OPERATOR" => $operator, "CUSTOMER_DELIVERS_TO" => $customer_delivers_to, "ZONE" => $zone,
				"UNIT_PRICE" => $unit_price_eur, "AMOUNT_TO_SAP" => $amount_eur_to_sap,"CUSTOMER_RECEIVES_FROM" => $customer_receives_from,
				"ZONE_2" => $zone2,"AMOUNT_FROM_SAP" => $amount_eur_from_sap,"UNIT_PRICE_EUR_2"=>$unit_price_eur_2,  
				"MCC" => $mcc,
				"MNC" => $mnc, "TAP_CODE" => $tap_code, "REPORT_DATE" => $report_date,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			# must have column value - column offset started from 1
			if( !isset($country) || !isset($operator) || !isset($customer_delivers_to) || !isset($zone)|| 
			!isset($unit_price_eur) || !isset($amount_eur_to_sap)){
				$data_error .= 'Row #'.$k.' is Blank. Please Remove it.<br />';
			}
			
			
			if( isset($amount_to_sap) && !is_numeric($amount_to_sap) ){
				$data_error .= 'Amount to SAP "'.$amount_to_sap.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($mcc) && !is_numeric($mcc) ){
				$data_error .= 'MCC "'.$mcc.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($mnc) && !is_numeric($mnc) ){
				$data_error .= 'MNC "'.$mnc.'" at Row #'.$k.' is invalid.<br />';
			}
		//	$duplicate_where[] = " (DATE_TIME='".$date_time."' AND OPERATOR='".$operator."' AND PREPOST_FLAG='".$prepost_flag."' AND TARIFFCLASS='".$tariffclass."') ";
		}
		
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_ISMS_DATA_FOR_JOURNAL";
		if($input->data_insert == "data_remove_insert" ){
				//$this->db->where_in('JOIN_DATA_FLAG',0);
					$this->db->where("YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month));
			  	$this->db->delete($table_name);
		 }
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('data_uploader_for_isms_journal'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_data_for_isms_journal', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_data_for_isms_journal');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	function isms_journal($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'isms_journal');
		$this->webspice->permission_verify('isms_journal');
		
		$data["b2b_b2c_ratio"] = $this->db->query("SELECT * FROM TBL_PAYABLE_INVOICE_ISMS")->row();
		$sql = "SELECT UNIT_PRICE,(SELECT SUM(CUSTOMER_RECEIVES_FROM) FROM TBL_ISMS_DATA_FOR_JOURNAL) AS TOTAL_TBL_ISMS_DATA_FOR_JOURNAL FROM TBL_ISMS_DATA_FOR_JOURNAL";
		$where = " WHERE UNIT_PRICE!=0 AND STATUS = 7 ";
	  //$group_by = " GROUP BY OPERATOR_NAME " ;
	  		
		$order_by = " ORDER BY OPERATOR " ;
		if( !$_POST ){
			$this->load->view('payment/isms_journal', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->date_to;
		$for_to_date=explode("-",$calculative_month);
		$data['to_date']=$for_to_date[2];
	  $last_date= date("Y-m-t", strtotime($calculative_month));
    $for_last_day_of_a_month=explode("-",$last_date);
    $data['last_day_of_a_month']=$for_last_day_of_a_month[2];
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "";
		$where .= " AND YEAR(REPORT_DATE) = ".date("Y",strtotime($calculative_month))." AND MONTH(REPORT_DATE) = ".date("m",strtotime($calculative_month));
		$data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
		$data['date']=date('M-Y', strtotime($calculative_month));
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-momms";
		$sql = $sql.$where.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    if($data["get_record"][0]==''){
    $this->webspice->message_board('Record is not found!');
    $this->load->view('payment/isms_journal', $data);
		return false;
    }
		$this->load->view('payment/print_isms_journal', $data);
	}
	
	function collection_with_dispute_($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'collection_with_dispute');
		$this->webspice->permission_verify('collection_with_dispute');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'ID'=>null,
			'BANK_ACCOUNT'=>null,
			'CHEQUE_NUMBER'=>null,
			'CHEQUE_AMOUNT'=>null,
			'CHEQUE_DATE'=>null,
			'ENTRY_DATE'=>null,
			'AIT_RATE_FOR_IOS'=>null,
			'AIT_RATE_FOR_PSTN_PTSP'=>null,
			'AIT_RATE_FOR_MOBILE'=>null,
			'SETTLEMENT_INCLUDING_CHEQUE_AMOUNT'=>null,			
			'MAIN_AMOUNT_WITH_VAT'=>null,
			'MAIN_AMOUNT_WITHOUT_VAT'=>null,
			'AIT_ON_SOURCH'=>null,
			'INVOICE_CHEQUE_AMOUNT'=>null,
			'BANK_NAME'=>null,
			'BILL_PERIOD'=>null,
			'INVOICE_NUMBER'=>null,
			'INVOICE_AMOUNT'=>null,
			'REMAINING_AMOUNT'=>null,
			'SETTLEMENT_AMOUNT'=>null,
			'TDS'=>null,
			'TOTAL_SETTLEMENT'=>null,
			'CHEQUE_AMOUNT_SETTLEMENT'=>null,
			'CHEQUE_AMOUNT_REMAINING'=>null,
			'TDS_SETTLEMENT'=>null,
			'TDS_REMAINING'=>null,
			'TOTAL_SETTLEMENT'=>null,
			'TOTAL_REMAINING'=>null
			);
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('OPERATOR','Operator','required|trim|xss_clean');
		$this->form_validation->set_rules('CHECQUE_NO','Checque No','required|trim|xss_clean');
		$this->form_validation->set_rules('BANK_NAME','Bank Name','required|trim|xss_clean');
		$this->form_validation->set_rules('AMOUNT','Amount','required|trim|xss_clean');
		$this->form_validation->set_rules('BILL_MONTH','Bill Month','required|trim|xss_clean');
		
		if( !$this->form_validation->run() ){ 
			$this->load->view('collection/collection_with_dispute', $data);
			return FALSE;
		}
		# get input post
		$input = $this->webspice->get_input('ID');
		#duplicate test	
		
		# update process
		if( $input->ID ){
			#update query
			$sql = " UPDATE TBL_COLLECTION SET OPERATOR=?, CHECQUE_NO=?, BANK=?, CURRENT_AMOUNT=?, AMOUNT=?, BILL_MONTH=?, UPDATED_BY=?, UPDATED_DATE=? WHERE ID=? ";
			$this->db->query($sql, array($input->OPERATOR, $input->CHECQUE_NO, $input->BANK_NAME, $input->CURRENT_AMOUNT, $input->AMOUNT, $input->BILL_MONTH, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID)); 
			
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('user_updated - '.$input->ID); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_collection');
			return false;
		}
		
		#create user
		$sql = " INSERT INTO TBL_COLLECTION
		(OPERATOR, CHECQUE_NO, BANK_NAME, CURRENT_AMOUNT, AMOUNT, BILL_MONTH, CREATED_BY, CREATED_DATE, STATUS)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, 7) ";
		$this->db->query($sql, array($input->OPERATOR, $input->CHECQUE_NO, $input->BANK_NAME, $input->CURRENT_AMOUNT, $input->AMOUNT, $input->BILL_MONTH, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->message_board('Record has been inserted!.');
		$this->webspice->force_redirect($url_prefix.'collection_module');
	}
	function collection_without_dispute($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'collection_without_dispute');
		$this->webspice->permission_verify('collection_without_dispute');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'ID'=>null,
			'BANK_ACCOUNT'=>null,
			'CHEQUE_NUMBER'=>null,
			'CHEQUE_AMOUNT'=>null,
			'CHEQUE_DATE'=>null,
			'ENTRY_DATE'=>null,
			'BANK_NAME'=>null,
			'BILL_PERIOD'=>null,
			'INVOICE_NUMBER'=>null,
			'INVOICE_AMOUNT'=>null,
			'REMAINING_AMOUNT'=>null,
			'SETTLEMENT_AMOUNT'=>null,
			'TDS'=>null,
			'TOTAL_SETTLEMENT'=>null,
			'CHEQUE_AMOUNT_SETTLEMENT'=>null,
			'CHEQUE_AMOUNT_REMAINING'=>null,
			'TDS_SETTLEMENT'=>null
			);
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('BANK_ACCOUNT','Bank Account','required|trim|xss_clean');
		$this->form_validation->set_rules('CHEQUE_NUMBER','Cheque Number','required|trim|xss_clean');
		$this->form_validation->set_rules('CHEQUE_AMOUNT','Cheque Amount','required|trim|xss_clean');
		$this->form_validation->set_rules('CHEQUE_DATE','Cheque Date','required|trim|xss_clean');
		$this->form_validation->set_rules('ENTRY_DATE','Entry Date','required|trim|xss_clean');
		$this->form_validation->set_rules('BANK_NAME','Bank Name','required|trim|xss_clean');
		$this->form_validation->set_rules('BILL_PERIOD','Bill Period','required|xss_clean');
		$this->form_validation->set_rules('INVOICE_NUMBER','Invoice Number','required|xss_clean');
		$this->form_validation->set_rules('INVOICE_AMOUNT','Invoice Amount','required|xss_clean');
		$this->form_validation->set_rules('REMAINING_AMOUNT','Remaining Amount','required|xss_clean');
		$this->form_validation->set_rules('SETTLEMENT_AMOUNT','Settlement Amount','required|xss_clean');
		$this->form_validation->set_rules('TDS','TDS','required|xss_clean');
		$this->form_validation->set_rules('TOTAL_SETTLEMENT','Total Settlement','required|xss_clean');
		$this->form_validation->set_rules('CHEQUE_AMOUNT_SETTLEMENT','Cheque Amount Settlement','required|xss_clean');
		$this->form_validation->set_rules('CHEQUE_AMOUNT_REMAINING','Cheque Amount remaining','required|xss_clean');
		$this->form_validation->set_rules('TDS_SETTLEMENT','TDS Sett','required|xss_clean');
		
		if( !$this->form_validation->run() ){ 
			$this->load->view('collection/collection_without_dispute', $data);
			return FALSE;
		}
		# get input post
		$input = $this->webspice->get_input('ID');
		#duplicate test	
		# update process
		/*if( $input->ID ){
			#update query
			$sql = " UPDATE TBL_COLLECTION SET OPERATOR=?, CHECQUE_NO=?, BANK=?, CURRENT_AMOUNT=?, AMOUNT=?, BILL_MONTH=?, UPDATED_BY=?, UPDATED_DATE=? WHERE ID=? ";
			$this->db->query($sql, array($input->OPERATOR, $input->CHECQUE_NO, $input->BANK_NAME, $input->CURRENT_AMOUNT, $input->AMOUNT, $input->BILL_MONTH, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID)); 
			
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('user_updated - '.$input->ID); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_collection');
			return false;
		}*/
		
		
		$operator_name = $input->OPERATOR_NAME;
		$operator_type = $input->OPERATOR_TYPE;
		$from_date = $input->from_date;
		$to_date = $input->to_date;
		$cheque_amount_settlement = $input->CHEQUE_AMOUNT_SETTLEMENT;
		$cheque_amount_remaining = $input->CHEQUE_AMOUNT_REMAINING;
		$total_amount = $cheque_amount_settlement + $cheque_amount_remaining;
		$tds_settlement = $input->TDS_SETTLEMENT;
		$bank_name = $input->BANK_NAME;
		$bank_account = $input->BANK_ACCOUNT;
		$cheque_number = $input->CHEQUE_NUMBER;
		$cheque_amount = $input->CHEQUE_AMOUNT;
		$tds_rate = $input->TDS_RATE;
		$cheque_date = $input->CHEQUE_DATE;
		$entry_date = $input->ENTRY_DATE;
		$total_settlement = $input->TOTAL_SETTLEMENT;
		$total_settlement=0;
		$invoice_id_in_string = implode(",",$input->INVOICE_ID);
		
		foreach ($input->invoice_full as $k=>$v){
			if (!in_array($v, $input->invoice_check)){
        $this->webspice->message_board('We could not execute your request.Invalied invoice full sattled.');
				$this->webspice->force_redirect($url_prefix.'collection_without_dispute');
				return false; 
      }
      $total_settlement = $total_settlement + $input->SETTLEMENT_AMOUNT[$v];
		}
		
		if($total_settlement > $cheque_amount){
			$this->webspice->message_board('We could not execute your request.Your collection is '.$cheque_amount.'tk but You try to settled '.$total_settlement.'tk.');
			$this->webspice->force_redirect($url_prefix.'collection_without_dispute');
			return false; 	
		}
		foreach($input->invoice_check as $k=>$v){
			$invoice_number_full_settled = $input->INVOICE_NUMBER[$v];
			$bill_period = $input->BILL_PERIOD[$v];
			$invoice_amount = $input->INVOICE_AMOUNT[$v];
			$settlement_amount = $input->SETTLEMENT_AMOUNT[$v];
			$tds = $input->TDS[$v];
			if(array_key_exists("invoice_full",$_POST)){
				//dd($v,3); dd($input->invoice_full,3);
				if(in_array($v, $input->invoice_full)){
					
					$invoice_full='full';
					$remaining_amount = 0;
				}else{
					
					$invoice_full='partial';
					$remaining_amount = $cheque_amount_remaining;
				}
		//	dd($remaining_amount);
			}else{
				$invoice_full='partial';
				$remaining_amount = $cheque_amount_remaining;
			}
				$values[] = array(
				"OPERATOR_NAME" => $operator_name, "OPERATOR_TYPE" => $operator_type, "INVOICE_NUMBER" => $invoice_number_full_settled, 
				"INVOICE_AMOUNT" => trim($invoice_amount), "NO_CLI"=> 0, "SMS" => 0, "VAT" => 0,"BILL_PERIOD"=> $cheque_date,"REMAINING_AMOUNT"=> trim(abs($remaining_amount)), "DISPUTE"=>0,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
		}
		
		//dd($values);
		$table_name='TBL_INVOICE';
		$this->db->insert_batch($table_name, $values);
		$table_name='TBL_INVOICE_DETAIL';
		$this->db->update_batch($table_name, $values, 'INVOICE_NUMBER');
		dd(111111);
		$sql = " INSERT INTO TBL_COLLECTION
		(OPERATOR, OPERATOR_TYPE, CHEQUE_NO, BANK_NAME, CHEQUE_AMOUNT, CHEQUE_DATE, ENTRY_DATE, CHEQUE_AMOUNT_SETTLEMENT , CHEQUE_AMOUNT_REMAINING , INVOICE_ID, CREATED_BY, CREATED_DATE, STATUS)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,? ,? , 7) ";
		$this->db->query($sql, array($operator_name, $operator_type, $cheque_number, $bank_name, trim($cheque_amount), $cheque_date,$entry_date, trim($cheque_amount_settlement), trim($cheque_amount_remaining), $invoice_id_in_string, $this->webspice->get_user_id(), $this->webspice->now()));
		
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted!.');
		$this->webspice->force_redirect($url_prefix.'collection_without_dispute');
	}
	
	
	
	
	//this is all right before ait gl 
	
	function collection_with_dispute___($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'collection_with_dispute');
		$this->webspice->permission_verify('collection_with_dispute');
		
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('CHEQUE_AMOUNT','Cheque Amount','required|trim|xss_clean');
		$this->form_validation->set_rules('CHEQUE_DATE','Cheque Date','required|trim|xss_clean');
		$this->form_validation->set_rules('ENTRY_DATE','Entry Date','required|trim|xss_clean');
		$data['operator_name']=$this->db->query("SELECT OPERATOR_NAME,OPERATOR_TYPE FROM TBL_OPERATOR")->result();
		if( !$_POST ){ 
			$this->load->view('collection/collection_with_dispute', $data);
			return FALSE;
		}
		$operator_name_type_string = $_POST['OPERATOR_NAME'];
		$operator_name_type_array = explode("|",$operator_name_type_string);
		$operator_name = $operator_name_type_array[1];
		$operator_type = $operator_name_type_array[0];
		$from_date = $_POST['from_date'];
		$to_date = $_POST['to_date'];
		$cheque_amount_settlement = $_POST['CHEQUE_AMOUNT_SETTLEMENT'];
		$cheque_amount_remaining = $_POST['CHEQUE_AMOUNT_REMAINING'];
		$total_amount = $cheque_amount_settlement + $cheque_amount_remaining;
		$tds_settlement = $_POST['TDS_SETTLEMENT'];
		$bank_name = $_POST['BANK_NAME'];
		$bank_account = $_POST['BANK_ACCOUNT'];
		$cheque_number = $_POST['CHEQUE_NUMBER'];
		$cheque_amount = $_POST['CHEQUE_AMOUNT'];
		$tds_rate = $_POST['TDS_RATE'];
		$cheque_date = $_POST['CHEQUE_DATE'];
		$entry_date = $_POST['ENTRY_DATE'];
		$total_settlement = $_POST['TOTAL_SETTLEMENT'];
		$total_settlement=0;
		$total_settlement=0;
		$allocated_data = $this->input->post("ALLOCATED_DATA");
		$edch_pn_sql = array();
					foreach($allocated_data as $key4 => $value4){
						$receiveable_data = $value4;
						if(array_key_exists('SEQ_ID',$receiveable_data)){
							$invoice_id_in_array[] = $receiveable_data['INVOICE_ID'];
							$values[] = array(
				                 	"OPERATOR_NAME" => $operator_name, "OPERATOR_TYPE" => $operator_type, "INVOICE_NUMBER" => $receiveable_data['INVOICE_NUMBER'], 
													"INVOICE_AMOUNT" => trim($receiveable_data['INVOICE_AMOUNT']), "NO_CLI"=> 0, "SMS" => 0, "VAT" => 0,"BILL_PERIOD"=> $receiveable_data['BILL_PERIOD'],"REMAINING_AMOUNT"=> trim($receiveable_data['REMAINING_AMOUNT']), "DISPUTE"=>$receiveable_data['DISPUTE'],
													"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
						}
					}
		$invoice_id_in_string = implode(",",$invoice_id_in_array);
		if($cheque_amount_remaining < 0){
			$net_amount=0;
		}else{
			$net_amount=$cheque_amount_remaining;
		}		
	//	if($total_settlement > $cheque_amount){
	//		$this->webspice->message_board('We could not execute your request.Your collection is '.$cheque_amount.'tk but You try to settled '.$total_settlement.'tk.');
	//		$this->webspice->force_redirect($url_prefix.'collection_with_dispute');
	//		return false;
	//	}
		$table_name='TBL_INVOICE';
		$this->db->insert_batch($table_name, $values);
		$table_name='TBL_INVOICE_DETAIL';
		//dd($values);
		$this->db->update_batch($table_name, $values, 'INVOICE_NUMBER');
		
		$sql = " INSERT INTO TBL_COLLECTION
		(OPERATOR, OPERATOR_TYPE, CHEQUE_NO, BANK_NAME, CHEQUE_AMOUNT, CHEQUE_DATE, ENTRY_DATE, CHEQUE_AMOUNT_SETTLEMENT , CHEQUE_AMOUNT_REMAINING , INVOICE_ID, CREATED_BY, CREATED_DATE, NET_AMOUNT, STATUS)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,? ,? , ?,7) ";
		$this->db->query($sql, array($operator_name, $operator_type, $cheque_number, $bank_name, trim($cheque_amount), $cheque_date,$entry_date, trim($cheque_amount_settlement), trim($cheque_amount_remaining), $invoice_id_in_string, $this->webspice->get_user_id(), $this->webspice->now(),$net_amount));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted!.');
		$this->webspice->force_redirect($url_prefix.'collection_with_dispute');
	}
	function get_invoice_amount_for_collection_with_dispute_(){
		$operator_name=$_POST['op_name'];
		$from_date=$_POST['from_date'];
		$to_date=$_POST['to_date']; 
		$op_type=$_POST['op_type'];
		$total_invoice = $this->db->query("SELECT * FROM TBL_INVOICE_DETAIL WHERE OPERATOR_NAME='".$operator_name."' AND OPERATOR_TYPE='".$op_type."' AND REMAINING_AMOUNT !=0 AND BILL_PERIOD BETWEEN '".$from_date."' AND '".$to_date."'")->result();
		
		$html = null;
		if($total_invoice){
			foreach($total_invoice as $k=>$v){
				$html .='
								<td>
									<div class="form_label">&nbsp</div>
									<div class="form-check">
  								<label class="form-check-label">
    							<input class="form-check-input invoice_checker"  type="checkbox" id="invoice_check" name="invoice_check[]" value="'.$k.'" />
  								</label>
									</div>
								</td>
								
		              <input type="hidden" id="invoice_id" name="INVOICE_ID[]" class="input_full input_style" value="'.$v->ID.'" required readonly/>
										
								<td>
									<div class="form_label">Bill Period *</div>
									<div>
		               <input type="text" id="bank_name" name="BILL_PERIOD[]" class="input_full input_style" value="'.$v->BILL_PERIOD.'" required readonly/>
										<span	class="fred"></span>
									</div>
								</td>
								<td colspan=2>
									<div class="form_label">Invoice Number *</div>
									<div>
		               <input type="text" id="bank_name" name="INVOICE_NUMBER[]" class="input_full input_style" value="'.$v->INVOICE_NUMBER.'" required readonly />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Invoice Amount *</div>
									<div>
		               <input type="text" id="bank_name" name="INVOICE_AMOUNT[]" class="input_full input_style" value="'.number_format($v->INVOICE_AMOUNT,2).'" required readonly />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Remaining Amount *</div>
									<div>
		               <input type="text" id="bank_name" data-invc_'.$k.'="'.$v->REMAINING_AMOUNT.'" name="REMAINING_AMOUNT[]" class="input_full input_style remaining_amount" value="'.number_format($v->REMAINING_AMOUNT,2).'" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td colspan=2>
									<div class="form_label">Settlement Amount *</div>
									<div>
		               <input type="text" id="bank_name" name="SETTLEMENT_AMOUNT[]" class="input_full input_style  stl_'.$k.'" value="" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">TDS *</div>
									<div>
		               <input type="text" id="bank_name" name="TDS[]" class="input_full input_style  tds_'.$k.'" value="" required />
										<span	class="fred" ></span>
									</div>
								</td>';
								if($_POST['collection_type']=='with_dispute'){
								$html.='<td>
									<div class="form_label">Dispute *</div>
									<div>
		               <input type="text" id="bank_name" name="DISPUTE" class="input_full input_style  dispute_'.$k.'" value="" required />
										<span	class="fred" ></span>
									</div>
								</td>';
								
								}
								$html.='<td>
									<div class="form_label">Total Settlement *</div>
									<div>
		               <input type="text" id="bank_name" name="TOTAL_SETTLEMENT[]" class="input_full input_style ttl_stl_'.$k.'" value="" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Full</div>
									<div class="form-check">
  								<label class="form-check-label">
    							<input class="form-check-input"  type="checkbox" id="invoice_full" name="invoice_full[]" value="'.$k.'" />
  								</label>
									</div>
								</td>
							';
				
			}	
			
		}else{
			$html='There are no invoice for this Bill Period';
			}
	
	echo $html;
	
	
	//	if($config){
			//$html=	
			
	//	}
	//	echo json_encode($config);
		exit;
	}
	function get_invoice_amount_for_collection_with_dispute(){
		$input = $this->input->post();
		$operatror_name_type=explode("|",$input['operator_name']);
		$data['tds_rate']=$input['tds_rate'];
		if($input['ajax_call']=="get_invoice"){
			//$data['collection_info'] = $tbl_collection = $this->db->get_where('TBL_COLLECTION_REPORT', array("ID" => $this->webspice->encrypt_decrypt($input['collection_id'],'decrypt')))->row();
			$data['invoice'] = $this->db->query("SELECT * FROM TBL_INVOICE_DETAIL WHERE OPERATOR_NAME='".$operatror_name_type[1]."' AND OPERATOR_TYPE='".$operatror_name_type[0]."' AND REMAINING_AMOUNT > 0 AND BILL_PERIOD BETWEEN '".$input['from_date']."' AND '".$input['to_date']."'")->result();
			//dd($this->db->last_query());
			$invoices = $this->load->view('collection/invoice_detail',$data, true);
			echo $invoices; 
			exit;
		}
		
	}
	
	function invoice_icx_($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'invoice_icx');
		$this->webspice->permission_verify('invoice_icx');
		
	  $sql = " SELECT * FROM TBL_ICX_REPORT_DATA ";
		$sql_for_cli=" SELECT * FROM TBL_NO_CLI ";
		$sql_for_operator=" SELECT * FROM TBL_OPERATOR ";
		
		if( !$_POST ){
				$this->load->view('invoice/invoice_icx');
			  return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$operator_name = $input->operator_name;
		if($operator_name != 'all'){
			$where ="WHERE OPERATOR_NAME = '".$operator_name."'";
			$cli_where ="WHERE OPERATOR = '".$operator_name."'";
			$operator_where =" WHERE OPERATOR_NAME = '".$operator_name."'";
		}else{
			$where='';
			$cli_where='';	
			$operator_where ='';
		}
		
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";	
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		
    if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y", $calculative_month)." AND MONTH(REPORT_DATE) = ".date("m", $calculative_month);
			 $cli_where .= " AND YEAR(REPORT_DATE) = ".date("Y", $calculative_month)." AND MONTH(REPORT_DATE) = ".date("m", $calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y", $calculative_month) ;
			 $data['date']=date('Y-m-d', $calculative_month);
			 $data['formated_date']=date('M Y', $calculative_month);
		}
		
		$data['current_date']=date("M d,Y");
		$sql = $sql.$where;
		$cli_sql = $sql_for_cli.$cli_where;
		$operator_sql = $sql_for_operator.$operator_where;
		$data["get_record"] = $this->db->query($sql)->result();
		$data["get_cli"] = $this->db->query($cli_sql)->result();
		$data["get_operator_info"] = $this->db->query($operator_sql)->row();
		
		if(empty($data["get_record"])){
			$this->webspice->message_board('No data Found!');
				$this->load->view('invoice/invoice_icx');
			  return false;
		}
		
	if( $this->input->post('pdf') ){
	    $data['action_type'] = 'pdf';
	    $_SESSION['sql'] = $sql; 
			$result = $this->db->query($sql)->result();
	    $data['get_record'] = $result;    
	    
	    $filename = time()."_invoice_icx.pdf";
      $html = $this->load->view('invoice/print_invoice_icx', $data, true);
      
      $this->load->library('M_pdf');
      
      #$this->m_pdf->param = "'c', 'L'";
			#$this->m_pdf->allow_charset_conversion=true;  // Set by default to TRUE
			
			$this->m_pdf->charset_in='utf-8';
      
      $this->m_pdf->pdf->WriteHTML($html);
      
      # $this->m_pdf->pdf->Output(FCPATH."global/".$filename, "F"); #F for sile save and D for download
      $this->m_pdf->pdf->Output($filename, "D"); # F for sile save and D for download
      
      return false;
    }
		
		$this->load->view('invoice/print_invoice_icx', $data);
	}







	
	
	
	
	function invoice_icx($data=null){
  	$url_prefix = $this->webspice->settings()->site_url_prefix;
    $this->webspice->user_verify($url_prefix.'login', $url_prefix.'invoice_icx');
    $this->webspice->permission_verify('invoice_icx');
       
    if( !$_POST ){
      $this->load->view('invoice/invoice_icx', $data);
      return false;
    }
     		//dd($_POST);  
    # get input post
    $input = $this->webspice->get_input();
    $operator_name_type = $input->operator_name;
    $name_type = explode("|",$operator_name_type);
    $operator_name = $name_type[1];
    $operator_type = $name_type[0];
    $calculative_month = $input->calculative_month;
    $report_date=date("Y-m-d",$calculative_month); 
   // $inv_exist=1; 
    if( $this->input->post('ajax_call') ){
    	$invoice_exist = $this->db->get_where(
         'TBL_INVOICE_DETAIL',
          array(
               'OPERATOR_NAME' => $operator_name,
               'YEAR(BILL_PERIOD)' => date("Y", $calculative_month),
               'MONTH(BILL_PERIOD)' => date("m", $calculative_month)
                )
            )->result();  
            
        
    		if($invoice_exist){ 
    		  echo 'inv_exist';
    		 	exit;
    		}else{
    		  echo 'inv_not_exist';   
    		  exit;
    		}
    }
   
    $sql2 = "
        SELECT *,
        SUM( CASE WHEN TYPE='VOICE' THEN AMOUNT END) AS VOICE_AMOUNT,
        SUM( CASE WHEN TYPE='NO_CLI' THEN AMOUNT END) AS NO_CLI_AMOUNT,
        CASE WHEN TYPE='NO_CLI' THEN NO_CLI_DATE END AS NO_CLI_MONTH,
        SUM( CASE WHEN TYPE='SMS_MMS' THEN AMOUNT END) AS SMS_MMS_AMOUNT,
        SUM( VAT_VALUE ) AS VAT_VALUE_AMOUNT,
        SUM( AMOUNT ) AS TOTAL_AMOUNT
        FROM TBL_ICX_REPORT_DATA
    ";
       
     $group_by2 = " GROUP BY OPERATOR_NAME ";
       
       
     $sql = " SELECT * FROM TBL_ICX_REPORT_DATA ";
     $sql_for_cli=" SELECT * FROM TBL_NO_CLI ";
     $sql_for_operator=" SELECT * FROM TBL_OPERATOR ";
       

     if($operator_name != 'all'){
         $where ="WHERE OPERATOR_NAME = '".$operator_name."'";
         $cli_where ="WHERE OPERATOR = '".$operator_name."'";
         $operator_where =" WHERE OPERATOR_NAME = '".$operator_name."'";
     }else{
         $where='';
         $cli_where='';   
         $operator_where ='';
     }
       
       
    	$data['filter_by'] = "Filtered By: ";   
    	$data['action_type'] = 'view';
    	if( $this->input->post('print') ){
    	    $data['action_type'] = 'print';
    	}elseif( $this->input->post('export') ){
    	    $data['action_type'] = 'csv';
    	}
       
    if(isset($calculative_month)){
             $where .= " AND YEAR(REPORT_DATE) = ".date("Y", $calculative_month)." AND MONTH(REPORT_DATE) = ".date("m", $calculative_month);
             $cli_where .= " AND YEAR(REPORT_DATE) = ".date("Y", $calculative_month)." AND MONTH(REPORT_DATE) = ".date("m", $calculative_month);
             $data['filter_by'] .= "Month: ".date("m-Y", $calculative_month) ;
             $data['date']=date('Y-m-d', $calculative_month);
             $data['formated_date']=date('M Y', $calculative_month);
    }
       
       $this->webspice->remove_cache('invoice_icx_ios');
        $data['current_date']=date("M d,Y");
        $sql = $sql.$where;
        $cli_sql = $sql_for_cli.$cli_where;
        $operator_sql = $sql_for_operator.$operator_where;
        $data["get_record"] = $this->db->query($sql)->result();
        $data["get_cli"] = $this->db->query($cli_sql)->result();
        $data["get_operator_info"] = $this->db->query($operator_sql)->row();
       
        if(empty($data["get_record"])){
            $this->webspice->message_board('No data Found!');
            $this->load->view('invoice/invoice_icx');
          return false;
        }
  
      // if( $this->input->post('pdf') ){
      //  	$data['action_type'] = 'pdf';
      //    $result = $this->db->query($sql)->result();
      //  	$data['get_record'] = $result;
       
      //		$filename = time()."_invoice_icx.pdf";
      //		$html = $this->load->view('invoice/print_invoice_icx', $data, true);
      //		$this->load->library('M_pdf');
      		#$this->m_pdf->param = "'c', 'L'";
          #$this->m_pdf->allow_charset_conversion=true;  // Set by default to TRUE 
       //   $this->m_pdf->charset_in='utf-8';
     	//	 	$this->m_pdf->pdf->WriteHTML($html);
     
  // dd($_POST);
      if($input->invoice_generation == "no"){

    			$total_invoice_value=0;
    			$total_cli=0;
    			$operator_name = $data['get_record'][0]->OPERATOR_NAME;
    			$invoice_number = 'Interconnection/BL-'.$operator_name.'/'.$data['date'];
          
          foreach($data['get_record'] as $k => $v){    
          	$total_invoice_value=$total_invoice_value+$v->AMOUNT;         
          }
          foreach($data['get_cli'] as $k => $v){
						$total_cli=$total_cli+$v->AMOUNT;
					}
					$total_vat=(($total_invoice_value+$total_cli)*15)/100;
          
          $invoice_data[] = array(
                  "OPERATOR_NAME" => $operator_name,
                  "OPERATOR_TYPE" => $operator_type,
                  "INVOICE_NUMBER" => $invoice_number,
                  "INVOICE_AMOUNT" => $total_invoice_value,
                  "NO_CLI"=> $total_cli,
                  "SMS"=>0,
                  "VAT"=>$total_vat,
                  "BILL_PERIOD" => $report_date,
                  "REMAINING_AMOUNT" => $total_invoice_value,
                  "DISPUTE"=>0
              );
           
          $this->db->insert_batch("TBL_INVOICE_DETAIL" , $invoice_data);
          $this->db->insert_batch("TBL_INVOICE" , $invoice_data);
 
     // }
     
      # $this->m_pdf->pdf->Output(FCPATH."global/".$filename, "F"); #F for sile save and D for download
      //$this->m_pdf->pdf->Output($filename, "D"); # F for sile save and D for download
     
     // return false;
    }
      if($input->invoice_generation != ""){ 
       $this->load->view('invoice/print_invoice_icx', $data);
      }else{
      	 //$this->webspice->message_board('No data Found!');
         $this->load->view('invoice/invoice_icx');
         return false;
      	}
  }


































	function upload_isms_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		#$config = $this->ft->get('config');
		#$config = $config->{'0'};
		#$usd_rate = $config->usd_rate;
		#$icx_portion = $config->icx_portion;
		#$igw_portion = $config->igw_portion;
		#$btrc_portion = $config->btrc_portion;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_isms_data');
		$this->webspice->permission_verify('upload_isms_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('payment/upload_isms_data', $data);
			return FALSE;
		}		
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'payment/upload_isms_data');
		}
		$sheet_columns = array("Date", "Total Messages To", "Total Messages From", "Total Amount (EUR) - Messsages To", "Total Amount (EUR) - Messages From");
		$header_offset = 1;
		$column_offset = 1;
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}

		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_isms_data');
			return FALSE;
		}
		
		$input = $this->webspice->get_input();
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$duplicate_where = array();
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$total_message_to = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$total_message_form = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$amount_to = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$amount_from = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$values[] = array(
				"TOTAL_MESSAGE_TO" => $total_message_to, "TOTAL_MESSAGE_FROM" => $total_message_form, "AMOUNT_TO" => $amount_to, 
				"AMOUNT_FROM" => $amount_from,
				"CREATED_BY" => $this->webspice->get_user_id(),"DATE_TIME"=>$date_time, "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			# must have column value - column offset started from 1
			if( !isset($total_message_to) || !isset($total_message_form) || !isset($amount_to)  || !isset($amount_from)){
				$data_error .= 'Row #'.$k.' is Blank. Please Remove it.<br />';
			}
			
			
			if( isset($total_message_to) && !is_numeric($total_message_to) ){
				$data_error .= 'Total Message From "'.$total_message_to.'" at Row #'.$k.' is invalid.<br />';
			}
			
		//	if( isset($mcc) && !is_numeric($mcc) ){
			//	$data_error .= 'MCC "'.$mcc.'" at Row #'.$k.' is invalid.<br />';
			//}
			
		//	if( isset($mnc) && !is_numeric($mnc) ){
		//		$data_error .= 'MNC "'.$mnc.'" at Row #'.$k.' is invalid.<br />';
		//	}
		//	$duplicate_where[] = " (DATE_TIME='".$date_time."' AND OPERATOR='".$operator."' AND PREPOST_FLAG='".$prepost_flag."' AND TARIFFCLASS='".$tariffclass."') ";
		}
		
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		$table_name = "TBL_ISMS_DATA";
		$is_value = false;
		 if($input->data_insert == "data_remove_insert" ){
			//$this->db->where_in('JOIN_DATA_FLAG',0);
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$date_time)." AND MONTH(DATE_TIME) = ".date("m",$date_time));
			$this->db->delete($table_name);
		 }
		$this->db->insert_batch($table_name, $values);
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_isms_data'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_isms_data', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_isms_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	
	
	
	function collection_with_dispute_perfect($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'collection_with_dispute');
		$this->webspice->permission_verify('collection_with_dispute');		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('CHEQUE_AMOUNT','Cheque Amount','required|trim|xss_clean');
		$this->form_validation->set_rules('CHEQUE_DATE','Cheque Date','required|trim|xss_clean');
		$this->form_validation->set_rules('ENTRY_DATE','Entry Date','required|trim|xss_clean');
		$data['operator_name']=$this->db->query("SELECT OPERATOR_NAME,OPERATOR_TYPE FROM TBL_OPERATOR")->result();
		$values_for_ait=null;
		if( !$_POST ){ 
			$this->load->view('collection/collection_with_dispute', $data);
			return FALSE;
		}
		$operator_name_type_string = $_POST['OPERATOR_NAME'];
		$operator_name_type_array = explode("|",$operator_name_type_string);
		$operator_name = $operator_name_type_array[1];
		$operator_type = $operator_name_type_array[0];
		$from_date = $_POST['from_date'];
		$to_date = $_POST['to_date'];
		$cheque_amount_settlement = $_POST['CHEQUE_AMOUNT_SETTLEMENT'];
		$cheque_amount_remaining = $_POST['CHEQUE_AMOUNT_REMAINING'];
		$total_amount = $cheque_amount_settlement + $cheque_amount_remaining;
		$tds_settlement = $_POST['TDS_SETTLEMENT'];
		$bank_name = $_POST['BANK_NAME'];
		$bank_account = $_POST['BANK_ACCOUNT'];
		$cheque_number = $_POST['CHEQUE_NUMBER'];
		$cheque_amount = $_POST['CHEQUE_AMOUNT'];
		$tds_rate = $_POST['TDS_RATE'];
		$cheque_date = $_POST['CHEQUE_DATE'];
		$entry_date = $_POST['ENTRY_DATE'];
		$total_settlement = $_POST['TOTAL_SETTLEMENT'];
		$total_settlement=0;
		$total_settlement=0;
		$allocated_data = $this->input->post("ALLOCATED_DATA");
		//dd($allocated_data);
		$edch_pn_sql = array();
		$gl_sql = "SELECT * FROM TBL_DOMESTIC_REV_GL_MAPPING WHERE OPERATOR_NAME='".$operator_name."'";
		                   $gl=$this->db->query($gl_sql)->row();
						    if($gl)
						   { $invoice_gl=$gl->INVOICE;}else{
							    $invoice_gl=0;
						   }
						   
		$gl_project_code= "SELECT * FROM TBL_OPERATOR WHERE OPERATOR_NAME='".$operator_name."' AND OPERATOR_TYPE='".$operator_type."'";
		                   $project_code=$this->db->query($gl_project_code)->row();
						   if($project_code)
						   { $project_code=$project_code->PROJECT_CODE;}else{
							    $project_code=0;
						   }
						   
					foreach($allocated_data as $key4 => $value4){
						$receiveable_data = $value4;
						if(array_key_exists('SEQ_ID',$receiveable_data)){
							$invoice_id_in_array[] = $receiveable_data['INVOICE_ID'];
							
							
							$values[] = array(
				                 	"OPERATOR_NAME" => $operator_name, "OPERATOR_TYPE" => $operator_type, "INVOICE_NUMBER" => $receiveable_data['INVOICE_NUMBER'], 
													"INVOICE_AMOUNT" => trim($receiveable_data['INVOICE_AMOUNT']), "NO_CLI"=> 0, "SMS" => 0, "VAT" => 0,"BILL_PERIOD"=> $receiveable_data['BILL_PERIOD'],"REMAINING_AMOUNT"=> trim($receiveable_data['REMAINING_AMOUNT']), "DISPUTE"=>$receiveable_data['DISPUTE'],
													"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
													
								//dd($receiveable_data);			
							if($receiveable_data['TDS'] !=0){					
							$values_for_ait[] = array(
				                 	"OPERATOR_NAME" => $operator_name, "AIT_COMMENT"=>$receiveable_data['COMMENT'],"OPERATOR_TYPE" => $operator_type,"PROJECT_CODE"=>$project_code, "INVOICE_NUMBER" => $receiveable_data['INVOICE_NUMBER'], "AIT"=>$receiveable_data['TDS'],"INVOICE_GL"=>$invoice_gl,													
													"TO_DATE"=>$to_date,"FROM_DATE"=>$from_date ,"REPORT_DATE"=> $entry_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
						}}
					}
		$invoice_id_in_string = implode(",",$invoice_id_in_array);
		if($cheque_amount_remaining < 0){
			$net_amount=0;
		}else{
			$net_amount=$cheque_amount_remaining;
		}		
	//	if($total_settlement > $cheque_amount){
	//		$this->webspice->message_board('We could not execute your request.Your collection is '.$cheque_amount.'tk but You try to settled '.$total_settlement.'tk.');
	//		$this->webspice->force_redirect($url_prefix.'collection_with_dispute');
	//		return false;
	//	}
		$table_name='TBL_INVOICE';
		$this->db->insert_batch($table_name, $values);
		if(!empty($values_for_ait)){
			$table_name='TBL_AIT';
		$this->db->insert_batch('TBL_AIT', $values_for_ait);
			
		}
		$table_name='TBL_INVOICE_DETAIL';
		//dd($values);
		$this->db->update_batch($table_name, $values, 'INVOICE_NUMBER');
		
		$sql = " INSERT INTO TBL_COLLECTION
		(OPERATOR, OPERATOR_TYPE, CHEQUE_NO, BANK_NAME, CHEQUE_AMOUNT, CHEQUE_DATE, ENTRY_DATE, CHEQUE_AMOUNT_SETTLEMENT , CHEQUE_AMOUNT_REMAINING , INVOICE_ID, CREATED_BY, CREATED_DATE, NET_AMOUNT, STATUS)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,? ,? , ?,7) ";
		$this->db->query($sql, array($operator_name, $operator_type, $cheque_number, $bank_name, trim($cheque_amount), $cheque_date,$entry_date, trim($cheque_amount_settlement), trim($cheque_amount_remaining), $invoice_id_in_string, $this->webspice->get_user_id(), $this->webspice->now(),$net_amount));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted!.');
		$this->webspice->force_redirect($url_prefix.'collection_with_dispute');
	}
	
	
	
	
	
	
	function collection_with_dispute($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'collection_with_dispute');
		$this->webspice->permission_verify('collection_with_dispute');
		
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('CHEQUE_AMOUNT','Cheque Amount','required|trim|xss_clean');
		$this->form_validation->set_rules('CHEQUE_DATE','Cheque Date','required|trim|xss_clean');
		$this->form_validation->set_rules('ENTRY_DATE','Entry Date','required|trim|xss_clean');
		$data['operator_name']=$this->db->query("SELECT OPERATOR_NAME,OPERATOR_TYPE FROM TBL_OPERATOR")->result();
		$values_for_ait=null;
		if( !$_POST ){ 
			$this->load->view('collection/collection_with_dispute', $data);
			return FALSE;
		}
	
		$operator_name_type_string = $_POST['OPERATOR_NAME'];
		$operator_name_type_array = explode("|",$operator_name_type_string);
		$operator_name = $operator_name_type_array[1];
		$operator_type = $operator_name_type_array[0];
		$from_date = $_POST['from_date'];
		$to_date = $_POST['to_date'];
		$cheque_amount_settlement = $_POST['CHEQUE_AMOUNT_SETTLEMENT'];
		$cheque_amount_remaining = $_POST['CHEQUE_AMOUNT_REMAINING'];
		$total_amount = $cheque_amount_settlement + $cheque_amount_remaining;
		$tds_settlement = $_POST['TDS_SETTLEMENT'];
		$bank_name = $_POST['BANK_NAME'];
		$bank_account = $_POST['BANK_ACCOUNT'];
		$cheque_number = $_POST['CHEQUE_NUMBER'];
		$cheque_amount = $_POST['CHEQUE_AMOUNT'];
		$tds_rate = $_POST['TDS_RATE'];
		$cheque_date = $_POST['CHEQUE_DATE'];
		$entry_date = $_POST['ENTRY_DATE'];
		$ageing_month = date("m",strtotime($entry_date));
		$ageing_year = date("Y",strtotime($entry_date));
		$ageing_date = $ageing_year.'-'.$ageing_month.'-'.'01';
		$total_settlement = $_POST['TOTAL_SETTLEMENT'];
		$total_settlement=0;
		$total_settlement=0;
		$allocated_data = $this->input->post("ALLOCATED_DATA");
		//dd($allocated_data);
		$edch_pn_sql = array();
		$gl_sql = "SELECT * FROM TBL_DOMESTIC_REV_GL_MAPPING WHERE OPERATOR_NAME='".$operator_name."'";
		                   $gl=$this->db->query($gl_sql)->row();
						    if($gl)
						   { $invoice_gl=$gl->INVOICE;}else{
							    $invoice_gl=0;
						   }
						   
		$gl_project_code= "SELECT * FROM TBL_OPERATOR WHERE OPERATOR_NAME='".$operator_name."' AND OPERATOR_TYPE='".$operator_type."'";
		                   $project_code=$this->db->query($gl_project_code)->row();
						   if($project_code)
						   { $project_code=$project_code->PROJECT_CODE;}else{
							    $project_code=0;
						   }
						   
					foreach($allocated_data as $key4 => $value4){
						$receiveable_data = $value4;
						if(array_key_exists('SEQ_ID',$receiveable_data)){
							$invoice_id_in_array[] = $receiveable_data['INVOICE_ID'];
							
							
							$values[] = array(
				                 	"OPERATOR_NAME" => $operator_name, "OPERATOR_TYPE" => $operator_type, "INVOICE_NUMBER" => $receiveable_data['INVOICE_NUMBER'], "AGEING_DATE"=>$ageing_date,
													"INVOICE_AMOUNT" => trim($receiveable_data['INVOICE_AMOUNT']), "NO_CLI"=> 0, "SMS" => 0, "VAT" => 0,"BILL_PERIOD"=> $receiveable_data['BILL_PERIOD'],"REMAINING_AMOUNT"=> trim($receiveable_data['REMAINING_AMOUNT']), "DISPUTE"=>$receiveable_data['DISPUTE'],
													"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
													
													
													
													
							
								//dd($receiveable_data);			
							if($receiveable_data['TDS'] !=0){					
							$values_for_ait[] = array(
				                 	"OPERATOR_NAME" => $operator_name, "AIT_COMMENT"=>$receiveable_data['COMMENT'],"OPERATOR_TYPE" => $operator_type,"PROJECT_CODE"=>$project_code, "INVOICE_NUMBER" => $receiveable_data['INVOICE_NUMBER'], "AIT"=>$receiveable_data['TDS'],"INVOICE_GL"=>$invoice_gl,													
													"TO_DATE"=>$to_date,"FROM_DATE"=>$from_date ,"REPORT_DATE"=> $entry_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
						}}
					}
		$invoice_id_in_string = implode(",",$invoice_id_in_array);
		if($cheque_amount_remaining < 0){
			$net_amount=0;
		}else{
			$net_amount=$cheque_amount_remaining;
		}		
	//	if($total_settlement > $cheque_amount){
	//		$this->webspice->message_board('We could not execute your request.Your collection is '.$cheque_amount.'tk but You try to settled '.$total_settlement.'tk.');
	//		$this->webspice->force_redirect($url_prefix.'collection_with_dispute');
	//		return false;
	//	}
		$table_name='TBL_INVOICE';
		$this->db->insert_batch($table_name, $values);
		if(!empty($values_for_ait)){
			$table_name='TBL_AIT';
		$this->db->insert_batch('TBL_AIT', $values_for_ait);
			
		}
		$table_name='TBL_INVOICE_DETAIL';
		//dd($values);
		$this->db->insert_batch($table_name, $values);
		
		$sql = " INSERT INTO TBL_COLLECTION
		(OPERATOR, OPERATOR_TYPE, CHEQUE_NO, BANK_NAME, CHEQUE_AMOUNT, CHEQUE_DATE, ENTRY_DATE, CHEQUE_AMOUNT_SETTLEMENT , CHEQUE_AMOUNT_REMAINING , INVOICE_ID, CREATED_BY, CREATED_DATE, NET_AMOUNT, STATUS)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,? ,? , ?,7) ";
		$this->db->query($sql, array($operator_name, $operator_type, $cheque_number, $bank_name, trim($cheque_amount), $cheque_date,$entry_date, trim($cheque_amount_settlement), trim($cheque_amount_remaining), $invoice_id_in_string, $this->webspice->get_user_id(), $this->webspice->now(),$net_amount));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted!.');
		$this->webspice->force_redirect($url_prefix.'collection_with_dispute');
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function ait_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'ait_report');
		$this->webspice->permission_verify('ait_report');
		
			$sql = "SELECT * FROM TBL_AIT";
		$where = " WHERE STATUS = 7 " ;
	
		if( !$_POST ){
			$this->load->view('report/ait_report', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		
		$sql = $sql.$where;
    $data["get_record"] = $this->db->query($sql)->result();
     if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/ait_report', $data);
			return false;
    	}
		//dd(333333);
		$this->load->view('report/print_ait_report', $data);
	}	
	
	
	
	
	

}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */