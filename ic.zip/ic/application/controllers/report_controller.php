<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	function domestic_sms_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'domestic_sms_jv');
		$this->webspice->permission_verify('domestic_sms_jv');
		
		$sql = " 
			SELECT DATE_TIME, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, OPERATOR, CALLTYPE, PREPOST_FLAG,PROJECT_CODE,OPERATOR_TYPE,
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN NETAMOUNT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN NETAMOUNT  END  ) AS PREP_VALUE 
			FROM TBL_DOMESTIC_SMS_MMS 
		";
		$where = " WHERE STATUS = 7 AND OPERATOR !='' AND OPERATOR!='Blank'  AND OPERATOR!='OTHERS' AND OPERATOR!='Banglalink'" ;
		$group_by = " GROUP BY OPERATOR " ;
		$order_by = " ORDER BY OPERATOR " ;
		
		if( !$_POST ){
			$this->load->view('report/domestic_sms_jv', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		
		$call_type = $input->CALLTYPE;
		$data['call_type'] = $call_type;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  		
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		
		if($call_type=="revenue"){
			 $where .= " AND CALLTYPE = 'MTSMS' ";
			 $data['filter_by'] .= "Revenue ";
		}
		
		if($call_type=="cost"){
			 $where .= " AND CALLTYPE = 'MOSMS' ";
			 $data['filter_by'] .= "Cost ";
		}

		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;
		$data["get_record"] = $this->db->query($sql)->result();
		if( empty($data["get_record"])){
			$this->webspice->message_board('Record is not found!');
			$this->load->view('report/domestic_sms_jv', $data);
			return false;
		}
		$this->load->view('report/print_domestic_sms_jv', $data);
	}
	
	function domestic_mms_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'domestic_mms_jv');
		$this->webspice->permission_verify('domestic_mms_jv');
		
		$sql = "SELECT DATE_TIME, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, OPERATOR, CALLTYPE, PREPOST_FLAG,OPERATOR_TYPE,PROJECT_CODE,  
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN NETAMOUNT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN NETAMOUNT  END  ) AS PREP_VALUE 
			FROM TBL_DOMESTIC_SMS_MMS";
			
		$where = " WHERE STATUS = 7 AND OPERATOR !='' AND OPERATOR!='Blank' AND OPERATOR!='OTHERS'" ;
		$group_by = " GROUP BY OPERATOR " ;
		$order_by = " ORDER BY OPERATOR " ;
		if( !$_POST ){
			$this->load->view('report/domestic_mms_jv', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$call_type = $input->CALLTYPE;
		$data['call_type'] = $call_type;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		
		if($call_type=="revenue"){
			 $where .= " AND CALLTYPE = 'MTMMS' ";
			 $data['filter_by'] .= "Revenue ";
		}
		
		if($call_type=="cost"){
			 $where .= " AND CALLTYPE = 'MOMMS' ";
			 $data['filter_by'] .= "Cost ";
		}
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    //dd($this->db->last_query());
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/domestic_mms_jv', $data);
			return false;
    	}
		$this->load->view('report/print_domestic_mms_jv', $data);
	}
	
	function domestic_voice_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'domestic_voice_jv');
		$this->webspice->permission_verify('domestic_voice_jv');
		
		$sql = " 
			SELECT DATE_TIME, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, OPERATOR,OPERATOR_TYPE,PROJECT_CODE, CALL_TYPE, PREPOST_FLAG,  
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN AMOUNT_EXCLUDING_VAT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN AMOUNT_EXCLUDING_VAT  END  ) AS PREP_VALUE 
			FROM TBL_VOICE_CALL_LOCAL 
		";
		$where = " WHERE STATUS = 7 AND OPERATOR !='' AND OPERATOR!='Blank' AND OPERATOR!='OTHERS'" ;
		$group_by = " GROUP BY OPERATOR " ;
		$order_by = " ORDER BY OPERATOR " ;
		
		
		
		
		$sql_icx = " 
			SELECT DATE_TIME, PROJECT_CODE,OPERATOR_TYPE,MAX(DAY(DATE_TIME)) AS MAX_DAY_ICX, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY_ICX, ICX AS OPERATOR, CALL_TYPE, PREPOST_FLAG,  
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN AMOUNT_EXCLUDING_VAT  END  ) AS POST_VALUE_ICX, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN AMOUNT_EXCLUDING_VAT  END  ) AS PREP_VALUE_ICX 
			FROM TBL_ICX_DAILY_DATA 
		";
		$icx_where = " WHERE STATUS = 7 AND ICX != '' AND ICX != 'Blank' AND ICX != 'OTHERS'" ;
		$icx_group_by = " GROUP BY ICX " ;
		$icx_order_by = " ORDER BY ICX " ;
		
		if( !$_POST ){
			$this->load->view('report/domestic_voice_jv', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		
		$call_type = $input->CALLTYPE;
		$data['call_type'] = $call_type;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		
		if($call_type=="revenue"){
			 $where .= " AND CALL_TYPE = 'MT' ";
			 $data['filter_by'] .= "Revenue ";
		}
		
		if($call_type=="cost"){
			 $where .= " AND CALL_TYPE = 'MO' ";
			 $data['filter_by'] .= "Cost ";
		}
		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month); 
			 $icx_where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;	
		$sql_icx = $sql_icx.$icx_where.$icx_group_by.$icx_order_by;	
		$data["get_record"] = $this->db->query($sql)->result();		
		$data["get_record_icx"] = $this->db->query($sql_icx)->result();	
	//dd($this->db->last_query());
		  if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    		$this->load->view('report/domestic_voice_jv', $data);
			return false;
    	}
		$this->load->view('report/print_domestic_voice_jv', $data);
	}
	
	function international_mms_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'international_mms_jv');
		$this->webspice->permission_verify('international_mms_jv');
		
		$sql = " 
			SELECT DATE_TIME, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, OPERATOR, CALL_TYPE, PREPOST_FLAG,  
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN AMOUNT_EXCLUDING_VAT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN AMOUNT_EXCLUDING_VAT  END  ) AS PREP_VALUE 
			FROM TBL_VOICE_CALL_LOCAL 
		";
		$where = " WHERE STATUS = 7 AND OPERATOR !='' " ;
		$group_by = " GROUP BY OPERATOR " ;
		$order_by = " ORDER BY OPERATOR " ;
		
		if( !$_POST ){
			$this->load->view('report/international_mms_jv', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		
		$call_type = $input->CALLTYPE;
		$data['call_type'] = $call_type;
		$prepost_flag = $input->PREPOST_FLAG;
		$report_type = $input->REPORT_TYPE;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		
		if($call_type=="revenue"){
			 $where .= " AND CALL_TYPE = 'MT' ";
			 $data['filter_by'] .= "Revenue ";
		}
		
		if($call_type=="cost"){
			 $where .= " AND CALL_TYPE = 'MO' ";
			 $data['filter_by'] .= "Cost ";
		}
		
		if($prepost_flag=="all"){
			 $where .= " AND ( PREPOST_FLAG = 'PREP' || PREPOST_FLAG = 'POST' ) ";
			 $data['filter_by'] .= "Prepaid, Postpaid ";
		}
		
		if($prepost_flag=="prep"){
			 $where .= " AND PREPOST_FLAG = 'PREP' ";
			 $data['filter_by'] .= "Prepaid ";
		}
		
		if($prepost_flag=="post"){
			 $where .= " AND PREPOST_FLAG = 'POST' ";
			 $data['filter_by'] .= "Postpaid ";
		}
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
		}
		
		$sql = $sql.$where.$group_by.$order_by;
		
		$data["report_type"] = $report_type;
		
		$data["get_record"] = $this->db->query($sql)->result();
		
		$this->load->view('report/print_international_mms_jv', $data);
	}
	
	function international_voice_in_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'international_voice_in_jv');
		$this->webspice->permission_verify('international_voice_in_jv');
		
		$sql = " 
			SELECT PROJECT_CODE,OPERATOR_TYPE,DATE_TIME, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, IOS AS OPERATOR, CALL_TYPE, PREPOST_FLAG,  
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN AMOUNT_EXCLUDING_VAT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN AMOUNT_EXCLUDING_VAT  END  ) AS PREP_VALUE 
			FROM TBL_VOICE_CALL_INT_IN 
		";
		$where = " WHERE STATUS = 7" ;
		$group_by = " GROUP BY IOS " ;
		$order_by = " ORDER BY IOS " ;
		
		if( !$_POST ){
			$this->load->view('report/international_voice_in_jv', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$data['call_type'] = 'revenue';
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= " AND CALL_TYPE = 'MT' ";
		$data['filter_by'] .= "Revenue ";
		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;
		$data["get_record"] = $this->db->query($sql)->result();
		if(empty($data["get_record"])){
			 $this->webspice->message_board('Record is not found!'); 
			$this->load->view('report/international_voice_in_jv', $data);
			return false;
		}
		$this->load->view('report/print_international_voice_in_jv', $data);
	}
	
	function domestic_toll_free_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'domestic_toll_free_jv');
		$this->webspice->permission_verify('domestic_toll_free_jv');
		$sql = " 
			SELECT DATE_TIME, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, OPERATOR_NAME, PREPOST_FLAG,OPERATOR_TYPE,PROJECT_CODE,  
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN REVENUE  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN REVENUE  END  ) AS PREP_VALUE 
			FROM TBL_LOCAL_TOLL_FREE_DATA 
		";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' AND OPERATOR_NAME!='Blank' AND OPERATOR_NAME!='OTHERS'" ;
		$group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		
		if( !$_POST ){
			$this->load->view('report/domestic_toll_free_jv', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$data['call_type'] = 'Revenue';
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Revenue ";
		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;
		$data["get_record"] = $this->db->query($sql)->result();
		//dd($this->db->last_query());
			if( empty($data["get_record"] ) ){
      $this->webspice->message_board('Record is not found!');
			$this->load->view('report/domestic_toll_free_jv', $data);
			return false;
		}
		
		$this->load->view('report/print_domestic_toll_free_jv', $data);
	}
	
	function international_toll_free_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'international_toll_free_jv');
		$this->webspice->permission_verify('international_toll_free_jv');
		$sql = " 
			SELECT DATE_TIME, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, OPERATOR_NAME, PREPOST_FLAG,OPERATOR_TYPE,PROJECT_CODE,  
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN BL_REVENUE  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN BL_REVENUE  END  ) AS PREP_VALUE 
			FROM TBL_INT_TOLL_FREE_DATA 
		";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' AND OPERATOR_NAME!='Blank' AND OPERATOR_NAME!='OTHERS'" ;
		$group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		
		if( !$_POST ){
			$this->load->view('report/international_toll_free_jv', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$call_type = 'Revenue';
		$data['call_type'] = $call_type;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		
		if($call_type=="revenue"){
			 #$where .= " AND CALL_TYPE = 'MT' ";
			 $data['filter_by'] .= "Revenue ";
		}
		
		if($call_type=="cost"){
			 #$where .= " AND CALL_TYPE = 'MO' ";
			 $data['filter_by'] .= "Cost ";
		}

		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;	
		$data["get_record"] = $this->db->query($sql)->result();
		if(empty($data["get_record"])){
    $this->webspice->message_board('Record is not found!');
			$this->load->view('report/international_toll_free_jv', $data);
			return false;
			}
		$this->load->view('report/print_international_toll_free_jv', $data);
	}
	
	function international_voice_out_jv($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'international_voice_out_jv');
		$this->webspice->permission_verify('international_voice_out_jv');
		
		$sql = " 
			SELECT DATE_TIME,OPERATOR_TYPE,PROJECT_CODE, MAX(DAY(DATE_TIME)) AS MAX_DAY, DAY(LAST_DAY(DATE_TIME)) AS LAST_DAY, 
			OPERATOR, PREPOST_FLAG, USD_RATE,
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN ICX_PORTION  END  ) AS POST_ICX_PORTION, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN ICX_PORTION  END  ) AS PREP_ICX_PORTION, 
			
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN IGW_PORTION  END  ) AS POST_IGW_PORTION, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN IGW_PORTION  END  ) AS PREP_IGW_PORTION,
			
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN BTRC_PORTION  END  ) AS POST_BTRC_PORTION, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN BTRC_PORTION  END  ) AS PREP_BTRC_PORTION,
			
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN AMOUNT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN AMOUNT  END  ) AS PREP_VALUE, 
			
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN Y_VALUE  END  ) AS POST_Y_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN Y_VALUE  END  ) AS PREP_Y_VALUE,
			
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN Z_VALUE  END  ) AS POST_Z_VALUE, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN Z_VALUE  END  ) AS PREP_Z_VALUE,
			
			
			SUM( CASE WHEN PREPOST_FLAG = 'POST' THEN TOTAL_COST  END  ) AS POST_TOTAL_COST, 
			SUM( CASE WHEN PREPOST_FLAG = 'PREP' THEN TOTAL_COST  END  ) AS PREP_TOTAL_COST
			
			FROM TBL_VOICE_CALL_INT_OUT 
		";
		$where = " WHERE STATUS = 7 AND OPERATOR !='' AND OPERATOR!='Blank' AND OPERATOR!='OTHERS'" ;
		$group_by = " GROUP BY OPERATOR " ;
		$order_by = " ORDER BY OPERATOR " ;
		
		if( !$_POST ){
			$this->load->view('report/international_voice_out_jv', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		
		$call_type = 'Cost';
		$data['call_type'] = $call_type;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		
		if($call_type=="revenue"){
			 #$where .= " AND CALL_TYPE = 'MT' ";
			 $data['filter_by'] .= "Revenue ";
		}
		
		if($call_type=="cost"){
			 #$where .= " AND CALL_TYPE = 'MO' ";
			 $data['filter_by'] .= "Cost ";
		}
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;	
		$data["get_record"] = $this->db->query($sql)->result();
		if(empty($data["get_record"])){
			$this->webspice->message_board('Record is not found!');
			$this->load->view('report/international_voice_out_jv', $data);
			return false;
			}
		$gl_sql = "SELECT * FROM TBL_COMMON_GL_MAPPING";
		$data['common_gl']=$this->db->query($gl_sql)->row();
		$this->load->view('report/print_international_voice_out_jv', $data);
	}
	
	
	function upload_no_cli(){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_no_cli');
		$this->webspice->permission_verify('upload_no_cli');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_no_cli');
			return FALSE;
		}		
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xls'), 'sap_file', $data, 'uploader/upload_no_cli');
		}
		
		$sheet_columns = array("DATE_TIME", "ICX", "OPERATOR", "CALLS", "MINUTES", "RATE_PER_MIN");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_no_cli');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$report_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$call_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$operator = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$icx = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$number_of_calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$rate_per_minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$amount_excluding_vat = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			
			$values[] = array(
				"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
				"PREPOST_FLAG" => $prepost_flag, "OPERATOR" => $operator, "NUMBER_OF_CALLS" => $number_of_calls, 
				"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			
			if( $date_traker < strtotime($date_time) ){
				$date_traker = strtotime($date_time);
				$single_values = array();
				$single_values[] = array(
					"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
					"PREPOST_FLAG" => $prepost_flag, "OPERATOR" => $operator, "NUMBER_OF_CALLS" => $number_of_calls, 
					"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat,
					"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
				);
				$single_date = $date_time;
			}elseif($date_traker == strtotime($date_time)){
				$single_values[] = array(
					"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
					"PREPOST_FLAG" => $prepost_flag, "OPERATOR" => $operator, "ICX" => $icx, "NUMBER_OF_CALLS" => $number_of_calls, 
					"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat,
					"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
				);
				$single_date = $date_time;
			}
			
			if( $unique_date_traker != strtotime($date_time) ){
					$unique_date_traker = strtotime($date_time);
					$unique_date[] = $date_time;
			}
			
			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($report_type) || !isset($call_type) || !isset($prepost_flag) || !isset($number_of_calls) || !isset($minutes) || !isset($rate_per_minutes) || !isset($amount_excluding_vat) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($number_of_calls) && !is_numeric($number_of_calls) ){
				$data_error .= 'Number Of Calls "'.$number_of_calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($minutes) && !is_numeric($minutes) ){
				$data_error .= 'Minutes "'.$minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($rate_per_minutes) && !is_numeric($rate_per_minutes) ){
				$data_error .= 'Rate Per Minutes "'.$rate_per_minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($amount_excluding_vat) && !is_numeric($amount_excluding_vat) ){
				$data_error .= 'Amount Excluding Vat "'.$amount_excluding_vat.'" at Row #'.$k.' is invalid.<br />';
			}
			
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_no_cli', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_NO_CLI";
		$input = $this->webspice->get_input();
		
		if( $input->data_update_new == "last_day_data" ){
			$values = $single_values;
			$unique_date = $single_date;
		}
		
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where_in('DATE_TIME', $unique_date);
			$this->db->delete($table_name);
		}
		
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_no_cli'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_no_cli', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_no_cli');
		}
		
		$this->webspice->force_redirect($url_prefix);
	
	}
	function manage_no_cli(){
	  $url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_no_cli');
		$this->webspice->permission_verify('manage_no_cli');
		$this->load->database();
    $orderby = ' ORDER BY TBL_NO_CLI.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		$initialSQL = " SELECT TBL_NO_CLI.* FROM TBL_NO_CLI ";
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_NO_CLI', 
				$InputField = array(),
				$Keyword = array(),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}
    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}	
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('uploader/print_no_cli',$data);
				return false;
        break;               
    }
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_no_cli/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_no_cli', $data);
	}
	
	function ait_gl($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'ait_gl');
		$this->webspice->permission_verify('ait_gl');
		
			$sql = "SELECT *
			FROM TBL_AIT_GL";
		//$sql = "SELECT OPERATOR_NAME,PRE_POST,AMOUNT FROM TBL_FULL_MONTH_MOMMS";
	  $group_by = "" ;
		$order_by = " ORDER BY DESCRIPTION " ;
		if( !$_POST ){
			$this->load->view('report/ait_gl', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		//$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/ait_gl', $data);
			return false;
    	}
		$this->load->view('report/print_ait_gl', $data);
	}		
	
	function journal_sybase_mobile($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'journal_sybase_mobile');
		$this->webspice->permission_verify('journal_sybase_mobile');
		$sql = " 
			SELECT UNIT_PRICE_EUR_2,DAY(LAST_DAY(REPORT_DATE)) AS LAST_DAY,
			SUM(CUSTOMER_RECEIVES_FROM) AS TOTAL_CUSTOMER_RECEIVES_FROM, 
			SUM(CUSTOMER_DELIVERS_TO) AS TOTAL_CUSTOMER_DELIVERS_TO
			FROM TBL_ISMS_DATA_FOR_JOURNAL
		";
		$where = "";
		$group_by = "" ;
		$order_by = "" ;
		$sql_cost = "SELECT UNIT_PRICE , ZONE, SUM(CUSTOMER_DELIVERS_TO) AS TOTAL_CUSTOMER_DELIVERS_TO FROM TBL_ISMS_DATA_FOR_JOURNAL ";
		$where_cost = "";
		$group_by_cost = " GROUP BY ZONE " ;
		$order_by_cost = " ORDER BY ZONE " ;
		if( !$_POST ){
		//	$this->load->view('report/domestic_sms_jv', $data);
			$this->load->view('report/journal_sybase_mobile', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
    $exchange_rate=$input->get_usd_rate;
    $data['usd_euro']=explode("|",$exchange_rate);
		$report_date = $input->CALCULATIVE_MONTH;
		$calculative_month=$report_date.'-01';
		$exchange_rate = $input->get_usd_rate;	
		$exchange_rate_month=$exchange_rate.'-01';	
		#$exchange_rate_month=date("Y-m-d",$exchange_rate);
		#dd($exchange_rate,'c');
		#dd($report_date);
		#$calculative_month=date("Y-m-d",$report_date);		
	//	$data['current_rate'] = $this->db->query("SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE WHERE REPORT_MONTH='".$exchange_rate_month."'")->row();
		$data['b2b_and_b2c_ratio'] = $this->db->query("SELECT * FROM TBL_MT_RATE WHERE REPORT_MONTH='".$calculative_month."'")->row();

    	if(empty($data['b2b_and_b2c_ratio'])){
    	$this->webspice->message_board('Please update ratio for the month of '.$calculative_month.' !');
			$this->load->view('report/journal_sybase_mobile', $data);
			return false;
    	}
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  		
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}

		if(isset($report_date)){
			 $where .= "WHERE YEAR(REPORT_DATE) = ".date("Y",strtotime($calculative_month))." AND MONTH(REPORT_DATE) = ".date("m",strtotime($calculative_month));
			 $where_cost = "WHERE YEAR(REPORT_DATE) = ".date("Y",strtotime($calculative_month))." AND MONTH(REPORT_DATE) = ".date("m",strtotime($calculative_month));
			 $data['filter_by'] .= "Month: ".date("m-Y",strtotime($calculative_month)) ;
			 $data['date']=date('M-Y',strtotime($calculative_month));
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;
		$data["get_record"] = $this->db->query($sql)->result();
		$sql_cost = $sql_cost.$where_cost.$group_by_cost.$order_by_cost;
		$data["get_record_cost"] = $this->db->query($sql_cost)->result();
		//$data['current_rate'] = $this->db->query("SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE WHERE REPORT_MONTH='".$exchange_rate_month."'")->row();
		$data['mt_rate'] = $this->db->query("SELECT * FROM TBL_MT_RATE WHERE REPORT_MONTH='".$calculative_month."'")->row();
		//dd($this->db->last_query());

		if(empty($data["get_record"]) && empty($data["get_record_cost"])){
			$this->webspice->message_board('Record is not found!');
			$this->load->view('report/journal_sybase_mobile', $data);
			return false;
		}
		$this->load->view('report/print_journal_sybase_mobile', $data);
	}
	
	function isms_summery_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'isms_summery_report');
		$this->webspice->permission_verify('isms_summery_report');
		$sql = " 
			SELECT UNIT_PRICE_EUR_2,DAY(LAST_DAY(REPORT_DATE)) AS LAST_DAY,
			SUM(CUSTOMER_RECEIVES_FROM) AS TOTAL_CUSTOMER_RECEIVES_FROM, 
			SUM(CUSTOMER_DELIVERS_TO) AS TOTAL_CUSTOMER_DELIVERS_TO
			FROM TBL_ISMS_DATA_FOR_JOURNAL
		";
		$where = "";
		$group_by = "" ;
		$order_by = "" ;
		$sql_cost = "SELECT UNIT_PRICE , ZONE, SUM(CUSTOMER_DELIVERS_TO) AS TOTAL_CUSTOMER_DELIVERS_TO FROM TBL_ISMS_DATA_FOR_JOURNAL ";
		$where_cost = "";
		$group_by_cost = " GROUP BY ZONE " ;
		$order_by_cost = " ORDER BY ZONE " ;
		if( !$_POST ){
			$this->load->view('report/isms_summery_report', $data);
			return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
    $exchange_rate=$input->get_usd_rate;
    $data['usd_euro']=explode("|",$exchange_rate);
   // dd($exchange_rate);
		$report_date = $input->CALCULATIVE_MONTH;
		$calculative_month=$report_date.'-01';
		//$exchange_rate = $input->EXCHANGE_RATE;	
		//$exchange_rate_month=$exchange_rate.'-01';	
		#$exchange_rate_month=date("Y-m-d",$exchange_rate);
		#dd($exchange_rate,'c');
		#dd($report_date);
		#$calculative_month=date("Y-m-d",$report_date);		
	//	$data['current_rate'] = $this->db->query("SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE WHERE REPORT_MONTH='".$exchange_rate_month."'")->row();
		$data['b2b_and_b2c_ratio'] = $this->db->query("SELECT * FROM TBL_MT_RATE WHERE REPORT_MONTH='".$calculative_month."'")->row();

    
    	if(empty($data['b2b_and_b2c_ratio'])){
    	$this->webspice->message_board('Please update ratio for the month of '.$calculative_month.' !');
			$this->load->view('report/journal_sybase_mobile', $data);
			return false;
    	}
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  		
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}

		if(isset($report_date)){
			 $where .= "WHERE YEAR(REPORT_DATE) = ".date("Y",strtotime($calculative_month))." AND MONTH(REPORT_DATE) = ".date("m",strtotime($calculative_month));
			 $where_cost = "WHERE YEAR(REPORT_DATE) = ".date("Y",strtotime($calculative_month))." AND MONTH(REPORT_DATE) = ".date("m",strtotime($calculative_month));
			 $data['filter_by'] .= "Month: ".date("m-Y",strtotime($calculative_month)) ;
			 $data['date']=date('M-Y',strtotime($calculative_month));
		}
		$data['current_date']=date("d-M-Y");
		$sql = $sql.$where.$group_by.$order_by;
		$data["get_record"] = $this->db->query($sql)->result();
		$sql_cost = $sql_cost.$where_cost.$group_by_cost.$order_by_cost;
		$data["get_record_cost"] = $this->db->query($sql_cost)->result();
		//$data['current_rate'] = $this->db->query("SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE WHERE REPORT_MONTH='".$exchange_rate_month."'")->row();
		$data['mt_rate'] = $this->db->query("SELECT * FROM TBL_MT_RATE WHERE REPORT_MONTH='".$calculative_month."'")->row();
		//dd($this->db->last_query());

		if(empty($data["get_record"]) && empty($data["get_record_cost"])){
			$this->webspice->message_board('Record is not found!');
			$this->load->view('report/isms_summery_report', $data);
			return false;
		}
		$this->load->view('report/print_isms_summery_report', $data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */