<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Upload_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	function upload_ro_dom_sms_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_dom_sms_data');
		$this->webspice->permission_verify('upload_ro_dom_sms_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_ic_domestic_sms_data', $data);
			return FALSE;
		}
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$report_month=date("Y-m",$calculative_month);
		$unique_date=$report_date;
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_ic_domestic_sms_data');
		}
		
		$sheet_columns = array("DATE_TIME", "OPERATOR", "CALLTYPE", "PREPOST_FLAG", "CALLS", "RATE_PER_EVENT", "NETAMOUNT");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_dom_sms_data');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$operator_name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$calltype = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$rate_per_event = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$netamount = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			if($operator_name==''){
				$operator_cname='Blank';
			}else{
					$operator = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
						$operator_cname='';
					}else{
						$operator_cname=$operator[0]->cName;
					}
			}	
			$values[] = array("DATE_TIME" => $date_time, "OPERATOR" => $operator_cname, "CALLTYPE" => $calltype, "PREPOST_FLAG" => $prepost_flag, "calls" => $calls, 
			"RATE_PER_EVENT" => $rate_per_event, "NETAMOUNT" => $netamount, "CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			
		
			
			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($operator) || !isset($calltype) || !isset($prepost_flag) || !isset($calls) || !isset($rate_per_event) || !isset($netamount) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($calls) && !is_numeric($calls) ){
				$data_error .= 'calls "'.$calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($rate_per_event) && !is_numeric($rate_per_event) ){
				$data_error .= 'Rate Per Event "'.$rate_per_event.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($netamount) && !is_numeric($netamount) ){
				$data_error .= 'Netamount "'.$netamount.'" at Row #'.$k.' is invalid.<br />';
			}
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_ic_domestic_sms_data', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_DOMESTIC_SMS_MMS";
		
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			$this->db->delete($table_name);
		}
		if(empty($values) ){
			$this->webspice->message_board('No data found for this month.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_dom_sms_data');
			return FALSE;
		}
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('ic_domestic_sms'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_dom_sms_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_dom_sms_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_ro_dom_sms_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_dom_sms_data');
		$this->webspice->permission_verify('manage_ro_dom_sms_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_DOMESTIC_SMS_MMS.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_DOMESTIC_SMS_MMS.* FROM TBL_DOMESTIC_SMS_MMS ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_DOMESTIC_SMS_MMS', 
			$InputField = array("OPERATOR","CALLTYPE","PREPOST_FLAG"),
			$Keyword = array(),
			$AdditionalWhere = null,
			$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			
			//$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_ic_domestic_sms_data',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_dom_sms_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_ic_domestic_sms_data', $data);
	}
	
	function upload_moid_daily_ro_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$config = $this->ft->get('config');
		$config = $config->{'0'};
		$usd_rate = $config->usd_rate;
		#$icx_portion = $config->icx_portion;
		#$igw_portion = $config->igw_portion;
		#$btrc_portion = $config->btrc_portion;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_moid_daily_ro_data');
		$this->webspice->permission_verify('upload_moid_daily_ro_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_voice_call_int_out', $data);
			return FALSE;
		}		
		
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$report_month=date("Y-m",$calculative_month);
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_voice_call_int_out');
		}
		
		$sheet_columns = array("DATE_TIME", "OPERATOR", "PREPOST_FLAG", "TARIFFCLASS", "CALLS", "AIR_UNITS", "CHARGED_UNITS", "AMOUNT", "Y_VALUE", "Z_VALUE", "BL_REVENUE", "IGW_PORTION", "ICX_PORTION", "BTRC_PORTION", "TOTAL_COST");
		
		# verify file type and read accordingly
		$get_data = array();
		if($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_moid_daily_ro_data');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$duplicate_where = array();
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$operator_name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			if($operator_name==''){
				$operator_cname='Blank';
				}else{
					
					$operator = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
						$operator_cname='';
					}else{
						$operator_cname=$operator[0]->cName;
					}
				}
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$tariffclass = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$air_units = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$charged_units = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$amount = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$y_value = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$z_value = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			$bl_revenue = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[10]));
			$igw_portion = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[11]));
			$icx_portion = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[12]));
			$btrc_portion = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[13]));
			$total_cost = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[14]));
			
			$values[] = array(
				"DATE_TIME" => $date_time, "OPERATOR" => $operator_cname, "PREPOST_FLAG" => $prepost_flag, 
				"TARIFFCLASS" => $tariffclass, "CALLS" => $calls, "AIR_UNITS" => $air_units, "CHARGED_UNITS" => $charged_units, 
				"AMOUNT" => $amount,  "Y_VALUE" => $y_value, "Z_VALUE" => $z_value, "USD_RATE" => $usd_rate,
				"ICX_PORTION" => $icx_portion, "IGW_PORTION" => $igw_portion, "BTRC_PORTION" => $btrc_portion,
				"BL_REVENUE" => $bl_revenue, "TOTAL_COST" => $total_cost,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			

			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($prepost_flag) || !isset($tariffclass) || !isset($calls) || 
			!isset($air_units) || !isset($charged_units) || !isset($amount) || !isset($y_value) || !isset($z_value) || 
			!isset($bl_revenue) || !isset($igw_portion) || !isset($icx_portion) || !isset($btrc_portion) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($calls) && !is_numeric($calls) ){
				$data_error .= 'calls "'.$calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($air_units) && !is_numeric($air_units) ){
				$data_error .= 'Air Units "'.$air_units.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($charged_units) && !is_numeric($charged_units) ){
				$data_error .= 'Charged Units "'.$charged_units.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($amount) && !is_numeric($amount) ){
				$data_error .= 'Amount "'.$amount.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($y_value) && !is_numeric($y_value) ){
				$data_error .= 'Y Value "'.$y_value.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($z_value) && !is_numeric($z_value) ){
				$data_error .= 'Z Value "'.$z_value.'" at Row #'.$k.' is invalid.<br />';
			}
			
			$duplicate_where[] = " (DATE_TIME='".$date_time."' AND OPERATOR='".$operator_cname."' AND PREPOST_FLAG='".$prepost_flag."' AND TARIFFCLASS='".$tariffclass."') ";
		}
		
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_VOICE_CALL_INT_OUT";
		$unique_date = $date_time;
		if( $input->data_insert == "data_remove_insert" ){
			//$this->db->where_in('DATE_TIME', $unique_date);
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			$this->db->delete($table_name);
		}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_voice_call_int_out', $data);
			return FALSE;
		}
		if(empty($values) ){
			$this->webspice->message_board('No data found for this month.');
			$this->webspice->force_redirect($url_prefix.'upload_moid_daily_ro_data');
			return FALSE;
		}
		$this->db->insert_batch($table_name, $values);
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_voice_call_int_out'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_moid_daily_ro_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_moid_daily_ro_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_moid_daily_ro_data_(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_moid_daily_ro_data');
		$this->webspice->permission_verify('manage_moid_daily_ro_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_VOICE_CALL_INT_OUT.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_VOICE_CALL_INT_OUT.* FROM TBL_VOICE_CALL_INT_OUT ";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_VOICE_CALL_INT_OUT', 
			$InputField = array("OPERATOR","PREPOST_FLAG","TARIFFCLASS"),
			$Keyword = array(),
			$AdditionalWhere = null,
			$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_voice_call_int_out',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_moid_daily_ro_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_voice_call_int_out', $data);
	}
	
	function upload_ro_daily_a2p_sms_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_daily_a2p_sms_data');
		$this->webspice->permission_verify('upload_ro_daily_a2p_sms_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_international_sms', $data);
			return FALSE;
		}
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_international_sms');
		}
		
		$sheet_columns = array("DATE_TIME", "MANE", "CALL_TYPE_DESC", "SMS_COUNT");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_international_sms');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$call_type_desc = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$sms_count = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			
			
			
			$operator = $this->ft->search("name_alternative", null, $name);
			if(empty($operator)){
				$data_error .= 'Operator Name "'.$name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			}else{
				$operator_cname=$operator[0]->cName;
				}
			$values[] = array(
				"DATE_TIME" => $date_time, "MANE" => $operator_cname, "CALL_TYPE_DESC" => $call_type_desc, "SMS_COUNT" => $sms_count,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7, "USD_TO_BDT_RATE"=>$_POST['USD_TO_BDT_RATE']
			);
			
			if( $date_traker < strtotime($date_time) ){
				$date_traker = strtotime($date_time);
				$single_values = array();
				$single_values[] = array(
					"DATE_TIME" => $date_time, "MANE" => $operator_cname, "CALL_TYPE_DESC" => $call_type_desc, "SMS_COUNT" => $sms_count,
					"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7, "USD_TO_BDT_RATE"=>$_POST['USD_TO_BDT_RATE']
				);
				$single_date = $date_time;
			}elseif($date_traker == strtotime($date_time)){
				$single_values[] = array(
					"DATE_TIME" => $date_time, "MANE" => $operator_cname, "CALL_TYPE_DESC" => $call_type_desc, "SMS_COUNT" => $sms_count,
					"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7, "USD_TO_BDT_RATE"=>$_POST['USD_TO_BDT_RATE']
				);
				$single_date = $date_time;
			}
			
			if( $unique_date_traker != strtotime($date_time) ){
					$unique_date_traker = strtotime($date_time);
					$unique_date[] = $date_time;
			}
			
			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($operator_cname) || !isset($call_type_desc) || !isset($sms_count) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($sms_count) && !is_numeric($sms_count) ){
				$data_error .= 'SMS Count "'.$sms_count.'" at Row #'.$k.' is invalid.<br />';
			}
			
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_international_sms', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_INTERNATIONAL_SMS";
		$input = $this->webspice->get_input();
		
		if( $input->data_update_new == "last_day_data" ){
			$values = $single_values;
			$unique_date = $single_date;
		}
		
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where_in('DATE_TIME', $unique_date);
			$this->db->delete($table_name);
		}
		
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('ic_international_sms'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_daily_a2p_sms_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_daily_a2p_sms_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_ro_daily_a2p_sms_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_daily_a2p_sms_data');
		$this->webspice->permission_verify('manage_ro_daily_a2p_sms_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_INTERNATIONAL_SMS.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_INTERNATIONAL_SMS.* FROM TBL_INTERNATIONAL_SMS ";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_INTERNATIONAL_SMS', 
			$InputField = array(),
			$Keyword = array("MANE","CALL_TYPE_DESC","SMS_COUNT","DATE_TIME"),
			$AdditionalWhere = null,
			$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_international_sms',$data);
				return false;
        break;                
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_daily_a2p_sms_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_international_sms', $data);
	}
	
	function upload_ro_daily_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		$config = $this->ft->get('config');
		$config = $config->{'0'};
		$usd_rate = $config->usd_rate;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_daily_data');
		$this->webspice->permission_verify('upload_ro_daily_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			if($_POST){
				$data['error'] = "File not found or invalid file type!";
			}
			$this->load->view('uploader/upload_voice_call_local_int', $data);
			return FALSE;
		}		
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$unique_date=$report_date;
		$report_month=date("Y-m",$calculative_month);
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_voice_call_local_int');
		}
		
		$sheet_columns = array("DATE_TIME", "REPORT_TYPE", "CALL_TYPE", "PREPOST_FLAG", "OPERATOR", "ICX", "NUMBER_OF_CALLS", "MINUTES", "RATE_PER_MINUTES", "AMOUNT_EXCLUDING_VAT");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_data');
			return FALSE;
		}
		$table_name = "TBL_VOICE_CALL_LOCAL";
		$table_name_int = "TBL_VOICE_CALL_INT_IN";
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		
		$values_int = array();
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$report_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$call_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$operator_name = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4])));
			if($operator_name==''){
				$operator='Blank';
				}else{
					$operator_alt_name = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator_alt_name)){
						$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
						$operator='';
					}else{
						$operator=$operator_alt_name[0]->cName;
					}
				}
			$icx = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$number_of_calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$rate_per_minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$amount_excluding_vat = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			if($report_type == "DOMESTIC"){
				$values[] = array(
					"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
					"PREPOST_FLAG" => $prepost_flag, "OPERATOR" => $operator, "ICX" => $icx, "NUMBER_OF_CALLS" => $number_of_calls, 
					"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat,
					"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
				);
			}elseif($report_type == "INTERNATIONAL"){
				$values_int[] = array("JOIN_DATA_FLAG"=>1,
					"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
					"PREPOST_FLAG" => $prepost_flag, "IGW" => $operator, "ICX" => $icx, "NUMBER_OF_CALLS" => $number_of_calls, 
					"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat, "USD_RATE" => $usd_rate,
					"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
				);
			}
			
			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($report_type) || !isset($call_type) || !isset($prepost_flag) || !isset($icx) || !isset($number_of_calls) || !isset($minutes) || !isset($rate_per_minutes) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($number_of_calls) && !is_numeric($number_of_calls) ){
				$data_error .= 'Number Of Calls "'.$number_of_calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($minutes) && !is_numeric($minutes) ){
				$data_error .= 'Minutes "'.$minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($rate_per_minutes) && !is_numeric($rate_per_minutes) ){
				$data_error .= 'Rate Per Minutes "'.$rate_per_minutes.'" at Row #'.$k.' is invalid.<br />';
			}
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_voice_call_local_int', $data);
			return FALSE;
		}
		
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		   if($input->data_insert == "data_remove_insert" ){
				//$this->db->where_in('JOIN_DATA_FLAG',0);
					$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			  	$this->db->delete($table_name_int);
		  	}
		  	
		  	 if($input->data_insert == "data_remove_insert" ){
			  	$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			  	$this->db->delete($table_name);
		  	}
		  	if(!empty($values_int)){
		  	$this->db->insert_batch($table_name_int, $values_int);
		    }
		    if(!empty($values)){
				$this->db->insert_batch($table_name, $values);
		   	}
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_voice_call_local_int'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_daily_data_local', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_daily_data_local');
		}
		
		if( $this->webspice->permission_verify('manage_ro_daily_data_int', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_daily_data_int');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_ro_daily_data_local(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_daily_data_local');
		$this->webspice->permission_verify('manage_ro_daily_data_local');
		$this->load->database();
    $orderby = ' ORDER BY TBL_VOICE_CALL_LOCAL.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_VOICE_CALL_LOCAL.* FROM TBL_VOICE_CALL_LOCAL ";
    
   	# filtering records
    if( $this->input->post('filter') ){
			  $result = $this->webspice->filter_generator(
				$TableName = 'TBL_VOICE_CALL_LOCAL', 
				$InputField = array(),
				$Keyword = array("REPORT_TYPE","CALL_TYPE","PREPOST_FLAG","OPERATOR","ICX","NUMBER_OF_CALLS","RATE_PER_MINUTES","MINUTES","AMOUNT_EXCLUDING_VAT"),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_voice_call_local',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_daily_data_local/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_voice_call_local', $data);
	}
	
	function manage_ro_daily_data_int(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_daily_data_int');
		$this->webspice->permission_verify('manage_ro_daily_data_int');
		$this->load->database();
    $orderby = ' ORDER BY TBL_VOICE_CALL_INT_IN.DATE_TIME DESC'; 
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_VOICE_CALL_INT_IN.* FROM TBL_VOICE_CALL_INT_IN ";
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_VOICE_CALL_INT_IN', 
				$InputField = array(),
				$Keyword = array("DATE_TIME","REPORT_TYPE","CALL_TYPE","PREPOST_FLAG","OPERATOR","ICX","NUMBER_OF_CALLS","MINUTES","RATE_PER_MINUTES","AMOUNT_EXCLUDING_VAT"),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_voice_call_int',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_daily_data_int/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_voice_call_int', $data);
	}
	
	function upload_ro_daily_ios_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 3000);
		$header_offset = 0;
		$column_offset = 0;
		$config = $this->ft->get('config');
		$config = $config->{'0'};
		//$usd_rate = $config->usd_rate;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_daily_ios_data');
		$this->webspice->permission_verify('upload_ro_daily_ios_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_int_voice_incoming', $data);
			return FALSE;
		}		
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$report_month=date("Y-m",$calculative_month);
		$unique_date=$report_date;
//$usd_rate = $this->db->query("SELECT * FROM TBL_SONALI_BANK_RATE WHERE REPORT_MONTH='".$report_date."'")->row();
		//$usd_rate = $this->db->query("SELECT * FROM TBL_SONALI_BANK_RATE WHERE YEAR(REPORT_MONTH) = ".date("Y",$calculative_month)." AND MONTH(REPORT_MONTH) = ".date("m",$calculative_month)." AND MAX(DAY(REPORT_MONTH))")->row();
		//dd($usd_rate);
		//if(!$usd_rate){
		//	$this->webspice->message_board('You should update Sonali Bank Rate for this month.');
		//	$this->webspice->force_redirect($url_prefix.'upload_ro_daily_ios_data');
		//	return FALSE;	
		//}
	//	$usd_to_bdt=$usd_rate->BUYING_TT_CLEAN;
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_int_voice_incoming');
		}
		
		$sheet_columns = array("DATE_TIME", "REPORT_TYPE", "CALL_TYPE", "PREPOST_FLAG", "IOS", "IGW", "ICX", "NUMBER_OF_CALLS", "MINUTES", "RATE_PER_MINUTES","USD/BDT","AMOUNT_EXCLUDING_VAT");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_ios_data');
			return FALSE;
		}
		
		# verify data
		ini_set('max_execution_time', 1800);
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$report_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$call_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$ios = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4])));
			$igw = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$icx_value = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6])));
			

			if($icx_value==''){
				$icx='Blank';
				}else{
					
					$operator = $this->ft->search("name_alternative", null, $icx_value);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$icx_value.'" at Row #'.$k.' is invalid.<br />';
						$icx='';
					}else{
						$icx=$operator[0]->cName;
					}
				}
	
			$number_of_calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$rate_per_minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			$usd_to_bdt = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[10]));
			$amount_excluding_vat = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[11]));
			
			
			
			
			//$ter_charge_usd=$minutes * $rate_per_minutes;
			//$ter_charge_bdt=$ter_charge_usd * $usd_to_bdt;
			//$amount_excluding_vat=($ter_charge_bdt *22.5)/100;
			$values[] = array(
				"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
				"PREPOST_FLAG" => $prepost_flag, "IOS" => $ios, "IGW" => $igw, "ICX" => $icx, "NUMBER_OF_CALLS" => $number_of_calls, 
				"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes,"USD_RATE" => $usd_to_bdt, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);

			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($report_type) || !isset($call_type) || !isset($prepost_flag) || !isset($number_of_calls) || !isset($minutes) || !isset($rate_per_minutes)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($number_of_calls) && !is_numeric($number_of_calls) ){
				$data_error .= 'Number Of Calls "'.$number_of_calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($minutes) && !is_numeric($minutes) ){
				$data_error .= 'Minutes "'.$minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($rate_per_minutes) && !is_numeric($rate_per_minutes) ){
				$data_error .= 'Rate Per Minutes "'.$rate_per_minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($amount_excluding_vat) && !is_numeric($amount_excluding_vat) ){
				$data_error .= 'Amount Excluding Vat "'.$amount_excluding_vat.'" at Row #'.$k.' is invalid.<br />';
			}
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_int_voice_incoming', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_VOICE_CALL_INT_IN";
		
		
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			$this->db->delete($table_name);
		}
		if(empty($values) ){
			$this->webspice->message_board('No data found for this month.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_ios_data');
			return FALSE;
		}
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_int_voice_incoming'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_daily_ios_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_daily_ios_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_ro_daily_ios_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_daily_ios_data');
		$this->webspice->permission_verify('manage_ro_daily_ios_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_VOICE_CALL_INT_IN.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_VOICE_CALL_INT_IN.* FROM TBL_VOICE_CALL_INT_IN ";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_VOICE_CALL_INT_IN', 
				$InputField = array(),
				$Keyword = array("DATE_TIME","REPORT_TYPE","CALL_TYPE","PREPOST_FLAG","IOS","IGW","ICX","NUMBER_OF_CALLS","MINUTES","RATE_PER_MINUTES","AMOUNT_EXCLUDING_VAT"),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_int_voice_in_out',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_daily_ios_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
    
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_int_voice_in_out', $data);
	}
	
	function upload_ro_daily_video_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_daily_video_data');
		$this->webspice->permission_verify('upload_ro_daily_video_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_daily_video_data', $data);
			return FALSE;
		}		
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$report_month=date("Y-m",$calculative_month);
		$unique_date=$report_date;
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_daily_video_data');
		}
		
		$sheet_columns = array("DATE_TIME", "REPORT_TYPE", "CALL_TYPE", "PREPOST_FLAG", "OPERATOR", "ICX", "NUMBER_OF_CALLS", "MINUTES", "RATE_PER_MINUTES", "AMOUNT_EXCLUDING_VAT");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_video_data');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$report_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$call_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$operator_name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$icx = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$number_of_calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$rate_per_minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$amount_excluding_vat = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			
			if($operator_name==''){
				$operator_cname='Blank';
			}else{
					$operator = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
						$operator_cname='';
					}else{
						$operator_cname=$operator[0]->cName;
					}
			}	
			
			$values[] = array(
				"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
				"PREPOST_FLAG" => $prepost_flag, "OPERATOR" => $operator_cname, "NUMBER_OF_CALLS" => $number_of_calls, 
				"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			
			
			
			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($report_type) || !isset($call_type) || !isset($prepost_flag) || !isset($number_of_calls) || !isset($minutes) || !isset($rate_per_minutes) || !isset($amount_excluding_vat) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($number_of_calls) && !is_numeric($number_of_calls) ){
				$data_error .= 'Number Of Calls "'.$number_of_calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($minutes) && !is_numeric($minutes) ){
				$data_error .= 'Minutes "'.$minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($rate_per_minutes) && !is_numeric($rate_per_minutes) ){
				$data_error .= 'Rate Per Minutes "'.$rate_per_minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($amount_excluding_vat) && !is_numeric($amount_excluding_vat) ){
				$data_error .= 'Amount Excluding Vat "'.$amount_excluding_vat.'" at Row #'.$k.' is invalid.<br />';
			}
			
		}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_daily_video_data', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_DAILY_VIDEO_DATA";
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			$this->db->delete($table_name);
		}
		if(empty($values) ){
			$this->webspice->message_board('No data found for this month.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_video_data');
			return FALSE;
		}
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_daily_video_data'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_daily_video_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_daily_video_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_ro_daily_video_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_daily_video_data');
		$this->webspice->permission_verify('manage_ro_daily_video_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_DAILY_VIDEO_DATA.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_DAILY_VIDEO_DATA.* FROM TBL_DAILY_VIDEO_DATA ";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_DAILY_VIDEO_DATA', 
				$InputField = array(),
				$Keyword = array("DATE_TIME","REPORT_TYPE","CALL_TYPE","PREPOST_FLAG","OPERATOR","ICX","NUMBER_OF_CALLS","MINUTES","RATE_PER_MINUTES","AMOUNT_EXCLUDING_VAT"),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_daily_video_data',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    	
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_daily_video_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_daily_video_data', $data);
	}
	
	function upload_ro_dom_icx_daily_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_dom_icx_daily_data');
		$this->webspice->permission_verify('upload_ro_dom_icx_daily_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_icx_daily_data', $data);
			return FALSE;
		}		
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$report_month=date("Y-m",$calculative_month);
		$unique_date=$report_date;
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_icx_daily_data');
		}
		
		$sheet_columns = array("DATE_TIME", "REPORT_TYPE", "CALL_TYPE", "PREPOST_FLAG", "OPERATOR", "ICX", "NUMBER_OF_CALLS", "MINUTES", "RATE_PER_MINUTES", "AMOUNT_EXCLUDING_VAT");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_dom_icx_daily_data');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("Y-m-d",strtotime($date_time));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$report_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$call_type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$operator_name = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4])));
			if ($operator_name=='') continue;
			$icx = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5])));
			$number_of_calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$rate_per_minutes = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$amount_excluding_vat = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			if($icx==''){
				$icx_cname='Blank';
			}else{
					$operator = $this->ft->search("name_alternative", null, $icx);
					if(empty($operator)){
						
						$data_error .= 'Operator Name "'.$icx.'" at Row #'.$k.' is invalid.<br />';
						$icx_cname='';
					}else{
						$icx_cname=$operator[0]->cName;
					}
			}	
			if($operator_name==''){
				$operator_cname='Blank';
			}else{
					$operator = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$icx.'" at Row #'.$k.' is invalid.<br />';
						$operator_cname='';
					}else{
						$operator_cname=$operator[0]->cName;
					}
			}	
			
			$values[] = array(
				"DATE_TIME" => $date_time, "REPORT_TYPE" => $report_type, "CALL_TYPE" => $call_type, 
				"PREPOST_FLAG" => $prepost_flag, "OPERATOR" => $operator_cname, "ICX" => $icx_cname, "NUMBER_OF_CALLS" => $number_of_calls, 
				"MINUTES" => $minutes,  "RATE_PER_MINUTES" => $rate_per_minutes, "AMOUNT_EXCLUDING_VAT" => $amount_excluding_vat,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			
			
			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($report_type) || !isset($call_type) || !isset($prepost_flag) || !isset($number_of_calls) || !isset($minutes) || !isset($rate_per_minutes) || !isset($amount_excluding_vat) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($number_of_calls) && !is_numeric($number_of_calls) ){
				$data_error .= 'Number Of Calls "'.$number_of_calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($minutes) && !is_numeric($minutes) ){
				$data_error .= 'Minutes "'.$minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($rate_per_minutes) && !is_numeric($rate_per_minutes) ){
				$data_error .= 'Rate Per Minutes "'.$rate_per_minutes.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($amount_excluding_vat) && !is_numeric($amount_excluding_vat) ){
				$data_error .= 'Amount Excluding Vat "'.$amount_excluding_vat.'" at Row #'.$k.' is invalid.<br />';
			}
			
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_icx_daily_data', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		$is_value = false;
		$table_name = "TBL_ICX_DAILY_DATA";
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			$this->db->delete($table_name);
		}
		if(empty($values) ){
			$this->webspice->message_board('No data found for this month.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_dom_icx_daily_data');
			return FALSE;
		}
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_icx_daily_data'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_dom_icx_daily_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_dom_icx_daily_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_ro_dom_icx_daily_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_dom_icx_daily_data');
		$this->webspice->permission_verify('manage_ro_dom_icx_daily_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_ICX_DAILY_DATA.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_ICX_DAILY_DATA.* FROM TBL_ICX_DAILY_DATA ";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_ICX_DAILY_DATA', 
				$InputField = array(),
				$Keyword = array("DATE_TIME","REPORT_TYPE","CALL_TYPE","PREPOST_FLAG","OPERATOR","ICX","NUMBER_OF_CALLS","MINUTES","RATE_PER_MINUTES","AMOUNT_EXCLUDING_VAT"),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_icx_daily_data',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_dom_icx_daily_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_icx_daily_data', $data);
	}
	
	function upload_ro_daily_ltfs_data($data=null){
		
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_daily_ltfs_data');
		$this->webspice->permission_verify('upload_ro_daily_ltfs_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_local_toll_free_data', $data);
			return FALSE;
		}		
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$report_month=date("Y-m",$calculative_month);
		$unique_date=$report_date;
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_local_toll_free_data');
		}

		$sheet_columns = array("DATE_TIME", "OPERATOR_NAME", "PREPOST_FLAG", "NUMBER_OF_CALLS", "DURATION_MIN", "RATE_PER_MIN_BDT", "REVENUE", "SD_RATE", "SC_RATE", "SC_AMOUNT", "VAT on (Revenue+SD)", "TOTAL");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_ltfs_data');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("y-m-d",strtotime($date_time));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$operator_name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$number_of_calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$duration_min = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$rate_per_min_bdt = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$revenue = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$sd_rate = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$sc_rate = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$sc_amount = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			$vat_on_revenue_sd = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[10]));
			$total = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[11]));
			if($operator_name==''){
				$operator_cname='Blank';
			}else{
					$operator = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
						$operator_cname='';
					}else{
						$operator_cname=$operator[0]->cName;
					}
			}	
			$values[] = array(
				"DATE_TIME" => $date_time, "OPERATOR_NAME" => $operator_cname, "PREPOST_FLAG" => $prepost_flag, 
				"NUMBER_OF_CALLS" => $number_of_calls, "DURATION_MIN" => $duration_min, "RATE_PER_MIN_BDT" => $rate_per_min_bdt, 
				"REVENUE" => $revenue,  "SD_RATE" => $sd_rate, "SC_RATE" => $sc_rate,
				"SC_AMOUNT" => $sc_amount,  "VAT_ON_REVENUE_SD" => $vat_on_revenue_sd, "TOTAL" => $total,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			
			# must have column value - column offset started from 1
			if( !isset($date_time) || !isset($operator_name) || !isset($number_of_calls) || !isset($duration_min) || !isset($rate_per_min_bdt) || !isset($revenue) || !isset($sd_rate) || !isset($sc_rate) ){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($number_of_calls) && !is_numeric($number_of_calls) ){
				$data_error .= 'Number Of Calls "'.$number_of_calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($duration_min) && !is_numeric($duration_min) ){
				$data_error .= 'Duration_Min "'.$duration_min.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($rate_per_min_bdt) && !is_numeric($rate_per_min_bdt) ){
				$data_error .= 'Rate Per Min BDT "'.$rate_per_min_bdt.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($revenue) && !is_numeric($revenue) ){
				$data_error .= 'Revenue "'.$revenue.'" at Row #'.$k.' is invalid.<br />';
			}
			
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_local_toll_free_data', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_LOCAL_TOLL_FREE_DATA";
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			$this->db->delete($table_name);
		}
		if(empty($values) ){
			$this->webspice->message_board('No data found for this month.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_ltfs_data');
			return FALSE;
		}
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_local_toll_free_data'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_daily_ltfs_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_daily_ltfs_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_ro_daily_ltfs_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_daily_ltfs_data');
		$this->webspice->permission_verify('manage_ro_daily_ltfs_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_LOCAL_TOLL_FREE_DATA.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_LOCAL_TOLL_FREE_DATA.* FROM TBL_LOCAL_TOLL_FREE_DATA ";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_LOCAL_TOLL_FREE_DATA', 
				$InputField = array(""),
				$Keyword = array("DATE_TIME","OPERATOR_NAME","PREPOST_FLAG","NUMBER_OF_CALLS","DURATION_MIN","RATE_PER_MIN_BDT","REVENUE","SD_RATE","SC_RATE","SC_AMOUNT","VAT_ON_REVENUE_SD","TOTAL"),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_local_toll_free_data',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_daily_ltfs_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_local_toll_free_data', $data);
	}
	
	function upload_ro_daily_itfs_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 0;
		$column_offset = 0;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ro_daily_itfs_data');
		$this->webspice->permission_verify('upload_ro_daily_itfs_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_int_toll_free_data', $data);
			return FALSE;
		}		

		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$report_month=date("Y-m",$calculative_month);
		$unique_date=$report_date;
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv'), 'sap_file', $data, 'uploader/upload_int_toll_free_data');
		}
		
		$sheet_columns = array("DATE_TIME", "OPERATOR_NAME", "PREPOST_FLAG", "NUMBER_OF_CALLS", "DURATION_MIN", "USD_RATE", " TER_CHARGE_USD", "USD_BDT", "TER_CHARGE_BDT", " BL_REVENUE");
		
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream'){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_itfs_data');
			return FALSE;
		}
			
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$date_time_verify = date("d-m-Y",strtotime($date_time));
			$date_time = date("y-m-d",strtotime($date_time));
			$data_month=date("Y-m",strtotime($date_time));
			if ($report_month!=$data_month) continue;
			$operator_name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			if($operator_name==''){
				$operator_cname='Blank';
			}else{
					$operator = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
						$operator_cname='';
					}else{
						$operator_cname=$operator[0]->cName;
					}
			}	

      $prepost_flag = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$number_of_calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$duration_min = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$usd_rate = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$ter_charge_usd = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$usd_bdt_rate = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$ter_charge_bdt = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
			$bl_revenue = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			
			
			
			if($operator_name==''){
				$operator_cname='Blank';
			}else{
					$operator = $this->ft->search("name_alternative", null, $operator_name);
					if(empty($operator)){
						$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
						$operator_cname='';
					}else{
						$operator_cname=$operator[0]->cName;
					}
			}	
			$values[] = array(
				"DATE_TIME" => $date_time, "OPERATOR_NAME" => $operator_cname, "PREPOST_FLAG" => $prepost_flag, 
				"NUMBER_OF_CALLS" => $number_of_calls, "DURATION_MIN" => $duration_min, "USD_RATE" => $usd_rate, 
				"TER_CHARGE_USD" => $ter_charge_usd,  "USD_BDT" => $usd_bdt_rate, "TER_CHARGE_BDT" => $ter_charge_bdt,
				"BL_REVENUE" => $bl_revenue,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);
			
			# must have column value - column offset started from 1
		//	if( !isset($date_time) || !isset($operator_name) || !isset($number_of_calls) || !isset($duration_min) || !isset($usd_rate) || !isset($bl_revenue) || $bl_revenue=='' ){
		//		$data_error .= 'Row #'.$k.' is incomplete.<br />';
		//	}
			
			# Verify Date
			 if( isset($date_time_verify) && !$this->webspice->isDate($date_time_verify, 'day', 'month', 'year') ){ 
			 	$data_error .= 'Date Time "'.$date_time_verify.'" at Row #'.$k.' is invalid.<br />';
			 }
			
			if( isset($number_of_calls) && !is_numeric($number_of_calls) ){
				$data_error .= 'Number Of Calls "'.$number_of_calls.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($duration_min) && !is_numeric($duration_min) ){
				$data_error .= 'Duration_Min "'.$duration_min.'" at Row #'.$k.' is invalid.<br />';
			}
			
			if( isset($usd_rate) && !is_numeric($usd_rate) ){
				$data_error .= 'Usd_Rate "'.$usd_rate.'" at Row #'.$k.' is invalid.<br />';
			}
			if( ($bl_revenue!='') && !is_numeric($bl_revenue) ){
				$data_error .= 'Bl_Revenue "'.$bl_revenue.'" at Row #'.$k.' is invalid.<br />';
			}
			
		}
		
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_int_toll_free_data', $data);
			return FALSE;
		}

		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_INT_TOLL_FREE_DATA";
		
		if( $input->data_insert == "data_remove_insert" ){
			$this->db->where("YEAR(DATE_TIME) = ".date("Y",$calculative_month)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month));
			$this->db->delete($table_name);
		}
		if(empty($values) ){
			$this->webspice->message_board('No data found for this month.');
			$this->webspice->force_redirect($url_prefix.'upload_ro_daily_itfs_data');
			return FALSE;
		}
		$this->db->insert_batch($table_name, $values);
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_int_toll_free_data'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_ro_daily_itfs_data', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_ro_daily_itfs_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
 function manage_ro_daily_itfs_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ro_daily_itfs_data');
		$this->webspice->permission_verify('manage_ro_daily_itfs_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_INT_TOLL_FREE_DATA.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_INT_TOLL_FREE_DATA.* FROM TBL_INT_TOLL_FREE_DATA ";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_INT_TOLL_FREE_DATA', 
				$InputField = array("OPERATOR_NAME","PREPOST_FLAG"),
				$Keyword = array("DATE_TIME","OPERATOR_NAME","PREPOST_FLAG","NUMBER_OF_CALLS","DURATION_MIN","USD_RATE","TER_CHARGE_USD","USD_BDT","TER_CHARGE_BDT","BL_REVENUE"),
				$AdditionalWhere = null,
				$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_int_toll_free_data',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ro_daily_itfs_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('uploader/manage_int_toll_free_data', $data);
 }
	//full month
	
  function upload_ios_invoice_report($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ios_invoice_report');
	$this->webspice->permission_verify('upload_ios_invoice_report');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_ios_invoice_report', $data);
		return FALSE;
	}
	
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_ios_invoice_report');
	}
	$rows_data=null;
	$data_error = null;
	$input = $this->webspice->get_input();
	$table_name = "TBL_IOS_REPORT_DATA";
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$calculative_month = $this->input->post("CALCULATIVE_MONTH");
	$report_date=date("Y-m-d",$calculative_month);
	$total_voice=0;
	foreach($_FILES['sap_file']['tmp_name'] as $fk => $fv){
		$full_file_name = $_FILES['sap_file']['name'][$fk];
		$contents = explode('_', $full_file_name);
		$file_name= end($contents);
		$contents_for_operator = explode('.', $file_name);
		$operator_name = $contents_for_operator[0];
		$tmp_operator = $this->ft->search("name_alternative", null, $operator_name);
			if(empty($tmp_operator)){
				$data_error .= 'Invalid Operator Name "'.$operator_name.'" regarding '.$file_name.' File.<br />';
				$Operator_Name='';
		  }else{
				$Operator_Name=$tmp_operator[0]->cName;
			}	
		$Operator_ST_Name=$Operator_Name;
		$xml_data = simplexml_load_file($fv);
		$xml_data = json_encode($xml_data);
		$xml_data = json_decode($xml_data,TRUE);
		if(!$xml_data){
			$data_error .= "Invalid file ".$_FILES['sap_file']['name'][$fk];
		}
	if($xml_data){
		#Report Basic Info
			
		$this->webspice->remove_cache('invoice_icx_ios');
		$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
		$code = $xml_data['report_header']['code']; #Bill_0091
		$criteria = $xml_data['report_header']['criteria']; #Report on September2017
		$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
		$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
		if($column_headers[0] !='Route Name (ICX)' || $column_headers[1] !='No of Calls' || $column_headers[2] !='Duration(In Min.)' || $column_headers[3] !='Rate(USD)' || $column_headers[4] !='Ter. Charge (USD)' || $column_headers[5] !='USD/BDT' || $column_headers[6] !='Ter. Charge (BDT)' || $column_headers[7] !='BL Rev @22.5% (BDT)'){
			$data_error .='Your File '.$full_file_name. 'is invalied';
		}else{
		if(!isset($xml_data['report_data']['action_summary']['rows']['row'])){
			$data_error .='Your File is Empty! '.$_FILES['sap_file']['name'][$fk];
		}else{
			$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
		}
		if(isset($rows_data)){
			foreach($rows_data as $k=>$v){
				if (isset($v['column1'])) continue;
				$data_list = $v['column'];
				$Route_Name = trim($this->webspice->clean_input($data_list[0]));
				$No_of_Calls = trim($this->webspice->clean_input($data_list[1]));
				$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
				$Rate_USD = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
				$Ter_Charge_USD= trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
				$USD_BDT=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
				$Ter_Charge_bdt=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
				$BL_Rev_BDT=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
			
				$values[] = array("REPORT_DATE" => $report_date, "ROUTE_NAME" => $Route_Name, 
				"NO_OF_CALLS" => $No_of_Calls, "DURATION_IN_MNT" => $Duration_In_Min, "RATE_USD" => $Rate_USD, "TER_CHARGE_USD" => $Ter_Charge_USD, 
				"USD_BDT" => $USD_BDT,"OPERATOR_NAME" =>$Operator_Name, "TER_CHARGE_BDT" => $Ter_Charge_bdt,"BL_REV_BDT"=>$BL_Rev_BDT,"VAT"=>$Vat ,"SD"=>$Sd ,"SURCHARGE"=>$Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
				"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
				$total_voice= $total_voice+$BL_Rev_BDT;
			}
		}
	}
	}
	
	$data['date']=date('Y-m-d', $calculative_month);
	$invoice_number='IOS/'.$Operator_ST_Name.' '.$data['date'];

	$values_invoice_detail[] = array("BILL_PERIOD" => $report_date,"OPERATOR_TYPE"=>'IGW', "OPERATOR_NAME" => $Operator_ST_Name, "INVOICE_AMOUNT"=>$total_voice,'REMAINING_AMOUNT'=>$total_voice,'INVOICE_NUMBER'=>$invoice_number,
		"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
}
	if($data_error){
		$data['error'] = $data_error;
		$this->load->view('upload_full_month_report/upload_ios_invoice_report', $data);
		return false;
	}
	  
	# insert data
	$this->db->trans_start();	

	if( $input->data_insert == "data_remove_insert" ){
	 $this->db->where('REPORT_DATE', $report_date);
	 $this->db->delete($table_name);
  }
  if( $input->data_insert == "data_remove_insert" ){
	 $this->db->where('BILL_PERIOD', $report_date);
	 $this->db->delete('TBL_INVOICE_DETAIL');
  }
  if( $input->data_insert == "data_remove_insert" ){
	 $this->db->where('BILL_PERIOD', $report_date);
	 $this->db->delete('TBL_INVOICE');
  }
  $this->webspice->remove_cache('invoice_icx_ios');
	if($values){
	$this->db->insert_batch($table_name, $values);	
	}
	if($values_invoice_detail){
	$this->db->insert_batch('TBL_INVOICE', $values_invoice_detail);	
	$this->db->insert_batch('TBL_INVOICE_DETAIL', $values_invoice_detail);	
	}
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_ios_invoice_report');
		return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_ios_invoice_report'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_ios_invoice_report', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_ios_invoice_report');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_icx_invoice_report($data=null){
 	ini_set('upload_max_filesize', '1900M');
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	//ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_icx_invoice_report');
	$this->webspice->permission_verify('upload_icx_invoice_report');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_icx_invoice_report', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_icx_invoice_report');
	}
	$rows_data=null;
	$data_error = null;
	$values = null;
	$total_amount= 0;
	$total_voice=0;
	$total_sms=0;
	$values_invoice_detail=null;
	$table_name = "TBL_ICX_REPORT_DATA";
	$input = $this->webspice->get_input();
	$calculative_month = $input->calculative_month;
	$report_date=date("Y-m-d",$calculative_month);
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	foreach($_FILES['sap_file']['tmp_name'] as $fk => $fv){
		$full_file_name = $_FILES['sap_file']['name'][$fk];
		$contents = explode('_', $full_file_name);
		$file_name= end($contents);
		$contents_for_operator = explode('.', $file_name);
		$operator_name = $contents_for_operator[0];
		$tmp_operator = $this->ft->search("name_alternative", null, $operator_name);
			if(empty($tmp_operator)){
				$data_error .= 'Invalid Operator Name "'.$operator_name.'" regarding '.$file_name.' File.<br />';
				$Operator_ST_Name='';
		  }else{
				$Operator_ST_Name=$tmp_operator[0]->cName;
			}	

		$xml_data = simplexml_load_file($fv);
		$xml_data = json_encode($xml_data);
		$xml_data = json_decode($xml_data,TRUE);
		if(!$xml_data){
			$data_error .= "Invalid file ".$_FILES['sap_file']['name'][$fk];
		}
	if($xml_data){
		#Report Basic Info
		$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
		$code = $xml_data['report_header']['code']; #Bill_0091
		$criteria = $xml_data['report_header']['criteria']; #Report on September2017
		$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
		$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
		
		if($column_headers[0] !='Operator Name' || $column_headers[1] !='Route' || $column_headers[2] !='No of Calls' || $column_headers[3] !='Duration (In Min.)' || $column_headers[4] !='Rate Per Min.' || $column_headers[5] !='Amount' || $column_headers[6] !='VAT' || $column_headers[7] !='Total'){
			$data_error .='Your File '.$full_file_name. 'is invalied';
		}else{
		//if(!isset($xml_data['report_data']['action_summary']['rows']['row']) && !isset($xml_data['report_data']['action_sms']['rows']['row'])) ){
		//	$data_error .='Your File is Empty! '.$_FILES['sap_file']['name'][$fk];
		//}
			
				#Report Data Voice
	
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
		$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
		foreach($rows_data as $k=>$v){
			$data_list = $v['column'];
			$Operator_Name = trim($this->webspice->clean_input($data_list[0]));
			if ($Operator_Name=='Total') continue;
			$Route = trim($this->webspice->clean_input($data_list[1]));
			$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
			$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
			$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
			$Amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
			$VAT=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
			$Total=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
			
			$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $Operator_ST_Name, "NO_CLI_DATE"=>'', 
			"ROUTE" => $Route, "NO_OF_CALLS" => $No_of_Calls, "DURATION" => $Duration_In_Min, "RATE_PER_MNT" => $Rate_Per_Min, 
			"AMOUNT" => $Amount, "VAT_VALUE" => $VAT, "VAT"=>$Vat, "SD"=>$Sd,"SURCHARGE"=>$Surcharge,"TOTAL" => $Total,"CREATED_BY" => $this->webspice->get_user_id(), 
			"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7, "TYPE"=>'VOICE');
	 $total_voice=$total_voice+$Amount;
	  }
	}
	
	

	#Report Data Noncli
	if(isset($xml_data['report_data']['action_noncli']['rows']['row'])){
		$rows_data = $xml_data['report_data']['action_noncli']['rows']['row'];
		
		foreach($rows_data as $k=>$v){
			if(array_key_exists('column', $v)){
				$data_list = $v['column'];
			}else{
			  $data_list = $v;	
			}
			
			$route_name = trim($this->webspice->clean_input($data_list[0]));
			if ($route_name=='Total') continue;
			
			$no_cli_date = trim($this->webspice->clean_input($data_list[1]));
			$no_cli_formated_date=date('Y_m_d',strtotime(str_replace(',','-', $no_cli_date)));
			$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
			$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
			$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
			$Amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
			$VAT=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
			$Total=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
			$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $Operator_ST_Name, "NO_CLI_DATE"=> $no_cli_formated_date,
			"ROUTE" => $Route, "NO_OF_CALLS" => $No_of_Calls, "DURATION" => $Duration_In_Min, "RATE_PER_MNT" => $Rate_Per_Min, 
			"AMOUNT" => $Amount,"VAT_VALUE" => $VAT,"VAT"=>$Vat ,"SD"=>$Sd ,"SURCHARGE"=>$Surcharge,"TOTAL" => $Total,"CREATED_BY" => $this->webspice->get_user_id(), 
			"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7,"TYPE"=>'NO_CLI');	
		
	}
	
	}
	
	#Report Data SMS
	if(isset($xml_data['report_data']['action_sms']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_sms']['rows']['row'];
	foreach($rows_data as $k=>$v){
		if(array_key_exists('column',$v)){
			$data_list = $v['column'];
		}else{
		  $data_list = $v;	
		}
		
		$Operator_Name = trim($this->webspice->clean_input($data_list[0]));
		if ($Operator_Name=='Total') continue;

		#if sms data exist then check operator and file
		$tmp_operator = $this->ft->search("name_alternative", null, $Operator_Name);
		$Route = trim($this->webspice->clean_input($data_list[1]));
		$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$Amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$VAT=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$Total=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $Operator_ST_Name, "NO_CLI_DATE"=>'',
		"ROUTE" => $Route, "NO_OF_CALLS" => $No_of_Calls, "DURATION" => $Duration_In_Min, "RATE_PER_MNT" => $Rate_Per_Min, 
		"AMOUNT" => $Amount,"VAT_VALUE" => $VAT,"VAT"=>$Vat ,"SD"=>$Sd ,"SURCHARGE"=>$Surcharge,"TOTAL" => $Total,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7,"TYPE"=>'SMS_MMS');
    $total_sms=$total_sms+$Amount;
  
  }
	} 
	
	if(isset($xml_data['report_data']['criteria3'])){
		$vat = $xml_data['report_data']['criteria3'][6];
	}else{
		$vat = 0;
	}
	
	$data['date']=date('Y-m-d', $calculative_month);
	$invoice_number='Interconnection/BL-'.$Operator_ST_Name.' '.$data['date'];
	$total_amount= $total_voice+$total_sms;
	$operator_info = $this->customcache->operator_maker_new($Operator_ST_Name,null);
	$values_invoice_detail[] = array("BILL_PERIOD" => $report_date,"OPERATOR_TYPE"=>$operator_info[3], "OPERATOR_NAME" => $Operator_ST_Name, "INVOICE_AMOUNT"=>$total_amount-$vat,'REMAINING_AMOUNT'=>$total_amount,'INVOICE_NUMBER'=>$invoice_number,
		"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
	}
}
	if($data_error){
		$data['error'] = $data_error;
		$this->load->view('upload_full_month_report/upload_icx_invoice_report', $data);
		return false;
	}
	  
	# insert data
	$this->db->trans_start();	

	if( $input->data_insert == "data_remove_insert" ){
	 $this->db->where('REPORT_DATE', $report_date);
	 $this->db->delete($table_name);
  }
  
  if( $input->data_insert == "data_remove_insert" ){
	 $this->db->where('BILL_PERIOD', $report_date);
	 $this->db->delete('TBL_INVOICE_DETAIL');
  }
  if( $input->data_insert == "data_remove_insert" ){
	 $this->db->where('BILL_PERIOD', $report_date);
	 $this->db->delete('TBL_INVOICE');
  }
  $this->webspice->remove_cache('invoice_icx_ios');
  //$this->cache->remove_group('invoice_icx_ios');
	if($values){
	$this->db->insert_batch($table_name, $values);	
	}
	if($values_invoice_detail){
	$this->db->insert_batch('TBL_INVOICE_DETAIL', $values_invoice_detail);	
	$this->db->insert_batch('TBL_INVOICE', $values_invoice_detail);
	}
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_invoice_report');
		return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_icx_invoice_report'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_icx_invoice_report', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_icx_invoice_report');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_ios_invoice_report__($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ios_invoice_report');
	$this->webspice->permission_verify('upload_ios_invoice_report');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_ios_invoice_report', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_ios_invoice_report');
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_IOS_REPORT_DATA";
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_ios_invoice_report');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	//$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT

	
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	foreach($rows_data as $k=>$v){
		if (isset($v['column1'])) continue;
		$data_list = $v['column'];
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$operator_name=$this->input->post("operator_name");
		$report_date=date("Y-m-d",$calculative_month);
		$Route_Name = trim($this->webspice->clean_input($data_list[0]));
		
		if( $input->data_insert == "data_remove_insert" ){
		 $this->db->where('REPORT_DATE', $report_date);
		 $this->db->delete($table_name);
	  }else{
		    $existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date,'ROUTE_NAME' => $Route_Name,'OPERATOR_NAME' => $operator_name), $limit=1)->result();
		    if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_ios_invoice_report');
				return false;
		}
	}	

		$No_of_Calls = trim($this->webspice->clean_input($data_list[1]));
		$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$Rate_USD = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$Ter_Charge_USD= trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$USD_BDT=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$Ter_Charge_bdt=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$BL_Rev_BDT=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
	
		$values[] = array("REPORT_DATE" => $report_date, "ROUTE_NAME" => $Route_Name, 
		"NO_OF_CALLS" => $No_of_Calls, "DURATION_IN_MNT" => $Duration_In_Min, "RATE_USD" => $Rate_USD, "TER_CHARGE_USD" => $Ter_Charge_USD, 
		"USD_BDT" => $USD_BDT,"OPERATOR_NAME" =>$operator_name, "TER_CHARGE_BDT" => $Ter_Charge_bdt,"BL_REV_BDT"=>$BL_Rev_BDT,"VAT"=>$Vat ,"SD"=>$Sd ,"SURCHARGE"=>$Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
	
	
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_ios_invoice_report');
	return false;
	
	}
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	


	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_ios_invoice_report');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_ios_invoice_report'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_ios_invoice_report', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_ios_invoice_report');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 
 function upload_icx_invoice_report__($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_icx_invoice_report');
	$this->webspice->permission_verify('upload_icx_invoice_report');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_icx_invoice_report', $data);
		return FALSE;
	}
	
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_icx_invoice_report');
	}
	
	$table_name = "TBL_ICX_REPORT_DATA";
	$input = $this->webspice->get_input();
	
	$calculative_month = $input->calculative_month;
	$report_date=date("Y-m-d",$calculative_month);
	$operator=$input->operator_name;
	
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_invoice_report');
		return FALSE;
	}
	
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
  
  $data_error = null;
  $values = array();
  
	if(empty($xml_data['report_data']['action_summary']['rows']) && empty($xml_data['report_data']['action_sms']['rows']) && empty($xml_data['report_data']['action_noncli']['rows'])){
		$this->webspice->message_board('Your File is Empty!');
	  $this->webspice->force_redirect($url_prefix.'upload_icx_invoice_report');
	  return false;
	}
	$this->webspice->remove_cache('payable_invoice_icx');
	#Report Data Voice
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
		$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
		
		foreach($rows_data as $k=>$v){
			$data_list = $v['column'];
			
			$Operator_Name = trim($this->webspice->clean_input($data_list[0]));
			if ($Operator_Name=='Total') continue;
			
			#if voice data exist then check operator and file
			$tmp_operator = $this->ft->search("name_alternative", null, $Operator_Name);
			if(empty($tmp_operator)){
				$data_error .= 'Operator Name "'.$Operator_Name.'" at Row #'.$k.' is invalid.<br />';
				$Operator_Name='';
		  }else{
				$Operator_Name=$tmp_operator[0]->cName;
			}			
			
			$Route = trim($this->webspice->clean_input($data_list[1]));
			$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
			$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
			$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
			$Amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
			$VAT=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
			$Total=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
			
			$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator, "NO_CLI_DATE"=>'', 
			"ROUTE" => $Route, "NO_OF_CALLS" => $No_of_Calls, "DURATION" => $Duration_In_Min, "RATE_PER_MNT" => $Rate_Per_Min, 
			"AMOUNT" => $Amount, "VAT_VALUE" => $VAT, "VAT"=>$Vat, "SD"=>$Sd,"SURCHARGE"=>$Surcharge,"TOTAL" => $Total,"CREATED_BY" => $this->webspice->get_user_id(), 
			"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7, "TYPE"=>'VOICE');
	  }
	}
	
	if($data_error){
		$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
		$this->load->view('upload_full_month_report/upload_icx_invoice_report', $data);
		return FALSE;
	}

	#Report Data Noncli
	if(isset($xml_data['report_data']['action_noncli']['rows']['row'])){
		$rows_data = $xml_data['report_data']['action_noncli']['rows']['row'];
		
		foreach($rows_data as $k=>$v){
			if(array_key_exists('column', $v)){
				$data_list = $v['column'];
			}else{
			  $data_list = $v;	
			}
			
			$route_name = trim($this->webspice->clean_input($data_list[0]));
			
			if ($route_name=='Total') continue;
			
			$no_cli_date = trim($this->webspice->clean_input($data_list[1]));
			$no_cli_formated_date=date('Y_m_d',strtotime(str_replace(',','-', $no_cli_date)));
			$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
			$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
			$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
			$Amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
			$VAT=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
			$Total=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
			
			$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator, "NO_CLI_DATE"=> $no_cli_formated_date,
			"ROUTE" => $Route, "NO_OF_CALLS" => $No_of_Calls, "DURATION" => $Duration_In_Min, "RATE_PER_MNT" => $Rate_Per_Min, 
			"AMOUNT" => $Amount,"VAT_VALUE" => $VAT,"VAT"=>$Vat ,"SD"=>$Sd ,"SURCHARGE"=>$Surcharge,"TOTAL" => $Total,"CREATED_BY" => $this->webspice->get_user_id(), 
			"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7,"TYPE"=>'NO_CLI');	
		
	}
	
	}
	
	#Report Data SMS
	if(isset($xml_data['report_data']['action_sms']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_sms']['rows']['row'];
	foreach($rows_data as $k=>$v){
		if(array_key_exists('column',$v)){
			$data_list = $v['column'];
		}else{
		  $data_list = $v;	
		}
		
		$Operator_Name = trim($this->webspice->clean_input($data_list[0]));
		if ($Operator_Name=='Total') continue;

		#if sms data exist then check operator and file
		$tmp_operator = $this->ft->search("name_alternative", null, $Operator_Name);
		if(empty($tmp_operator)){
			$data_error .= 'Operator Name "'.$Operator_Name.'" at Row #'.$k.' is invalid.<br />';
			$Operator_Name='';
	  }else{
			$Operator_Name=$tmp_operator[0]->cName;
		}	
 
		$Route = trim($this->webspice->clean_input($data_list[1]));
		$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$Amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$VAT=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$Total=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator, "NO_CLI_DATE"=>'',
		"ROUTE" => $Route, "NO_OF_CALLS" => $No_of_Calls, "DURATION" => $Duration_In_Min, "RATE_PER_MNT" => $Rate_Per_Min, 
		"AMOUNT" => $Amount,"VAT_VALUE" => $VAT,"VAT"=>$Vat ,"SD"=>$Sd ,"SURCHARGE"=>$Surcharge,"TOTAL" => $Total,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7,"TYPE"=>'SMS_MMS');
  }
  
	}
  
	if($data_error){
		$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
		$this->load->view('uploader/upload_icx_invoice_report', $data);
		return FALSE;
	}
	
	#insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
			$this->webspice->message_board('Duplicate data found for this date range!');
			$this->webspice->force_redirect($url_prefix.'upload_icx_invoice_report');
			return false;
		}
	}
	$this->db->insert_batch($table_name, $values);	
	
	if($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_invoice_report');
		return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_icx_invoice_report'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_icx_invoice_report', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_icx_invoice_report');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 
 function upload_full_month_mtid($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_mtid');
	$this->webspice->permission_verify('upload_full_month_mtid');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_mtid', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_mtid');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtid');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='IOS' && $column_headers[1]!=='ICX' && $column_headers[2]!=='Pre\Post' && $column_headers[3]!=='Type' && $column_headers[4]!=='No of Calls' && $column_headers[5]!=='Duration (In Min.)' && $column_headers[6]!=='Rate(USD)' && $column_headers[7]!=='Ter. Charge (USD)' && $column_headers[6]!=='USD/BDT' && $column_headers[6]!=='Ter. Charge (BDT)' && $column_headers[6]!=='BL Revenue'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtid');
		return false;
	} 
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$ios = trim($this->webspice->clean_input($data_list[0]));
		if (trim($ios)=='Total') continue;
		$icx = trim($this->webspice->clean_input($data_list[1]));
		$pre_post = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$type = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$duration_in_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$rate_usd=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$ter_charge_usd=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$usd_bdt=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$ter_charge_bdt=trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$bl_revenue=trim(str_replace(",","",$this->webspice->clean_input($data_list[10])));
		$operator = $this->ft->search("name_alternative", null, $ios);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$ios.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}

		$values[] = array("REPORT_DATE" => $report_date, "IOS" => $operator_cname, "OPERATOR_TYPE" => 'IGW',
		"ICX" => $icx, "PRE_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, 
		"DURATION_IN_MIN" => $duration_in_min,"RATE_USD" => $rate_usd,"TER_CHARGE_USD" => $ter_charge_usd,"USD_BDT" => $ter_charge_bdt,"TER_CHARGE_BDT" => $usd_bdt,"BL_REVENUE" => $bl_revenue,"INTEREST_RATE"=>$Interest_Rate,"SD"=>$Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
	if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_mtid', $data);
			return FALSE;
		}
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_mtid');
	return false;
	}
	
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_MTID";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_mtid');
				return false;
		}
	}	

	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtid');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_mtid'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_mtid', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtid');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 

 function upload_full_month_itfs($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_itfs');
	$this->webspice->permission_verify('upload_full_month_itfs');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_itfs', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_itfs');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='Pre\Post' && $column_headers[2]!=='No of Calls' && $column_headers[3]!=='Duration (In Min.)' && $column_headers[4]!=='Rate(USD)' && $column_headers[5]!=='Ter. Charge (USD)' && $column_headers[6]!=='USD/BDT' && $column_headers[7]!=='Ter. Charge (BDT)' && $column_headers[8]!=='BL Revenue'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_itfs');
		return false;
	}   
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	#Report Data
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		$operator_info=$this->customcache->operator_maker($operator_name);
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$duration_in_min = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$rate_usd = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$ter_charge_usd=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$usd_bdt=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$ter_charge_bdt=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$bl_revenue=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
		
			if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			}else{
				$operator_cname=$operator[0]->cName;
				}
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, "OPERATOR_TYPE"=>'ITFS',
		"PRE_POST" => $pre_post, "NO_OF_CALLS" => $no_of_calls, "DURATION_IN_MIN" => $duration_in_min, "RATE_USD" => $rate_usd, 
		"TER_CHARGE_USD" => $ter_charge_usd,"USD_BDT" => $usd_bdt,"TER_CHARGE_BDT" => $ter_charge_bdt,"BL_REVENUE" => $bl_revenue,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_itfs', $data);
			return FALSE;
		}
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_itfs');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_ITFS";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_itfs');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_itfs');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_itfs'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_itfs', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_itfs');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_full_month_ltfs($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_ltfs');
	$this->webspice->permission_verify('upload_full_month_ltfs');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_ltfs', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_ltfs');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_ltfs');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='Pre\Post' && $column_headers[2]!=='No of Calls' && $column_headers[3]!=='Duration (In Min.)' && $column_headers[4]!=='Rate Per Min.(BDT)' && $column_headers[5]!=='Revenue' && $column_headers[6]!=='SD Rate' && $column_headers[7]!=='SD Amount' && $column_headers[8]!=='SC Rate' && $column_headers[9]!=='SC Rate' && $column_headers[10]!=='SC Rate'  && $column_headers[11]!=='SD Amount' && $column_headers[12]!=='VAT on (Revenue+SD)' && $column_headers[13]!=='Total' ){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_ltfs');
		return false;
	}  
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	#Report Data
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$rate_per_min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$revenue=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$sd_rate=trim(str_replace(array(",","%"),
    array("", ""),$this->webspice->clean_input($data_list[6])));
		$sd_amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$sc_rate=trim(str_replace(array(",","%"),array("", ""),$this->webspice->clean_input($data_list[8])));
		$sc_amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$vat_on_revenue_sd=trim(str_replace(",","",$this->webspice->clean_input($data_list[10])));
		$total=trim(str_replace(",","",$this->webspice->clean_input($data_list[11])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
			if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			}else{
				$operator_cname=$operator[0]->cName;
				}
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, "OPERATOR_TYPE" => 'LTFS',
		"PRE_POST" => $pre_post, "NO_OF_CALLS" => $no_of_calls, "DURATION_IN_MIN" => $duration, "RATE_PER_MIN_BDT" => $rate_per_min, 
		"REVENUE" => $revenue,"SD_RATE" => $sd_rate,"SD_AMOUNT" => $sd_amount,"SC_RATE" => $sc_rate,"SC_AMOUNT"=>$sc_amount,"VAT_ON_REVENUE_SD"=>$vat_on_revenue_sd,"TOTAL"=>$total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_ltfs', $data);
			return FALSE;
		}
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_ltfs');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_LTFS";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_ltfs');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_ltfs');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_ltfs'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_ltfs', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_ltfs');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_full_month_moid($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_moid');
	$this->webspice->permission_verify('upload_full_month_moid');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_moid', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_moid');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_moid');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='Pre\Post' && $column_headers[2]!=='Type' && $column_headers[3]!=='No of Calls' && $column_headers[4]!=='Actual charged_units (In Min.)' && $column_headers[5]!=='charged_units (In Min.)' && $column_headers[6]!=='X Value' && $column_headers[7]!=='Y Value' && $column_headers[6]!=='Z Value' && $column_headers[7]!=='BL Revenue' && $column_headers[8]!=='IGW Portion'  && $column_headers[9]!=='ICX Portion' && $column_headers[10]!=='BTRC Portion' && $column_headers[11]!=='Total Cost' ){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_moid');
		return false;
	}  
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	#Report Data
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
	  $calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$type = trim($this->webspice->clean_input($data_list[2]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$actual_charged_units_in_min = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$charged_units_in_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$x_value=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$y_value=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$z_value=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$bl_revenue=trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$igw_portion=trim(str_replace(",","",$this->webspice->clean_input($data_list[10])));
		$icx_portion=trim(str_replace(",","",$this->webspice->clean_input($data_list[11])));
		$btrc_portion=trim(str_replace(",","",$this->webspice->clean_input($data_list[12])));
		$total_cost=trim(str_replace(",","",$this->webspice->clean_input($data_list[13])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
			if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			}else{
				$operator_cname=$operator[0]->cName;
				}
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, "OPERATOR_TYPE" => 'ICX',
		"PREP_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "ACTUAL_CHARGED_UNITS_IN_MIN" => $actual_charged_units_in_min, 
		"CHARGED_UNIT_IN_MIN" => $charged_units_in_min,"X_VALUE" => $x_value,"Y_VALUE" => $y_value,"Z_VALUE" => $z_value,"BL_REVENUE"=>$bl_revenue,"IGW_PORTION"=>$igw_portion,"ICX_PORTION"=>$icx_portion,"BTRC_PORTION"=>$btrc_portion,"TOTAL_COST"=>$total_cost,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_moid', $data);
			return FALSE;
		}
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_moid');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_MOID";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_moid');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_moid');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_moid'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_moid', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_moid');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_full_month_mosms($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_mosms');
	$this->webspice->permission_verify('upload_full_month_mosms');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_mosms', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_mosms');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mosms');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='Pre\Post' && $column_headers[2]!=='Type' && $column_headers[3]!=='No of Calls' && $column_headers[4]!=='Duration' && $column_headers[5]!=='Rate Per Min.' && $column_headers[6]!=='Amount' && $column_headers[7]!=='VAT' && $column_headers[8]!=='Total'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mosms');
		return false;
	} 
	
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	#Report Data
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total' || $operator_name=='Banglalink') continue;
		   $operator = $this->ft->search("name_alternative", null, $operator_name);
		   
				if(empty($operator) || $operator==''){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }
			  
		$operator_cname=$operator[0]->cName;
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$type = trim($this->webspice->clean_input($data_list[2]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$rate_per_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$vat=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$total=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		 
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"PRE_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION" => $duration, 
		"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat,"TOTAL" => $total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_mosms');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_MOSMS";
	if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_mosms', $data);
			return FALSE;
		}
	
	
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_mosms');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mosms');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_mosms'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_mosms', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mosms');
	}
	$this->webspice->force_redirect($url_prefix);
 }
  
 function upload_full_month_mtsms($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_mtsms');
	$this->webspice->permission_verify('upload_full_month_mtsms');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_mtsms', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_mtsms');
	}
	
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtsms');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$code = $xml_data['report_header']['code']; #Bill_0091
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='Pre\Post' && $column_headers[2]!=='Type' && $column_headers[3]!=='No of Calls' && $column_headers[4]!=='Duration' && $column_headers[5]!=='Rate Per Min.' && $column_headers[6]!=='Amount' && $column_headers[7]!=='VAT' && $column_headers[8]!=='Total'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtsms');
		return false;
	} 
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total' || $operator_name=='Banglalink') continue;
		$operator = $this->ft->search("name_alternative", null, $operator_name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}

		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$type = trim($this->webspice->clean_input($data_list[2]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$rate_per_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$vat=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$total=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"PRE_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION" => $duration, 
		"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat,"TOTAL" => $total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_mtsms', $data);
			return FALSE;
		}
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_mtsms');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_MTSMS";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE',$report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_mtsms');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtsms');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_mtsms'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_mtsms', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtsms');
	}
	$this->webspice->force_redirect($url_prefix);
 }
  
 function upload_full_month_momms($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_momms');
	$this->webspice->permission_verify('upload_full_month_momms');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_momms', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_momms');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_momms');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='Pre\Post' && $column_headers[2]!=='Type' && $column_headers[3]!=='No of Calls' && $column_headers[4]!=='Duration' && $column_headers[5]!=='Rate Per Min.' && $column_headers[6]!=='Amount'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_momms');
		return false;
	}  
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	#Report Data
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$type = trim($this->webspice->clean_input($data_list[2]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$rate_per_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$vat_value=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$total=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"PRE_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION" => $duration, 
		"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat_value,"TOTAL" => $total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_momms', $data);
			return FALSE;
		}
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_momms');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_MOMMS";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_momms');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_momms');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_momms'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_momms', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_momms');
	}
	$this->webspice->force_redirect($url_prefix);
 }
  
  
 function upload_full_month_mtmms($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_mtmms');
	$this->webspice->permission_verify('upload_full_month_mtmms');
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_mtmms', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_mtmms');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtmms');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='Pre\Post' && $column_headers[2]!=='Type' && $column_headers[3]!=='No of Calls' && $column_headers[4]!=='Duration' && $column_headers[5]!=='Rate Per Min.' && $column_headers[6]!=='Amount' && $column_headers[7]!=='VAT' && $column_headers[8]!=='Total'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtmms');
		return false;
	} 
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$type = trim($this->webspice->clean_input($data_list[2]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$rate_per_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$vat=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$total=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}
		
		$values[] = array("REPORT_DATE" => $report_date,"OPERATOR_NAME" => $operator_cname, 
		"PRE_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION" => $duration, 
		"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat,"TOTAL" => $total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_mtmms', $data);
			return FALSE;
		}

	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_mtmms');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_MTMMS";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_mtmms');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtmms');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_mtmms'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_mtmms', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_mtmms');
	}
	$this->webspice->force_redirect($url_prefix);
 }
  
 function upload_full_month_videomoc($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_videomoc');
	$this->webspice->permission_verify('upload_full_month_videomoc');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_videomoc', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_videomoc');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_videomoc');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$type = trim($this->webspice->clean_input($data_list[2]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$rate_per_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$vat=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$total=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"PRE_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION" => $duration, 
		"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat,"TOTAL" => $total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_videomoc', $data);
			return FALSE;
		}
	}else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_videomoc');
	return false;
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_VIDEOMOC";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_videomoc');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_videomoc');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_videomoc'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_videomoc', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_videomoc');
	}
	$this->webspice->force_redirect($url_prefix);
 }
  
 function upload_full_month_videomtc($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_videomtc');
	$this->webspice->permission_verify('upload_full_month_videomtc');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_videomtc', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_videomtc');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_videomtc');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	
	#Report Data

	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	if($rows_data){
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$pre_post = trim($this->webspice->clean_input($data_list[1]));
		$type = trim($this->webspice->clean_input($data_list[2]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$rate_per_min=trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$amount=trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$vat=trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$total=trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}
		
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"PRE_POST" => $pre_post, "TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION" => $duration, 
		"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat,"TOTAL" => $total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_videomtc', $data);
			return FALSE;
		}
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_videomtc');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_VIDEOMTC";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_videomtc');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_videomtc');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_videomtc'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_videomtc', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_videomtc');
	}
	$this->webspice->force_redirect($url_prefix);
 }

 function upload_full_month_iptsp($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_full_month_iptsp');
	$this->webspice->permission_verify('upload_full_month_iptsp');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_full_month_iptsp', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_full_month_iptsp');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_iptsp');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	if($rows_data){
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name = trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$icx_route = trim($this->webspice->clean_input($data_list[1]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$duration = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$operator = $this->ft->search("name_alternative", null, $operator_name);
      if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			}else{
				$operator_cname=$operator[0]->cName;
			}	
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"ICX_ROUTE" => $icx_route, "NO_OF_CALLS" => $no_of_calls, "DURATION" => $duration,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_full_month_iptsp', $data);
			return FALSE;
		}
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_full_month_iptsp');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_FULL_MONTH_IPTSP";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_full_month_iptsp');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_full_month_iptsp');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_full_month_iptsp'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_full_month_iptsp', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_full_month_iptsp');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 
  function upload_icx_moc($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_icx_moc');
	$this->webspice->permission_verify('upload_icx_moc');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_icx_moc', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_icx_moc');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_moc');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='ICX' && $column_headers[1]!=='Operator Name' && $column_headers[2]!=='Pre\Post' && $column_headers[3]!=='Type' && $column_headers[4]!=='No of Calls' && $column_headers[5]!=='Duration (In Min.)' && $column_headers[6]!=='Rate Per Min.' && $column_headers[7]!=='Amount' && $column_headers[6]!=='VAT' && $column_headers[7]!=='Total'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_icx_moc');
		return false;
	}
	
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];

	#Delete Last Index (Total)
	if($rows_data){
  $data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$ICX_name = trim($this->webspice->clean_input($data_list[0]));
		if ($ICX_name=='Total') continue;
		$operator_cname = trim($this->webspice->clean_input($data_list[1]));
		$Pre_Post = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$Type = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$Amount = trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$VAT_value = trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$Total = trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$icx = $this->ft->search("name_alternative", null, $ICX_name);
				if(empty($icx)){
				$data_error .= 'ICX Name "'.$ICX_name.'" at Row #'.$k.' is invalid.<br />';
				$ICX='';
			  }else{
				$ICX=$icx[0]->cName;
				}
		$values[] = array("REPORT_DATE" => $report_date, "ICX" => $ICX, "OPERATOR_TYPE" => 'ICX',
		"OPERATOR_NAME" => $operator_cname, "PRE_POST" => $Pre_Post, "TYPE" => $Type,"NO_OF_CALLS"=>$No_of_Calls,"DURATION_IN_MIN"=>$Duration_In_Min,"RATE_PER_MIN"=>$Rate_Per_Min,"AMOUNT"=>$Amount,"VAT_VALUE"=>$VAT_value,"TOTAL"=>$Total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_icx_moc', $data);
			return FALSE;
		}
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_icx_moc');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_ICX_MOC";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_icx_moc');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_moc');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_icx_moc'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_icx_moc', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_icx_moc');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_icx_videomoc($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_icx_videomoc');
	$this->webspice->permission_verify('upload_icx_videomoc');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_icx_videomoc', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_icx_videomoc');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_videomoc');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	if($rows_data){
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$ICX = trim($this->webspice->clean_input($data_list[0]));
		if ($ICX=='Total') continue;
		$Operator_Name = trim($this->webspice->clean_input($data_list[1]));
		$Pre_Post = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$Type = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$Amount = trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$VAT_value = trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$Total = trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$operator = $this->ft->search("name_alternative", null, $Operator_Name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			 }else{
				$operator_cname=$operator[0]->cName;
				}
		$values[] = array("REPORT_DATE" => $report_date, "ICX" => $ICX, 
		"OPERATOR_NAME" => $operator_cname, "PRE_POST" => $Pre_Post, "TYPE" => $Type,"NO_OF_CALLS"=>$No_of_Calls,"DURATION_IN_MIN"=>$Duration_In_Min,"RATE_PER_MIN"=>$Rate_Per_Min,"AMOUNT"=>$Amount,"VAT_VALUE"=>$VAT_value,"TOTAL"=>$Total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_icx_videomoc', $data);
			return FALSE;
		}
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_icx_videomoc');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_ICX_VIDEOMOC";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_icx_videomoc');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_videomoc');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_icx_videomoc'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_icx_videomoc', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_icx_videomoc');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_icx_videomtc($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_icx_videomtc');
	$this->webspice->permission_verify('upload_icx_videomtc');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_icx_videomtc', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_icx_videomtc');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_videomtc');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	if($rows_data){
	$data_error = null;
	foreach($rows_data as $k=>$v){ 
		if(array_key_exists('column',$v)){
			$data_list = $v['column'];
		}else{
		  $data_list = $v;	
		}
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$Operator_Name = trim($this->webspice->clean_input($data_list[0]));
		if ($Operator_Name=='Total') continue;
		$ICX = trim($this->webspice->clean_input($data_list[1]));
		$Pre_Post = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$Type = trim(str_replace(",","",$this->webspice->clean_input($data_list[3])));
		$No_of_Calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$Duration_In_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[5])));
		$Rate_Per_Min = trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$Amount = trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$VAT_value = trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$Total = trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$operator = $this->ft->search("name_alternative", null, $Operator_Name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$Operator_Name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}
		$values[] = array("REPORT_DATE" => $report_date, "ICX" => $ICX, 
		"OPERATOR_NAME" => $operator_cname, "PRE_POST" => $Pre_Post, "TYPE" => $Type,"NO_OF_CALLS"=>$No_of_Calls,"DURATION_IN_MIN"=>$Duration_In_Min,"RATE_PER_MIN"=>$Rate_Per_Min,"AMOUNT"=>$Amount,"VAT_VALUE"=>$VAT_value,"TOTAL"=>$Total,"INTEREST_RATE" => $Interest_Rate,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
			if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_icx_videomtc', $data);
			return FALSE;
		  }
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_icx_videomtc');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_ICX_VIDEOMTC";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_icx_videomtc');
				return false;
		}
	}	
	dd($values);
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_icx_videomtc');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_icx_videomtc'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_icx_videomtc', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_icx_videomtc');
	}
	$this->webspice->force_redirect($url_prefix);
 }
  

 function upload_a2p_sms_incomming($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_a2p_sms_incomming');
	$this->webspice->permission_verify('upload_a2p_sms_incomming');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_a2p_sms_incomming', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_a2p_sms_incomming');
	}
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_a2p_sms_incomming');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	if($rows_data){
	foreach($rows_data as $k=>$v){
		$data_list = $v;
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$Name= trim($this->webspice->clean_input($data_list[0]));
		if ($Name=='Total') continue;
		$Call_Type_Description = trim($this->webspice->clean_input($data_list[1]));
		$No_of_SMS = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$values[] = array("REPORT_DATE" => $report_date, "NAME" => $Name, 
		"CALL_TYPE_DESCRIPTION" => $Call_Type_Description, "NO_OF_SMS" => $No_of_SMS, "CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7, "USD_TO_BDT_RATE"=>$_POST['USD_TO_BDT_RATE']);
	}
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_a2p_sms_incomming');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_A2P_INT_SMS_INCOMMING";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_a2p_sms_incomming');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_a2p_sms_incomming');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_a2p_sms_incomming'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_a2p_sms_incomming', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_a2p_sms_incomming');
	}
	$this->webspice->force_redirect($url_prefix);
 }

 function upload_operator_wise_moc($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_operator_wise_moc');
	$this->webspice->permission_verify('upload_operator_wise_moc');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_operator_wise_moc', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_operator_wise_moc');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_moc');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='ICX' && $column_headers[2]!=='Pre\Post' && $column_headers[3]!=='Type' && $column_headers[4]!=='No of Calls' && $column_headers[5]!=='Duration (In Min.)' && $column_headers[6]!=='Rate Per Min.' && $column_headers[7]!=='Amount' && $column_headers[8]!=='VAT' && $column_headers[9]!=='Total'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_moc');
		return false;
	} 
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	
	if($rows_data){
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name= trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$ICX = trim($this->webspice->clean_input($data_list[1]));
		$pre_post = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$type = trim($this->webspice->clean_input($data_list[3]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$duration_in_min = trim($this->webspice->clean_input($data_list[5]));
		$rate_per_min = trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$amount = trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$vat = trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$total = trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$operator = $this->ft->search("name_alternative", null,$operator_name);
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"ICX" => $ICX, "PRE_POST" => $pre_post,"TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION_IN_MIN" => $duration_in_min,"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat,"TOTAL" => $total,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
	if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_operator_wise_moc', $data);
			return FALSE;
	}
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_operator_wise_moc');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_OP_MOC";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_operator_wise_moc');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_moc');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_operator_wise_moc'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_operator_wise_moc', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_moc');
	}
	$this->webspice->force_redirect($url_prefix);
 }
 function upload_operator_wise_mtc($data=null){
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	ini_set('MAX_EXECUTION_TIME', 300);
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_operator_wise_mtc');
	$this->webspice->permission_verify('upload_operator_wise_mtc');
	
	if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
		$this->load->view('upload_full_month_report/upload_operator_wise_mtc', $data);
		return FALSE;
	}
	# verify file type
	if( $_FILES['sap_file']['tmp_name'] ){
		$this->webspice->check_file_type(array('xml'), 'sap_file', $data, 'upload_full_month_report/upload_operator_wise_mtc');
	}
	$Configaration = $this->ft->get($Parent="config",$Key=0);
	$Interest_Rate = $Configaration->{"0"}->interest_rate;
	$Sd = $Configaration->{"0"}->sd;
	$Vat = $Configaration->{"0"}->vat;
	$Surcharge = $Configaration->{"0"}->surcharge;
	$xml_data = simplexml_load_file($_FILES['sap_file']['tmp_name']);
	$xml_data = json_encode($xml_data);
	$xml_data = json_decode($xml_data,TRUE);
	if(!$xml_data){
		$this->webspice->message_board('Invalid file.');
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_mtc');
		return FALSE;
	}
	#Report Basic Info
	$title = $xml_data['report_header']['title']; #Roaming Inbound Subscribers and Usage Report
	$criteria = $xml_data['report_header']['criteria']; #Report on September2017
	$table1_title = $xml_data['report_header']['criteria']; #Report between 01/09/2017 and 30/09/2017
	$column_headers = $xml_data['report_data']['action_summary']['column_headers']['column_header']; #Operator, Seq from, Seq to, Call SMS, SDR and BDT
	if($column_headers[0]!=='Operator Name' && $column_headers[1]!=='ICX' && $column_headers[2]!=='Pre\Post' && $column_headers[3]!=='Type' && $column_headers[4]!=='No of Calls' && $column_headers[5]!=='Duration (In Min.)' && $column_headers[6]!=='Rate Per Min.' && $column_headers[7]!=='Amount' && $column_headers[8]!=='VAT' && $column_headers[9]!=='Total'){
		$this->webspice->message_board('You try to upload invalied file!');
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_mtc');
		return false;
	} 
	#Report Data
	if(isset($xml_data['report_data']['action_summary']['rows']['row'])){
	$rows_data = $xml_data['report_data']['action_summary']['rows']['row'];
	#Delete Last Index (Total)
	
	if($rows_data){
	$data_error = null;
	foreach($rows_data as $k=>$v){
		$data_list = $v['column'];
		$calculative_month = $date_from = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		$operator_name= trim($this->webspice->clean_input($data_list[0]));
		if ($operator_name=='Total') continue;
		$ICX = trim($this->webspice->clean_input($data_list[1]));
		$pre_post = trim(str_replace(",","",$this->webspice->clean_input($data_list[2])));
		$type = trim($this->webspice->clean_input($data_list[3]));
		$no_of_calls = trim(str_replace(",","",$this->webspice->clean_input($data_list[4])));
		$duration_in_min = trim($this->webspice->clean_input($data_list[5]));
		$rate_per_min = trim(str_replace(",","",$this->webspice->clean_input($data_list[6])));
		$amount = trim(str_replace(",","",$this->webspice->clean_input($data_list[7])));
		$vat = trim(str_replace(",","",$this->webspice->clean_input($data_list[8])));
		$total = trim(str_replace(",","",$this->webspice->clean_input($data_list[9])));
		$operator = $this->ft->search("name_alternative", null,$operator_name);
		$type_new=array('MOBILE','IPTSP','PSTN');
				if(empty($operator)){
				$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
				$operator_cname='';
			  }else{
				$operator_cname=$operator[0]->cName;
				}		
		
	//	echo "SELECT OPERATOR_NAME,OPERATOR_TYPE WHERE OPERATOR_NAME='".$operator_cname."' AND OPERATOR_TYPE='MOBILE' OR OPERATOR_TYPE='IPTSP' OR OPERATOR_TYPE='PSTN'SELECT OPERATOR_NAME,OPERATOR_TYPE WHERE OPERATOR_NAME='".$operator_cname."' AND OPERATOR_TYPE='MOBILE' OR OPERATOR_TYPE='IPTSP' OR OPERATOR_TYPE='PSTN'"; 
	//	exit;
		 $operator_type_array=$this->db->query("SELECT OPERATOR_NAME,OPERATOR_TYPE FROM TBL_OPERATOR WHERE OPERATOR_NAME='".$operator_cname."' AND OPERATOR_TYPE='MOBILE' OR OPERATOR_TYPE='IPTSP' OR OPERATOR_TYPE='PSTN'");	
		$values[] = array("REPORT_DATE" => $report_date, "OPERATOR_NAME" => $operator_cname, 
		"ICX" => $ICX, "PRE_POST" => $pre_post,"TYPE" => $type, "NO_OF_CALLS" => $no_of_calls, "DURATION_IN_MIN" => $duration_in_min,"RATE_PER_MIN" => $rate_per_min,"AMOUNT" => $amount,"VAT_VALUE" => $vat,"TOTAL" => $total,"SD" => $Sd,"VAT" => $Vat,"SURCHARGE" => $Surcharge,"CREATED_BY" => $this->webspice->get_user_id(), 
		"CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
	}
	if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('upload_full_month_report/upload_operator_wise_mtc', $data);
			return FALSE;
	}
	}
 }else{
	$this->webspice->message_board('Your File is Empty!');
	$this->webspice->force_redirect($url_prefix.'upload_operator_wise_mtc');
	return false;
	
	}
	$input = $this->webspice->get_input();
	$table_name = "TBL_OP_MTC";
	
	# insert data
	$this->db->trans_off();
	$this->db->trans_begin();	
	if( $input->data_insert == "data_remove_insert" ){
		$this->db->where('REPORT_DATE', $report_date);
		$this->db->delete($table_name);
	}else{
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_operator_wise_mtc');
				return false;
		}
	}	
	$this->db->insert_batch($table_name, $values);	
	if ($this->db->trans_status() === FALSE){
		$this->db->trans_rollback();
		$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_mtc');
	return false;
	}else{
		$this->db->trans_commit();
	}
	$this->db->trans_off();
	$this->webspice->log_me('upload_operator_wise_mtc'); # log
	$this->webspice->message_board('Record has been inserted successfully.');
	if( $this->webspice->permission_verify('upload_operator_wise_mtc', true) ){
		$this->webspice->force_redirect($url_prefix.'upload_operator_wise_mtc');
	}
	$this->webspice->force_redirect($url_prefix);
 }
  #manage
  
 function manage_a2p_sms_incomming(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_a2p_sms_incomming');
		$this->webspice->permission_verify('manage_a2p_sms_incomming');
		$this->load->database();
    $orderby = ' ORDER BY TBL_A2P_INT_SMS_INCOMMING.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_A2P_INT_SMS_INCOMMING.* FROM TBL_A2P_INT_SMS_INCOMMING ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_A2P_INT_SMS_INCOMMING', 
			$InputField = array(),
			$Keyword= array("NAME","CALL_TYPE_DESCRIPTION","NO_OF_SMS"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_a2p_sms_incomming',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_a2p_sms_incomming/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_a2p_sms_incomming', $data);
 }
 function manage_icx_videomoc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_icx_videomoc');
		$this->webspice->permission_verify('manage_icx_videomoc');
		$this->load->database();
    $orderby = ' ORDER BY TBL_ICX_VIDEOMOC.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_ICX_VIDEOMOC.* FROM TBL_ICX_VIDEOMOC ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_ICX_VIDEOMOC', 
			$InputField = array(),
			$Keyword= array("ID","ICX","OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION_IN_MIN","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_icx_videomoc',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_icx_videomoc/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_icx_videomoc', $data);
 }
 
 function manage_operator_wise_moc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_operator_wise_moc');
		$this->webspice->permission_verify('manage_operator_wise_moc');
		$this->load->database();
    $orderby = ' ORDER BY TBL_OP_MOC.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_OP_MOC.* FROM TBL_OP_MOC ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_OP_MOC', 
			$InputField = array(),
			$Keyword= array("ID","ICX","OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION_IN_MIN","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_operator_wise_moc',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_operator_wise_moc/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_operator_wise_moc', $data);
 }
 function manage_operator_wise_mtc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_operator_wise_mtc');
		$this->webspice->permission_verify('manage_operator_wise_mtc');
		$this->load->database();
    $orderby = ' ORDER BY TBL_OP_MTC.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_OP_MTC.* FROM TBL_OP_MTC ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_OP_MTC', 
			$InputField = array(),
			$Keyword= array("ID","ICX","OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION_IN_MIN","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_operator_wise_mtc',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_operator_wise_mtc/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_operator_wise_mtc', $data);
 }
 function manage_icx_videomtc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_icx_videomtc');
		$this->webspice->permission_verify('manage_icx_videomtc');
		$this->load->database();
    $orderby = ' ORDER BY TBL_ICX_VIDEOMTC.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_ICX_VIDEOMTC.* FROM TBL_ICX_VIDEOMTC ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_ICX_VIDEOMTC', 
			$InputField = array(),
			$Keyword= array("ID","ICX","OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION_IN_MIN","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_icx_videomtc',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_icx_videomtc/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_icx_videomtc', $data);
 }
 function manage_icx_moc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_icx_moc');
		$this->webspice->permission_verify('manage_icx_moc');
		$this->load->database();
    $orderby = ' ORDER BY TBL_ICX_MOC.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_ICX_MOC.* FROM TBL_ICX_MOC ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_ICX_MOC', 
			$InputField = array(),
			$Keyword= array("ID","ICX","OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION_IN_MIN","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_icx_moc',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_icx_moc/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_icx_moc', $data);
 }
 function manage_ios_invoice_report(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ios_invoice_report');
		$this->webspice->permission_verify('manage_ios_invoice_report');
		$this->load->database();
    $orderby = ' ORDER BY TBL_IOS_REPORT_DATA.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_IOS_REPORT_DATA.* FROM TBL_IOS_REPORT_DATA ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_IOS_REPORT_DATA', 
			$InputField = array(),
			$Keyword= array("OPERATOR_NAME","PRE_POST","NO_OF_CALLS","DURATION_IN_MIN","RATE_USD"),
			$AdditionalWhere = null,
			$DateBetween = array('DATE_FROM', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_ios_invoice_report',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ios_invoice_report/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_ios_invoice_report', $data);
 }
 function manage_full_month_itfs(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_itfs');
		$this->webspice->permission_verify('manage_full_month_itfs');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_ITFS.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_ITFS.* FROM TBL_FULL_MONTH_ITFS ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_ITFS', 
			$InputField = array(),
			$Keyword= array("OPERATOR_NAME","PRE_POST","NO_OF_CALLS","DURATION_IN_MIN","RATE_USD"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}
    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_full_month_itfs',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	dd();
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_itfs/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_itfs', $data);
 }
 function manage_full_month_ltfs(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_ltfs');
		$this->webspice->permission_verify('manage_full_month_ltfs');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_LTFS.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_LTFS.* FROM TBL_FULL_MONTH_LTFS ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_LTFS', 
			$InputField = array(),
			$Keyword = array("OPERATOR_NAME","PRE_POST","NO_OF_CALLS","DURATION_IN_MIN","RATE_PER_MIN_BDT"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('upload_full_month_report/print_full_month_ltfs',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_ltfs/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_ltfs', $data);
 }
	
 function manage_full_month_moid(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_moid');
		$this->webspice->permission_verify('manage_full_month_moid');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_MOID.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_MOID.* FROM TBL_FULL_MONTH_MOID ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_MOID', 
			 $InputField= array(),
			$Keyword = array("OPERATOR_NAME","PREP_POST","TYPE","NO_OF_CALLS","ACTUAL_CHARGED_UNITS_IN_MIN","CHARGED_UNIT_IN_MIN","X_VALUE","Y_VALUE","Z_VALUE","BL_REVENUE","IGW_PORTION","ICX_PORTION","BTRC_PORTION","TOTAL_COST"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_moid',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_moid/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_moid', $data);
 }	
	
 function manage_full_month_mosms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_mosms');
		$this->webspice->permission_verify('manage_full_month_mosms');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_MOSMS.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT * FROM TBL_FULL_MONTH_MOSMS";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_MOSMS', 
			$InputField = array(),
			$Keyword = array("OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_mosms',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_mosms/page/', 10 );
		}
     
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_mosms', $data);
 }	

 function manage_full_month_mtsms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_mtsms');
		$this->webspice->permission_verify('manage_full_month_mtsms');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_MTSMS.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }		
		$initialSQL = " SELECT TBL_FULL_MONTH_MTSMS.* FROM TBL_FULL_MONTH_MTSMS ";
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_MTSMS', 
			 $InputField= array(),
			$Keyword = array("OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_mtsms',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_mtsms/page/', 10 );
		}   
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_mtsms', $data);
 }	
	
 function manage_full_month_momms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_momms');
		$this->webspice->permission_verify('manage_full_month_momms');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_MOMMS.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }	
		$initialSQL = " SELECT TBL_FULL_MONTH_MOMMS.* FROM TBL_FULL_MONTH_MOMMS ";
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_MOMMS', 
			 $InputField= array(),
			$Keyword = array("OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);	
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}	
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_momms',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_momms/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_momms', $data);
 }	
	
 function manage_full_month_mtmms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_mtmms');
		$this->webspice->permission_verify('manage_full_month_mtmms');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_MTMMS.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_MTMMS.* FROM TBL_FULL_MONTH_MTMMS ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_MTMMS', 
			 $InputField= array(),
			$Keyword = array("OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_mtmms',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_mtmms/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_mtmms', $data);
 }	
	
 function manage_full_month_videomoc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_videomoc');
		$this->webspice->permission_verify('manage_full_month_videomoc');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_VIDEOMOC.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_VIDEOMOC.* FROM TBL_FULL_MONTH_VIDEOMOC ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_VIDEOMOC', 
			 $InputField= array(),
			$Keyword = array("OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION","RATE_PER_MIN","AMOUNT","VAT_VALUE","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_videomoc',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_videomoc/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_videomoc', $data);
 }	
	
 function manage_full_month_videomtc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_videomtc');
		$this->webspice->permission_verify('manage_full_month_videomtc');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_VIDEOMTC.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_VIDEOMTC.* FROM TBL_FULL_MONTH_VIDEOMTC ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_VIDEOMTC', 
			 $InputField= array(),
			$Keyword = array("OPERATOR_NAME","PRE_POST","TYPE","NO_OF_CALLS","DURATION","TOTAL"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_videomtc',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_videomtc/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_videomtc', $data);
 }	
	
 function manage_full_month_iptsp(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_iptsp');
		$this->webspice->permission_verify('manage_full_month_iptsp');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_IPTSP.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_IPTSP.* FROM TBL_FULL_MONTH_IPTSP ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_IPTSP', 
			 $InputField= array("OPERATOR_NAME"),
			$Keyword = array("OPERATOR_NAME","ICX_ROUTE","NO_OF_CALLS","DURATION"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_iptsp',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_iptsp/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_iptsp', $data);
 }	

 function manage_full_month_mtid(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_full_month_mtid');
		$this->webspice->permission_verify('manage_full_month_mtid');
		$this->load->database();
    $orderby = ' ORDER BY TBL_FULL_MONTH_MTID.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_FULL_MONTH_MTID.* FROM TBL_FULL_MONTH_MTID ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_FULL_MONTH_MTID', 
			 $InputField= array(),
			$Keyword = array("IOS","ICX","PRE_POST","TYPE","NO_OF_CALLS","DURATION_IN_MIN","RATE_USD","TER_CHARGE_USD"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('upload_full_month_report/print_full_month_mtid',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_full_month_mtid/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('upload_full_month_report/manage_full_month_mtid', $data);
 }	
	
	 function manage_icx_invoice_report(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_icx_invoice_report');
			$this->webspice->permission_verify('manage_icx_invoice_report');
			$this->load->database();
	    $orderby = ' ORDER BY TBL_ICX_REPORT_DATA.REPORT_DATE DESC';
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = ' LIMIT '.$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
	    if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
			
			$initialSQL = " SELECT TBL_ICX_REPORT_DATA.* FROM TBL_ICX_REPORT_DATA ";
			
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_ICX_REPORT_DATA', 
				 $InputField= array(),
				$Keyword = array("OPERATOR_NAME","ROUTE","NO_OF_CALLS","DURATION","RATE_PER_MNT","AMOUNT","VAT","TOTAL"),
				$AdditionalWhere = null,
				$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
				);
				
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}

	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		
	    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('upload_full_month_report/print_icx_invoice_report',$data);
					return false;
	        break;                  
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    # only for pager
	    if( $criteria == 'page' ){
	    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
	    		$sql = $sql;
	    	}
	    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
	    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
	    	$sql = $sql . $limit;
	    }
	     
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_icx_invoice_report/page/', 10 );
			}
	    
	    $_SESSION['sql'] = $sql;
	    $_SESSION['filter_by'] = $filter_by;
	    $result = $this->db->query($sql)->result();	
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('upload_full_month_report/manage_icx_invoice_report', $data);
	 }	
	 # upload NO CLI
	 	function upload_no_cli($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$data_batch = 50; # how much row(s) inserted once
			ini_set('MAX_EXECUTION_TIME', 300);
			$header_offset = 1;
			$column_offset = 2;
			
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_no_cli');
			$this->webspice->permission_verify('upload_no_cli');
			
			if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
				$this->load->view('uploader/upload_no_cli',$data);
				return FALSE;
			}		
			
			# verify file type
			if( $_FILES['sap_file']['tmp_name'] ){
				$this->webspice->check_file_type(array('csv','xls','xlsx'), 'sap_file', $data, 'uploader/upload_no_cli');
			}
			
			$sheet_columns = array("DATE_TIME", "ICX", "OPERATOR", "CALLS", "Seconds", "MINUTES", "RATE_PER_MIN","AMOUNT","VAT","TOTAL");
			
			# verify file type and read accordingly
			$get_data = array();
			if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
				$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset,1);
			}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
				$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
			}else{
				echo 'File Invalid!';
				exit;
			}
			
			if( !is_array($get_data) ){
				$this->webspice->message_board($get_data.' Please try again.');
				$this->webspice->force_redirect($url_prefix.'upload_no_cli');
				return FALSE;
			}
			
			# verify data
			$data_error = null;
			$values = array();
			$single_values = array();
			$unique_date = array();
			$unique_date_traker = null;
			$date_traker = null;
			$report_date = $this->input->post('year_month');
			$data['c_year'] = date("Y", $report_date);
	    $data['c_month'] = date("m",$report_date);
	    $report_date =  $this->webspice->last_of_month($data['c_year'], $data['c_month']);
			foreach($get_data as $k=>$v){
				#$report_date = date("d-M-Y",strtotime($report_date));
				$data_list = $v;
				$date_time = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
				$icx = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
				$operator_name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
				
				$operator_alt = $this->ft->search("name_alternative", null, $operator_name);
				if(empty($operator_alt)){
					$data_error .= 'Operator Name "'.$operator_name.'" at Row #'.$k.' is invalid.<br />';
					$operator='';
				}else{
					$operator=$operator_alt[0]->cName;
				}
				
				$calls = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
				$seconds =  str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
				$minutes =	$seconds/60;
				$rate_per_minute = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
				$amount = $minutes*$rate_per_minute;
				$vat = ($amount*15)/100;
				$total = $amount+$vat;
				
				$values[] = array(
					"REPORT_DATE" => $report_date, "DATE_TIME" => $date_time, "ICX" => $icx, 
					"OPERATOR" => $operator, "CALLS" => $calls, "MINUTES" => $minutes, "SECONDS" => $seconds,
					"RATE_PER_MIN" => $rate_per_minute, "AMOUNT" => $amount,
					"VAT" => $vat, "TOTAL" => $total, 
					"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
				);
			}
			
			if($data_error){
				$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
				$this->load->view('uploader/upload_no_cli', $data);
				return FALSE;
			}
			
			# insert data
			$this->db->trans_off();
			$this->db->trans_begin();
			
			$is_value = false;
			$table_name = "TBL_NO_CLI";
			$input = $this->webspice->get_input();
		
			
			if( $input->data_insert == "data_remove_insert" ){
				$this->db->where_in('REPORT_DATE', $report_date);
				$this->db->delete($table_name);
			}
			
			$this->db->insert_batch($table_name, $values);
			
			if ($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}else{
				$this->db->trans_commit();
			}
			$this->db->trans_off();
			$this->webspice->log_me('upload_no_cli'); # log

			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('manage_no_cli', true) ){
				$this->webspice->force_redirect($url_prefix.'manage_no_cli');
			}
			
			$this->webspice->force_redirect($url_prefix);
		
		}
	 # manage NO CLI
		function manage_no_cli(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_no_cli');
			$this->webspice->permission_verify('manage_no_cli');
			$this->load->database();
	    $orderby = ' ORDER BY TBL_NO_CLI.REPORT_DATE DESC';
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = ' LIMIT '.$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
	    if ($criteria == 'page') {
	    	$page_index = (int)$key; 
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }

			$initialSQL = " SELECT TBL_NO_CLI.* FROM TBL_NO_CLI ";
			
	    
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
					$TableName = 'TBL_NO_CLI', 
					$InputField = array(),
					$Keyword = array(),
					$AdditionalWhere = null,
					$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
				);
				
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}

	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		
	    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
				
					$this->load->view('uploader/print_no_cli',$data);
					return false;
	        break;               
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    # only for pager
	    if( $criteria == 'page' ){
	    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
	    		$sql = $sql;
	    	}
	    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
	    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
	    	$sql = $sql . $limit;
	    }
	    
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_no_cli/page/', 10 );
			}
	    
	    $_SESSION['sql'] = $sql;
	    $_SESSION['filter_by'] = $filter_by;
	    $result = $this->db->query($sql)->result();
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('uploader/manage_no_cli', $data);
		}
	
	

	
	 function manage_trial_balance(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_trial_balance');
		$this->webspice->permission_verify('manage_trial_balance');
		$this->load->database();
    $orderby = ' ORDER BY TBL_TRIAL_BALANCE.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_TRIAL_BALANCE.* FROM TBL_TRIAL_BALANCE ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_TRIAL_BALANCE', 
			$InputField = array(),
			$Keyword= array("ACCOUNT","DESCRIPTION","BEGIN_BALANCE","PERIOD_DR_AMOUNT","PERIOD_CR_AMOUNT","PERIOD_NET_BALANCE","PERIOD_END_BALANCE"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('report/print_trial_balance',$data);
				return false;
        break;  
      case 'edit':
      $this->webspice->edit_generator($TableName='TBL_TRIAL_BALANCE', $KeyField='ID', $key, $RedirectController='upload_controller', $RedirectFunction='create_trial_balance', $PermissionName='create_trial_balance', $StatusCheck=null, $Log='edit_trial_balance');          
			return false;
      break;                
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_trial_balance/page/', 10 );
		}
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('report/manage_trial_balance', $data);
   }
 
 

	
	
	function upload_vendor_liability($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 3;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_vendor_liability');
		$this->webspice->permission_verify('upload_vendor_liability');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_vendor_liability', $data);
			return FALSE;
		}
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'uploader/upload_vendor_liability');
		}
		
		$sheet_columns = array("Account", "Accountt Description", "Accounting Liability", "Accounting Liability Desc", "Invoice Liability Type", "Vendor Number", "Supplier Name","Vendor Type Code","Vendor Sub Type","Batch Name","Vendor Site Code","Invoice Type","Invoice Currency","Invoice Currency Rate","Invoice Number","Bill Month","Invoice Date","GL Date","Invoice Description","Due Date","Invoice Curr Amount","Invoice Amount - BDT","Invoice Curr Remain","Remaining Amount - BDT","Po Number","Revaluation Amount","Net Balance");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_vendor_liability');
			return FALSE;
		}
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$table_name = "TBL_VENDOR_LIABILITY";
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$vendor_type_code = $this->input->post("vendor_type_code");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$Vendor_Type_Code = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			if(in_array($Vendor_Type_Code, $vendor_type_code)){
			$Account = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$Account_Description = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			if ($Account_Description=='Total') continue;
			$Accounting_Liability = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$Accounting_Liability_Desc = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$Invoice_Liability_Type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$Vendor_Number = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$Supplier_Name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$Vendor_Sub_Type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));
      $Batch_Name = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[9]));
			$Vendor_Site_Code = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[10]));
			$Invoice_Type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[11]));
			//$Vendor_Sub_Type = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[11]));
			$Invoice_Currency = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[12]));
			$Invoice_Currency_Rate = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[13]));
			$Invoice_Number = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[14]));
			$bill_Month = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[15]));
			$invoice_Date = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[16]));
			$Invoice_Date = date("Y-m-d",strtotime($invoice_Date));
			$Bill_Month = date("Y-m-d",strtotime($bill_Month));
			$gl_Date = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[17]));
			$GL_Date = date("Y-m-d",$gl_Date);
			$Invoice_Description = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[18]));
			$due_Date = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[19]));
			$Due_Date = date("Y-m-d",strtotime($due_Date));
			$Invoice_Curr_Amount = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[20]));
			$Invoice_Amount_BDT = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[21]));
			$Invoice_Curr_Remain = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[22]));
			$Remaining_Amount_BDT = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[23]));
			$Po_Number = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[24]));
			$Revaluation_Amount = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[25]));
			$Net_Balance = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[26]));
			$payment=$Invoice_Amount_BDT-$Net_Balance;
			$initialSQL_for_operator_name = " SELECT TBL_PAYABLE_AGEING.* FROM TBL_PAYABLE_AGEING WHERE INVOICE_NUMBER='".$Invoice_Number."'";
			$record = $this->db->query($initialSQL_for_operator_name);										 		
			$operator_name = $record->result();
			if($operator_name){
	#INVOICE_DATE = REPORT_DATE
				$sql = "
			UPDATE TBL_PAYABLE_AGEING SET BILL_MONTH=?, INVOICE_AMOUNT_AFTER_VAT_TAX =?, REPORT_DATE=?, UPDATED_BY=?, UPDATED_DATE=? 
			WHERE INVOICE_NUMBER=?";
			$this->db->query($sql, array($Bill_Month,$Net_Balance, $report_date, $this->webspice->get_user_id(), $this->webspice->now(), $Invoice_Number)); 
			}
			
			
			#here cancel or end process
			#if(empty($operator_name)){
			#	$data_error .= 'Invalied Invoice Number '.$Invoice_Number. ' at Row #'.$k.'.<br />';
			#}
			
			
			$values[] = array("VENDOR_TYPE_CODE"=>$Vendor_Type_Code,"ACCOUNT" => $Account, "ACCOUNT_DESCRIPTION" => $Account_Description, 
			"ACCOUNTING_LIABILITY" => $Accounting_Liability, "ACCOUNTING_LIABILITY_DESC" => $Accounting_Liability_Desc, 
			"INVOICE_LIABILITY_TYPE" =>$Invoice_Liability_Type,"VENDOR_NUMBER" => $Vendor_Number, "SUPPLIER_NAME" => $Supplier_Name,
			"BATCH_NAME"=>$Batch_Name,"VENDOR_SUB_TYPE" => $Vendor_Sub_Type,
			"VENDOR_SITE_CODE" => $Vendor_Site_Code, "INVOICE_TYPE" => $Invoice_Type,  "INVOICE_CURRENCY" => $Invoice_Currency,
			"INVOICE_CURRENCY_RATE" => $Invoice_Currency_Rate, "INVOICE_NUMBER" => $Invoice_Number,"INVOICE_DATE"=>$Invoice_Date,
			"BILL_MONTH" => $Bill_Month, "GL_DATE" =>$GL_Date,"INVOICE_DESCRIPTION" => $Invoice_Description, 
			"DUE_DATE" => $Due_Date,"INVOICE_CURR_AMOUNT"=>$Invoice_Curr_Amount,"INVOICE_AMOUNT_BDT" => $Invoice_Amount_BDT, 
			"INVOICE_CURR_REMAIN" => $Invoice_Curr_Remain, "REMAINING_AMOUNT_BDT" => $Remaining_Amount_BDT, 
			"PO_NUMBER" => $Po_Number,"REVALUATION_AMOUNT" => $Revaluation_Amount, "NET_BALANCE" => $Net_Balance,"REPORT_DATE"=> $report_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
      $values_for_payable_ageing[] = array("INVOICE_NUMBER"=>$Invoice_Number,"REMAINING_AMOUNT" => $Remaining_Amount_BDT, "PAY_AMOUNT" => $payment, "REPORT_DATE"=> $report_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			# must have column value - column offset started from 1
			if( !isset($Account)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
		}
		}
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();		
		$is_value = false;
		if($values){
					$this->db->insert_batch($table_name, $values);
			}
		if($values_for_payable_ageing){ 
					$this->db->insert_batch('TBL_PAYMENT_HISTORY_FOR_AGEING', $values_for_payable_ageing);
			
			}
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_vendor_liability'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_vendor_liability', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_vendor_liability');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	
  function manage_vendor_liability(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_vendor_liability');
		$this->webspice->permission_verify('manage_vendor_liability');
		$this->load->database();
    $orderby = ' ORDER BY TBL_VENDOR_LIABILITY.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_VENDOR_LIABILITY.* FROM TBL_VENDOR_LIABILITY ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_VENDOR_LIABILITY', 
			$InputField = array(),
			$Keyword= array("ACCOUNT","ACCOUNTING_LIABILITY","SUPPLIER_NAME","INVOICE_CURR_AMOUNT","INVOICE_AMOUNT_BDT","INVOICE_CURR_REMAIN","REMAINING_AMOUNT_BDT","REVALUATION_AMOUNT","NET_BALANCE"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('uploader/print_vendor_liability',$data);
				return false;
        break;  
      case 'edit':
      $this->webspice->edit_generator($TableName='TBL_VENDOR_LIABILITY', $KeyField='ID', $key, $RedirectController='upload_controller', $RedirectFunction='create_vendor_liability', $PermissionName='create_vendor_liability', $StatusCheck=null, $Log='edit_vendor_liability');          
			return false;
      break;                
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_vendor_liability/page/', 10 );
		}
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('uploader/manage_vendor_liability', $data);
   }
   
 	function upload_ait_gl($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 1;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_ait_gl');
		$this->webspice->permission_verify('upload_ait_gl');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_ait_gl', $data);
			return FALSE;
		}
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'uploader/upload_ait_gl');
		}
		
		$sheet_columns = array("Account", "Entered:Debit", "Entered:Credit", "Description");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ait_gl');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$table_name = "TBL_AIT_GL";
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
      $data_list = $v;
			$Account = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$Entered_Debit = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$Entered_Credit = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$Description = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$values[] = array("ACCOUNT" => $Account, "ENTRED_DEBIT" => $Entered_Debit, "ENTRED_CREDIT" => $Entered_Credit, "DESCRIPTION" => $Description,"REPORT_DATE"=> $report_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			# must have column value - column offset started from 1
			if( !isset($Account)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
		
		}
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();		
		$is_value = false;
		if($values){
					$this->db->insert_batch($table_name, $values);
			}

		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_ait_gl'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_ait_gl', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_ait_gl');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}

   function manage_ait_gl(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_ait_gl');
		$this->webspice->permission_verify('manage_ait_gl');
		$this->load->database();
    $orderby = ' ORDER BY TBL_AIT_GL.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_AIT_GL.* FROM TBL_AIT_GL ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_AIT_GL', 
			$InputField = array(),
			$Keyword= array("ACCOUNT","ENTRED_DEBIT","ENTRED_CREDIT"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('uploader/print_ait_gl',$data);
				return false;
        break;  
      case 'edit':
      $this->webspice->edit_generator($TableName='TBL_AIT_GL', $KeyField='ID', $key, $RedirectController='upload_controller', $RedirectFunction='create_ait_gl', $PermissionName='create_ait_gl', $StatusCheck=null, $Log='edit_ait_gl');          
			return false;
      break;                
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_ait_gl/page/', 10 );
		}
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('uploader/manage_ait_gl', $data);
   }
   
   

	function manage_moid_daily_ro_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_moid_daily_ro_data');
		$this->webspice->permission_verify('manage_moid_daily_ro_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_VOICE_CALL_INT_OUT.DATE_TIME DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = " SELECT TBL_VOICE_CALL_INT_OUT.* FROM TBL_VOICE_CALL_INT_OUT ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_VOICE_CALL_INT_OUT', 
			$InputField = array("OPERATOR","PREPOST_FLAG","TARIFFCLASS"),
			$Keyword = array("DATE_TIME","OPERATOR","PREPOST_FLAG","TARIFFCLASS","CALLS","AIR_UNITS","CHARGED_UNITS","AMOUNT","Y_VALUE","Z_VALUE"),
			$AdditionalWhere = null,
			$DateBetween = array('DATE_TIME', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('uploader/print_voice_call_int_out',$data);
				return false;
        break;               
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_moid_daily_ro_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
		
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('uploader/manage_voice_call_int_out', $data);
	}

 	function upload_domestic_icx_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 1;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_domestic_icx_data');
		$this->webspice->permission_verify('upload_domestic_icx_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_domestic_icx_data', $data);
			return FALSE;
		}
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'uploader/upload_ait_gl');
		}
		
		$sheet_columns = array("Account", "Entered: Debit", "Entered: Credit", "Description");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_ait_gl');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$table_name = "TBL_AIT_GL";
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
      $data_list = $v;
			$Account = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$Entered_Debit = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$Entered_Credit = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$Description = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$values[] = array("ACCOUNT" => $Account, "ENTRED_DEBIT" => $Entered_Debit, "ENTRED_CREDIT" => $Entered_Credit, "DESCRIPTION" => $Description,"REPORT_DATE"=> $report_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			# must have column value - column offset started from 1
			if( !isset($Account)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
		
		}
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();		
		$is_value = false;
		if($values){
					$this->db->insert_batch($table_name, $values);
			}

		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_ait_gl'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_ait_gl', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_ait_gl');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	

 	function upload_igw_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 1;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_igw_data');
		$this->webspice->permission_verify('upload_igw_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_igw_data', $data);
			return FALSE;
		}
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'uploader/upload_igw_data');
		}
		$sheet_columns = array("ICX Name", "No.of Call", "Actual duration Mins", "Billed duration Mins","X Value BDT","Y Value BDT","Z Value BDT","Invoie Value 15% of Z","Invoice amount");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_igw_data');
			return FALSE;
		}
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$table_name = "TBL_IGW_DATA";
		$input = $this->webspice->get_input();
		$IGW = $this->input->post("IGW");
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
      $data_list = $v;
			$ICX_NAME = trim(preg_replace('/\s+/',' ', $data_list[0]));
			$ICX = $this->ft->search("name_alternative", null, $ICX_NAME);
			if(empty($ICX)){
				$data_error .= 'Operator Name "'.$ICX_NAME.'" at Row #'.($k+$header_offset).' is invalid.<br />';
				$ICX='';
			}else{
				$ICX=$ICX[0]->cName;
			}
			$NO_OF_CALLS = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$ACTUAL_DURATION_MINS = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$BILLED_DURATION_MINS = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$X_VALUE = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$Y_VALUE = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$Z_VALUE = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$INVOICE_VALUE_OF_Z = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$INVOICE_AMOUNT = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));

			$values[] = array("IGW"=>$IGW,"ICX" => $ICX, "NO_OF_CALLS" => $NO_OF_CALLS, "ACTUAL_DURATION_MINS" => $ACTUAL_DURATION_MINS, "BILLED_DURATION_MINS" => $BILLED_DURATION_MINS,"X_VALUE" => $X_VALUE, "Y_VALUE" => $Y_VALUE,"Z_VALUE" => $Z_VALUE, "INVOICE_VALUE_OF_Z" => $INVOICE_VALUE_OF_Z,"INVOICE_AMOUNT"=>$INVOICE_AMOUNT,"REPORT_DATE"=> $report_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			# must have column value - column offset started from 1
			#if( !isset($Account)){
			#	$data_error .= 'Row #'.$k.' is incomplete.<br />';
			#}
		
		}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_igw_data', $data);
			return FALSE;
		}
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date,'IGW' => $IGW), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_igw_data');
				return false;
		}
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();		
		$is_value = false;
		if($values){
					$this->db->insert_batch($table_name, $values);
			}
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_igw_data'); # log
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_igw_data', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_igw_data');
		}
		$this->webspice->force_redirect($url_prefix);
	}
	
 	function upload_icx_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 1;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_icx_data');
		$this->webspice->permission_verify('upload_icx_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('uploader/upload_icx_data', $data);
			return FALSE;
		}
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'uploader/upload_icx_data');
		}
		$sheet_columns = array("IGW Name", "No.of Call", "Actual duration Mins", "Billed duration Mins","X Value BDT","Y Value BDT","Z Value BDT","Invoie Value 15% of Z","Invoice amount");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_icx_data');
			return FALSE;
		}
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$table_name = "TBL_ICX_DATA";
		$input = $this->webspice->get_input();
		$ICX = $this->input->post("ICX");
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
      $data_list = $v;
      $IGW_NAME = trim(preg_replace('/\s+/',' ', $data_list[0])); 
			$IGW = $this->ft->search("name_alternative", null, $IGW_NAME);
			if(empty($IGW)){
				$data_error .= 'Operator Name "'.$IGW_NAME.'" at Row #'.$k.' is invalid.<br />';
				$IGW='';
			}else{
				$IGW=$IGW[0]->cName;
			}
			$NO_OF_CALLS = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			$ACTUAL_DURATION_MINS = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$BILLED_DURATION_MINS = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$X_VALUE = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$Y_VALUE = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$Z_VALUE = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$INVOICE_VALUE_OF_Z = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[7]));
			$INVOICE_AMOUNT_FOR_ICX = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[8]));

			$values[] = array("IGW"=>$IGW,"ICX" => $ICX, "NO_OF_CALLS" => $NO_OF_CALLS, "ACTUAL_DURATION_MINS" => $ACTUAL_DURATION_MINS, "BILLED_DURATION_MINS" => $BILLED_DURATION_MINS,"X_VALUE" => $X_VALUE, "Y_VALUE" => $Y_VALUE,"Z_VALUE" => $Z_VALUE, "INVOICE_VALUE_OF_Z" => $INVOICE_VALUE_OF_Z,"INVOICE_AMOUNT"=>$INVOICE_AMOUNT_FOR_ICX,"REPORT_DATE"=> $report_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			# must have column value - column offset started from 1
			#if( (!isset($Z_VALUE)) && (!isset($INVOICE_VALUE_OF_Z))){
			#	$data_error .= 'Row #'.$k.' is incomplete.<br />';
			#}
		
		}
		if($data_error){
			$data['error'] = $data_error.'<span class="fred fbold">Please update the file and try again.</span>';
			$this->load->view('uploader/upload_icx_data', $data);
			return FALSE;
		}
		$existing_data = $this->db->get_where($table_name, array('REPORT_DATE' => $report_date,'ICX' => $ICX), $limit=1)->result();
		if($existing_data){
				$this->webspice->message_board('Duplicate data found for this date range!');
				$this->webspice->force_redirect($url_prefix.'upload_icx_data');
				return false;
		}
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();		
		$is_value = false;
		if($values){
					$this->db->insert_batch($table_name, $values);
			}
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_icx_data'); # log
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_icx_data', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_icx_data');
		}
		$this->webspice->force_redirect($url_prefix);
	}
	












	function igw_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'igw_report');
		$this->webspice->permission_verify('igw_report');
	 // $igw_icx_sql = "SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW";
	  $sql="SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT,SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.NO_OF_CALLS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(B.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(B.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX" ;
		$order_by = "" ;

		if( !$_POST ){
			$this->load->view('report/igw_report', $data);
			return false;
		}
		$input = $this->webspice->get_input();
    $data['IGW'] = $input->IGW;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = " WHERE A.IGW='".$data['IGW']."'";
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Report";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    //dd($data["get_record"]);
    if(empty($data["get_record"]) && empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/igw_report', $data);
			return false;
    	}
		$this->load->view('report/print_igw_report', $data);
	}	
	function icx_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'icx_report');
		$this->webspice->permission_verify('icx_report');
	 // $igw_icx_sql = "SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW";
	  $sql="SELECT A.IGW AS ICX_IGW, A.ICX AS ICX_ICX,A.NO_OF_CALLS AS ICX_NO_OF_CALLS,A.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,A.X_VALUE AS ICX_X_VALUE,A.Y_VALUE AS ICX_Y_VALUE,A.Z_VALUE AS ICX_Z_VALUE,A.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT,B.IGW AS IGW_IGW, B.ICX AS IGW_ICX,B.NO_OF_CALLS AS IGW_NO_OF_CALLS,B.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,B.X_VALUE AS IGW_X_VALUE,B.Y_VALUE AS IGW_Y_VALUE,B.Z_VALUE AS IGW_Z_VALUE,B.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(A.NO_OF_CALLS) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(A.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(A.X_VALUE) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(A.Y_VALUE) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(A.Z_VALUE) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(A.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_ICX_DATA AS A LEFT JOIN TBL_IGW_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW  LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX, A.IGW" ;
		$order_by = "" ;

		if( !$_POST ){
			$this->load->view('report/icx_report', $data);
			return false;
		}
		$input = $this->webspice->get_input();
    $data['ICX'] = $input->ICX;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = " WHERE A.ICX='".$data['ICX']."'";
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Report";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();  
    if(empty($data["get_record"]) && empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/icx_report', $data);
			return false;
    	}
		$this->load->view('report/print_icx_report', $data);
	}	
	
	function igw_payment_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'igw_payment_report');
		$this->webspice->permission_verify('igw_payment_report');
	 // $igw_icx_sql = "SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW";
	  $sql="SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT, SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.NO_OF_CALLS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(B.INVOICE_VALUE_OF_Z) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_INVOICE_VALUE_OF_Z,(SELECT SUM(B.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(B.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX" ;
		$order_by = "" ;

		if( !$_POST ){
			$this->load->view('report/igw_payment_report', $data);
			return false;
		}
		$input = $this->webspice->get_input();
    $data['IGW'] = $input->IGW;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = " WHERE A.IGW='".$data['IGW']."'";
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Report";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    if(empty($data["get_record"]) && empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/igw_payment_report', $data);
			return false;
    	}
   // dd($data["get_record"] ); 
		$this->load->view('report/print_igw_payment_report', $data);
	}		
	
	
	function icx_payment_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'icx_payment_report');
		$this->webspice->permission_verify('icx_payment_report');
	 // $igw_icx_sql = "SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW";
	  $sql="SELECT A.IGW AS ICX_IGW, A.ICX AS ICX_ICX,A.NO_OF_CALLS AS ICX_NO_OF_CALLS,A.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,A.X_VALUE AS ICX_X_VALUE,A.Y_VALUE AS ICX_Y_VALUE,A.Z_VALUE AS ICX_Z_VALUE,A.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT,B.IGW AS IGW_IGW, B.ICX AS IGW_ICX,B.NO_OF_CALLS AS IGW_NO_OF_CALLS,B.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,B.X_VALUE AS IGW_X_VALUE,B.Y_VALUE AS IGW_Y_VALUE,B.Z_VALUE AS IGW_Z_VALUE,B.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(A.NO_OF_CALLS) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(A.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(A.X_VALUE) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(A.Y_VALUE) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(A.Z_VALUE) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(A.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS A WHERE B.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_ICX_DATA AS A LEFT JOIN TBL_IGW_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX, A.IGW" ;
		$order_by = "" ;

		if( !$_POST ){
			$this->load->view('report/icx_payment_report', $data);
			return false;
		}
		$input = $this->webspice->get_input();
    $data['ICX'] = $input->ICX;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = " WHERE A.ICX='".$data['ICX']."'";
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Report";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();  
    if(empty($data["get_record"]) && empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/icx_payment_report', $data);
			return false;
    	}
		$this->load->view('report/print_icx_payment_report', $data);
	}	
	
	function igw_summery_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'igw_summery_data');
		$this->webspice->permission_verify('igw_summery_data');

		if( !$_POST ){
			$this->load->view('report/igw_summery_data', $data);
			return false;
		}
		$input = $this->webspice->get_input();
	  $data['excluded_igw']= $input->EXCLUDED_IGW;
		$calculative_month = $input->CALCULATIVE_MONTH;
	  $igw_sql = "SELECT A.IGW,SUM(A.INVOICE_AMOUNT) AS TOTAL_IGW_INVOICE_AMOUNT,B.IGW,SUM(B.INVOICE_AMOUNT) AS TOTAL_ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.IGW=B.IGW AND A.ICX=B.ICX";
    $bl_sql = "SELECT B.IGW,B.ICX,B.X_VALUE,B.Y_VALUE,B.Z_VALUE,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_Z_VALUE,(SELECT SUM(C.Z_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_Z_VALUE,(SELECT SUM(C.X_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_X_VALUE,(SELECT SUM(C.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_Y_VALUE FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON B.ICX = C.OPERATOR_NAME AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month)."";
    $igw_group_by = " GROUP BY A.IGW" ;
		$igw_order_by = "" ;
		$bl_group_by="";
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		//$data['filter_by'] .= "Prepaid, Postpaid ";
		if(isset($calculative_month)){
			 $igw_sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month);
			

		}		
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Report";
		$igw_sql=$igw_sql.$igw_group_by;
		$bl_sql=$bl_sql.$bl_group_by;
    $data["get_igw_record"] = $this->db->query($igw_sql)->result();
    $data["get_bl_record"] = $this->db->query($bl_sql)->result();
    if(empty($data["get_igw_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/igw_summery_data', $data);
			return false;
    	}
		$this->load->view('report/print_igw_summery_data', $data);
	}	

	function short_summery($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'short_summery');
		$this->webspice->permission_verify('short_summery');
	 // $igw_icx_sql = "SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW";
	  $sql="SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT,SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.NO_OF_CALLS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(B.INVOICE_VALUE_OF_Z) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_INVOICE_VALUE_OF_Z,(SELECT SUM(B.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(B.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX" ;
		$order_by = "" ;

		if( !$_POST ){
			$this->load->view('report/short_summery_report', $data);
			return false;
		}
		$input = $this->webspice->get_input();
    $data['IGW'] = $input->IGW;
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = " WHERE A.IGW='".$data['IGW']."'";
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Report";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    if(empty($data["get_record"]) && empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/short_summery_report', $data);
			return false;
    	}
		$this->load->view('report/print_short_summery_report', $data);
	}	
		
	function bl_vs_ios_reconciliation($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'bl_vs_ios_reconciliation');
		$this->webspice->permission_verify('bl_vs_ios_reconciliation');
	  $sql="SELECT A.ICX,SUM(A.X_VALUE) AS IGW_X_VALUE,SUM(A.Y_VALUE) AS IGW_Y_VALUE,SUM(A.Z_VALUE) AS IGW_Z_VALUE,SUM(A.BILLED_DURATION_MINS) AS IGW_BILLED_DURATION_MIN,(SELECT SUM(B.CHARGED_UNIT_IN_MIN) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.X_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Z_VALUE,(SELECT SUM(B.ICX_PORTION) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_PERCENTAGE_OF_Z,(SELECT SUM(B.IGW_PORTION) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_IGW_PORTION_FOR_INVOICE,(SELECT SUM(B.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Y_VALUE_FOR_INVOICE FROM TBL_IGW_DATA AS A LEFT JOIN TBL_FULL_MONTH_MOID AS B ON A.ICX=B.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX " ;
		$order_by = "" ;
		$igw_sql="SELECT IGW,SUM(X_VALUE) AS TOTAL_IGW_X_VALUE,SUM(Y_VALUE) AS TOTAL_IGW_Y_VALUE,SUM(Z_VALUE) AS TOTAL_IGW_Z_VALUE,SUM(INVOICE_VALUE_OF_Z) AS TOTAL_INVOICE_VALUE_OF_Z,SUM(INVOICE_AMOUNT) AS TOTAL_INVOICE_AMOUNT,SUM(BILLED_DURATION_MINS) AS TOTAL_BILLED_DURATION_MINS FROM TBL_IGW_DATA";
    $igw_group_by =" GROUP BY IGW";
		if( !$_POST ){
			$this->load->view('report/bl_vs_ios_reconciliation', $data);
			return false;
		}
		$input = $this->webspice->get_input();
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Prepaid, Postpaid ";
		if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = "";
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
			 $igw_where=" WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="BL_vs_IOS_reconciliation Report";
		$sql = $sql.$where.$group_by.$order_by;
		$igw_sql = $igw_sql.$igw_where.$igw_group_by;
    $data["get_record"] = $this->db->query($sql)->result();  
    $data["igw_get_record"] = $this->db->query($igw_sql)->result();
    if(empty($data["get_record"]) && empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/bl_vs_ios_reconciliation', $data);
			return false;
    	}
		$this->load->view('report/print_bl_vs_ios_reconciliation', $data);
	}
	
	
	
	
	
	function ios_reconciliation_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'ios_reconciliation_report');
		$this->webspice->permission_verify('ios_reconciliation_report');
		if( !$_POST ){
			$this->load->view('report/ios_reconciliation_report', $data);
			return false;
		}
		$input = $this->webspice->get_input();
		$calculative_month = $input->CALCULATIVE_MONTH;
	  if(array_key_exists("ios_summery",$input)){
	  	$data['ios_summery']="yes";
	    $data['excluded_igw']= $input->EXCLUDED_IGW;
	    $igw_sql = "SELECT A.IGW,SUM(A.INVOICE_AMOUNT) AS TOTAL_IGW_INVOICE_AMOUNT,B.IGW,SUM(B.INVOICE_AMOUNT) AS TOTAL_ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.IGW=B.IGW AND A.ICX=B.ICX";
      $bl_sql = "SELECT B.IGW,B.ICX,B.X_VALUE,B.Y_VALUE,B.Z_VALUE,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_Z_VALUE,(SELECT SUM(C.Z_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_Z_VALUE,(SELECT SUM(C.X_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_X_VALUE,(SELECT SUM(C.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_Y_VALUE FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON B.ICX = C.OPERATOR_NAME AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month)."";
      $igw_group_by = " GROUP BY A.IGW" ;
		  $igw_order_by = "" ;
		  $bl_group_by="";
		if(isset($calculative_month)){
			 $igw_sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month);
		}		
		$igw_sql=$igw_sql.$igw_group_by;
		$bl_sql=$bl_sql.$bl_group_by;
    $data["get_igw_record_for_ios_summery_report"] = $this->db->query($igw_sql)->result();
    $data["get_bl_record_for_ios_summery_report"] = $this->db->query($bl_sql)->result();
	  }else{
	  	$data['ios_summery']="no";	
	  }
	  if(array_key_exists("bl_vs_ios_reconcilation",$input)){
	  $data['bl_vs_ios_reconcilation']='yes';
	  $sql="SELECT A.ICX,SUM(A.X_VALUE) AS IGW_X_VALUE,SUM(A.Y_VALUE) AS IGW_Y_VALUE,SUM(A.Z_VALUE) AS IGW_Z_VALUE,SUM(A.BILLED_DURATION_MINS) AS IGW_BILLED_DURATION_MIN,(SELECT SUM(B.CHARGED_UNIT_IN_MIN) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.X_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Z_VALUE,(SELECT SUM(B.ICX_PORTION) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_PERCENTAGE_OF_Z,(SELECT SUM(B.IGW_PORTION) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_IGW_PORTION_FOR_INVOICE,(SELECT SUM(B.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Y_VALUE_FOR_INVOICE FROM TBL_IGW_DATA AS A LEFT JOIN TBL_FULL_MONTH_MOID AS B ON A.ICX=B.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX " ;
		$order_by = "" ;
		$igw_sql="SELECT IGW,SUM(X_VALUE) AS TOTAL_IGW_X_VALUE,SUM(Y_VALUE) AS TOTAL_IGW_Y_VALUE,SUM(Z_VALUE) AS TOTAL_IGW_Z_VALUE,SUM(INVOICE_VALUE_OF_Z) AS TOTAL_INVOICE_VALUE_OF_Z,SUM(INVOICE_AMOUNT) AS TOTAL_INVOICE_AMOUNT,SUM(BILLED_DURATION_MINS) AS TOTAL_BILLED_DURATION_MINS FROM TBL_IGW_DATA";
    $igw_group_by =" GROUP BY IGW";
    if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = "";
			 $igw_where=" WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		}
		$sql = $sql.$where.$group_by.$order_by;
		$igw_sql = $igw_sql.$igw_where.$igw_group_by;
    $data["get_record_for_bl_vs_ios_report"] = $this->db->query($sql)->result();  
    $data["igw_get_record_for_bl_vs_ios_report"] = $this->db->query($igw_sql)->result();
	  }else{$data['bl_vs_ios_reconcilation']='no';}
	  if(array_key_exists("single_ios_sort_summery",$input)){
	  	$data['single_ios_sort_summery']='yes';
	  	$data['igw']= $input->IOS;
	  	$sql="SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT,SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.NO_OF_CALLS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(B.INVOICE_VALUE_OF_Z) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_INVOICE_VALUE_OF_Z,(SELECT SUM(B.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(B.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	    $group_by = " GROUP BY A.ICX" ;
		  $order_by = "" ;
		  if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = " WHERE A.IGW='".$data['igw']."'";
		  }
		  $sql = $sql.$where.$group_by.$order_by;
      $data["get_record_for_single_ios_short_summery"] = $this->db->query($sql)->result(); 
	  }else{$data['single_ios_sort_summery']='no';}
	  if(array_key_exists("single_ios_detail_summery",$input)){
	  	$data['single_ios_detail_summery']='yes';
	  	$sql="SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT, SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.NO_OF_CALLS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(B.INVOICE_VALUE_OF_Z) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_INVOICE_VALUE_OF_Z,(SELECT SUM(B.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(B.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	    $group_by = " GROUP BY A.ICX" ;
		  $order_by = "" ;
	  	if(isset($calculative_month)){
			 $sql.=" AND YEAR(A.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(A.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(B.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(B.REPORT_DATE) = ".date("m",$calculative_month)." AND YEAR(C.REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(C.REPORT_DATE) = ".date("m",$calculative_month);
			 $where = " WHERE A.IGW='".$data['igw']."'";
		  }
	  	$sql = $sql.$where.$group_by.$order_by;
      $data["get_record_for_single_ios_detail_summery"] = $this->db->query($sql)->result();
	  }else{$data['single_ios_detail_summery']='no';}
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
  	$data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
		$data['current_date']=date("d-M-Y");
		$data['report_name']="IOS Reconcilation Report";
		if( $this->input->post('email')){
  		$email_sql="SELECT EMAIL_ADDRESS FROM TBL_OPERATOR WHERE OPERATOR_NAME='".$data['igw']."'";
  	  $email_address=$this->db->query($email_sql)->row();
  	  $data['action_type']='Email';
  	  $html = $this->load->view('report/print_ios_reconcilation_report', $data, true);
  	  $this->webspice->create_file($html, $this->webspice->get_path('custom_full').'/ios_recouncilation.xls');     
  	  $this->webspice->email('iubat.sathy@gmail.com', 'IOS Reconcilation', 'aaaaaa', null, null, $this->webspice->get_path('custom_full').'/ios_recouncilation.xls');	
  	 // $this->webspice->message_board('Record has been sent to IOS!');
  	  $data['action_type']='view';
  	}
   # if(empty($data["get_record"]) && empty($data["get_record"])){
    #	$this->webspice->message_board('Record is not found!');
    #	$this->load->view('report/bl_vs_ios_reconciliation', $data);
		#	return false;
    #	}
		$this->load->view('report/print_ios_reconcilation_report', $data);   
	}
	

 
 
 	function report_full_month_momms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_momms');
		$this->webspice->permission_verify('report_full_month_momms');
		$orderby = ' ORDER BY TBL_FULL_MONTH_MOMMS.REPORT_DATE DESC';
    $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_momms');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->calculative_month;
		$sql = " SELECT TBL_FULL_MONTH_MOMMS.* FROM TBL_FULL_MONTH_MOMMS WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		$record = $this->db->query($sql)->result();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_momms');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_momms', $data);
	}
	
  function report_full_month_mosms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_mosms');
		$this->webspice->permission_verify('report_full_month_mosms');
		$orderby = ' ORDER BY TBL_FULL_MONTH_MOSMS.REPORT_DATE DESC';
    $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_mosms');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->calculative_month;
		$sql = " SELECT TBL_FULL_MONTH_MOSMS.* FROM TBL_FULL_MONTH_MOSMS WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		$record = $this->db->query($sql)->result();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_mosms');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_mosms', $data);
	}
	
  function report_full_month_moid(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_moid');
		$this->webspice->permission_verify('report_full_month_moid');
		$orderby = ' ORDER BY TBL_FULL_MONTH_MOID.REPORT_DATE DESC';
    $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_moid');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->calculative_month;
		$sql = " SELECT TBL_FULL_MONTH_MOID.* FROM TBL_FULL_MONTH_MOID WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		$record = $this->db->query($sql)->result();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_moid');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_moid', $data);
	}
  function report_full_month_itfs(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_itfs');
		$this->webspice->permission_verify('report_full_month_itfs');
		$orderby = ' ORDER BY TBL_FULL_MONTH_ITFS.REPORT_DATE DESC';
    $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_itfs');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->calculative_month;
		$sql = " SELECT TBL_FULL_MONTH_ITFS.* FROM TBL_FULL_MONTH_ITFS WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		$record = $this->db->query($sql)->result();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_itfs');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_itfs', $data);
	}
	
  function report_full_month_mtid(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_mtid');
		$this->webspice->permission_verify('report_full_month_mtid');
		$orderby = ' ORDER BY TBL_FULL_MONTH_MTID.REPORT_DATE DESC';
    $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_mtid');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->calculative_month;
		$sql = " SELECT TBL_FULL_MONTH_MTID.* FROM TBL_FULL_MONTH_MTID WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)." GROUP BY IOS,PRE_POST";
		$record = $this->db->query($sql)->result();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_mtid');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_mtid', $data);
	}
	
  function report_full_month_ltfs(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_ltfs');
		$this->webspice->permission_verify('report_full_month_ltfs');
		$orderby = ' ORDER BY TBL_FULL_MONTH_LTFS.REPORT_DATE DESC';
    $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_ltfs');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->calculative_month;
		$sql = " SELECT TBL_FULL_MONTH_LTFS.* FROM TBL_FULL_MONTH_LTFS WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		$record = $this->db->query($sql)->result();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_ltfs');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_ltfs', $data);
	}
	
  function report_full_month_mtsms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_mtsms');
		$this->webspice->permission_verify('report_full_month_mtsms');
		$orderby = ' ORDER BY TBL_FULL_MONTH_MTSMS.REPORT_DATE DESC';
        $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_mtsms');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->CALCULATIVE_MONTH;
		//$sql = " SELECT TBL_FULL_MONTH_MTSMS.* FROM TBL_FULL_MONTH_MTSMS WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		$sql="SELECT OPERATOR_NAME,PRE_POST,RATE_PER_MIN, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT END ) AS POST_AMOUNT_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT END ) AS PREP_AMOUNT_VALUE,	
              SUM( CASE WHEN PRE_POST = 'POST' THEN NO_OF_CALLS END ) AS POST_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN NO_OF_CALLS END ) AS PREP_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN DURATION END ) AS POST_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN DURATION END ) AS PREP_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN VAT_VALUE END ) AS POST_VAT_VALUE_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN VAT_VALUE END ) AS PREP_VAT_VALUE_VALUE,
			  SUM( CASE WHEN PRE_POST = 'POST' THEN TOTAL END ) AS POST_TOTAL, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN TOTAL END ) AS PREP_TOTAL	
              FROM TBL_FULL_MONTH_MTSMS WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
              GROUP BY OPERATOR_NAME, PRE_POST
              ORDER BY OPERATOR_NAME, PRE_POST";
		
		
		$record = $this->db->query($sql)->result();
		if( !$record ){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_mtsms');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_mtsms', $data);
	}
	
	
	
  function report_full_month_operator_wise_moc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_operator_wise_moc');
		$this->webspice->permission_verify('report_full_month_operator_wise_moc');
		$orderby = ' ORDER BY TBL_OP_MOC.REPORT_DATE DESC';
        $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_operator_wise_moc');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->CALCULATIVE_MONTH;
		$sql="SELECT OPERATOR_NAME,PRE_POST,RATE_PER_MIN, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT END ) AS POST_AMOUNT_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT END ) AS PREP_AMOUNT_VALUE,	
              SUM( CASE WHEN PRE_POST = 'POST' THEN NO_OF_CALLS END ) AS POST_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN NO_OF_CALLS END ) AS PREP_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN DURATION_IN_MIN END ) AS POST_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN DURATION_IN_MIN END ) AS PREP_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN VAT_VALUE END ) AS POST_VAT_VALUE_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN VAT_VALUE END ) AS PREP_VAT_VALUE_VALUE,
			  SUM( CASE WHEN PRE_POST = 'POST' THEN TOTAL END ) AS POST_TOTAL, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN TOTAL END ) AS PREP_TOTAL	
              FROM TBL_OP_MOC WHERE OPERATOR_NAME!='OTHERS' AND OPERATOR_NAME!='Others' AND OPERATOR_NAME!='others' AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
              GROUP BY OPERATOR_NAME, PRE_POST";  
			  
		
			  
		$record = $this->db->query($sql)->result();
		if(empty($record )){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_operator_wise_moc');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_operator_wise_moc', $data);
	}
	
	
	
	
  function report_full_month_operator_wise_mtc(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_operator_wise_mtc');
		$this->webspice->permission_verify('report_full_month_operator_wise_mtc');
		$orderby = ' ORDER BY TBL_OP_MTC.REPORT_DATE DESC';
        $groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_operator_wise_mtc');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->CALCULATIVE_MONTH;
		//$sql = " SELECT TBL_OP_MOC.* FROM TBL_OP_MOC WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
		$sql="SELECT OPERATOR_NAME,PRE_POST,RATE_PER_MIN, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT END ) AS POST_AMOUNT_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT END ) AS PREP_AMOUNT_VALUE,	
              SUM( CASE WHEN PRE_POST = 'POST' THEN NO_OF_CALLS END ) AS POST_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN NO_OF_CALLS END ) AS PREP_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN DURATION_IN_MIN END ) AS POST_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN DURATION_IN_MIN END ) AS PREP_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN VAT_VALUE END ) AS POST_VAT_VALUE_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN VAT_VALUE END ) AS PREP_VAT_VALUE_VALUE,
			  SUM( CASE WHEN PRE_POST = 'POST' THEN TOTAL END ) AS POST_TOTAL, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN TOTAL END ) AS PREP_TOTAL	
              FROM TBL_OP_MTC WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
              GROUP BY OPERATOR_NAME, PRE_POST
              ORDER BY OPERATOR_NAME, PRE_POST";
		$record = $this->db->query($sql)->result();
		if(empty($record )){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_operator_wise_mtc');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_operator_wise_mtc', $data);
	}
	
	function report_full_month_mtmms(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'report_full_month_mtmms');
		$this->webspice->permission_verify('report_full_month_mtmms');
		//$orderby = ' ORDER BY TBL_OP_MTC.REPORT_DATE DESC';
        //$groupby = null;
		if( !$_POST ){
			$this->load->view('report/report_full_month_mtmms');
			return false;
		}

		# get post
		$input = $this->webspice->get_input();
		$calculative_month = $input->CALCULATIVE_MONTH;
		$sql="SELECT OPERATOR_NAME,PRE_POST,RATE_PER_MIN, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT END ) AS POST_AMOUNT_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT END ) AS PREP_AMOUNT_VALUE,	
              SUM( CASE WHEN PRE_POST = 'POST' THEN NO_OF_CALLS END ) AS POST_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN NO_OF_CALLS END ) AS PREP_NO_OF_CALLS_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN DURATION END ) AS POST_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN DURATION END ) AS PREP_DURATION_IN_MIN_VALUE, 
              SUM( CASE WHEN PRE_POST = 'POST' THEN VAT_VALUE END ) AS POST_VAT_VALUE_VALUE, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN VAT_VALUE END ) AS PREP_VAT_VALUE_VALUE,
			  SUM( CASE WHEN PRE_POST = 'POST' THEN TOTAL END ) AS POST_TOTAL, 
              SUM( CASE WHEN PRE_POST = 'PREP' THEN TOTAL END ) AS PREP_TOTAL	
              FROM TBL_FULL_MONTH_MTMMS WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
              GROUP BY OPERATOR_NAME, PRE_POST
              ORDER BY OPERATOR_NAME, PRE_POST";
		$record = $this->db->query($sql)->result();
		if(empty($record )){
			$this->webspice->message_board('There is no data according to your given month!');
			$this->webspice->force_redirect($url_prefix.'report_full_month_mtmms');
			return false;
		}
		$data['get_record'] = $record;
		$data['action_type'] = 'view';
		if( $this->input->post('print') ){
			// dd(3);
			$data['action_type'] = 'print';
		}elseif( $this->input->post('export') ){
			$data['action_type'] = 'csv';
		} 
		$this->load->view('report/print_report_full_month_mtmms', $data);
	}
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
