<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Master_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	
	function ajax_edit(){
		$data=null;
		if( $this->input->post('call_type') == 'edit' ){
			$key = $this->webspice->encrypt_decrypt(1,'encrypt');
			$data = $this->webspice->edit_generator($TableName='TBL_USER', $KeyField='USER_ID', $key, $RedirectController='master_controller', $RedirectFunction='ajax_edit', $PermissionName='manage_user', $StatusCheck=null, $Log='edit_user');
		}

		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_user');
		$this->webspice->permission_verify('create_user');
		
		$this->webspice->display_error();
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'USER_ID'=>null,
			'EMPLOYEE_ID'=>null,
			'USER_NAME'=>null,  
			'DESIGNATION'=>null,
			'DEPARTMENT_DIVISION'=>null,
			'USER_EMAIL'=>null,
			'USER_PHONE'=>null
			);
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('register_name','register name','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('employee_id','employee name','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('employee_designation','employee designation','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('employee_department','employee department','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('register_email','register email','required|valid_email|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('register_phone','register phone','required|trim|xss_clean|max_length[50]');
		
		if( !$this->form_validation->run() ){ 
			$form = $this->load->view('master/create_user', $data, true);
			exit($form);
		}
		
		exit('inserted');
	}
	
	
	
	function create_user($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_user');
		$this->webspice->permission_verify('create_user');
		
		$this->webspice->display_error();
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'USER_ID'=>null,
			'EMPLOYEE_ID'=>null,
			'USER_NAME'=>null,  
			'DESIGNATION'=>null,
			'DEPARTMENT_DIVISION'=>null,
			'USER_EMAIL'=>null,
			'USER_PHONE'=>null
			);
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('register_name','register name','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('employee_id','employee name','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('employee_designation','employee designation','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('employee_department','employee department','required|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('register_email','register email','required|valid_email|trim|xss_clean|max_length[50]');
		$this->form_validation->set_rules('register_phone','register phone','required|trim|xss_clean|max_length[50]');
		
		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_user', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('user_id');
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_USER WHERE USER_EMAIL=?", array( $input->register_email), 'You are not allowed to enter duplicate email', 'USER_ID', $input->user_id, $data, 'master/create_user');
		
		# remove cache
		$this->webspice->remove_cache('user');
		
		# update process
		if( $input->user_id ){
			#update query
			$sql = "
			UPDATE TBL_USER SET EMPLOYEE_ID=?, USER_NAME=?, DESIGNATION=?, DEPARTMENT_DIVISION=?, USER_EMAIL=?, USER_PHONE=?, ROLE_ID=?, UPDATED_BY=?, UPDATED_DATE=? 
			WHERE USER_ID=?";
			$this->db->query($sql, array($input->employee_id, $input->register_name, $input->employee_designation, $input->employee_department, $input->register_email, $input->register_phone, $input->user_role, $this->webspice->get_user_id(), $this->webspice->now(), $input->user_id)); 

			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('user_updated - '.$input->register_email); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_user');
			return false;
		}
		
		#create user
		$random_password = '1234';//rand(1,5);
		$sql = "
		INSERT INTO TBL_USER
		(EMPLOYEE_ID, USER_NAME, DESIGNATION, DEPARTMENT_DIVISION, USER_EMAIL, USER_PHONE, USER_PASSWORD, ROLE_ID, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 7)";
		$this->db->query($sql, array($input->employee_id, $input->register_name, $input->employee_designation, $input->employee_department, 
		$input->register_email, $input->register_phone, 
		$this->webspice->encrypt_decrypt($random_password, 'encrypt'), $input->user_role, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		# send verification email
		#$this->load->library('email_template');
		#$this->email_template->send_new_user_password_change_email($input->register_name, $input->register_email);
		
		$this->webspice->message_board('An account has been created and sent an email to the user.');
		$this->webspice->force_redirect($url_prefix);
		 
	}
	function manage_user(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_user');
		$this->webspice->permission_verify('manage_user');

    $orderby = ' ORDER BY TBL_USER.USER_ID DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 1;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = "
		SELECT TBL_USER.*,
		TBL_ROLE.ROLE_NAME
		FROM TBL_USER
		LEFT JOIN TBL_ROLE ON TBL_ROLE.ROLE_ID = TBL_USER.ROLE_ID";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_USER', 
			$InputField = array(), 
			$Keyword = array('USER_ID','USER_NAME','USER_EMAIL','USER_PHONE'),
			$AdditionalWhere = null,
			$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('report/print_user',$data);
				return false;
        break;

			case 'edit':
          $this->webspice->edit_generator($TableName='TBL_USER', $KeyField='USER_ID', $key, $RedirectController='master_controller', $RedirectFunction='create_user', $PermissionName='manage_user', $StatusCheck=null, $Log='edit_user');          
					return false;
          break;
          
 			case 'inactive':
      		$this->webspice->action_executer($TableName='TBL_USER', $KeyField='USER_ID', $key, $RedirectURL='manage_user', $PermissionName='manage_user', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='user', $Log='inactive_user');
					return false;	
          break; 

			case 'active':
					$this->webspice->action_executer($TableName='TBL_USER', $KeyField='USER_ID', $key, $RedirectURL='manage_user', $PermissionName='manage_user', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='user', $Log='active_user');
					return false;	
			    break;   
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_user/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
    
    
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;

		$this->load->view('master/manage_user', $data);
	}
	
	function create_role($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_user');
		$this->webspice->permission_verify('create_role,manage_role');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'ROLE_ID'=>null,
			'ROLE_NAME'=>null,  
			'PERMISSION_NAME'=>null
			);
		}
		
		# get permission name
		$sql = "
		SELECT TBL_PERMISSION.* 
		FROM TBL_PERMISSION
		WHERE TBL_PERMISSION.STATUS = 1
		GROUP BY TBL_PERMISSION.GROUP_NAME,TBL_PERMISSION.PERMISSION_NAME
		ORDER BY TBL_PERMISSION.GROUP_NAME
		";
		$data['get_permission'] = $this->db->query($sql);
		$result_set = $this->db->query($sql);
		$data['get_permission_data'] = $result_set->result();		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('role_name','role_name','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_role', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('ROLE_ID');

		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_ROLE WHERE ROLE_NAME=?", array( $input->role_name), 'You are not allowed to enter duplicate role name.', 'ROLE_ID', $input->ROLE_ID, $data, 'master/create_role');
		
		# remove cache
		$this->webspice->remove_cache('role');
		
		# update data
		if( $input->ROLE_ID ){
			#update query
			$sql = "
			UPDATE TBL_ROLE SET ROLE_NAME=?, PERMISSION_NAME=?, UPDATED_BY=?, UPDATED_DATE=? 
			WHERE ROLE_ID=?";
			$this->db->query($sql, array($input->role_name, implode(',',$input->permission), $this->webspice->get_user_id(), $this->webspice->now(), $input->ROLE_ID)); 

			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('role_updated - '.$input->role_name); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_role');
			return false;
		}
		
		# insert data
		$sql = "
		INSERT INTO TBL_ROLE
		(ROLE_NAME, PERMISSION_NAME, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, 7)";
		$this->db->query($sql, array($input->role_name, implode(',',$input->permission), $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->message_board('New Role has been created.');
		if( $this->webspice->permission_verify('manage_role', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_role');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_role(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_user');
		$this->webspice->permission_verify('manage_role');

		$this->load->database();
    $orderby = ' ORDER BY TBL_ROLE.ROLE_ID DESC';
    $groupby = null;
    $where = null;
    $page_index = 0;
    $no_of_record = 20;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = "
		SELECT TBL_ROLE.*
		FROM TBL_ROLE  ";
    
   	# filtering records
    if( $this->input->post('filter') ){
 			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_ROLE', 
			$InputField = array(),
			$Keyword = array('ROLE_ID','ROLE_NAME','PERMISSION_NAME','CREATED_DATE','UPDATED_DATE'),
			$AdditionalWhere = null,
			$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = str_replace('WHERE', 'WHERE (', $result['where']).')  AND TBL_ROLE.ROLE_NAME !="company_role"' : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;	
			
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('report/print_role',$data);
				return false;
        break;

			case 'edit':
          $this->webspice->edit_generator($TableName='TBL_ROLE', $KeyField='ROLE_ID', $key, $RedirectController='master_controller', $RedirectFunction='create_role', $PermissionName='create_role', $StatusCheck=null, $Log='edit_role');          
					return false;
          break; 
          
 			case 'inactive':
      		$this->webspice->action_executer($TableName='TBL_ROLE', $KeyField='ROLE_ID', $key, $RedirectURL='manage_role', $PermissionName='manage_role', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='role', $Log='inactive_role');
					return false;	
          break; 

			case 'active':
					$this->webspice->action_executer($TableName='TBL_ROLE', $KeyField='ROLE_ID', $key, $RedirectURL='manage_role', $PermissionName='manage_role', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='role', $Log='active_role');
					return false;	
			    break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;	
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
    
		# load all records for pager
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_role/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;

		$this->load->view('master/manage_role', $data);
	}
	
	#update configuration data
	function update_configuration_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'update_configuration_data');
		$this->webspice->permission_verify('update_configuration_data');
		$data['get_record'] = $this->ft->get($parent='config');
		#for ajax calling
		if( $this->input->post('ajax_call') ){
			$result = $this->ft->search($parent='config',$attribute=$this->input->post('attribute'));
			echo json_encode($result);
			return false;
		}	
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'attribute'=>null,
			'value'=>null,
			'key' => null
			);
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('attribute','attribute','required|trim|xss_clean');
		$this->form_validation->set_rules('value','value','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/update_configuration_data', $data);
			return FALSE;
		}
		#update
		$this->ft->set('config',$this->input->post('key'),$this->input->post('attribute'),$this->input->post('value'));
		$this->webspice->message_board("Record has been updated successfully!");
		$this->webspice->force_redirect($url_prefix.'view_configuration_data');
		return false;
	}
	
	#load all confihuration data
	function view_configuration_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'view_configuration_data');
		$this->webspice->permission_verify('view_configuration_data');
		$criteria = $this->uri->segment(2);
		if( $criteria == 'edit' ){
			$key = $this->uri->segment(3);
			$attribute = $this->webspice->encrypt_decrypt($this->uri->segment(4),'decrypt');
			$data_set = $this->ft->get('config',$key);
			$value = $data_set->{'0'}->$attribute;
			$data['edit'] = array(
											'attribute'=> $attribute,
											'value'=> $value,
											'key'=> $key
											);
			$data['get_record'] = $this->ft->get($parent='config');								
			$this->load->library('form_validation');								
			$this->load->view('master/update_configuration_data', $data);
			return FALSE;								
				
		}
		$filter_by = 'All Data';
		$data['filter_by'] = $filter_by;
		$data['get_record'] = $this->ft->get($parent='config');
		$this->load->view('master/view_configuration_data',$data);
		return false;
	}
	
	function create_name_alternative($data=null){
		#dd ($this->ft->get('customer'));
		#$cName = 'cName';
		#dd($val->{'0'}->$cName);
		#dd($this->ft->del('name_alternative',5,'cName'));
		#dd($this->ft->set('config',0,'MB_rate',0.401));
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_name_alternative');
		$this->webspice->permission_verify('create_name_alternative');
		
		#load all record
		$data['get_record'] = $this->ft->get($parent='name_alternative');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'attribute'=> null,
			'value'=> null,
			'key' => null,
			'core' => null
			);
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('value','value','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_name_alternative', $data);
			return FALSE;
		}

		if( $this->input->post('type') == 'core' ){
			$key =  ( $this->input->post('original_key') != '') ? $this->input->post('original_key') : $this->ft->iid('name_alternative')+1;
			$this->ft->set('name_alternative',$key,'cName',$this->input->post('value'));
		}
		
		if( $this->input->post('type') == 'alias' ){
			$key = $this->input->post('key');
			$attribute = ( $this->input->post('attribute') ) ? $this->input->post('attribute') : date('Y_m_d_i_h_s_a');
			$this->ft->set('name_alternative',$key,$attribute,$this->input->post('value'));
		}
		
		$this->webspice->message_board("Executed successfully!");
		$this->webspice->force_redirect($url_prefix.'create_name_alternative');
		return false;
	}

	function manage_name_alternative(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_name_alternative');
		$this->webspice->permission_verify('manage_name_alternative');
		
		$criteria = $this->uri->segment(2);
		$data['get_record'] = $this->ft->get('name_alternative');
		if( $criteria == 'edit' ){
			$key = $this->uri->segment(3);
			$core = 'cName'; # core name
			$attribute = $this->webspice->encrypt_decrypt($this->uri->segment(4),'decrypt');
			$data_set = $this->ft->get('name_alternative');
			$value = $data_set->{$key}->$attribute;
			$customer = $data_set->{$key}->$core;
			$data['edit'] = array(
											'attribute'=> $attribute,
											'value'=> $value,
											'key'=> $key,
											'core' => $customer
											);
						
			$this->load->library('form_validation');								
			$this->load->view('master/create_name_alternative', $data);
			return FALSE;
		}
		$this->load->view('master/manage_name_alternative',$data);
		return false;
	}
	
	
	
	
	# call confirmation for redirect another url with message
	function confirmation($message){
		$_SESSION['confirmation'] = $message;
		$this->webspice->force_redirect($this->webspice->settings()->site_url_prefix.'confirmation');
	}
	
	function show_confirmation(){
		if( !isset($_SESSION['confirmation']) ){
			$_SESSION['confirmation'] = array();	
		}
		$data = $_SESSION['confirmation'];
		$this->load->view('view_message',$data);
	}
	//upload
	function create_operator($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_operator');
			$this->webspice->permission_verify('create_operator,manage_operator');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATOR_NAME'=> null,
				'OPERATOR_SHORT_CODE'=> null,
				'OPERATOR_TYPE' => null,
				'PROJECT_CODE'=>null,
				'ID' => null,
				'ATTENTION'=>null,
				'ADDRESS'=>null,
				'TEL_NO'=>null,
				'VAT_REG_NO'=>NULL,
				'SUPPLIER_CODE'=>null,
				'REF_NO'=>null,
				'EMAIL_ADDRESS' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('operator_name','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('supplier_code','Supplier Code','required|trim|xss_clean');
			$this->form_validation->set_rules('operator_type','Operator Type','required|trim|xss_clean');
			$this->form_validation->set_rules('projrct_code','Project Code','required|trim|xss_clean');
			$this->form_validation->set_rules('attention','Attention','required|trim|xss_clean');
			$this->form_validation->set_rules('address','Address','required|trim|xss_clean');
			$this->form_validation->set_rules('tel_no','Tel No','required|trim|xss_clean');
			$this->form_validation->set_rules('vat_reg_no','VAT Registration No','required|trim|xss_clean');
			$this->form_validation->set_rules('email_address','Email Address','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('master/create_operator', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_OPERATOR WHERE OPERATOR_NAME=? AND OPERATOR_TYPE=? AND PROJECT_CODE=? ", array( $input->operator_name,$input->operator_type,$input->projrct_code), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_operator');
			# remove cache
			$this->webspice->remove_cache('operator');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_OPERATOR SET SUPPLIER_CODE=?,EMAIL_ADDRESS=?, OPERATOR_NAME=?, OPERATOR_SHORT_CODE=?, PROJECT_CODE=?, OPERATOR_TYPE=?, ATTENTION=?, ADDRESS=?, TEL_NO=?, VAT_REG_NO=?, REF_NO=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->supplier_code,$input->email_address,html_entity_decode($input->operator_name),$input->short_code,$input->projrct_code, $input->operator_type, $input->attention, $input->address, $input->tel_no, $input->vat_reg_no, $input->ref_no, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('operator_updated - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_operator');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_OPERATOR
			(SUPPLIER_CODE,EMAIL_ADDRESS, OPERATOR_NAME, OPERATOR_SHORT_CODE, PROJECT_CODE, OPERATOR_TYPE, ATTENTION, ADDRESS, TEL_NO, VAT_REG_NO, REF_NO, CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->supplier_code,$input->email_address,$input->operator_name, $input->short_code,$input->projrct_code, $input->operator_type, $input->attention, $input->address, $input->tel_no, $input->vat_reg_no,  $input->ref_no, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('create_operator', true) ){
				$this->webspice->force_redirect($url_prefix.'create_operator');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_operator(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_operator');
			$this->webspice->permission_verify('manage_operator');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = ' LIMIT '.$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = " SELECT TBL_OPERATOR.* FROM TBL_OPERATOR ";
	   // $initialSQL = "SELECT * FROM TBL_OPERATOR ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
					$TableName = 'TBL_OPERATOR',
					$InputField = array(),
					$Keyword = array('OPERATOR_NAME','SUPPLIER_CODE','OPERATOR_SHORT_CODE', 'OPERATOR_TYPE','PROJECT_CODE','TEL_NO'),
					$AdditionalWhere = array('BILL_MONTH'),
					$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	   	
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('master/print_operator',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_OPERATOR', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='create_operator', $PermissionName='create_operator', $StatusCheck=null, $Log='edit_operator');          
					return false;
          break;
	
	 		  case 'inactive':
	      		$this->webspice->action_executer($TableName='TBL_OPERATOR', $KeyField='ID', $key, $RedirectURL='manage_operator', $PermissionName='manage_operator', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='operator', $Log='inactive_operator');
						return false;
	          break;
	
			  case 'active':
						$this->webspice->action_executer($TableName='TBL_OPERATOR', $KeyField='ID', $key, $RedirectURL='manage_operator', $PermissionName='manage_operator', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='operator', $Log='active_operator');
						return false;
				    break;
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $limit;
			}
			
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
				#dd($this->db->last_query());
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_operator/page/', 10 );
		  }
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_operator', $data);
	}
	
	
	//GL_MAPPING
/*	function create_gl_mapping($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_gl_mapping');
			$this->webspice->permission_verify('create_gl_mapping,manage_gl_mapping');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATOR_ID'=> null,
				'GL_TYPE'=> null,
				'GL_CODE'=> null,
				'ID' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('operator_name','operator_name','required|trim|xss_clean');
			$this->form_validation->set_rules('gl_type','gl_type','required|trim|xss_clean');
			$this->form_validation->set_rules('gl_code','gl_code','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('master/create_gl_mapping', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_GL_MAPPING WHERE GL_CODE=? ", array( $input->gl_code), 'You are not allowed to enter duplicate GL Code!', 'ID', $input->ID, $data, 'master_controller/create_gl_mapping');
			# remove cache
			$this->webspice->remove_cache('gl');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_GL_MAPPING SET OPERATOR_NAME=?, GL_TYPE=?, GL_CODE=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->operator_name,$input->gl_type, $input->gl_code, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('operator_updated - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_gl_mapping');
				return false;
			}
			$new_squence = $this->webspice->getLastInserted('tbl_gl_mapping','ID');
			$sql = "
			INSERT INTO TBL_GL_MAPPING
			(ID,OPERATOR_NAME, GL_TYPE, GL_CODE,CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array(($new_squence+1),$input->operator_name, $input->gl_type, $input->gl_code,$this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('create_gl_mapping', true) ){
				$this->webspice->force_redirect($url_prefix.'create_gl_mapping');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_gl_mapping(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_gl_mapping');
			$this->webspice->permission_verify('manage_gl_mapping');
			$this->load->database();
	    $orderby = null;
	    $groupby = null;
	    $where = ' WHERE ID <= 10';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = null;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = "SELECT * FROM TBL_GL_MAPPING ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_GL_MAPPING',
				$InputField = array(),
				$Keyword = array('OPERATOR_NAME','GL_TYPE', 'GL_CODE','STATUS'),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('master/print_gl_mapping',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_GL_MAPPING', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='create_gl_mapping', $PermissionName='create_gl_mapping', $StatusCheck=null, $Log='edit_gl_mapping');          
					return false;
          break;
	
	 		  case 'inactive':
	      		$this->webspice->action_executer($TableName='TBL_GL_MAPPING', $KeyField='ID', $key, $RedirectURL='manage_gl_mapping', $PermissionName='manage_gl_mapping', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='operator_option', $Log='inactive_gl');
						return false;
	          break;
	
			  case 'active':
						$this->webspice->action_executer($TableName='TBL_GL_MAPPING', $KeyField='ID', $key, $RedirectURL='manage_gl_mapping', $PermissionName='manage_gl_mapping', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='operator_option', $Log='active_gl');
						return false;
				    break;
	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_gl_mapping/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_gl_mapping', $data);
	}
	
	*/

	
	function actual_journal_for_momms($data=null){	
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_momms');
		$this->webspice->permission_verify('actual_journal_for_momms');
		
			$sql = "SELECT OPERATOR_NAME,PRE_POST, OPERATOR_TYPE,PROJECT_CODE, 
			SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT  END  ) AS PREP_VALUE 
			FROM TBL_FULL_MONTH_MOMMS";
		//$sql = "SELECT OPERATOR_NAME,PRE_POST,AMOUNT FROM TBL_FULL_MONTH_MOMMS";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !=''" ;
		// AND LOWER(OPERATOR_NAME) !='banglalink' 
	    $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_momms', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-momms";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    //dd($this->db->last_query());
    if($data["get_record"][0]->OPERATOR_NAME==''){
    $this->webspice->message_board('Record is not found!');
    $this->load->view('report/actual_journal_for_momms', $data);
		return false;
    }
		$this->load->view('report/print_actual_journal_for_momms', $data);
	}
	
	function actual_journal_for_mosms($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_mosms');
		$this->webspice->permission_verify('actual_journal_for_mosms');
		
			$sql = "SELECT OPERATOR_NAME,PRE_POST,OPERATOR_TYPE,PROJECT_CODE,  
			SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT  END  ) AS PREP_VALUE 
			FROM TBL_FULL_MONTH_MOSMS";
		//$sql = "SELECT OPERATOR_NAME,PRE_POST,AMOUNT FROM TBL_FULL_MONTH_MOMMS";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' " ;
	  $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_mosms', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-momms";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
      if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_mosms', $data);
			return false;
    	}
		$this->load->view('report/print_actual_journal_for_mosms', $data);
	}	
	function actual_journal_for_moid($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_moid');
		$this->webspice->permission_verify('actual_journal_for_moid');
		
			$sql = "SELECT OPERATOR_NAME,PREP_POST,OPERATOR_TYPE,PROJECT_CODE,  
			SUM( CASE WHEN PREP_POST = 'POST' THEN TOTAL_COST  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PREP_POST = 'PREP' THEN TOTAL_COST  END  ) AS PREP_VALUE,
			SUM( CASE WHEN PREP_POST = 'POST' THEN BTRC_PORTION  END  ) AS POST_BTRC_PORTION, 
			SUM( CASE WHEN PREP_POST = 'PREP' THEN BTRC_PORTION  END  ) AS PREP_BTRC_PORTION,
			SUM( CASE WHEN PREP_POST = 'POST' THEN ICX_PORTION  END  ) AS POST_ICX_PORTION, 
			SUM( CASE WHEN PREP_POST = 'PREP' THEN ICX_PORTION  END  ) AS PREP_ICX_PORTION,
			SUM( CASE WHEN PREP_POST = 'POST' THEN Y_VALUE  END  ) AS POST_Y_VALUE, 
			SUM( CASE WHEN PREP_POST = 'PREP' THEN Y_VALUE  END  ) AS PREP_Y_VALUE,
			SUM( CASE WHEN PREP_POST = 'POST' THEN IGW_PORTION  END  ) AS POST_IGW_PORTION, 
			SUM( CASE WHEN PREP_POST = 'PREP' THEN IGW_PORTION  END  ) AS PREP_IGW_PORTION
			FROM TBL_FULL_MONTH_MOID";
		//$sql = "SELECT OPERATOR_NAME,PRE_POST,AMOUNT FROM TBL_FULL_MONTH_MOMMS";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' " ;
	  $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_moid', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-momms";
		$gl_sql = "SELECT * FROM TBL_COMMON_GL_MAPPING";
		$data['common_gl']=$this->db->query($gl_sql)->row();
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_moid', $data);
			return false;
    	}
		$this->load->view('report/print_actual_journal_for_moid', $data);
	}	
	
	
	function actual_journal_for_mtmms($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_mtmms');
		$this->webspice->permission_verify('actual_journal_for_mtmms');
		
			$sql = "SELECT OPERATOR_NAME,PRE_POST, OPERATOR_TYPE,PROJECT_CODE, 
			SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT  END  ) AS PREP_VALUE,
			SUM( CASE WHEN PRE_POST = 'POST' THEN VAT_VALUE  END  ) AS POST_VAT_VALUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN VAT_VALUE  END  ) AS PREP_VAT_VALUE 
			FROM TBL_FULL_MONTH_MTMMS";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' " ;
	  $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_mtmms', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-mtmms";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_mtmms', $data);
			return false;
    	}
    
    $gl_sql = "SELECT * FROM TBL_COMMON_GL_MAPPING";
		$data['common_gl']=$this->db->query($gl_sql)->row();
		$this->load->view('report/print_actual_journal_for_mtmms', $data);
	}	
	
	function actual_journal_for_mtsms($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_mtsms');
		$this->webspice->permission_verify('actual_journal_for_mtsms');
		
			$sql = "SELECT OPERATOR_NAME,PRE_POST,OPERATOR_TYPE,PROJECT_CODE,
			SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT  END  ) AS POST_VALUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT  END  ) AS PREP_VALUE,
			SUM( CASE WHEN PRE_POST = 'POST' THEN VAT_VALUE  END  ) AS POST_VAT_VALUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN VAT_VALUE  END  ) AS PREP_VAT_VALUE 
			FROM TBL_FULL_MONTH_MTSMS";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' " ;
	  $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_mtsms', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-mtsms";
		$gl_sql = "SELECT * FROM TBL_COMMON_GL_MAPPING";
		$data['common_gl']=$this->db->query($gl_sql)->row();
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
     if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_mtsms', $data);
			return false;
    	}
		$this->load->view('report/print_actual_journal_for_mtsms', $data);
	}	
	
	function actual_journal_for_ltfs($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_ltfs');
		$this->webspice->permission_verify('actual_journal_for_ltfs');
		
			$sql = "SELECT OPERATOR_NAME,PRE_POST,  OPERATOR_TYPE,PROJECT_CODE,
			SUM( CASE WHEN PRE_POST = 'POST' THEN REVENUE  END  ) AS POST_REVENUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN REVENUE  END  ) AS PREP_REVENUE,
			SUM( CASE WHEN PRE_POST = 'POST' THEN SD_AMOUNT  END  ) AS POST_SD_AMOUNT, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN SD_AMOUNT  END  ) AS PREP_SD_AMOUNT,
			SUM( CASE WHEN PRE_POST = 'POST' THEN SC_AMOUNT  END  ) AS POST_SC_AMOUNT, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN SC_AMOUNT  END  ) AS PREP_SC_AMOUNT, 
			SUM( CASE WHEN PRE_POST = 'POST' THEN VAT_ON_REVENUE_SD  END  ) AS POST_VAT_ON_REVENUE_SD, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN VAT_ON_REVENUE_SD  END  ) AS PREP_VAT_ON_REVENUE_SD 
			FROM TBL_FULL_MONTH_LTFS";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' " ;
	  $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_ltfs', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-ltfs";
		$gl_sql = "SELECT * FROM TBL_COMMON_GL_MAPPING";
		$data['common_gl']=$this->db->query($gl_sql)->row();
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
     if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_ltfs', $data);
			return false;
    	}
		$this->load->view('report/print_actual_journal_for_ltfs', $data);
	}	
	
	function actual_journal_for_itfs($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_itfs');
		$this->webspice->permission_verify('actual_journal_for_itfs');
		
			$sql = "SELECT OPERATOR_NAME,PRE_POST,SD,VAT,SURCHARGE, OPERATOR_TYPE,PROJECT_CODE, 
			SUM( CASE WHEN PRE_POST = 'POST' THEN BL_REVENUE  END  ) AS POST_REVENUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN BL_REVENUE  END  ) AS PREP_REVENUE
			FROM TBL_FULL_MONTH_ITFS";
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' " ;
	  $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_itfs', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-ltfs";
		$gl_sql = "SELECT * FROM TBL_COMMON_GL_MAPPING";
		$data['common_gl']=$this->db->query($gl_sql)->row();
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_itfs', $data);
			return false;
    	}
		$this->load->view('report/print_actual_journal_for_itfs', $data);
	}	

	function actual_journal_for_mtid($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_mtid');
		$this->webspice->permission_verify('actual_journal_for_mtid');
		
			$sql = "SELECT IOS,PRE_POST,OPERATOR_TYPE,PROJECT_CODE,
			SUM( CASE WHEN PRE_POST = 'POST' THEN BL_REVENUE  END  ) AS POST_REVENUE, 
			SUM( CASE WHEN PRE_POST = 'PREP' THEN BL_REVENUE  END  ) AS PREP_REVENUE
			FROM TBL_FULL_MONTH_MTID";
		$where = " WHERE STATUS = 7 AND IOS !='' " ;
	  $group_by = " GROUP BY IOS " ;
		$order_by = " ORDER BY IOS " ;
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_mtid', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";
		
		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-mtid";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
     if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_mtid', $data);
			return false;
    	}
		$this->load->view('report/print_actual_journal_for_mtid', $data);
	}	

	
	function actual_journal_for_operator_wise_mtc($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_operator_wise_mtc');
		$this->webspice->permission_verify('actual_journal_for_operator_wise_mtc');
	
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_operator_wise_mtc', $data);
			return false;
		}

    # get input post
        $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
	 $sql = "SELECT OPERATOR_NAME,PRE_POST,OPERATOR_TYPE,PROJECT_CODE,
           SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT  END  ) AS POST_AMOUNT, 
           SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT  END  ) AS PREP_AMOUNT,
           SUM(VAT_VALUE) AS TOTAL_VAT_VALUE,
           (SELECT SUM(AMOUNT) FROM TBL_NO_CLI WHERE STATUS = 7 AND OPERATOR !=''  
           AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
           AND OPERATOR_NAME=OPERATOR
           GROUP BY OPERATOR  ) AS NO_CLI_AMOUNT,
           (SELECT SUM(VAT) FROM TBL_NO_CLI WHERE STATUS = 7 AND OPERATOR !=''  
           AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month)."
           AND OPERATOR_NAME=OPERATOR
           GROUP BY OPERATOR  ) AS NO_CLI_VAT_AMOUNT
           FROM TBL_OP_MTC
           ";
      
      
		$where = " WHERE STATUS = 7 AND OPERATOR_NAME !='' AND OPERATOR_NAME !='OTHERS' " ;
	    $group_by = " GROUP BY OPERATOR_NAME " ;
		$order_by = " ORDER BY OPERATOR_NAME " ;
		
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$where .= "";
		$data['filter_by'] .= "Prepaid, Postpaid ";

		if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('M-Y', $calculative_month);
		}
		
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-mtid";
		$sql = $sql.$where.$group_by.$order_by;
    $data["get_record"] = $this->db->query($sql)->result();
	//dd($data["get_record"]);
   //dd($this->db->last_query()); 
	 $gl_sql="SELECT * FROM TBL_COMMON_GL_MAPPING";
	 $data["get_gl"] = $this->db->query($gl_sql)->row();
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/actual_journal_for_operator_wise_mtc', $data);
			return false;
    }
    $gl_sql = "SELECT * FROM TBL_COMMON_GL_MAPPING";
		$data['common_gl']=$this->db->query($gl_sql)->row();
		$this->load->view('report/print_actual_journal_for_operator_wise_mtc', $data);
	}
	
	function create_vendor_code($data=null){
		
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_vendor_code');
		$this->webspice->permission_verify('create_vendor_code');
		#dd($data);
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'ID'=>null,
			'VENDOR_TYPE'=>null,
			'CODE'=>null,  
			'VENDOR_NO'=>null,
			'SUPPLIER_NAME'=>null,
			'IDENTIFIER'=>null
			);
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('vendor_type','vendor_type','required|trim|xss_clean');
		$this->form_validation->set_rules('code','code','required|trim|xss_clean');
		$this->form_validation->set_rules('vendor_no','vendor_no','required|trim|xss_clean');
		$this->form_validation->set_rules('supplier_name','supplier_name','required|trim|xss_clean');
		$this->form_validation->set_rules('identifier','Identifier','required|trim|xss_clean');
		
		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_vendor_code', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('ID');
		
		# duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_VENDOR_CODE WHERE CODE=?", array( $input->code), 'You are not allowed to enter duplicate vendor code', 'ID', $input->ID, $data, 'uploader/create_vendor_code');
		
		# remove cache
		#$this->webspice->remove_cache('user');
		
		# update process
		if( $input->ID ){
			#update query
			$sql = "
			UPDATE TBL_VENDOR_CODE SET VENDOR_TYPE=?, CODE=?, VENDOR_NO=?, SUPPLIER_NAME=?, IDENTIFIER=?, UPDATED_BY=?, UPDATED_DATE=? 
			WHERE ID=?";
			$this->db->query($sql, array($input->vendor_type, $input->code, $input->vendor_no, $input->supplier_name, $input->identifier, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID)); 

			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('vendor_code_updated - '.$input->code); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_vendor_code');
			return false;
		}
		# insert process
		$sql = "
		INSERT INTO TBL_VENDOR_CODE
		(VENDOR_TYPE, CODE, VENDOR_NO, SUPPLIER_NAME, IDENTIFIER, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, ?, ?, ?, 7)";
		$this->db->query($sql, array($input->vendor_type, $input->code, $input->vendor_no, $input->supplier_name, $input->identifier, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$this->db->insert_id() ){
			$this->webspice->message_board('We could not execute your request. Please try again later.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->message_board('A vendor code information has been created.');
		$this->webspice->force_redirect($url_prefix.'manage_vendor_code');
	
	}
	
	function manage_vendor_code(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_vendor_code');
		$this->webspice->permission_verify('manage_vendor_code');
		$this->load->database();
    $orderby = ' ORDER BY TBL_VENDOR_CODE.CREATED_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 20;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_VENDOR_CODE.* FROM TBL_VENDOR_CODE ";
		
   	# filtering records
    if( $this->input->post('filter') ){
    	$limit = null;
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_VENDOR_CODE', 
			$InputField = array("VENDOR_TYPE","CODE","VENDOR_NO","SUPPLIER_NAME","IDENTIFIER"),
			$Keyword = array("VENDOR_TYPE","CODE","VENDOR_NO","SUPPLIER_NAME","IDENTIFIER"),
			$AdditionalWhere = null,
			$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('master/print_vendor_code',$data);
				return false;
        break;
           
			case 'edit':
          $this->webspice->edit_generator($TableName='TBL_VENDOR_CODE', $KeyField='ID', $key, $RedirectController='upload_controller', $RedirectFunction='create_vendor_code', $PermissionName='manage_vendor_code', $StatusCheck=null, $Log='edit_vendor_code');          
					return false;
          break;
          
 			case 'inactive':
      		$this->webspice->action_executer($TableName='TBL_VENDOR_CODE', $KeyField='ID', $key, $RedirectURL='manage_vendor_code', $PermissionName='manage_vendor_code', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache=null, $Log='inactive_vendor_code');
					return false;	
          break; 

			case 'active':
					$this->webspice->action_executer($TableName='TBL_VENDOR_CODE', $KeyField='ID', $key, $RedirectURL='manage_vendor_code', $PermissionName='manage_vendor_code', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache=null, $Log='active_vendor_code');
					return false;	
			    break; 
                       
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_vendor_code/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->load->view('master/manage_vendor_code', $data);
	}
	
	

function invoice_for_mobile_pstn_iptsp_($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'invoice_for_mobile_pstn_iptsp');
		$this->webspice->permission_verify('invoice_for_mobile_pstn_iptsp');
	  $sql = " SELECT * FROM TBL_IOS_REPORT_DATA ";
		$sql_for_operator=" SELECT * FROM TBL_OPERATOR";
		if( !$_POST ){
				$this->load->view('invoice/invoice_for_mobile_pstn_iptsp');
			  return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$operator_name = $input->operator_name;
		if($operator_name!='all'){
			$where ="WHERE OPERATOR_NAME = '".$operator_name."'";
			$operator_where =" WHERE OPERATOR_NAME = '".$operator_name."'";
		}else{
			$where='';
			$operator_where ='';
		}
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";	
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}

    if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('Y-m-d', $calculative_month);
			 $data['formated_date']=date('M Y', $calculative_month);
		}
		$data['current_date']=date("M d,Y");
		$sql = $sql.$where;
		$operator_sql = $sql_for_operator.$operator_where;
		$data["get_record"] = $this->db->query($sql)->result();
		$data["get_operator_info"] = $this->db->query($operator_sql)->row();
		if(empty($data["get_record"])){
			$this->webspice->message_board('No data Found!');
				$this->load->view('invoice/invoice_ios');
			  return false;
		}
		$this->load->view('invoice/print_invoice_ios', $data);
	}
	
	function invoice_ios($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'invoice_ios');
		$this->webspice->permission_verify('invoice_ios');
	  $sql = " SELECT * FROM TBL_IOS_REPORT_DATA ";
		$sql_for_operator=" SELECT * FROM TBL_OPERATOR";
		if( !$_POST ){
				$this->load->view('invoice/invoice_ios');
			  return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		//$operator_name = $input->operator_name;
		$operator_name_type = $input->operator_name;
    $name_type = explode("|",$operator_name_type);
    $operator_name = $name_type[1];
    $operator_type = $name_type[0];
		if($operator_name!='all'){
			$where ="WHERE OPERATOR_NAME = '".$operator_name."'";
			$operator_where =" WHERE OPERATOR_NAME = '".$operator_name."'";
		}else{
			$where='';
			$operator_where ='';
		}
		$calculative_month = $input->calculative_month;
		$data['formated_date']=date('M Y', $calculative_month);
		$data['date']=date('Y-m-d', $calculative_month);
		$invoice_number='IOS/'.$operator_name.'/'.$data['date'];
		if( $this->input->post('ajax_call') ){
    	$invoice_exist = $this->db->get_where(
         'TBL_INVOICE_DETAIL',
          array(
               'INVOICE_NUMBER' => $invoice_number
                )
            )->result();
           // dd($this->db->last_query());  
    		if($invoice_exist){ 
    		  echo 'inv_exist';
    		 	exit;
    		}else{
    		  echo 'inv_not_exist';   
    		  exit;
    		}
    		
    }
		$data['filter_by'] = "Filtered By: ";	
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}

    if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
		}
		$this->webspice->remove_cache('invoice_icx_ios');
		$data['current_date']=date("M d,Y");
		$sql = $sql.$where;
		$operator_sql = $sql_for_operator.$operator_where;
		$data["get_record"] = $this->db->query($sql)->result();
		$data["get_operator_info"] = $this->db->query($operator_sql)->row();
		if(empty($data["get_record"])){
			$this->webspice->message_board('No data Found!');
			$this->load->view('invoice/invoice_ios');
			return false;
		}
		//sabina
		// if( $this->input->post('pdf') ){
      //  	$data['action_type'] = 'pdf';
      //    $result = $this->db->query($sql)->result();
      //  	$data['get_record'] = $result;
       
      //		$filename = time()."_invoice_icx.pdf";
      //		$html = $this->load->view('invoice/print_invoice_icx', $data, true);
      //		$this->load->library('M_pdf');
      		#$this->m_pdf->param = "'c', 'L'";
          #$this->m_pdf->allow_charset_conversion=true;  // Set by default to TRUE 
       //   $this->m_pdf->charset_in='utf-8';
     	//	 	$this->m_pdf->pdf->WriteHTML($html);
     
  // dd($_POST);
      if($input->invoice_generation == "no"){
    			$total_invoice_value=0;
    			$total_cli=0;
    			$operator_name = $data['get_record'][0]->OPERATOR_NAME;
    			$invoice_number = $invoice_number;
          foreach($data['get_record'] as $k => $v){    
          	$total_invoice_value=$total_invoice_value+$v->BL_REV_BDT;         
          }
          $invoice_data[] = array(
                  "OPERATOR_NAME" => $operator_name,
                  "OPERATOR_TYPE" => $operator_type,
                  "INVOICE_NUMBER" => $invoice_number,
                  "INVOICE_AMOUNT" => $total_invoice_value,
                  "NO_CLI"=> 0,
                  "SMS"=>0,
                  "VAT"=>0,
                  "BILL_PERIOD" => $data['date'],
                  "REMAINING_AMOUNT" => $total_invoice_value,
                  "DISPUTE"=>0
              );
           
          $this->db->insert_batch("TBL_INVOICE_DETAIL" , $invoice_data);
          $this->db->insert_batch("TBL_INVOICE" , $invoice_data);
 
     // }
     
      # $this->m_pdf->pdf->Output(FCPATH."global/".$filename, "F"); #F for sile save and D for download
      //$this->m_pdf->pdf->Output($filename, "D"); # F for sile save and D for download
     
     // return false;
    }
    if($input->invoice_generation != ""){ 
      $this->load->view('invoice/print_invoice_ios', $data);
    }else{
      //$this->webspice->message_board('No data Found!');
      $this->load->view('invoice/invoice_ios');
      return false;
    }
		//$this->load->view('invoice/print_invoice_ios', $data);
	}	

	
	
	function domestic_cost_gl_mapping($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'domestic_cost_gl_mapping');
			$this->webspice->permission_verify('domestic_cost_gl_mapping,manage_domestic_cost_gl_mapping');
			if( !isset($data['edit'])){
				$data['edit'] = array( 
				'OPERATOR_NAME'=> null,
				'ACCURED'=> null,
				'POST_VOICE' => null,
				'PRE_VOICE'=>null,
				'POST_SMS' => null,
				'PRE_SMS'=>null,
				'ID'=>null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('operator_name','operator_name','required|trim|xss_clean');
			$this->form_validation->set_rules('accrued','Accrued','required|trim|xss_clean');
			$this->form_validation->set_rules('post_voice','post_voice','required|trim|xss_clean');
			$this->form_validation->set_rules('pre_voice','Pre Voice','required|trim|xss_clean');
			$this->form_validation->set_rules('post_sms','Post SMS','required|trim|xss_clean');
			$this->form_validation->set_rules('pre_sms','Pre SMS','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('master/domestic_cost_gl_mapping', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_DOMESTIC_COST_GL_MAPPING WHERE OPERATOR_NAME=? ", array( $input->operator_name), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/domestic_cost_gl_mapping');
			# remove cache
			$this->webspice->remove_cache('gl');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_DOMESTIC_COST_GL_MAPPING SET OPERATOR_NAME=?, ACCURED=?, POST_VOICE=?, PRE_VOICE=?, POST_SMS=?, PRE_SMS=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->operator_name,$input->accrued,$input->post_voice, $input->pre_voice, $input->post_sms, $input->pre_sms, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('operator_updated - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_domestic_cost_gl_mapping');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_DOMESTIC_COST_GL_MAPPING','ID');
			$sql = "
			INSERT INTO TBL_DOMESTIC_COST_GL_MAPPING
			(OPERATOR_NAME, ACCURED, POST_VOICE, PRE_VOICE, POST_SMS, PRE_SMS, CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->operator_name, $input->accrued,$input->post_voice, $input->pre_voice, $input->post_sms, $input->pre_sms, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('domestic_cost_gl_mapping', true) ){
				$this->webspice->force_redirect($url_prefix.'domestic_cost_gl_mapping');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	       
	function manage_domestic_cost_gl_mapping(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_domestic_cost_gl_mapping');
			$this->webspice->permission_verify('manage_domestic_cost_gl_mapping');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = 'LIMIT ' .$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = "SELECT * FROM TBL_DOMESTIC_COST_GL_MAPPING ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_DOMESTIC_COST_GL_MAPPING',
				$InputField = array(),
				$Keyword = array("OPERATOR_NAME","ACCURED", "POST_VOICE","PRE_VOICE","POST_SMS","PRE_SMS"),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = 'Last Created';
					$this->load->view('master/print_domestic_cost_gl_mapping',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_DOMESTIC_COST_GL_MAPPING', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='domestic_cost_gl_mapping', $PermissionName='domestic_cost_gl_mapping', $StatusCheck=null, $Log='edit_domestic_cost_gl_mapping');          
					return false;
          break;

	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	           
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_domestic_cost_gl_mapping/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_domestic_cost_gl_mapping', $data);
	}

	function domestic_rev_gl_mapping($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'domestic_rev_gl_mapping');
			$this->webspice->permission_verify('domestic_rev_gl_mapping,manage_domestic_rev_gl_mapping');
			if( !isset($data['edit'])){
				$data['edit'] = array( 
				'OPERATOR_NAME'=> null,
				'INVOICE'=> null,
				'POST_VOICE_DEBIT' => null,
				'PRE_VOICE_DEBIT'=>null,
				'POST_VOICE_CREDIT' => null,
				'PRE_VOICE_CREDIT'=>null,
				'POST_SMS_DEBIT'=>null,
				'POST_SMS_CREDIT'=>null,
				'PRE_SMS_DEBIT'=>null,
				'PRE_SMS_CREDIT'=>null,
				
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('operator_name','Operator Name','required|trim|xss_clean');
			$this->form_validation->set_rules('invoice','Invoice','required|trim|xss_clean');
			$this->form_validation->set_rules('post_voice_debit','Post Voice Debit','required|trim|xss_clean');
			$this->form_validation->set_rules('pre_voice_debit','Pre Voice Debit','required|trim|xss_clean');
			$this->form_validation->set_rules('post_voice_credit','Post Voice Credit','required|trim|xss_clean');
			$this->form_validation->set_rules('pre_voice_credit','Pre Voice Credit','required|trim|xss_clean');
			$this->form_validation->set_rules('post_sms_debit','Post SMS Debit','required|trim|xss_clean');
			$this->form_validation->set_rules('post_sms_credit','Post SMS Credit','required|trim|xss_clean');
			$this->form_validation->set_rules('pre_sms_debit','Pre SMS Debit','required|trim|xss_clean');
			$this->form_validation->set_rules('pre_sms_credit','Pre SMS Credit','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('master/domestic_rev_gl_mapping', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_DOMESTIC_REV_GL_MAPPING WHERE OPERATOR_NAME=? ", array( $input->operator_name), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/domestic_rev_gl_mapping');
			# remove cache
			//$this->webspice->remove_cache('demestic_rev_gl');
		   $this->webspice->remove_cache('gl');
		
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_DOMESTIC_REV_GL_MAPPING SET OPERATOR_NAME=?, INVOICE=?, POST_VOICE_DEBIT=?, PRE_VOICE_DEBIT=?, POST_VOICE_CREDIT=?, PRE_VOICE_CREDIT=?,POST_SMS_DEBIT=?, POST_SMS_CREDIT=?,PRE_SMS_DEBIT=?, PRE_SMS_CREDIT=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->operator_name,$input->invoice,$input->post_voice_debit, $input->pre_voice_debit, $input->post_voice_credit, $input->pre_voice_credit,$input->post_sms_debit, $input->post_sms_credit,$input->pre_sms_debit, $input->pre_sms_credit, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('operator_updated - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_domestic_rev_gl_mapping');
				return false;
			}
			$sql = "
			INSERT INTO TBL_DOMESTIC_REV_GL_MAPPING
			(OPERATOR_NAME, INVOICE, POST_VOICE_DEBIT, PRE_VOICE_DEBIT, POST_VOICE_CREDIT, PRE_VOICE_CREDIT,POST_SMS_DEBIT,POST_SMS_CREDIT, PRE_SMS_DEBIT,PRE_SMS_CREDIT,CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->operator_name, $input->invoice,$input->post_voice_debit, $input->pre_voice_debit, $input->post_voice_credit, $input->pre_voice_credit,$input->post_sms_debit,$input->post_sms_credit,$input->pre_sms_debit,$input->pre_sms_credit, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('domestic_rev_gl_mapping', true) ){
				$this->webspice->force_redirect($url_prefix.'domestic_rev_gl_mapping');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	       
	function manage_domestic_rev_gl_mapping(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_domestic_rev_gl_mapping_');
			$this->webspice->permission_verify('manage_domestic_rev_gl_mapping_');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = null;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = "SELECT * FROM TBL_DOMESTIC_REV_GL_MAPPING ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_DOMESTIC_REV_GL_MAPPING',
				$InputField = array(),
				$Keyword = array('OPERATOR_NAME','INVOICE', 'POST_VOICE_DEBIT','PRE_VOICE_DEBIT','POST_VOICE_CREDIT','PRE_VOICE_CREDIT','POST_SMS_DEBIT','POST_SMS_CREDIT','PRE_SMS_DEBIT','PRE_SMS_CREDIT'),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = 'Last Created';
					$this->load->view('master/print_domestic_rev_gl_mapping',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_DOMESTIC_REV_GL_MAPPING', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='domestic_rev_gl_mapping', $PermissionName='domestic_rev_gl_mapping', $StatusCheck=null, $Log='edit_domestic_rev_gl_mapping');          
					return false;
          break;

	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	           
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_domestic_rev_gl_mapping/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_domestic_rev_gl_mapping', $data);
	}
	
	
	
	
	
	
	
	function common_gl_mapping($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'common_gl_mapping');
			$this->webspice->permission_verify('common_gl_mapping,manage_common_gl_mapping');
			if( !isset($data['edit'])){
				$data['edit'] = array( 
				'VAT'=> null,
				'TF_INVOICE'=> null,
				'TF_REVENUE' => null,
				'TF_SD'=>null,
				'TF_SC' => null,
				'COST_INTN_POST'=>null,
				'COST_INTN_PRE'=>null,
				'ICX_PORTION'=>null,
				'BTRC_PORTION'=>null,
				'IGW_PORTION'=>null,
				'INTN_REV_INVOICE'=>null,
				'INTN_REV_POST_DEBIT'=>null,
				'INTN_REV_PRE_DEBIT'=>null,
				'INTN_REV_POST_CREDIT'=>null,
				'INTN_REV_PRE_CREDIT'=>null,
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('vat','Vat','required|trim|xss_clean');
			$this->form_validation->set_rules('tf_invoice','TF Invoice','required|trim|xss_clean');
			$this->form_validation->set_rules('tf_revenue','TF Revenue','required|trim|xss_clean');
			$this->form_validation->set_rules('tf_sd','TF SD','required|trim|xss_clean');
			$this->form_validation->set_rules('tf_sc','TF SC','required|trim|xss_clean');
			$this->form_validation->set_rules('cost_internal_post','Cost Internal Post','required|trim|xss_clean');
			$this->form_validation->set_rules('cost_internal_pre','Cost Internal Pre','required|trim|xss_clean');
			$this->form_validation->set_rules('icx_portion','ICX Portion','required|trim|xss_clean');
			$this->form_validation->set_rules('btrc_portion','BTRC Portion','required|trim|xss_clean');
			$this->form_validation->set_rules('igw_portion','IGW Portion','required|trim|xss_clean');
			$this->form_validation->set_rules('intn_rev_post_debit','Intn Rev Post Debit','required|trim|xss_clean');
			$this->form_validation->set_rules('intn_rev_invoice','internal Rev Invoice','required|trim|xss_clean');
			$this->form_validation->set_rules('intn_rev_pre_debit','Intn Rev Pre Debit','required|trim|xss_clean');
			$this->form_validation->set_rules('intn_rev_post_credit','Intn Rev Post Credit','required|trim|xss_clean');
			$this->form_validation->set_rules('intn_rev_pre_credit','Intn Rev Pre Credit','required|trim|xss_clean');
			
			if( !$this->form_validation->run() ){
					$this->load->view('master/common_gl_mapping', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
	//	  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_COMMON_GL_MAPPING WHERE OPERATOR_NAME=? ", array( $input->operator_name), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/domestic_rev_gl_mapping');
			# remove cache
			$this->webspice->remove_cache('domestic_rev_common_gl_mapping');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_COMMON_GL_MAPPING SET VAT=?, TF_INVOICE=?, TF_REVENUE=?, TF_SD=?, TF_SC=?, COST_INTN_POST=?,COST_INTN_PRE=?, ICX_PORTION=?,BTRC_PORTION=?, IGW_PORTION=?,INTN_REV_INVOICE=?,INTN_REV_POST_DEBIT=?,INTN_REV_PRE_DEBIT=?,INTN_REV_POST_CREDIT=?,INTN_REV_PRE_CREDIT=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->vat,$input->tf_invoice,$input->tf_revenue, $input->tf_sd, $input->tf_sc, $input->cost_internal_post,$input->cost_internal_pre, $input->icx_portion,$input->btrc_portion, $input->igw_portion,$input->intn_rev_invoice,$input->intn_rev_post_debit,$input->intn_rev_pre_debit,$input->intn_rev_post_credit,$input->intn_rev_pre_credit, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				//$this->webspice->log_me('operator_updated - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_common_gl_mapping');
				return false;
			}
			$sql = "
			INSERT INTO TBL_COMMON_GL_MAPPING
			(VAT, TF_INVOICE, TF_REVENUE, TF_SD, TF_SC, COST_INTN_POST,COST_INTN_PRE,ICX_PORTION, BTRC_PORTION,IGW_PORTION,INTN_REV_INVOICE,INTN_REV_POST_DEBIT,INTN_REV_PRE_DEBIT,INTN_REV_POST_CREDIT,INTN_REV_PRE_CREDIT,CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->vat, $input->tf_invoice,$input->tf_revenue, $input->tf_revenue, $input->tf_sd, $input->tf_sc,$input->cost_internal_post,$input->cost_internal_pre,$input->icx_portion,$input->btrc_portion,$input->igw_portion,$input->intn_rev_invoice,$input->intn_rev_post_debit,$input->intn_rev_pre_debit,$input->intn_rev_post_credit,$input->intn_rev_pre_credit,$this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('common_gl_mapping', true) ){
				$this->webspice->force_redirect($url_prefix.'common_gl_mapping');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	       
	function manage_common_gl_mapping(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_common_gl_mapping');
			$this->webspice->permission_verify('manage_common_gl_mapping');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = null;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = "SELECT * FROM TBL_COMMON_GL_MAPPING ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_COMMON_GL_MAPPING',
				$InputField = array(),
				$Keyword = array('VAT','TF_INVOICE', 'TF_REVENUE','TF_SD','TF_SC','COST_INTN_POST','COST_INTN_PRE','ICX_PORTION','BTRC_PORTION','IGW_PORTION','INTN_REV_INVOICE','INTN_REV_POST_DEBIT','INTN_REV_PRE_DEBIT','INTN_REV_POST_CREDIT','INTN_REV_PRE_CREDIT'),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = 'Last Created';
					$this->load->view('master/print_common_gl_mapping',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_COMMON_GL_MAPPING', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='common_gl_mapping', $PermissionName='common_gl_mapping', $StatusCheck=null, $Log='edit_common_gl_mapping');          
					return false;
          break;

	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	           
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_common_gl_mapping/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_common_gl_mapping', $data);
	}
	//vendor type
	
	function create_vendor_type($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_vendor_type');
			$this->webspice->permission_verify('create_vendor_type,manage_vendor_type');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'VENDOR_TYPE'=> null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('vendor_type','Vendor Type','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('master/create_vendor_type', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_VENDOR_TYPE WHERE VENDOR_TYPE=?", array( $input->vendor_type), 'You are not allowed to enter duplicate Vendor Type!', 'ID', $input->ID, $data, 'master/create_vendor_type');
			# remove cache
			$this->webspice->remove_cache('vendor_type');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_VENDOR_TYPE SET VENDOR_TYPE=?, UPDATED_BY=?, UPDATED_DATE=? WHERE ID=?";
				$this->db->query($sql , array($input->vendor_type, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('vendor_type'.$input->vendor_type);
				$this->webspice->force_redirect($url_prefix.'manage_vendor_type');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_VENDOR_TYPE
			(VENDOR_TYPE, CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->vendor_type, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('create_vendor_type', true) ){
				$this->webspice->force_redirect($url_prefix.'create_vendor_type');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_vendor_type(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_vendor_type');
			$this->webspice->permission_verify('manage_vendor_type');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = null;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = "SELECT * FROM TBL_VENDOR_TYPE ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_VENDOR_TYPE',
				$InputField = array(),
				$Keyword = array('VENDOR_TYPE'),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = 'Last Created';
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = 'Last Created';
					$this->load->view('master/print_vendor_type',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_VENDOR_TYPE', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='create_vendor_type', $PermissionName='create_vendor_type', $StatusCheck=null, $Log='edit_vendor');          
					return false;
          break;
	
	 		  case 'inactive':
	      		$this->webspice->action_executer($TableName='TBL_VENDOR_TYPE', $KeyField='ID', $key, $RedirectURL='manage_vendor_type', $PermissionName='manage_vendor_type', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='vendor_type', $Log='inactive_vendor');
						return false;
	          break;
	
			  case 'active':
						$this->webspice->action_executer($TableName='TBL_VENDOR_TYPE', $KeyField='ID', $key, $RedirectURL='manage_vendor_type', $PermissionName='manage_vendor_type', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='vendor_type', $Log='active_vendor');
						return false;
				    break;
	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_vendor_type/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_vendor_type', $data);
	}
	


	function international_invoice_forwarding($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'international_invoice_forwarding');
		$this->webspice->permission_verify('international_invoice_forwarding');
	  $sql = " SELECT * FROM TBL_ICX_REPORT_DATA ";
		$sql_for_cli=" SELECT * FROM TBL_NO_CLI ";
		$sql_for_operator=" SELECT * FROM TBL_OPERATOR";
		if( !$_POST ){
				$this->load->view('invoice/international_invoice_forwarding');
			  return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$operator_name = $input->operator_name;
	  $data['type'] = $input->TYPE;
		$where ="WHERE OPERATOR_NAME = '".$operator_name."'";
		$cli_where ="WHERE OPERATOR = '".$operator_name."'";
		$operator_where =" WHERE OPERATOR_NAME = '".$operator_name."'";
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";	
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'doc';
  	}

    if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $cli_where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('Y-m-d', $calculative_month);
			 $data['formated_date']=date('M Y', $calculative_month);
		}
		$data['current_date']=date("M d,Y");
		$sql = $sql.$where;
		$cli_sql = $sql_for_cli.$cli_where;
		$operator_sql = $sql_for_operator.$operator_where;
		$data["get_record"] = $this->db->query($sql)->result();
		$data["get_cli"] = $this->db->query($cli_sql)->result();
		$data["get_operator_info"] = $this->db->query($operator_sql)->row();
		//if(empty($data["get_record"])){
		//	$this->webspice->message_board('No data Found!');
		//		$this->load->view('invoice/invoice_forwarding_international');
		//	  return false;
		//}
		$this->load->view('invoice/print_international_invoice_forwarding', $data);
	}
	function domestic_invoice_forwarding($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'domestic_invoice_forwarding');
		$this->webspice->permission_verify('domestic_invoice_forwarding');
	  $sql = " SELECT * FROM TBL_ICX_REPORT_DATA ";
		$sql_for_cli=" SELECT * FROM TBL_NO_CLI ";
		$sql_for_operator=" SELECT * FROM TBL_OPERATOR";
		if( !$_POST ){
				$this->load->view('invoice/domestic_invoice_forwarding');
			  return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$operator_name = $input->operator_name;
		$data['type'] = $input->TYPE;
		if($operator_name!='all'){
			$where ="WHERE OPERATOR_NAME = '".$operator_name."'";
			$cli_where ="WHERE OPERATOR = '".$operator_name."'";
			$operator_where =" WHERE OPERATOR_NAME = '".$operator_name."'";
		}else{
			$where='';
			$cli_where='';	
			$operator_where ='';
		}
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";	
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}

    if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $cli_where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('Y-m-d', $calculative_month);
			 $data['formated_date']=date('M Y', $calculative_month);
		}
		$data['current_date']=date("M d,Y");
		$sql = $sql.$where;
		$cli_sql = $sql_for_cli.$cli_where;
		$operator_sql = $sql_for_operator.$operator_where;
		$data["get_record"] = $this->db->query($sql)->result();
		$data["get_cli"] = $this->db->query($cli_sql)->result();
		$data["get_operator_info"] = $this->db->query($operator_sql)->row();
		if(empty($data["get_record"])){
			$this->webspice->message_board('No data Found!');
			$this->load->view('invoice/domestic_invoice_forwarding');
			return false;
		}
		$this->load->view('invoice/print_domestic_invoice_forwarding', $data);
	}
	
	function invoice_for_itfs($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'invoice_for_itfs');
		$this->webspice->permission_verify('invoice_for_itfs');
	  $sql = " SELECT * FROM TBL_ICX_REPORT_DATA ";
		$sql_for_cli=" SELECT * FROM TBL_NO_CLI ";
		$sql_for_operator=" SELECT * FROM TBL_OPERATOR";
		if( !$_POST ){
				$this->load->view('invoice/invoice_icx');
			  return false;
		}
		
    # get input post
    $input = $this->webspice->get_input();
		$operator_name = $input->operator_name;
		if($operator_name!='all'){
			$where ="WHERE OPERATOR_NAME = '".$operator_name."'";
			$cli_where ="WHERE OPERATOR = '".$operator_name."'";
			$operator_where =" WHERE OPERATOR_NAME = '".$operator_name."'";
		}else{
			$where='';
			$cli_where='';	
			$operator_where ='';
		}
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";	
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}

    if(isset($calculative_month)){
			 $where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $cli_where .= " AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month);
			 $data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
			 $data['date']=date('Y-m-d', $calculative_month);
			 $data['formated_date']=date('M Y', $calculative_month);
		}
		$data['current_date']=date("M d,Y");
		$sql = $sql.$where;
		$cli_sql = $sql_for_cli.$cli_where;
		$operator_sql = $sql_for_operator.$operator_where;
		$data["get_record"] = $this->db->query($sql)->result();
		$data["get_cli"] = $this->db->query($cli_sql)->result();
		$data["get_operator_info"] = $this->db->query($operator_sql)->row();
		if(empty($data["get_record"])){
			$this->webspice->message_board('No data Found!');
				$this->load->view('invoice/invoice_icx');
			  return false;
		}
		$this->load->view('invoice/print_invoice_icx', $data);
	}
	
	function a2p_configeration($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'a2p_configeration');
			$this->webspice->permission_verify('a2p_configeration,manage_a2p_configeration');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'TOTAL_SMS_COMMITMENT_PER_MONTH'=> null,
				'AGREED_RATE'=> null,
				'RATIO' => null,
				'USD_TO_BDT_RATE'=>null,
				'ID' => null,
				'USD_AMOUNT'=>null,
				'DEAL_PERIOD'=>null,
				'FROM_DATE'=>null,
				'FROM_DATE'=>null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('TOTAL_SMS_COMMITMENT_PER_MONTH','Total Sms Commitment Per Month','required|trim|xss_clean');
			$this->form_validation->set_rules('AGREED_RATE','Agreed Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('RATIO','Ratio','required|trim|xss_clean');
			$this->form_validation->set_rules('USD_TO_BDT_RATE','Usd to Bdt Rate','required|trim|xss_clean');
			$this->form_validation->set_rules('USD_AMOUNT','Usd Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('DEAL_PERIOD','Deal Period','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('master/a2p_configeration', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			$from_date = $this->input->post("FROM_DATE");
			$to_date = $this->input->post("TO_DATE");
		  $from_date=date("Y-m-d",$from_date);
		  $to_date=date("Y-m-d",$to_date);
			#duplicate test
		 // $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_OPERATOR WHERE OPERATOR_NAME=? AND OPERATOR_TYPE=? AND PROJECT_CODE=? ", array( $input->operator_name,$input->operator_type,$input->projrct_code), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_operator');
			# remove cache
			$this->webspice->remove_cache('a2p_configuration');
			# update process
		//	if($input->ID ){
				#update query
			//	$sql = "UPDATE TBL_OPERATOR SET SUPPLIER_CODE=?,EMAIL_ADDRESS=?, OPERATOR_NAME=?, OPERATOR_SHORT_CODE=?, PROJECT_CODE=?, OPERATOR_TYPE=?, ATTENTION=?, ADDRESS=?, TEL_NO=?, VAT_REG_NO=?, REF_NO=?, UPDATED_BY=?, UPDATED_DATE=?
			//	WHERE ID=?";
			//	$this->db->query($sql , array($input->supplier_code,$input->email_address,$input->operator_name,$input->short_code,$input->projrct_code, $input->operator_type, $input->attention, $input->address, $input->tel_no, $input->vat_reg_no, $input->ref_no, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
			//	$this->webspice->message_board('Record has been updated!');
			//	$this->webspice->log_me('operator_updated - '.$input->operator_name);
			//	$this->webspice->force_redirect($url_prefix.'manage_operator');
			//	return false;
			//}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_A2P_CONF
			(TOTAL_SMS_COMMITMENT_PER_MONTH,AGREED_RATE, RATIO, USD_TO_BDT_RATE, USD_AMOUNT, DEAL_PERIOD,CREATED_BY, CREATED_DATE, FROM_DATE, TO_DATE,STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->TOTAL_SMS_COMMITMENT_PER_MONTH,$input->AGREED_RATE,$input->RATIO, $input->USD_TO_BDT_RATE,$input->USD_AMOUNT, $input->DEAL_PERIOD, $this->webspice->get_user_id(), $this->webspice->now(), $from_date, $to_date));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('a2p_configeration', true) ){
				$this->webspice->force_redirect($url_prefix.'a2p_configeration');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_a2p_configeration(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_a2p_configeration');
			$this->webspice->permission_verify('manage_a2p_configeration');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = ' LIMIT '.$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = " SELECT TBL_A2P_CONF.* FROM TBL_A2P_CONF ";
	   // $initialSQL = "SELECT * FROM TBL_OPERATOR ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
					$TableName = 'TBL_A2P_CONF',
					$InputField = array(),
					$Keyword = array('TOTAL_SMS_COMMITMENT_PER_MONTH','AGREED_RATE','RATIO'),
					$AdditionalWhere = null,
					$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	   	
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('master/print_a2p_configeration',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_A2P_CONF', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='a2p_configeration', $PermissionName='a2p_configeration', $StatusCheck=null, $Log='edit_a2p_configeration');          
					return false;
          break;
	    }
	    
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $limit;
			}
			
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
				#dd($this->db->last_query());
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_a2p_configeration/page/', 10 );
		  }
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_a2p_configeration', $data);
	}
	
	function a2p_fixed_monthly_journal($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'a2p_fixed_monthly_journal');
		$this->webspice->permission_verify('a2p_fixed_monthly_journal');
		if( !$_POST ){
			$this->load->view('report/a2p_fixed_monthly_journal', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$calculative_month=date("Y-m-d",$calculative_month);
		$data['date']=date('M-Y', strtotime($calculative_month));
		$sql = "SELECT * FROM TBL_A2P_CONF WHERE  '".$calculative_month."' BETWEEN FROM_DATE  AND TO_DATE" ;
		$data['filter_by'] = "Filtered By: ";
		
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['current_date']=date("d-M-Y");
    $data["get_record"] = $this->db->query($sql)->row();
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/a2p_fixed_monthly_journal', $data);
			return false;
    	}
		$this->load->view('report/print_a2p_fixed_monthly_journal', $data);
	}
	
	function a2p_additional_provision_journal($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'a2p_additional_provision_journal');
		$this->webspice->permission_verify('a2p_additional_provision_journal');
		if( !$_POST ){
			$this->load->view('report/a2p_additional_provision_journal', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month_formate = $input->CALCULATIVE_MONTH;
		$calculative_month=date("Y-m-d",$calculative_month_formate);
		$data['date']=date('M-Y', strtotime($calculative_month));
		$sql = "SELECT * FROM TBL_A2P_CONF WHERE  '".$calculative_month."' BETWEEN FROM_DATE  AND TO_DATE" ;
	  $sql_provition="SELECT SUM(SMS_COUNT) AS TOTAL_SMS , USD_TO_BDT_RATE FROM TBL_INTERNATIONAL_SMS WHERE YEAR(DATE_TIME) = ".date("Y",$calculative_month_formate)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month_formate);
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['current_date']=date("d-M-Y");
    $data["get_record"] = $this->db->query($sql)->row();
    $data["provition_record"] = $this->db->query($sql_provition)->row();
    
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/a2p_additional_provision_journal', $data);
			return false;
    	}
		$this->load->view('report/print_a2p_additional_provision_journal', $data);
	}
	
	function a2p_full_month_journal($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'a2p_full_month_journal');
		$this->webspice->permission_verify('a2p_full_month_journal');
		if( !$_POST ){
			$this->load->view('report/a2p_full_month_journal', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month_formate = $input->CALCULATIVE_MONTH;
		$calculative_month=date("Y-m-d",$calculative_month_formate);
		$data['date']=date('M-Y', strtotime($calculative_month));
		$sql = "SELECT * FROM TBL_A2P_CONF WHERE  '".$calculative_month."' BETWEEN FROM_DATE  AND TO_DATE" ;
	  $sql_actual="SELECT SUM(NO_OF_SMS) AS TOTAL_SMS , USD_TO_BDT_RATE FROM TBL_A2P_INT_SMS_INCOMMING WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month_formate)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month_formate);
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['current_date']=date("d-M-Y");
    $data["get_record"] = $this->db->query($sql)->row();
    $data["actual_record"] = $this->db->query($sql_actual)->row();
    
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/a2p_full_month_journal', $data);
			return false;
    	}
		$this->load->view('report/print_a2p_full_month_journal', $data);
	}
	function generate_ageing(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'generate_ageing');
		$this->webspice->permission_verify('generate_ageing');

		$this->load->database();
		$orderby = null;
		$groupby = null;
		$where = ' ';
		$page_index = 0;
		$no_of_record = 30;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		
		//$max_ageing_date = $this->db->query(" SELECT MAX(LAST_DAY(TO_DATE(PERIOD,'MON-YY'))+1) AS MAX_AGEING_DATE FROM TBL_AGEING_DATA_TEMP ")->row("MAX_AGEING_DATE");
	
		$initialSQL = "SELECT * FROM TBL_VENDOR_LIABILITY";

		#dd($initialSQL);

   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_AGEING_DATA_TEMP',
				$InputField = array('PROJECT_NAME'),
				$Keyword = array(),
				$AdditionalWhere = " EXTRACT (YEAR FROM TBL_AGEING_DATA_TEMP.CREATED_DATE) = 2017 /*EXTRACT (YEAR FROM SYSDATE)*/ AND EXTRACT (MONTH FROM TBL_AGEING_DATA_TEMP.CREATED_DATE) = 11 /*EXTRACT (MONTH FROM SYSDATE)*/ ",
				$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
			$initialSQL = "SELECT * FROM
			TBL_VENDOR_LIABILITY
			";
		}

    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql_ageing']) || !$_SESSION['sql_ageing'] ){
				$_SESSION['sql_ageing'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}

			$record = $this->db->query( $_SESSION['sql_ageing'] );
			$data['get_record'] = $record->result();
			$data['filter_by'] = $_SESSION['filter_by'];
dd($data['get_record']);
			$this->load->view('ageing/print_ageing_report',$data);
			return false;
			break;

			case 'approve':
			$this->webspice->action_executer($TableName='TBL_BUNDLE', $KeyField='BUNDLE_ID', $key, $RedirectURL='manage_bundle', $PermissionName='manage_bundle', $StatusCheck=1, $ChangeStatus=2, $RemoveCache='bundle', $Log='approve_bundle');
			return false;
			break;

			case 'remove':
					# delete permanently bundle and bundle item related information
			$this->db->trans_off();
			$this->db->trans_begin();

			$key = $this->webspice->encrypt_decrypt($key, 'decrypt');

			$delete_sql = "DELETE FROM TBL_BUNDLE WHERE BUNDLE_ID = ? AND ROWNUM = 1";
			$this->db->query($delete_sql, $key);

			$delete_sql = "DELETE FROM TBL_BUNDLE_ITEM WHERE BUNDLE_ID = ? ";
			$this->db->query($delete_sql, $key);

			if ($this->db->trans_status() === FALSE){
				$this->db->trans_rollback();
				$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return FALSE;

			}else{
				$this->db->trans_commit();
			}
			$this->db->trans_off();

					# remove cache
			$this->webspice->remove_cache('bundle');

			$this->webspice->force_redirect($url_prefix.'manage_bundle');
			return false;
			break;
		}

    # default
		$sql = $initialSQL;
		
    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql_bundle']) || !$_SESSION['sql_bundle'] ){
    		$sql = substr($sql, 0, strpos($sql,'LIMIT'));
    	}else{
    		$sql = substr($_SESSION['sql_bundle'], 0, strpos($_SESSION['sql_bundle'],'LIMIT'));
    	}

    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = $sql . $limit;
    }*/

		# load all records
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_bundle/page/', 10 );
		}*/

		$_SESSION['sql_ageing'] = $sql;
		$_SESSION['filter_by'] = $filter_by;
		$result = $this->db->query($sql)->result();
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;

		$this->load->view('ageing/generate_ageing', $data);
	}
	
	
 	function a2p_provision_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'a2p_provision_report');
		$this->webspice->permission_verify('a2p_provision_report');
		if( !$_POST ){
			$this->load->view('report/a2p_provision_report', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month_formate = $input->CALCULATIVE_MONTH;
		$calculative_month=date("Y-m-d",$calculative_month_formate);
		$data['date']=date('M-Y', strtotime($calculative_month));
		$sql = "SELECT * FROM TBL_A2P_CONF WHERE  '".$calculative_month."' BETWEEN FROM_DATE  AND TO_DATE" ;
	  $sql_provition="SELECT SUM(SMS_COUNT) AS TOTAL_SMS , USD_TO_BDT_RATE FROM TBL_INTERNATIONAL_SMS WHERE YEAR(DATE_TIME) = ".date("Y",$calculative_month_formate)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month_formate);
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['current_date']=date("d-M-Y");
    $data["get_record"] = $this->db->query($sql)->row();
    $data["provition_record"] = $this->db->query($sql_provition)->row();
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/a2p_provision_report', $data);
			return false;
    	}
		$this->load->view('report/print_a2p_provision_report', $data);
	}
	
	function a2p_actual_report($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'a2p_actual_report');
		$this->webspice->permission_verify('a2p_actual_report');
		if( !$_POST ){
			$this->load->view('report/a2p_actual_report', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month_formate = $input->CALCULATIVE_MONTH;
		$calculative_month=date("Y-m-d",$calculative_month_formate);
		$data['date']=date('M-Y', strtotime($calculative_month));
		$sql = "SELECT * FROM TBL_A2P_CONF WHERE  '".$calculative_month."' BETWEEN FROM_DATE  AND TO_DATE" ;
	  $sql_actual="SELECT SUM(NO_OF_SMS) AS TOTAL_SMS , USD_TO_BDT_RATE FROM TBL_A2P_INT_SMS_INCOMMING WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month_formate)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month_formate);
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['current_date']=date("d-M-Y");
    $data["get_record"] = $this->db->query($sql)->row();
    $data["actual_record"] = $this->db->query($sql_actual)->row();
    
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/a2p_actual_report', $data);
			return false;
    	}
		$this->load->view('report/print_a2p_actual_report', $data);
	}
	
	
	function a2p_invoice($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'a2p_invoice');
		$this->webspice->permission_verify('a2p_invoice');
		if( !$_POST ){
			$this->load->view('report/a2p_invoice', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month_formate = $input->CALCULATIVE_MONTH;
		$calculative_month=date("Y-m-d",$calculative_month_formate);
		$data['date']=date('M-Y', strtotime($calculative_month));
		$sql = "SELECT * FROM TBL_A2P_CONF WHERE  '".$calculative_month."' BETWEEN FROM_DATE  AND TO_DATE" ;
	  $sql_actual="SELECT SUM(NO_OF_SMS) AS TOTAL_SMS , USD_TO_BDT_RATE FROM TBL_A2P_INT_SMS_INCOMMING WHERE YEAR(REPORT_DATE) = ".date("Y",$calculative_month_formate)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month_formate);
		$sql_provition="SELECT SUM(SMS_COUNT) AS TOTAL_SMS , USD_TO_BDT_RATE FROM TBL_INTERNATIONAL_SMS WHERE YEAR(DATE_TIME) = ".date("Y",$calculative_month_formate)." AND MONTH(DATE_TIME) = ".date("m",$calculative_month_formate);
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
  	$data['formated_date']=date('M Y', $calculative_month);
		$data['current_date']=date("d-M-Y");
    $data["get_record"] = $this->db->query($sql)->row();
    $data["actual_record"] = $this->db->query($sql_actual)->row();
    $data["provition_record"] = $this->db->query($sql_provition)->row();
    if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('report/a2p_invoice', $data);
			return false;
    	}
		$this->load->view('report/print_a2p_invoice', $data);
	}
	
	
	
	function actual_journal_for_operator_wise_moc($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'actual_journal_for_operator_wise_moc');
		$this->webspice->permission_verify('actual_journal_for_operator_wise_moc');
		if( !$_POST ){
			$this->load->view('report/actual_journal_for_operator_wise_moc', $data);
			return false;
		}
    # get input post
    $input = $this->webspice->get_input();	
		$calculative_month = $input->CALCULATIVE_MONTH;
		$data['filter_by'] = "Filtered By: ";
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
		$data['filter_by'] .= "Prepaid, Postpaid ";
		$data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
		$data['date']=date('M-Y',$calculative_month);
			$sql = "SELECT OPERATOR_NAME,OPERATOR_TYPE,PROJECT_CODE,
             SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT  END  ) AS POST_VALUE, 
             SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT  END  ) AS PREP_VALUE 
             FROM TBL_OP_MOC
			 WHERE OPERATOR_NAME!='OTHERS' AND OPERATOR_NAME!='Others' AND OPERATOR_NAME!='others' AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month).
             " GROUP BY OPERATOR_NAME
			 UNION ALL
             SELECT ICX AS OPERATOR_NAME,OPERATOR_TYPE,PROJECT_CODE,
             SUM( CASE WHEN PRE_POST = 'POST' THEN AMOUNT  END  ) AS POST_VALUE, 
             SUM( CASE WHEN PRE_POST = 'PREP' THEN AMOUNT  END  ) AS PREP_VALUE 
             FROM TBL_ICX_MOC
			 WHERE OPERATOR_NAME!='OTHERS' AND OPERATOR_NAME!='Others' AND OPERATOR_NAME!='others' AND YEAR(REPORT_DATE) = ".date("Y",$calculative_month)." AND MONTH(REPORT_DATE) = ".date("m",$calculative_month).
             " GROUP BY ICX";
		
		
		$data['current_date']=date("d-M-Y");
		$data['report_name']="Journal-inter-moc";
    $data["get_record"] = $this->db->query($sql)->result();
    if(empty($data["get_record"])){
    $this->webspice->message_board('Record is not found!');
    $this->load->view('report/actual_journal_for_operator_wise_moc', $data);
		return false;
    }
		$this->load->view('report/print_actual_journal_for_operator_wise_moc', $data);
	}
	function create_corporate_exchange_rate($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_corporate_exchange_rate');
		$this->webspice->permission_verify('create_corporate_exchange_rate, manage_corporate_exchange_rate');

		if( !isset($data['edit']) ){
			$data['edit'] = array(
				'ID'=>null,
				'USD_TO_BDT'=>null,  
				'EURO_TO_BDT'=>null,
				'GBP_TO_BDT'=>null,
				'REPORT_MONTH'=>null
			);
		}

		$this->load->library('form_validation');
		$this->form_validation->set_rules('USD_TO_BDT','USD TO BDT','required|trim|xss_clean');
		$this->form_validation->set_rules('EURO_TO_BDT','EURO TO BDT','required|trim|xss_clean');
		$this->form_validation->set_rules('GBP_TO_BDT','GBP TO BDT','required|trim|xss_clean');
		$this->form_validation->set_rules('REPORT_MONTH','REPORT MONTH','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_corporate_exchange_rate', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('exchange_rate_id');
		$calculative_month = $this->input->post("REPORT_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE WHERE REPORT_MONTH=?", array($report_date), 'You are not allowed to enter duplicate curency rate', 'ID', $input->exchange_rate_id, $data, 'master/create_corporate_exchange_rate');

		# remove cache
		$this->webspice->remove_cache('corp_ex_rate');
		
		# update process
		if( $input->exchange_rate_id ){
			#update query
			$sql = "UPDATE TBL_CORPORATE_EXCHANGE_RATE SET USD_TO_BDT=?, EURO_TO_BDT=?, GBP_TO_BDT=?, REPORT_MONTH=?, UPDATED_BY=?, UPDATED_DATE=?
			WHERE ID=?";
			$this->db->query($sql, array($input->USD_TO_BDT, $input->EURO_TO_BDT, $input->GBP_TO_BDT, $report_date, $this->webspice->get_user_id(), $this->webspice->now(), $input->exchange_rate_id)); 
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('exchange_rate_id');
			$this->webspice->force_redirect($url_prefix.'manage_corporate_exchange_rate');
			return false;
		}
		// var_dump($input->cutt_off_data);exit;
		$sql = "
		INSERT INTO TBL_CORPORATE_EXCHANGE_RATE
		(USD_TO_BDT, EURO_TO_BDT, GBP_TO_BDT, REPORT_MONTH, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, ?, ?, 7)";
		$result = $this->db->query($sql, array( $input->USD_TO_BDT, $input->EURO_TO_BDT, $input->GBP_TO_BDT, $report_date, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_corporate_exchange_rate', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_corporate_exchange_rate');
		}
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_corporate_exchange_rate(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_corporate_exchange_rate');
		$this->webspice->permission_verify('manage_corporate_exchange_rate');
		$this->load->database();
		$orderby = ' ORDER BY ID DESC '; 
		$groupby = null;
		$where = '';
		$page_index = 0;
		$no_of_record = 10;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		$initialSQL = "SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE ";
	   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_CORPORATE_EXCHANGE_RATE',
				$InputField = array(),
				$Keyword = array('ID', 'USD_TO_BDT', 'EURO_TO_BDT', 'GBP_TO_BDT'),
				$AdditionalWhere = null,
				$DateBetween = array('REPORT_MONTH','date_from','date_end')  
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
		}
	    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
				$_SESSION['sql'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql'] );
			$data['get_record'] = $record->result();
			$this->load->view('master/print_corporate_exchange_rate',$data);
			return false;
			break;
			
			case 'edit':

			$this->webspice->edit_generator($TableName='TBL_CORPORATE_EXCHANGE_RATE', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='create_corporate_exchange_rate', $PermissionName='create_corporate_exchange_rate', $StatusCheck=null, $Log='edit_corporate_exchange_rate');          
			return false;
			break;
			
		
		}
	    # default
		$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		
	    	# only for pager
		if( $criteria == 'page' && !$this->input->post('filter') ){
			$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
			$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		}
			# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( $initialSQL .$groupby );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_corporate_exchange_rate/page/', 10 );
		}
		$result = $this->db->query($sql)->result();
		$_SESSION['sql']=$sql;
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('master/manage_corporate_exchange_rate', $data);
	}
	
	
	
	function mt_rate($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'mt_rate');
		$this->webspice->permission_verify('mt_rate, manage_mt_rate');

		if( !isset($data['edit']) ){
			$data['edit'] = array(
				'ID'=>null,
				'B2B_RATIO'=>null,
				'B2C_RATIO'=>null,
				'B2B_RATIO_COST'=>null,
				'B2C_RATIO_COST'=>null,
				'AIT'=>null,
				'REPORT_MONTH'=>null
			);
		}

		$this->load->library('form_validation');
		$this->form_validation->set_rules('B2B_RATIO','B2B RATIO','required|trim|xss_clean');
		$this->form_validation->set_rules('B2C_RATIO','B2C RATIO','required|trim|xss_clean');
		$this->form_validation->set_rules('B2B_RATIO_COST','B2B RATIO COST','required|trim|xss_clean');
		$this->form_validation->set_rules('B2C_RATIO_COST','B2C RATIO COST','required|trim|xss_clean');
		$this->form_validation->set_rules('AIT','AIT','required|trim|xss_clean');
		$this->form_validation->set_rules('REPORT_MONTH','REPORT MONTH','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/mt_rate', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('mt_rate_id');
		$calculative_month = $this->input->post("REPORT_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_MT_RATE WHERE REPORT_MONTH=?", array($report_date), 'You are not allowed to enter duplicate curency rate', 'ID', $input->mt_rate_id, $data, 'master/mt_rate');

		# remove cache
		//$this->webspice->remove_cache('mt_rate');
		
		# update process
		if( $input->mt_rate_id ){
			#update query
			$sql = "UPDATE TBL_MT_RATE SET AIT=? , B2B_RATIO_COST=?,B2C_RATIO_COST=?, B2B_RATIO=?, B2C_RATIO=?, REPORT_MONTH=?, UPDATED_BY=?, UPDATED_DATE=?
			WHERE ID=?";
			$this->db->query($sql, array(trim($input->AIT), trim($input->B2B_RATIO_COST),trim($input->B2C_RATIO_COST),trim($input->B2B_RATIO), trim($input->B2C_RATIO), trim($report_date), $this->webspice->get_user_id(), $this->webspice->now(), $input->mt_rate_id)); 
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('mt_rate_id');
			$this->webspice->force_redirect($url_prefix.'manage_mt_rate');
			return false;
		}
		// var_dump($input->cutt_off_data);exit;
		$sql = "
		INSERT INTO TBL_MT_RATE
		(AIT , B2B_RATIO_COST,B2C_RATIO_COST, B2B_RATIO, B2C_RATIO, REPORT_MONTH, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(? , ?, ?, ?, ?, ?, ?, ?, 7)";
		$result = $this->db->query($sql, array( trim($input->AIT) , trim($input->B2B_RATIO_COST),trim($input->B2C_RATIO_COST), trim($input->B2B_RATIO),trim($input->B2C_RATIO), $report_date, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_mt_rate', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_mt_rate');
		}
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_mt_rate(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_mt_rate');
		$this->webspice->permission_verify('manage_mt_rate');
		$this->load->database();
		$orderby = ' ORDER BY ID DESC '; 
		$groupby = null;
		$where = '';
		$page_index = 0;
		$no_of_record = 10;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		$initialSQL = "SELECT * FROM TBL_MT_RATE ";
	   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_MT_RATE',
				$InputField = array(),
				$Keyword = array('ID', 'B2B_RATIO', 'B2B_RATIO_COST','B2C_RATIO_COST', 'B2C_RATIO'),
				$AdditionalWhere = null,
				$DateBetween = array('REPORT_MONTH','date_from','date_end')  
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
		}
	    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
				$_SESSION['sql'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql'] );
			$data['get_record'] = $record->result();
			$this->load->view('master/print_mt_rate',$data);
			return false;
			break;
			
			case 'edit':

			$this->webspice->edit_generator($TableName='TBL_MT_RATE', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='mt_rate', $PermissionName='mt_rate', $StatusCheck=null, $Log='edit_mt_rate');          
			return false;
			break;
			
		
		}
	    # default
		$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		
	    	# only for pager
		if( $criteria == 'page' && !$this->input->post('filter') ){
			$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
			$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		}
			# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( $initialSQL .$groupby );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_mt_rate/page/', 10 );
		}
		$result = $this->db->query($sql)->result();
		$_SESSION['sql']=$sql;
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('master/manage_mt_rate', $data);
	}
	function tax_configuration($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'tax_configuration');
		$this->webspice->permission_verify('manage_tax_configuration, tax_configuration');

		if( !isset($data['edit']) ){
			$data['edit'] = array(
				'ID'=>null,
				'RATE'=>null,  
				'OPERATOR_TYPE'=>null
			);
		}

		$this->load->library('form_validation');
		$this->form_validation->set_rules('RATE','RATE','required|trim|xss_clean');
		$this->form_validation->set_rules('OPERATOR_TYPE','OPERATOR TYPE','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/tax_configuration', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('configuration_id');
		#duplicate test
	//	$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE WHERE REPORT_MONTH=?", array($report_date), 'You are not allowed to enter duplicate curency rate', 'ID', $input->exchange_rate_id, $data, 'master/create_corporate_exchange_rate');

		# remove cache
		$this->webspice->remove_cache('configuration_tax');
		
		# update process
		if( $input->configuration_id ){
			#update query
			$sql = "UPDATE TBL_TAX_CONFIGURATION SET OPERATOR_TYPE=?, RATE=?, UPDATED_BY=?, UPDATED_DATE=?
			WHERE ID=?";
			$this->db->query($sql, array($input->OPERATOR_TYPE, $input->RATE, $this->webspice->get_user_id(), $this->webspice->now(), $input->configuration_id)); 
			//$this->webspice->message_board('Record has been updated!');
			//$this->webspice->log_me('configuration_id');
		//	$this->webspice->force_redirect($url_prefix.'manage_tax_configuration');
		//	return false;
		}
		// var_dump($input->cutt_off_data);exit;
		$sql = "
		INSERT INTO TBL_TAX_CONFIGURATION
		(OPERATOR_TYPE, RATE, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, 7)";
		$result = $this->db->query($sql, array( $input->OPERATOR_TYPE, $input->RATE, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_tax_configuration', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_tax_configuration');
		}
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_tax_configuration(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_tax_configuration');
		$this->webspice->permission_verify('manage_tax_configuration');
		$this->load->database();
		$orderby = ' ORDER BY ID DESC '; 
		$groupby = null;
		$where = '';
		$page_index = 0;
		$no_of_record = 10;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		$initialSQL = "SELECT * FROM TBL_TAX_CONFIGURATION ";
	   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_TAX_CONFIGURATION',
				$InputField = array(),
				$Keyword = array('ID', 'OPERATOR_TYPE', 'RATE'),
				$AdditionalWhere = null,
				$DateBetween = array('REPORT_MONTH','date_from','date_end')  
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
		}
	    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
				$_SESSION['sql'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sql'] );
			$data['get_record'] = $record->result();
			$this->load->view('master/print_tax_configuration',$data);
			return false;
			break;
			
			case 'edit':

			$this->webspice->edit_generator($TableName='TBL_TAX_CONFIGURATION', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='tax_configuration', $PermissionName='tax_configuration', $StatusCheck=null, $Log='edit_tax_configuration');          
			return false;
			break;
			
		
		}
	    # default
		$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		
	    	# only for pager
		if( $criteria == 'page' && !$this->input->post('filter') ){
			$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
			$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		}
			# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( $initialSQL .$groupby );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_corporate_exchange_rate/page/', 10 );
		}
		$result = $this->db->query($sql)->result();
		$_SESSION['sql']=$sql;
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('master/manage_tax_configuration', $data);
	}
	
	

	function manage_data_for_isms_journal(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_data_for_isms_journal');
		$this->webspice->permission_verify('manage_data_for_isms_journal');
		$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = 'LIMIT ' .$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
	    if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = "SELECT * FROM TBL_ISMS_DATA_FOR_JOURNAL ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_ISMS_DATA_FOR_JOURNAL',
				$InputField = array(),
				$Keyword = array("OPERATOR_NAME","ACCURED", "POST_VOICE","PRE_VOICE","POST_SMS","PRE_SMS"),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = 'Last Created';
					$this->load->view('master/print_data_for_isms_journal',$data);
					return false;
	        break;
	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	           
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
				//dd($sql);
			}
			# load all records
			if( !$this->input->post('filter') ){
				$count_data = $this->db->query( $initialSQL .$groupby );
				$count_data = $count_data->result();
				$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_data_for_isms_journal/page/', 10 );
			}
	    $result = $this->db->query($sql)->result();
	   // $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('master/manage_data_for_isms_journal', $data);
	}

	
	
	
	
	
	
	
	
	
	function create_sonali_bank_rate($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_sonali_bank_rate');
		$this->webspice->permission_verify('create_sonali_bank_rate, manage_sonali_bank_rate');

		if( !isset($data['edit']) ){
			$data['edit'] = array(
				'ID'=>null,
				'BUYING_TT_CLEAN'=>null,  
				'SELLING_BC'=>null,
				'REPORT_MONTH'=>null
			);
		}

		$this->load->library('form_validation');
		$this->form_validation->set_rules('BUYING_TT_CLEAN','BUYING TT CLEAN','required|trim|xss_clean');
		$this->form_validation->set_rules('SELLING_BC','SELLING BC','required|trim|xss_clean');
		$this->form_validation->set_rules('REPORT_MONTH','REPORT MONTH','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_sonali_bank_rate', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('rate_id');
		$calculative_month = $this->input->post("REPORT_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_SONALI_BANK_RATE WHERE REPORT_MONTH=?", array($report_date), 'You are not allowed to enter duplicate curency rate', 'ID', $input->rate_id, $data, 'master/create_sonali_bank_rate');

		# remove cache
		//$this->webspice->remove_cache('rate');
		
		# update process
		if( $input->rate_id ){
			#update query
			$sql = "UPDATE TBL_SONALI_BANK_RATE SET BUYING_TT_CLEAN=?, SELLING_BC=?, REPORT_MONTH=?, UPDATED_BY=?, UPDATED_DATE=?
			WHERE ID=?";
			$this->db->query($sql, array($input->BUYING_TT_CLEAN, $input->SELLING_BC, $report_date, $this->webspice->get_user_id(), $this->webspice->now(), $input->rate_id)); 
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('rate_id');
			$this->webspice->force_redirect($url_prefix.'manage_sonali_bank_rate');
			return false;
		}
		// var_dump($input->cutt_off_data);exit;
		$sql = "
		INSERT INTO TBL_SONALI_BANK_RATE
		(BUYING_TT_CLEAN, SELLING_BC, REPORT_MONTH, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, ?, 7)";
		$result = $this->db->query($sql, array( $input->BUYING_TT_CLEAN, $input->SELLING_BC,  $report_date, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_sonali_bank_rate', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_sonali_bank_rate');
		}
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_sonali_bank_rate(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_sonali_bank_rate');
		$this->webspice->permission_verify('manage_sonali_bank_rate');
		$this->load->database();
		$orderby = ' ORDER BY ID DESC '; 
		$groupby = null;
		$where = '';
		$page_index = 0;
		$no_of_record = 10;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		$initialSQL = "SELECT * FROM TBL_SONALI_BANK_RATE ";
	   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_SONALI_BANK_RATE',
				$InputField = array(),
				$Keyword = array('ID', 'BUYING_TT_CLEAN', 'SELLING_BC'),
				$AdditionalWhere = null,
				$DateBetween = array('REPORT_MONTH','date_from','date_end')  
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
		}
	    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['sonali_sql']) || !$_SESSION['sonali_sql'] ){
				$_SESSION['sonali_sql'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['sonali_sql'] );
			$data['get_record'] = $record->result();
			$this->load->view('master/print_sonali_bank_rate',$data);
			return false;
			break;
			
			case 'edit':
			$this->webspice->edit_generator($TableName='TBL_SONALI_BANK_RATE', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='create_sonali_bank_rate', $PermissionName='create_sonali_bank_rate', $StatusCheck=null, $Log='edit_sonali_bank_rate');          
			return false;
			break;
			
		
		}
	    # default
		$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		
	    	# only for pager
		if( $criteria == 'page' && !$this->input->post('filter') ){
			$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
			$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		}
			# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( $initialSQL .$groupby );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_sonali_bank_rate/page/', 10 );
		}
		$result = $this->db->query($sql)->result();
		$_SESSION['sonali_sql']=$sql;
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('master/manage_sonali_bank_rate', $data);
	}

	function create_citi_bank_rate($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_citi_bank_rate');
		$this->webspice->permission_verify('create_citi_bank_rate, manage_citi_bank_rate');

		if( !isset($data['edit']) ){
			$data['edit'] = array(
				'ID'=>null,
				'BUYING_TT_CLEAN'=>null,  
				'SELLING_BC'=>null,
				'REPORT_MONTH'=>null
			);
		}

		$this->load->library('form_validation');
		$this->form_validation->set_rules('BUYING_TT_CLEAN','BUYING TT CLEAN','required|trim|xss_clean');
		$this->form_validation->set_rules('SELLING_BC','SELLING BC','required|trim|xss_clean');
		$this->form_validation->set_rules('REPORT_MONTH','REPORT MONTH','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_citi_bank_rate', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('rate_id');
		$report_date = $this->input->post("REPORT_MONTH");
		//$report_date=date("Y-m-d",$calculative_month);
		
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_CITI_BANK_RATE WHERE REPORT_MONTH=?", array($report_date), 'You are not allowed to enter duplicate curency rate', 'ID', $input->rate_id, $data, 'master/create_sonali_bank_rate');

		# remove cache
		//$this->webspice->remove_cache('rate');
		
		# update process
		if( $input->rate_id ){
			#update query
			$sql = "UPDATE TBL_CITI_BANK_RATE SET BUYING_TT_CLEAN=?, SELLING_BC=?, REPORT_MONTH=?, UPDATED_BY=?, UPDATED_DATE=?
			WHERE ID=?";
			$this->db->query($sql, array($input->BUYING_TT_CLEAN, $input->SELLING_BC, $report_date, $this->webspice->get_user_id(), $this->webspice->now(), $input->rate_id)); 
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('rate_id');
			$this->webspice->force_redirect($url_prefix.'manage_citi_bank_rate');
			return false;
		}
		// var_dump($input->cutt_off_data);exit;
		$sql = "
		INSERT INTO TBL_CITI_BANK_RATE
		(BUYING_TT_CLEAN, SELLING_BC, REPORT_MONTH, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, ?, 7)";
		$result = $this->db->query($sql, array( $input->BUYING_TT_CLEAN, $input->SELLING_BC,  $report_date, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_citi_bank_rate', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_citi_bank_rate');
		}
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_citi_bank_rate(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_citi_bank_rate');
		$this->webspice->permission_verify('manage_citi_bank_rate');
		$this->load->database();
		$orderby = ' ORDER BY ID DESC '; 
		$groupby = null;
		$where = '';
		$page_index = 0;
		$no_of_record = 10;
		$limit = null;
		$filter_by = 'Last Created';
		$data['pager'] = null;
		$criteria = $this->uri->segment(2);
		$key = $this->uri->segment(3);
		if ($criteria == 'page') {
			$page_index = (int)$key;
			$page_index < 0 ? $page_index=0 : $page_index=$page_index;
		}
		$initialSQL = "SELECT * FROM TBL_CITI_BANK_RATE ";
	   	# filtering records
		if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
				$TableName = 'TBL_CITI_BANK_RATE',
				$InputField = array(),
				$Keyword = array('ID', 'BUYING_TT_CLEAN', 'SELLING_BC'),
				$AdditionalWhere = null,
				$DateBetween = array('REPORT_MONTH','date_from','date_end')  
			);
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
		}
	    # action area
		switch ($criteria) {
			case 'print':
			case 'csv':
			if( !isset($_SESSION['citi_sql']) || !$_SESSION['citi_sql'] ){
				$_SESSION['citi_sql'] = $initialSQL . $where . $orderby;
				$_SESSION['filter_by'] = $filter_by;
			}
			$record = $this->db->query( $_SESSION['citi_sql'] );
			$data['get_record'] = $record->result();
			$this->load->view('master/print_citi_bank_rate',$data);
			return false;
			break;
			
			case 'edit':
			$this->webspice->edit_generator($TableName='TBL_CITI_BANK_RATE', $KeyField='ID', $key, $RedirectController='master_controller', $RedirectFunction='create_citi_bank_rate', $PermissionName='create_citi_bank_rate', $StatusCheck=null, $Log='edit_citi_bank_rate');          
			return false;
			break;
			
		
		}
	    # default
		$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		
	    	# only for pager
		if( $criteria == 'page' && !$this->input->post('filter') ){
			$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
			$sql = $initialSQL . $where . $groupby . $orderby . $limit;
		}
			# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( $initialSQL .$groupby );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_sonali_bank_rate/page/', 10 );
		}
		$result = $this->db->query($sql)->result();
		$_SESSION['citi_sql']=$sql;
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('master/manage_citi_bank_rate', $data);
	}
}	
	
	
	

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */