<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dispute_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	function dispute_management($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'dispute_management');
		$this->webspice->permission_verify('dispute_management');
		if( !$_POST ){
			$this->load->view('dispute_module/dispute_management', $data);
			return false;
		}
		$input = $this->webspice->get_input();
		$invoice_received_from = $input->INVOICE_RECEIVED_FROM;
		$invoice_received_to = $input->INVOICE_RECEIVED_TO;
	  if(array_key_exists("ios_summery",$input)){
	  	$data['ios_summery']="yes";
	    $data['excluded_igw']= $input->EXCLUDED_IGW;
	    $igw_sql = "SELECT A.IGW,SUM(A.INVOICE_AMOUNT) AS TOTAL_IGW_INVOICE_AMOUNT,B.IGW,SUM(B.INVOICE_AMOUNT) AS TOTAL_ICX_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.IGW=B.IGW AND A.ICX=B.ICX";
      $bl_sql = "SELECT B.IGW,B.ICX,B.X_VALUE,B.Y_VALUE,B.Z_VALUE,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS TOTAL_ICX_Z_VALUE,(SELECT SUM(C.Z_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_Z_VALUE,(SELECT SUM(C.X_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_X_VALUE,(SELECT SUM(C.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS C WHERE A.ICX=C.OPERATOR_NAME) AS TOTAL_BL_Y_VALUE FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW AND A.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."' AND B.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_to."' LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON B.ICX = C.OPERATOR_NAME AND B.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_to."' AND C.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_to."'";
      $igw_group_by = " GROUP BY A.IGW" ;
		  $igw_order_by = "" ;
		  $bl_group_by="";
		if(isset($invoice_received_from) && isset($invoice_received_to)){
			 $igw_sql.=" AND A.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_to."' AND B.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_to."'";
		}		
		$igw_sql=$igw_sql.$igw_group_by;
		$bl_sql=$bl_sql.$bl_group_by;
    $data["get_igw_record_for_ios_summery_report"] = $this->db->query($igw_sql)->result();
    $data["get_bl_record_for_ios_summery_report"] = $this->db->query($bl_sql)->result();
	  }else{
	  	$data['ios_summery']="no";	
	  }
	  if(array_key_exists("bl_vs_ios_reconcilation",$input)){
	  $data['bl_vs_ios_reconcilation']='yes';
	  $sql="SELECT A.ICX,SUM(A.X_VALUE) AS IGW_X_VALUE,SUM(A.Y_VALUE) AS IGW_Y_VALUE,SUM(A.Z_VALUE) AS IGW_Z_VALUE,SUM(A.BILLED_DURATION_MINS) AS IGW_BILLED_DURATION_MIN,(SELECT SUM(B.CHARGED_UNIT_IN_MIN) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.X_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Z_VALUE,(SELECT SUM(B.ICX_PORTION) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_PERCENTAGE_OF_Z,(SELECT SUM(B.IGW_PORTION) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_IGW_PORTION_FOR_INVOICE,(SELECT SUM(B.Y_VALUE) FROM TBL_FULL_MONTH_MOID AS B WHERE A.ICX=B.OPERATOR_NAME) AS BL_TOTAL_Y_VALUE_FOR_INVOICE FROM TBL_IGW_DATA AS A LEFT JOIN TBL_FULL_MONTH_MOID AS B ON A.ICX=B.OPERATOR_NAME";
	  $group_by = " GROUP BY A.ICX " ;
		$order_by = "" ;
		$igw_sql="SELECT IGW,SUM(X_VALUE) AS TOTAL_IGW_X_VALUE,SUM(Y_VALUE) AS TOTAL_IGW_Y_VALUE,SUM(Z_VALUE) AS TOTAL_IGW_Z_VALUE,SUM(INVOICE_VALUE_OF_Z) AS TOTAL_INVOICE_VALUE_OF_Z,SUM(INVOICE_AMOUNT) AS TOTAL_INVOICE_AMOUNT,SUM(BILLED_DURATION_MINS) AS TOTAL_BILLED_DURATION_MINS FROM TBL_IGW_DATA";
    $igw_group_by =" GROUP BY IGW";
    if(isset($calculative_month)){
			 $sql.=" AND A.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."' AND  B.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."'";
			 $where = "";
			 $igw_where=" WHERE REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."'";
		}
		$sql = $sql.$where.$group_by.$order_by;
		$igw_sql = $igw_sql.$igw_where.$igw_group_by;
    $data["get_record_for_bl_vs_ios_report"] = $this->db->query($sql)->result();  
    $data["igw_get_record_for_bl_vs_ios_report"] = $this->db->query($igw_sql)->result();
	  }else{$data['bl_vs_ios_reconcilation']='no';}
	  if(array_key_exists("single_ios_sort_summery",$input)){
	  	$data['single_ios_sort_summery']='yes';
	  	$data['igw']= $input->IOS;
	  	$sql="SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT,SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.NO_OF_CALLS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(B.INVOICE_VALUE_OF_Z) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_INVOICE_VALUE_OF_Z,(SELECT SUM(B.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(B.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	    $group_by = " GROUP BY A.ICX" ;
		  $order_by = "" ;
		  if(isset($calculative_month)){
			 $sql.=" AND A.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."' AND B.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."' AND C.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."'";
			 $where = " WHERE A.IGW='".$data['igw']."'";
		  }
		  $sql = $sql.$where.$group_by.$order_by;
      $data["get_record_for_single_ios_short_summery"] = $this->db->query($sql)->result(); 
	  }else{$data['single_ios_sort_summery']='no';}
	  if(array_key_exists("single_ios_detail_summery",$input)){
	  	$data['single_ios_detail_summery']='yes';
	  	$sql="SELECT A.IGW AS IGW_IGW, A.ICX AS IGW_ICX,A.NO_OF_CALLS AS IGW_NO_OF_CALLS,A.BILLED_DURATION_MINS AS IGW_BILLED_DURATION_MINS,A.X_VALUE AS IGW_X_VALUE,A.Y_VALUE AS IGW_Y_VALUE,A.Z_VALUE AS IGW_Z_VALUE,A.INVOICE_AMOUNT AS IGW_INVOICE_AMOUNT,B.IGW AS ICX_IGW, B.ICX AS ICX_ICX,B.NO_OF_CALLS AS ICX_NO_OF_CALLS,B.BILLED_DURATION_MINS AS ICX_BILLED_DURATION_MINS,B.X_VALUE AS ICX_X_VALUE,B.Y_VALUE AS ICX_Y_VALUE,B.Z_VALUE AS ICX_Z_VALUE,B.INVOICE_AMOUNT AS ICX_INVOICE_AMOUNT, SUM(C.NO_OF_CALLS) AS BL_TOTAL_NO_OF_CALLS,SUM(C.X_VALUE) AS BL_TOTAL_X_VALUE,SUM(C.Y_VALUE) AS BL_TOTAL_Y_VALUE,SUM(C.Z_VALUE) AS BL_TOTAL_Z_VALUE,SUM(C.ICX_PORTION) AS BL_TOTAL_ICX_PORTION,SUM(C.IGW_PORTION) AS BL_TOTAL_IGW_PORTION,SUM(C.CHARGED_UNIT_IN_MIN) AS BL_TOTAL_CHARGED_UNIT_IN_MIN,(SELECT SUM(B.NO_OF_CALLS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_NO_OF_CALLS,(SELECT SUM(B.X_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_X_VALUE,(SELECT SUM(B.Y_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Y_VALUE,(SELECT SUM(B.Z_VALUE) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_Z_VALUE,(SELECT SUM(B.INVOICE_VALUE_OF_Z) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_INVOICE_VALUE_OF_Z,(SELECT SUM(B.BILLED_DURATION_MINS) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_BILLED_DURATION_MINS,(SELECT SUM(B.INVOICE_AMOUNT) FROM TBL_ICX_DATA AS B WHERE A.ICX=B.ICX) AS ICX_TOTAL_INVOICE_AMOUNT FROM TBL_IGW_DATA AS A LEFT JOIN TBL_ICX_DATA AS B ON A.ICX = B.ICX AND A.IGW=B.IGW LEFT JOIN TBL_FULL_MONTH_MOID AS C  ON A.ICX = C.OPERATOR_NAME";
	    $group_by = " GROUP BY A.ICX" ;
		  $order_by = "" ;
	  	if(isset($calculative_month)){
			 $sql.=" AND A.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."' AND B.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."' AND C.REPORT_DATE BETWEEN '".$invoice_received_from."' AND '".$invoice_received_from."'";
			 $where = " WHERE A.IGW='".$data['igw']."'";
		  }
	  	$sql = $sql.$where.$group_by.$order_by;
      $data["get_record_for_single_ios_detail_summery"] = $this->db->query($sql)->result();
	  }else{$data['single_ios_detail_summery']='no';}
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export') ){
  		$data['action_type'] = 'csv';
  	}
  	$data['filter_by'] .= "Month: ".date("m-Y",$calculative_month) ;
		$data['current_date']=date("d-M-Y");
		$data['report_name']="IOS Reconcilation Report";
		if( $this->input->post('email')){
  		$email_sql="SELECT EMAIL_ADDRESS FROM TBL_OPERATOR WHERE OPERATOR_NAME='".$data['igw']."'";
  	  $email_address=$this->db->query($email_sql)->row();
  	  $data['action_type']='Email';
  	  $html = $this->load->view('report/print_ios_reconcilation_report', $data, true);
  	  $this->webspice->create_file($html, $this->webspice->get_path('custom_full').'/ios_recouncilation.xls');     
  	  $this->webspice->email('iubat.sathy@gmail.com', 'IOS Reconcilation', 'aaaaaa', null, null, $this->webspice->get_path('custom_full').'/ios_recouncilation.xls');	
  	 // $this->webspice->message_board('Record has been sent to IOS!');
  	  $data['action_type']='view';
  	}
   # if(empty($data["get_record"]) && empty($data["get_record"])){
    #	$this->webspice->message_board('Record is not found!');
    #	$this->load->view('report/bl_vs_ios_reconciliation', $data);
		#	return false;
    #	}
		$this->load->view('report/print_ios_reconcilation_report', $data);   
	}
	
	
	
	

}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */