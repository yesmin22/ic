<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Btrc_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	Log Prefix:
	login_attempt - Login Ateempt
	login_success
	unauthorized_access
	password_retrieve_request
	password_changed
	insert_error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/

	function subscriber_and_cost($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'subscriber_and_cost');
			$this->webspice->permission_verify('subscriber_and_cost,manage_subscriber_and_cost');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATOR_NAME'=> null,
				'OPERATOR_SHORT_CODE'=> null,
				'OPERATOR_TYPE' => null,
				'PROJECT_CODE' => null,
				'ID' => null,
				'ATTENTION' => null,
				'ADDRESS' => null,
				'TEL_NO' => null,
				'VAT_REG_NO' => null,
				'SUPPLIER_CODE' => null,
				'REF_NO' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('operator_name','Operator Name','required|trim|xss_clean');
			
			if( !$this->form_validation->run() ){
					$this->load->view('btrc/subscriber_and_cost', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_OPERATOR WHERE OPERATOR_NAME=? AND OPERATOR_TYPE=? AND PROJECT_CODE=? ", array( $input->operator_name,$input->operator_type,$input->projrct_code), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_operator');
			# remove cache
			$this->webspice->remove_cache('operator');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_OPERATOR SET SUPPLIER_CODE=?, OPERATOR_NAME=?, OPERATOR_SHORT_CODE=?, PROJECT_CODE=?, OPERATOR_TYPE=?, ATTENTION=?, ADDRESS=?, TEL_NO=?, VAT_REG_NO=?, REF_NO=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->supplier_code,$input->operator_name,$input->short_code,$input->projrct_code, $input->operator_type, $input->attention, $input->address, $input->tel_no, $input->vat_reg_no, $input->ref_no, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('operator_updated - '.$input->operator_name);
				$this->webspice->force_redirect($url_prefix.'manage_operator');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_OPERATOR
			(SUPPLIER_CODE, OPERATOR_NAME, OPERATOR_SHORT_CODE, PROJECT_CODE, OPERATOR_TYPE, ATTENTION, ADDRESS, TEL_NO, VAT_REG_NO, REF_NO, CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->supplier_code,$input->operator_name, $input->short_code,$input->projrct_code, $input->operator_type, $input->attention, $input->address, $input->tel_no, $input->vat_reg_no,  $input->ref_no, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('create_operator', true) ){
				$this->webspice->force_redirect($url_prefix.'create_operator');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	function create_tb_gl($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_tb_gl');
			$this->webspice->permission_verify('create_tb_gl,manage_tb_gl');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'GL_CODE'=> null,
				'GL_DESCRIPTION'=> null,
				'SUB_TYPE' => null,
				'ID' => null,
				'TYPE'=> null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('GL_CODE','GL Code','required|trim|xss_clean');
			$this->form_validation->set_rules('GL_DESCRIPTION','GL Description','required|trim|xss_clean');
			$this->form_validation->set_rules('SUB_TYPE','Sub Type','required|trim|xss_clean');
			$this->form_validation->set_rules('TYPE','Type','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('btrc/create_tb_gl', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_TB_GL WHERE GL_CODE=?", array( $input->GL_CODE), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_tb_gl');
			# remove cache
			$this->webspice->remove_cache('tb_gl');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_TB_GL SET GL_CODE=?,TYPE=?, SUB_TYPE=?, GL_DESCRIPTION=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->GL_CODE,$input->TYPE,$input->SUB_TYPE,$input->GL_DESCRIPTION,$this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('tb_gl_updated - '.$input->GL_CODE);
				$this->webspice->force_redirect($url_prefix.'manage_tb_gl');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_TB_GL
			(GL_CODE,TYPE,SUB_TYPE, GL_DESCRIPTION,CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->GL_CODE,$input->TYPE,$input->SUB_TYPE, $input->GL_DESCRIPTION, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('create_tb_gl', true) ){
				$this->webspice->force_redirect($url_prefix.'create_tb_gl');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_tb_gl(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_tb_gl');
			$this->webspice->permission_verify('manage_tb_gl');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = ' LIMIT '.$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = " SELECT TBL_TB_GL.* FROM TBL_TB_GL ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_TB_GL',
				$InputField = array(),
				$Keyword = array('GL_CODE','SUB_TYPE','TYPE','GL_DESCRIPTION'),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('btrc/print_tb_gl',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_TB_GL', $KeyField='ID', $key, $RedirectController='btrc_controller', $RedirectFunction='create_tb_gl', $PermissionName='create_tb_gl', $StatusCheck=null, $Log='edit_tb_gl');          
					return false;
          break;
	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    # only for pager
	    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
      }
			
			# load all records
			if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_tb_gl/page/', 10 );
		}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('btrc/manage_tb_gl', $data);
	}
	function MIS_Rev_and_Y_Value($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'MIS_Rev_and_Y_Value');
			$this->webspice->permission_verify('MIS_Rev_and_Y_Value,manage_MIS_Rev_and_Y_Value');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'REPORT_MONTH'=> null,
				'X_VALUE'=> null,
				'Y_VALUE' => null,
				'Z_VALUE' => null,
				'ID' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('REPORT_MONTH','Report Month','required|trim|xss_clean');
			$this->form_validation->set_rules('X_VALUE','X Value','required|trim|xss_clean');
			$this->form_validation->set_rules('Y_VALUE','X Value','required|trim|xss_clean');
			$this->form_validation->set_rules('Z_VALUE','Z Value','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('btrc/mis_rev_and_y_value', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		//  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_MIS_REV_AND_Y_VALUE WHERE RE=? AND SUB_TYPE=?", array( $input->GL_CODE,$input->SUB_TYPE), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_tb_gl');
			# remove cache
			$this->webspice->remove_cache('rev_y_value');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_MIS_REV_AND_Y_VALUE SET REPORT_MONTH=?, X_VALUE=?, Y_VALUE=?,Z_VALUE=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array(date("Y-m-d",$input->REPORT_MONTH),$input->X_VALUE,$input->Y_VALUE,$input->Z_VALUE,$this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('tb_gl_updated - '.$input->REPORT_MONTH);
				$this->webspice->force_redirect($url_prefix.'manage_MIS_Rev_and_Y_Value');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_MIS_REV_AND_Y_VALUE
			(REPORT_MONTH, X_VALUE, Y_VALUE,Z_VALUE,CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array(date("Y-m-d",$input->REPORT_MONTH),$input->X_VALUE, $input->Y_VALUE,$input->Z_VALUE, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('MIS_Rev_and_Y_Value', true) ){
				$this->webspice->force_redirect($url_prefix.'MIS_Rev_and_Y_Value');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_MIS_Rev_and_Y_Value(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_MIS_Rev_and_Y_Value');
			$this->webspice->permission_verify('manage_MIS_Rev_and_Y_Value');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = ' LIMIT '.$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = " SELECT TBL_MIS_REV_AND_Y_VALUE.* FROM TBL_MIS_REV_AND_Y_VALUE ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_MIS_REV_AND_Y_VALUE',
				$InputField = array(),
				$Keyword = array('X_VALUE','Y_VALUE','Z_VALUE'),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('btrc/print_mis_rev_and_y_value',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_MIS_REV_AND_Y_VALUE', $KeyField='ID', $key, $RedirectController='btrc_controller', $RedirectFunction='MIS_Rev_and_Y_Value', $PermissionName='MIS_Rev_and_Y_Value', $StatusCheck=null, $Log='edit_rev_y_value');          
					return false;
          break;
	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_MIS_Rev_and_Y_Value/page/', 10 );
		}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('btrc/manage_mis_rev_and_y_value', $data);
	}
	
	
	
	function subscriber_and_iig_cost($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'subscriber_and_iig_cost');
			$this->webspice->permission_verify('subscriber_and_iig_cost,manage_subscriber_and_iig_cost');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'REPORT_MONTH'=> null,
				'NO_OF_3G_SUBSCRIBER'=> null,
				'NO_OF_2G_SUBSCRIBER' => null,
        'POSTPAID_COLLECTION'=>null,
				'IIG_COST' => null,
				'ID' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('REPORT_MONTH','Report Month','required|trim|xss_clean');
			$this->form_validation->set_rules('NO_OF_3G_SUBSCRIBER','NO of 3G Subscriber','required|trim|xss_clean');
			$this->form_validation->set_rules('NO_OF_2G_SUBSCRIBER','NO of 2G Subscriber','required|trim|xss_clean');
			$this->form_validation->set_rules('IIG_COST','IIG Cost','required|trim|xss_clean');
			$this->form_validation->set_rules('POSTPAID_COLLECTION','Postpaid Collection','required|trim|xss_clean');
			
			if( !$this->form_validation->run() ){
					$this->load->view('btrc/subscriber_and_iig_cost', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  $this->webspice->db_field_duplicate_test("SELECT * FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH=?", array( date("Y-m-d",$input->REPORT_MONTH)), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'btrc/subscriber_and_iig_cost');
			# remove cache
			$this->webspice->remove_cache('subscriber_and_iig_cost');
			# update process
			if($input->ID ){
				#update query
				$sql = "UPDATE TBL_SUBSCRIBER_AND_IIG_COST SET POSTPAID_COLLECTION=?, REPORT_MONTH=?, NO_OF_3G_SUBSCRIBER=?, NO_OF_2G_SUBSCRIBER=?,IIG_COST=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->POSTPAID_COLLECTION,date("Y-m-d",$input->REPORT_MONTH),$input->NO_OF_3G_SUBSCRIBER,$input->NO_OF_2G_SUBSCRIBER,$input->IIG_COST,$this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('tb_gl_updated - '.$input->REPORT_MONTH);
				$this->webspice->force_redirect($url_prefix.'manage_subscriber_and_iig_cost');
				return false;
			}
			//$new_squence = $this->webspice->getLastInserted('TBL_OPERATOR','ID');
			$sql = "
			INSERT INTO TBL_SUBSCRIBER_AND_IIG_COST
			(POSTPAID_COLLECTION,REPORT_MONTH, NO_OF_3G_SUBSCRIBER, NO_OF_2G_SUBSCRIBER,IIG_COST,CREATED_BY, CREATED_DATE, STATUS)
			VALUES
			(?,?, ?, ?, ?, ?, ?, 7)";
			$result = $this->db->query($sql, array($input->POSTPAID_COLLECTION,date("Y-m-d",$input->REPORT_MONTH),$input->NO_OF_3G_SUBSCRIBER, $input->NO_OF_2G_SUBSCRIBER,$input->IIG_COST, $this->webspice->get_user_id(), $this->webspice->now()));
			if( !$result ){
				$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
				$this->webspice->force_redirect($url_prefix);
				return false;
			}
			$this->webspice->message_board('Record has been inserted successfully.');
			if( $this->webspice->permission_verify('subscriber_and_iig_cost', true) ){
				$this->webspice->force_redirect($url_prefix.'manage_subscriber_and_iig_cost');
			}
			$this->webspice->force_redirect($url_prefix);
	}
	
	function manage_subscriber_and_iig_cost(){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_subscriber_and_iig_cost');
			$this->webspice->permission_verify('manage_subscriber_and_iig_cost');
			$this->load->database();
	    $orderby = ' ORDER BY ID DESC '; 
	    $groupby = null;
	    $where = '';
	    $page_index = 0;
	    $no_of_record = 10;
	    $limit = ' LIMIT '.$no_of_record;
	    $filter_by = 'Last Created';
	    $data['pager'] = null;
	    $criteria = $this->uri->segment(2);
	    $key = $this->uri->segment(3);
			  if ($criteria == 'page') {
	    	$page_index = (int)$key;
	    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
	    }
	    $initialSQL = " SELECT TBL_SUBSCRIBER_AND_IIG_COST.* FROM TBL_SUBSCRIBER_AND_IIG_COST ";
	   	# filtering records
	    if( $this->input->post('filter') ){
				$result = $this->webspice->filter_generator(
				$TableName = 'TBL_SUBSCRIBER_AND_IIG_COST',
				$InputField = array(),
				$Keyword = array('POSTPAID_COLLECTION','NO_OF_3G_SUBSCRIBER','NO_OF_2G_SUBSCRIBER','IIG_COST'),
				$AdditionalWhere = null,
				$DateBetween = array()
				);
				$result['where'] ? $where = $result['where'] : $where=$where;
				$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
	   	}
	    # action area
	    switch ($criteria) {
	      case 'print':
	      case 'csv':
	        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
						$_SESSION['sql'] = $initialSQL . $where . $orderby;
						$_SESSION['filter_by'] = $filter_by;
	    		}
	    		$record = $this->db->query( $_SESSION['sql'] );
					$data['get_record'] = $record->result();
					$data['filter_by'] = $_SESSION['filter_by'];
					$this->load->view('btrc/print_subscriber_and_iig_cost',$data);
					return false;
	        break;
	          
			  case 'edit':
          $this->webspice->edit_generator($TableName='TBL_SUBSCRIBER_AND_IIG_COST', $KeyField='ID', $key, $RedirectController='btrc_controller', $RedirectFunction='subscriber_and_iig_cost', $PermissionName='subscriber_and_iig_cost', $StatusCheck=null, $Log='subscriber_and_iig_cost');          
					return false;
          break;
	    }
	    # default
	    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
	    
	    	# only for pager
			if( $criteria == 'page' && !$this->input->post('filter') ){
				$where = ' WHERE ID BETWEEN '.($page_index+1). ' AND '.($page_index + $no_of_record);
				$sql = $initialSQL . $where . $groupby . $orderby . $limit;
			}
			# load all records
			if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_subscriber_and_iig_cost/page/', 10 );
		}
	    $result = $this->db->query($sql)->result();
	    $_SESSION['sql']=$sql;
			$data['get_record'] = $result;
			$data['filter_by'] = $filter_by;
			$this->load->view('btrc/manage_subscriber_and_iig_cost', $data);
	}

	function upload_igw_collection($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$header_offset = 1;
		$column_offset = 1;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_igw_collection');
		$this->webspice->permission_verify('upload_igw_collection');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('btrc/upload_igw_collection', $data);
			return FALSE;
		}		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'btrc/upload_igw_collection');
		}
		
		$sheet_columns = array("Operators Name", "Value");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
				$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset,1);
			}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
				$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
			}else{
				echo 'File Invalid!';
				exit;
			}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_igw_collection');
			return FALSE;
		}
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$duplicate_where = array();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
			$data_list = $v;
			if ($v[0]==''||$v[0]=='Total') continue;
			$operators_name = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0])));
			$value = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1])));
			$values[] = array(
				"OPERATORS_NAME" => $operators_name, "VALUE" => $value, "REPORT_DATE" => $report_date,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);		
			# must have column value - column offset started from 1
			if( !isset($operators_name)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			//$duplicate_where[] = " (DATE_TIME='".$date_time."' AND OPERATOR='".$operator."' AND PREPOST_FLAG='".$prepost_flag."' AND TARIFFCLASS='".$tariffclass."') ";
		}
		
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_IGW_COLLECTION";
		$input = $this->webspice->get_input();
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_igw_collection'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_igw_collection', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_igw_collection');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function upload_cnc_revenue($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$header_offset = 1;
		$column_offset = 1;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_cnc_revenue');
		$this->webspice->permission_verify('upload_cnc_revenue');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('btrc/upload_cnc_revenue', $data);
			return FALSE;
		}		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'btrc/upload_cnc_revenue');
		}
		
		$sheet_columns = array("GL", "Value");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
				$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset,1);
			}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
				$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
			}else{
				echo 'File Invalid!';
				exit;
			}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_cnc_revenue');
			return FALSE;
		}
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$duplicate_where = array();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
			$data_list = $v;
			if ($v[0]==''||$v[0]=='Total') continue;
			$GL = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0])));
			$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_CNC_REVENUE WHERE GL=? AND REPORT_DATE=?", array( $GL,$report_date), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'btrc/upload_cnc_revenue');
			$value = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1])));
			$values[] = array(
				"GL" => $GL, "VALUE" => $value, "REPORT_DATE" => $report_date,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);		
			# must have column value - column offset started from 1
			if( !isset($operators_name)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			$duplicate_where[] = " (REPORT_DATE='".$report_date."'  AND GL='".$GL."') ";
		}
		
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_CNC_REVENUE";
		$input = $this->webspice->get_input();
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_cnc_revenue'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_cnc_revenue', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_cnc_revenue');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	function upload_postpaid_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$header_offset = 1;
		$column_offset = 1;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);

		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_postpaid_data');
		$this->webspice->permission_verify('upload_postpaid_data');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name'] ){
			$this->load->view('btrc/upload_postpaid_data', $data);
			return FALSE;
		}		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx'), 'sap_file', $data, 'btrc/upload_postpaid_data');
		}
		
		$sheet_columns = array("GL", "Description","Value");

		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ){
				$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset,1);
			}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values' ||  $_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
				$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
			}else{
				echo 'File Invalid!';
				exit;
			}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_postpaid_data');
			return FALSE;
		}
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$duplicate_where = array();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
			$data_list = $v;
			if ($v[0]==''||$v[0]=='Total') continue;
			$GL = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0])));
			$Description = trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1])));
			$Value= trim(str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2])));
		  $record = $this->db->query("SELECT * FROM TBL_TB_GL WHERE GL_CODE=".$GL);										 		
			$get_record = $record->row();
			$gl_type=$get_record->SUB_TYPE;
			$values[] = array(
				"GL" => $GL,"DESCRIPTION" => $Description, "VALUE" => $Value, "REPORT_DATE" => $report_date,"SUB_TYPE"=>$gl_type,
				"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7
			);		
			# must have column value - column offset started from 1
			if( !isset($operators_name)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
			//$duplicate_where[] = " (DATE_TIME='".$date_time."' AND OPERATOR='".$operator."' AND PREPOST_FLAG='".$prepost_flag."' AND TARIFFCLASS='".$tariffclass."') ";
		}
		
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();
		
		$is_value = false;
		$table_name = "TBL_POSTPAID_DATA";
		$input = $this->webspice->get_input();
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_POSTPAID_DATA WHERE GL=? AND REPORT_DATE=?", array( $input->GL_CODE,$report_date), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'btrc/upload_postpaid_data');
		
		
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_postpaid_data'); # log

		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_postpaid_data', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_postpaid_data');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	function upload_trial_balance($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$data_batch = 50; # how much row(s) inserted once
		ini_set('MAX_EXECUTION_TIME', 300);
		$header_offset = 1;
		$column_offset = 1;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'upload_trial_balance');
		$this->webspice->permission_verify('upload_trial_balance');
		
		if( !$_FILES || !$_FILES['sap_file']['tmp_name']){
			$this->load->view('uploader/upload_trial_balance', $data);
			return FALSE;
		}
		
		# verify file type
		if( $_FILES['sap_file']['tmp_name'] ){
			$this->webspice->check_file_type(array('csv','xlsx','xls'), 'sap_file', $data, 'uploader/upload_trial_balance');
		}
		
		$sheet_columns = array("Account", "Description", "Begin Balance", "Period Dr Amount", "Period Cr Amount", "Period Net Balance", "Period End Balance");
		# verify file type and read accordingly
		$get_data = array();
		if( $_FILES['sap_file']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || $_FILES['sap_file']['type'] == 'application/octet-stream' ||$_FILES['sap_file']['type'] = 'application/vnd.ms-excel'){
			$get_data = $this->webspice->excelx_reader($_FILES['sap_file']['tmp_name'], $sheet_columns, $header_offset, $column_offset,$SheetIndex=1);
		}elseif($_FILES['sap_file']['type'] == 'text/csv' || $_FILES['sap_file']['type'] == 'text/comma-separated-values'){
			$get_data = $this->webspice->csv_reader('sap_file', $sheet_columns);
		}else{
			echo 'File Invalid!';
			exit;
		}
		if( !is_array($get_data) ){
			$this->webspice->message_board($get_data.' Please try again.');
			$this->webspice->force_redirect($url_prefix.'upload_trial_balance');
			return FALSE;
		}
		
		# verify data
		$data_error = null;
		$values = array();
		$single_values = array();
		$unique_date = array();
		$unique_date_traker = null;
		$date_traker = null;
		$table_name = "TBL_TRIAL_BALANCE";
		$input = $this->webspice->get_input();
		$calculative_month = $this->input->post("CALCULATIVE_MONTH");
		$report_date=date("Y-m-d",$calculative_month);
		foreach($get_data as $k=>$v){
			$data_list = $v;
			$Account = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[0]));
			$record = $this->db->query("SELECT * FROM TBL_TB_GL WHERE GL_CODE='".$Account."'");										 		
			$get_record = $record->row();
			$gl_type=$get_record->SUB_TYPE;
			$Description = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[1]));
			if ($Description=='Total') continue;
			$Begin_Balance = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[2]));
			$Period_Dr_Amount = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[3]));
			$Period_Cr_Amount = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[4]));
			$Period_Net_Balance = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[5]));
			$Period_End_Balance = str_replace(array("'",'"',','), array('','',''), $this->webspice->clean_input($data_list[6]));
			$values[] = array("SUB_TYPE"=>$gl_type,"ACCOUNT" => $Account, "DESCRIPTION" => $Description, "BEGIN_BALANCE" => $Begin_Balance, "PERIOD_DR_AMOUNT" => $Period_Dr_Amount, "PERIOD_CR_AMOUNT" => $Period_Cr_Amount, 
			"PERIOD_NET_BALANCE" => $Period_Net_Balance, "PERIOD_END_BALANCE" => $Period_End_Balance, "REPORT_DATE"=> $report_date,"CREATED_BY" => $this->webspice->get_user_id(), "CREATED_DATE" => $this->webspice->now(), "STATUS" => 7);
			# must have column value - column offset started from 1
			if( !isset($Account) || !isset($Description)){
				$data_error .= 'Row #'.$k.' is incomplete.<br />';
			}
		}
		# insert data
		$this->db->trans_off();
		$this->db->trans_begin();		
		$is_value = false;
		$this->db->insert_batch($table_name, $values);
		
		if ($this->db->trans_status() === FALSE){
			$this->db->trans_rollback();
			$this->webspice->message_board('We could not execute your request. Please try again or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}else{
			$this->db->trans_commit();
		}
		$this->db->trans_off();
		$this->webspice->log_me('upload_trial_balance'); # log
		
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('upload_trial_balance', true) ){
			$this->webspice->force_redirect($url_prefix.'upload_trial_balance');
		}
		
		$this->webspice->force_redirect($url_prefix);
	}
	
	
	
 function manage_cnc_revenue(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_cnc_revenue');
		$this->webspice->permission_verify('manage_cnc_revenue');
		$this->load->database();
    $orderby = ' ORDER BY TBL_CNC_REVENUE.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_CNC_REVENUE.* FROM TBL_CNC_REVENUE ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_CNC_REVENUE', 
			 $InputField= array(),
			$Keyword = array("GL","VALUE"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
    	case 'edit':
          $this->webspice->edit_generator($TableName='TBL_CNC_REVENUE', $KeyField='ID', $key, $RedirectController='btrc_controller', $RedirectFunction='create_cnc_revenue', $PermissionName='create_cnc_revenue', $StatusCheck=null, $Log='edit_cnc_rev');          
					return false;
          break;
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('btrc/print_cnc_revenue',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_cnc_revenue/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('btrc/manage_cnc_revenue', $data);
 }	

	function create_cnc_revenue($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_cnc_revenue');
			$this->webspice->permission_verify('create_cnc_revenue,manage_cnc_revenue');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'GL'=> null,
				'VALUE'=> null,
				'REPORT_DATE' => null,
				'ID' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('GL','GL','required|trim|xss_clean');
			$this->form_validation->set_rules('VALUE','Value','required|trim|xss_clean');
			$this->form_validation->set_rules('REPORT_DATE','Report Date','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('btrc/create_cnc_revenue', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  //$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_TB_GL WHERE GL_CODE=? AND SUB_TYPE=?", array( $input->GL_CODE,$input->SUB_TYPE), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_tb_gl');
			# remove cache
			$this->webspice->remove_cache('cnc_revenue');
			# update process
			if($input->ID ){
				
				$calculative_month = $this->input->post("REPORT_DATE");
		    $report_date=date("Y-m-d",$calculative_month);
				#update query
				$sql = "UPDATE TBL_CNC_REVENUE SET GL=?, VALUE=?, REPORT_DATE=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->GL,$input->VALUE,$report_date,$this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('tb_gl_updated - '.$input->GL);
				$this->webspice->force_redirect($url_prefix.'manage_cnc_revenue');
				return false;
			}
		
	}

	function manage_igw_collection(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_igw_collection');
		$this->webspice->permission_verify('manage_igw_collection');
		$this->load->database();
    $orderby = ' ORDER BY TBL_IGW_COLLECTION.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_IGW_COLLECTION.* FROM TBL_IGW_COLLECTION ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_IGW_COLLECTION', 
			 $InputField= array(),
			$Keyword = array("OPERATORS_NAME","VALUE"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
    	case 'edit':
          $this->webspice->edit_generator($TableName='TBL_IGW_COLLECTION', $KeyField='ID', $key, $RedirectController='btrc_controller', $RedirectFunction='create_igw_collection', $PermissionName='create_igw_collection', $StatusCheck=null, $Log='edit_igw_collection');          
					return false;
          break;
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('btrc/print_igw_collection',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_igw_collection/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('btrc/manage_igw_collection', $data);
 }	

	function create_igw_collection($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_igw_collection');
			$this->webspice->permission_verify('create_igw_collection,manage_igw_collection');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'OPERATORS_NAME'=> null,
				'VALUE'=> null,
				'REPORT_DATE' => null,
				'ID' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('OPERATORS_NAME','OPERATORS NAME','required|trim|xss_clean');
			$this->form_validation->set_rules('VALUE','Value','required|trim|xss_clean');
			$this->form_validation->set_rules('REPORT_DATE','Report Date','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('btrc/create_igw_collection', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  //$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_TB_GL WHERE GL_CODE=? AND SUB_TYPE=?", array( $input->GL_CODE,$input->SUB_TYPE), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_tb_gl');
			# remove cache
			$this->webspice->remove_cache('igw_collection');
			# update process
			if($input->ID ){
				
				$calculative_month = $this->input->post("REPORT_DATE");
		    $report_date=date("Y-m-d",$calculative_month);
				#update query
				$sql = "UPDATE TBL_IGW_COLLECTION SET OPERATORS_NAME=?, VALUE=?, REPORT_DATE=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->OPERATORS_NAME,$input->VALUE,$report_date,$this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('tb_gl_updated - '.$input->OPERATORS_NAME);
				$this->webspice->force_redirect($url_prefix.'manage_igw_collection');
				return false;
			}
		
	}
	
	
	
 function manage_postpaid_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_postpaid_data');
		$this->webspice->permission_verify('manage_postpaid_data');
		$this->load->database();
    $orderby = ' ORDER BY TBL_POSTPAID_DATA.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_POSTPAID_DATA.* FROM TBL_POSTPAID_DATA ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_POSTPAID_DATA', 
			 $InputField= array(),
			$Keyword = array("GL","VALUE","DESCRIPTION"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
    	case 'edit':
    	
          $this->webspice->edit_generator($TableName='TBL_POSTPAID_DATA', $KeyField='ID', $key, $RedirectController='btrc_controller', $RedirectFunction='create_postpaid_data', $PermissionName='create_postpaid_data', $StatusCheck=null, $Log='edit_postpaid_data');          
					return false;
          break;
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
				$this->load->view('btrc/print_postpaid_data',$data);
				return false;
        break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_postpaid_data/page/', 10 );
		}
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('btrc/manage_postpaid_data', $data);
 }	

	function create_postpaid_data($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_postpaid_data');
			$this->webspice->permission_verify('create_postpaid_data,manage_postpaid_data');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'GL'=> null,
				'VALUE'=> null,
				'DESCRIPTION'=> null,
				'REPORT_DATE' => null,
				'ID' => null
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('GL','GL','required|trim|xss_clean');
			$this->form_validation->set_rules('VALUE','Value','required|trim|xss_clean');
			$this->form_validation->set_rules('DESCRIPTION','Description','required|trim|xss_clean');
			$this->form_validation->set_rules('REPORT_DATE','Report Date','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('btrc/create_postpaid_data', $data);
				return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  //$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_TB_GL WHERE GL_CODE=? AND SUB_TYPE=?", array( $input->GL_CODE,$input->SUB_TYPE), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'master/create_tb_gl');
			# remove cache
			$this->webspice->remove_cache('postpaid_data');
			# update process
			if($input->ID ){
			
			$record = $this->db->query("SELECT * FROM TBL_TB_GL WHERE GL_CODE=".$input->GL);										 		
			$get_record = $record->row();
			if($get_record){
				$gl_type=$get_record->SUB_TYPE;
			}else{
				$this->webspice->message_board('Unknown GL Type'.$input->GL.'!');
				$this->webspice->force_redirect($url_prefix.'create_postpaid_data');
				}
		
				$calculative_month = $this->input->post("REPORT_DATE");
		    $report_date=date("Y-m-d",$calculative_month);
				#update query
				$sql = "UPDATE TBL_POSTPAID_DATA SET GL=?, VALUE=?, DESCRIPTION=?,SUB_TYPE=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($input->GL,$input->VALUE,$input->DESCRIPTION,$gl_type,$this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('tb_gl_updated - '.$input->GL);
				//$this->webspice->force_redirect($url_prefix.'manage_postpaid_data');
				return false;
			}
		
	}
	 function manage_trial_balance(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_trial_balance');
		$this->webspice->permission_verify('manage_trial_balance');
		$this->load->database();
    $orderby = ' ORDER BY TBL_TRIAL_BALANCE.REPORT_DATE DESC';
    $groupby = null;
    $where = '';
    $page_index = 0;
    $no_of_record = 10;
    $limit = ' LIMIT '.$no_of_record;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key;
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }
		
		$initialSQL = " SELECT TBL_TRIAL_BALANCE.* FROM TBL_TRIAL_BALANCE ";
		
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_TRIAL_BALANCE', 
			$InputField = array(),
			$Keyword= array("ACCOUNT","DESCRIPTION","BEGIN_BALANCE","PERIOD_DR_AMOUNT","PERIOD_CR_AMOUNT","PERIOD_NET_BALANCE","PERIOD_END_BALANCE"),
			$AdditionalWhere = null,
			$DateBetween = array('REPORT_DATE', 'date_from', 'date_end')
			);
			
			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( substr($_SESSION['sql'], 0, stripos($_SESSION['sql'],'LIMIT')) );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('report/print_trial_balance',$data);
				return false;
        break;  
      case 'edit':
      $this->webspice->edit_generator($TableName='TBL_TRIAL_BALANCE', $KeyField='ID', $key, $RedirectController='btrc_controller', $RedirectFunction='create_trial_balance', $PermissionName='create_trial_balance', $StatusCheck=null, $Log='edit_trial_balance');          
			return false;
      break;                
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }
     
		# load all records
		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_trial_balance/page/', 10 );
		}
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->load->view('report/manage_trial_balance', $data);
   }
     function create_trial_balance($data=null){
			$url_prefix = $this->webspice->settings()->site_url_prefix;
			$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_trial_balance');
			$this->webspice->permission_verify('create_trial_balance');
			if( !isset($data['edit'])){
				$data['edit'] = array(
				'ACCOUNT'=> null,
				'DESCRIPTION'=> null,
				'BEGIN_BALANCE' => null,
				'PERIOD_DR_AMOUNT'=>null,
				'ID' => null,
				'PERIOD_CR_AMOUNT'=>null,
				'PERIOD_NET_BALANCE'=>null,
				'PERIOD_END_BALANCE'=>null,
				'REPORT_DATE'=>NULL
				);
			}
			$this->load->library('form_validation');
			$this->form_validation->set_rules('account','Account','required|trim|xss_clean');
			$this->form_validation->set_rules('description','Description','required|trim|xss_clean');
			$this->form_validation->set_rules('begin_balance','Begin Balance','required|trim|xss_clean');
			$this->form_validation->set_rules('period_dr_amount','Period Dr Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('period_cr_amount','Period Cr Amount','required|trim|xss_clean');
			$this->form_validation->set_rules('period_net_balance','Period Net Balance','required|trim|xss_clean');
			$this->form_validation->set_rules('period_end_balance','Period End Balance','required|trim|xss_clean');
			$this->form_validation->set_rules('report_date','Report Date','required|trim|xss_clean');
			if( !$this->form_validation->run() ){
					$this->load->view('uploader/create_trial_balance', $data);
				  return FALSE;
			}
			# get input post
			$input = $this->webspice->get_input('key');
			#duplicate test
		  //$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_TRIAL_BALANCE WHERE ACCOUNT=? AND REPORT_DATE=?", array( $input->account,$input->report_date), 'You are not allowed to enter duplicate Operator Name!', 'ID', $input->ID, $data, 'report/create_trial_balance');
			# remove cache
				$record = $this->db->query("SELECT * FROM TBL_TB_GL WHERE GL_CODE=".$input->account);										 		
			$get_record = $record->row();
			if($get_record){
				$gl_type=$get_record->SUB_TYPE;
			}else{
				$this->webspice->message_board('Unknown GL '.$input->account.'!');
				$this->webspice->force_redirect($url_prefix.'create_trial_balance');
				}
		
			$this->webspice->remove_cache('trial_balance');
			# update process
				#update query
				$sql = "UPDATE TBL_TRIAL_BALANCE SET SUB_TYPE=?,ACCOUNT=?, DESCRIPTION=?, BEGIN_BALANCE=?, PERIOD_DR_AMOUNT=?, PERIOD_CR_AMOUNT=?, PERIOD_NET_BALANCE=?, PERIOD_END_BALANCE=?, REPORT_DATE=?, UPDATED_BY=?, UPDATED_DATE=?
				WHERE ID=?";
				$this->db->query($sql , array($gl_type,$input->account,$input->description,$input->begin_balance,$input->period_dr_amount, $input->period_cr_amount, $input->period_net_balance, $input->period_end_balance,$input->report_date, $this->webspice->get_user_id(), $this->webspice->now(), $input->ID));
				$this->webspice->message_board('Record has been updated!');
				$this->webspice->log_me('operator_updated - '.$input->account);
				$this->webspice->force_redirect($url_prefix.'manage_trial_balance');
				
	}
	
	function oracle_collection($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'oracle_collection');
		$this->webspice->permission_verify('oracle_collection');
			if( !$_POST ){
			$this->load->view('btrc/oracle_collection', $data);
			return false;
		  }
		$input = $this->webspice->get_input();	
		 $QUAD= $input->QUAD;
		 $YEAR= $input->YEAR;
     if($QUAD==1){
     	$date[0]=$YEAR.'-1-1';
     	$date[1]=$YEAR.'-2-1';
     	$date[2]=$YEAR.'-3-1';
     }elseif($QUAD==2){
    	$date[0]=$YEAR.'-4-1';
     	$date[1]=$YEAR.'-5-1';
     	$date[2]=$YEAR.'-6-1';
     }elseif($QUAD==3){
    	$date[0]=$YEAR.'-7-1';
     	$date[1]=$YEAR.'-8-1';
     	$date[2]=$YEAR.'-9-1';
     }else{
     	$date[0]=$YEAR.'-10-1';
     	$date[1]=$YEAR.'-11-1';
     	$date[2]=$YEAR.'-12-1';
     	}
	 	$sql = "
			SELECT SUB_TYPE, GL_CODE, GL_DESCRIPTION,
			SUM(TB_VALUE_ONE) AS TB_VALUE_ONE,
			SUM(POSTPAID_ONE) AS POSTPAID_ONE,
			SUM(CNC_VALUE_ONE) AS CNC_VALUE_ONE, 
			SUM(POSTPAID_ONE) - SUM(CNC_VALUE_ONE) AS NET_POSTPAID_ONE,
			POSTPAID_COLLECTION_ONE,
			
			SUM(TB_VALUE_TWO) AS TB_VALUE_TWO,
			SUM(POSTPAID_TWO) AS POSTPAID_TWO,
			SUM(CNC_VALUE_TWO) AS CNC_VALUE_TWO, 
			SUM(POSTPAID_TWO) - SUM(CNC_VALUE_TWO) AS NET_POSTPAID_TWO,
			POSTPAID_COLLECTION_TWO,
			
			SUM(TB_VALUE_THREE) AS TB_VALUE_THREE,
			SUM(POSTPAID_THREE) AS POSTPAID_THREE,
			SUM(CNC_VALUE_THREE) AS CNC_VALUE_THREE, 
			SUM(POSTPAID_THREE) - SUM(CNC_VALUE_THREE) AS NET_POSTPAID_THREE,
			POSTPAID_COLLECTION_THREE,
			TYPE
			
			FROM  TBL_TB_GL LEFT JOIN (
				SELECT ACCOUNT, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_TWO, 
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_THREE, 
				0 AS POSTPAID_ONE, 
				0 AS POSTPAID_TWO, 
				0 AS POSTPAID_THREE, 
				0 AS CNC_VALUE_ONE, 
				0 AS CNC_VALUE_TWO,
				0 AS CNC_VALUE_THREE,
				0 AS POSTPAID_COLLECTION_ONE, 
				0 AS POSTPAID_COLLECTION_TWO, 
				0 AS POSTPAID_COLLECTION_THREE 
				FROM TBL_TRIAL_BALANCE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
				GROUP BY ACCOUNT
				UNION ALL
				
				SELECT ACCOUNT, 
				0 AS TB_VALUE_ONE, 
				0 AS TB_VALUE_TWO, 
				0 AS TB_VALUE_THREE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_TWO, 
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_THREE, 
				0 AS CNC_VALUE_ONE, 
				0 AS CNC_VALUE_TWO,
				0 AS CNC_VALUE_THREE,
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[0]."') AS POSTPAID_COLLECTION_ONE, 
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[1]."') AS POSTPAID_COLLECTION_TWO, 
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[2]."') AS POSTPAID_COLLECTION_THREE 
				FROM TBL_TRIAL_BALANCE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."') 
				AND ACCOUNT IN ('4012101','4012153','4012202','4012203','4012204','4012206','4012501','4012607','4012608','4012609','4012610','4012651','4012652','4012653','4012659','4012660','4012663','4012664','4012665','4012666','4012667','4012669','4012670','4012671','4012672','4012673','4012674','4012676','4012677','4012751','4012754','4012756','4017101','4017151','4017201','4017202','4017203','4017301','4017351','4017352','4017353','4017354','4017401','4017402','4017403','4017405','4017406','4017409','4017410','4017411','4017412','4017413','4017414','4017415','4017417','4017418','4017419','4017421','4017422','4017451','4017454','4017456')
				GROUP BY ACCOUNT
				UNION ALL
				
				SELECT GL AS ACCOUNT,
				0 AS POSTPAID_ONE,
				0 AS POSTPAID_TOW,
				0 AS POSTPAID_THREE, 
				0 AS TB_VALUE_ONE, 
				0 AS TB_VALUE_TWO, 
				0 AS TB_VALUE_THREE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_TWO,
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_THREE,
				0 AS POSTPAID_COLLECTION_ONE,
				0 AS POSTPAID_COLLECTION_TWO,
				0 AS POSTPAID_COLLECTION_THREE
				FROM TBL_CNC_REVENUE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
				GROUP BY GL
			) TBL_TEMP
			ON TBL_TB_GL.GL_CODE = TBL_TEMP.ACCOUNT
			GROUP BY GL_CODE
			ORDER BY SUB_TYPE
	 	";
	 
	  $data['date']=$date;
    # get input post
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export')){
  		$data['action_type'] = 'csv';
  	}
  	
		$data['report_name']="Banglalink Digital Communications Limited";
		$data["get_record"] = $this->db->query($sql)->result_array();
		if(empty($data["get_record"])){
			$this->webspice->message_board('Record is not found!');
			$this->load->view('btrc/oracle_collection', $data);
			return false;
		}
		$this->load->view('btrc/print_oracle_collection', $data);
	}

	function btrc_revenue($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'btrc_revenue');
		$this->webspice->permission_verify('btrc_revenue');
		if( !$_POST ){
			$this->load->view('btrc/btrc_revenue', $data);
			return false;
		}
		$input = $this->webspice->get_input();	
		$QUAD= $input->QUAD;
		$YEAR= $input->YEAR;
		if($QUAD==1){
			$date[0]=$YEAR.'-1-1';
			$date[1]=$YEAR.'-2-1';
			$date[2]=$YEAR.'-3-1';
		}elseif($QUAD==2){
			$date[0]=$YEAR.'-4-1';
			$date[1]=$YEAR.'-5-1';
			$date[2]=$YEAR.'-6-1';
		}elseif($QUAD==3){
			$date[0]=$YEAR.'-7-1';
			$date[1]=$YEAR.'-8-1';
			$date[2]=$YEAR.'-9-1';
		}else{
			$date[0]=$YEAR.'-10-1';
			$date[1]=$YEAR.'-11-1';
			$date[2]=$YEAR.'-12-1';
		}
	 	
	 	$sql = "
			SELECT SUB_TYPE, GL_CODE, GL_DESCRIPTION,
			SUM(TB_VALUE_ONE) AS TB_VALUE_ONE,
			SUM(POSTPAID_ONE) AS POSTPAID_ONE,
			SUM(CNC_VALUE_ONE) AS CNC_VALUE_ONE, 
			SUM(POSTPAID_ONE) - SUM(CNC_VALUE_ONE) AS NET_POSTPAID_ONE,
			POSTPAID_COLLECTION_ONE,
			
			SUM(TB_VALUE_TWO) AS TB_VALUE_TWO,
			SUM(POSTPAID_TWO) AS POSTPAID_TWO,
			SUM(CNC_VALUE_TWO) AS CNC_VALUE_TWO, 
			SUM(POSTPAID_TWO) - SUM(CNC_VALUE_TWO) AS NET_POSTPAID_TWO,
			POSTPAID_COLLECTION_TWO,
			
			SUM(TB_VALUE_THREE) AS TB_VALUE_THREE,
			SUM(POSTPAID_THREE) AS POSTPAID_THREE,
			SUM(CNC_VALUE_THREE) AS CNC_VALUE_THREE, 
			SUM(POSTPAID_THREE) - SUM(CNC_VALUE_THREE) AS NET_POSTPAID_THREE,
			POSTPAID_COLLECTION_THREE,
			TYPE
			
			FROM  TBL_TB_GL LEFT JOIN (
				SELECT ACCOUNT, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_TWO, 
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_THREE, 
				0 AS POSTPAID_ONE, 
				0 AS POSTPAID_TWO, 
				0 AS POSTPAID_THREE, 
				0 AS CNC_VALUE_ONE, 
				0 AS CNC_VALUE_TWO,
				0 AS CNC_VALUE_THREE,
				0 AS POSTPAID_COLLECTION_ONE, 
				0 AS POSTPAID_COLLECTION_TWO, 
				0 AS POSTPAID_COLLECTION_THREE 
				FROM TBL_TRIAL_BALANCE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
				GROUP BY ACCOUNT
				UNION ALL
				
				SELECT ACCOUNT, 
				0 AS TB_VALUE_ONE, 
				0 AS TB_VALUE_TWO, 
				0 AS TB_VALUE_THREE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_TWO, 
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_THREE, 
				0 AS CNC_VALUE_ONE, 
				0 AS CNC_VALUE_TWO,
				0 AS CNC_VALUE_THREE,
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[0]."') AS POSTPAID_COLLECTION_ONE, 
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[1]."') AS POSTPAID_COLLECTION_TWO, 
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[2]."') AS POSTPAID_COLLECTION_THREE 
				FROM TBL_TRIAL_BALANCE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."') 
				AND ACCOUNT IN ('4012101','4012153','4012202','4012203','4012204','4012206','4012501','4012607','4012608','4012609','4012610','4012651','4012652','4012653','4012659','4012660','4012663','4012664','4012665','4012666','4012667','4012669','4012670','4012671','4012672','4012673','4012674','4012676','4012677','4012751','4012754','4012756','4017101','4017151','4017201','4017202','4017203','4017301','4017351','4017352','4017353','4017354','4017401','4017402','4017403','4017405','4017406','4017409','4017410','4017411','4017412','4017413','4017414','4017415','4017417','4017418','4017419','4017421','4017422','4017451','4017454','4017456')
				GROUP BY ACCOUNT
				UNION ALL
				
				SELECT GL AS ACCOUNT,
				0 AS POSTPAID_ONE,
				0 AS POSTPAID_TOW,
				0 AS POSTPAID_THREE, 
				0 AS TB_VALUE_ONE, 
				0 AS TB_VALUE_TWO, 
				0 AS TB_VALUE_THREE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_TWO,
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_THREE,
				0 AS POSTPAID_COLLECTION_ONE,
				0 AS POSTPAID_COLLECTION_TWO,
				0 AS POSTPAID_COLLECTION_THREE
				FROM TBL_CNC_REVENUE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
				GROUP BY GL
			) TBL_TEMP
			ON TBL_TB_GL.GL_CODE = TBL_TEMP.ACCOUNT
			GROUP BY GL_CODE
			ORDER BY SUB_TYPE
	 	";
	 	
	 	$get_ocb = $this->db->query($sql)->result_array();
	 	
		$net_postpaid_one = array_sum(array_column($get_ocb,"NET_POSTPAID_ONE"));
		$net_postpaid_two = array_sum(array_column($get_ocb,"NET_POSTPAID_TWO"));
		$net_postpaid_three = array_sum(array_column($get_ocb,"NET_POSTPAID_THREE"));
		$value_one = 0;
		$value_two = 0;
		$value_three = 0;
		$revenue_share = array();
  	foreach($get_ocb as $key => $value){
			$value_one = round($value['TB_VALUE_ONE']);
			$value_two = round($value['TB_VALUE_TWO']);
			$value_three = round($value['TB_VALUE_THREE']);
  		if(in_array($value['GL_CODE'], array("4012101","4012153","4012202","4012203","4012204","4012206","4012501","4012607","4012608","4012609","4012610","4012651","4012652","4012653","4012659","4012660","4012663","4012664","4012665","4012666","4012667","4012669","4012670","4012671","4012672","4012673","4012674","4012676","4012677","4012751","4012754","4012756","4017101","4017151","4017201","4017202","4017203","4017301","4017351","4017352","4017353","4017354","4017401","4017402","4017403","4017405","4017406","4017409","4017410","4017411","4017412","4017413","4017414","4017415","4017417","4017418","4017419","4017421","4017422","4017451","4017454","4017456"))){
  			$value_one = -round((($value['NET_POSTPAID_ONE']/$net_postpaid_one) * $value['POSTPAID_COLLECTION_ONE']) + $value['CNC_VALUE_ONE']);
  			$value_two = -round((($value['NET_POSTPAID_TWO']/$net_postpaid_two) * $value['POSTPAID_COLLECTION_TWO']) + $value['CNC_VALUE_TWO']);
  			$value_three = -round((($value['NET_POSTPAID_THREE']/$net_postpaid_three) * $value['POSTPAID_COLLECTION_THREE']) + $value['CNC_VALUE_THREE']);
  		}
  		
			if($value['TYPE']=="Not to be shared"){
					@$revenue_share[0]["TITLE"] = "Not to be shared";
					@$revenue_share[0]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[0]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[0]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="Intra Operator Domestic Service Voice Calls"){
					@$revenue_share[1]["TITLE"] = "Intra Operator Domestic Service Voice Calls";
					@$revenue_share[1]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[1]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[1]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="Inter Operator Domestic Service Voice Calls - Outgoing"){
					@$revenue_share[2]["TITLE"] = "Inter Operator Domestic Service Voice Calls - Outgoing";
					@$revenue_share[2]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[2]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[2]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="MTC"){
					@$revenue_share[3]["TITLE"] = "Inter Operator Domestic Service Voice Calls - Incoming";
					@$revenue_share[3]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[3]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[3]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="International Long Distance Voice Calls - Outgoing"){
					@$revenue_share[4]["TITLE"] = "International Long Distance Voice Calls - Outgoing";
					@$revenue_share[4]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[4]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[4]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="International Long Distance Voice Calls - Incoming"){
					@$revenue_share[5]["TITLE"] = "International Long Distance Voice Calls - Incoming";
					@$revenue_share[5]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[5]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[5]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="International Roaming Service inbound"){
					@$revenue_share[6]["TITLE"] = "International Roaming Service inbound";
					@$revenue_share[6]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[6]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[6]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="International Roaming Service outbound"){
					@$revenue_share[7]["TITLE"] = "International Roaming Service outbound";
					@$revenue_share[7]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[7]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[7]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="SMS/EMS/VMS - Outgoing on-net"){
					@$revenue_share[8]["TITLE"] = "SMS/EMS/VMS - Outgoing on-net";
					@$revenue_share[8]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[8]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[8]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="SMS/EMS/VMS - Outgoing off-net"){
					@$revenue_share[9]["TITLE"] = "SMS/EMS/VMS - Outgoing off-net";
					@$revenue_share[9]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[9]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[9]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="MTSMS"){
					@$revenue_share[10]["TITLE"] = "SMS/EMS/VMS - Incoming";
					@$revenue_share[10]["MTSMS_FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[10]["MTSMS_SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[10]["MTSMS_THIRD_MONTH_VALUE"] += $value_three;
			}
			if($value['SUB_TYPE']=="ISMS REVENUE"){
					@$revenue_share[10]["TITLE"] = "SMS/EMS/VMS - Incoming";
					@$revenue_share[10]["ISMS_FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[10]["ISMS_SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[10]["ISMS_THIRD_MONTH_VALUE"] += $value_three;
					
			}
			
			if($value['TYPE']=="Mobile Internet"){
					@$revenue_share[11]["TITLE"] = "Mobile Internet";
					@$revenue_share[11]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[11]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[11]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="Value Added Service"){
					@$revenue_share[12]["TITLE"] = "Value Added Service";
					@$revenue_share[12]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[12]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[12]["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['TYPE']=="Others"){
					@$revenue_share[13]["TITLE"] = "Others";
					@$revenue_share[13]["FIRST_MONTH_VALUE"] +=  $value_one;
					@$revenue_share[13]["SECOND_MONTH_VALUE"] += $value_two;
					@$revenue_share[13]["THIRD_MONTH_VALUE"] += $value_three;
			}
	  }
	  
	  
	 	$data['revenue'] = $revenue_share;
	  $data['date'] = $date;
    # get input post
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export')){
  		$data['action_type'] = 'csv';
  	}
		
		if(empty($data["revenue"])){
			$this->webspice->message_board('Record is not found!');
			$this->load->view('btrc/btrc_revenue_sharing', $data);
			return false;
		}
		
		$this->load->view('btrc/print_btrc_revenue', $data);
	}

	function btrc_revenue_sharing($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'btrc_revenue_sharing');
		$this->webspice->permission_verify('btrc_revenue_sharing');
		if( !$_POST ){
			$this->load->view('btrc/btrc_revenue_sharing', $data);
			return false;
		}
		$input = $this->webspice->get_input();	
		$QUAD= $input->QUAD;
		$YEAR= $input->YEAR;
		if($QUAD==1){
			$date[0]=$YEAR.'-1-1';
			$date[1]=$YEAR.'-2-1';
			$date[2]=$YEAR.'-3-1';
		}elseif($QUAD==2){
			$date[0]=$YEAR.'-4-1';
			$date[1]=$YEAR.'-5-1';
			$date[2]=$YEAR.'-6-1';
		}elseif($QUAD==3){
			$date[0]=$YEAR.'-7-1';
			$date[1]=$YEAR.'-8-1';
			$date[2]=$YEAR.'-9-1';
		}else{
	   	$date[0]=$YEAR.'-10-1';
	   	$date[1]=$YEAR.'-11-1';
	   	$date[2]=$YEAR.'-12-1';
   	}
	 	
	 	$subscriber_sql = "
			SELECT 
			'No of Subscriber: 2G Subscriber' AS PARTICULARS,
			SUM(CASE WHEN REPORT_MONTH = '".$date[0]."' THEN NO_OF_2G_SUBSCRIBER ELSE 0 END) AS NO_OF_SUBSCRIBER_ONE, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[1]."' THEN NO_OF_2G_SUBSCRIBER ELSE 0 END) AS NO_OF_SUBSCRIBER_TWO, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[2]."' THEN NO_OF_2G_SUBSCRIBER ELSE 0 END) AS NO_OF_SUBSCRIBER_THREE
			FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
			UNION ALL
			SELECT 
			'No of Subscriber: 3G Subscriber' AS PARTICULARS,
			SUM(CASE WHEN REPORT_MONTH = '".$date[0]."' THEN NO_OF_3G_SUBSCRIBER ELSE 0 END) AS NO_OF_SUBSCRIBER_ONE, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[1]."' THEN NO_OF_3G_SUBSCRIBER ELSE 0 END) AS NO_OF_SUBSCRIBER_TWO, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[2]."' THEN NO_OF_3G_SUBSCRIBER ELSE 0 END) AS NO_OF_SUBSCRIBER_THREE
			FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
	 	";
	 	$data["subscriber_data"] = $this->db->query($subscriber_sql)->result_array();
	 	
	 	$igw_sql = "
			SELECT 
			'International Incoming' AS PARTICULARS,
			SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN VALUE ELSE 0 END) AS FIRST_MONTH_VALUE, 
			SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN VALUE ELSE 0 END) AS SECOND_MONTH_VALUE, 
			SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN VALUE ELSE 0 END) AS THIRD_MONTH_VALUE
			FROM TBL_IGW_COLLECTION WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
	 	";
	 	$igw_data = $this->db->query($igw_sql)->result_array();
	 	$data["igw_data"] = $igw_data[0];
	 	
	 	$y_value_sql = "
			SELECT 
			'International Outgoing (Note: 1)' AS PARTICULARS,
			SUM(CASE WHEN REPORT_MONTH = '".$date[0]."' THEN Y_VALUE ELSE 0 END) AS FIRST_MONTH_VALUE, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[1]."' THEN Y_VALUE ELSE 0 END) AS SECOND_MONTH_VALUE, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[2]."' THEN Y_VALUE ELSE 0 END) AS THIRD_MONTH_VALUE
			FROM TBL_MIS_REV_AND_Y_VALUE WHERE REPORT_MONTH IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
	 	";
	 	$y_value_data = $this->db->query($y_value_sql)->result_array();
	 	
	 	$int_outgoing_revenue = array();
		@$int_outgoing_revenue["PARTICULARS"] = "International Outgoing (Note: 1)";
		@$int_outgoing_revenue["FIRST_MONTH_OTHERS"] =  $y_value_data[0]["FIRST_MONTH_VALUE"];
		@$int_outgoing_revenue["SECOND_MONTH_OTHERS"] = $y_value_data[0]["SECOND_MONTH_VALUE"];
		@$int_outgoing_revenue["THIRD_MONTH_OTHERS"] = $y_value_data[0]["THIRD_MONTH_VALUE"];
	 	
	 	$iig_cost = "
			SELECT 
			'Internet Service - 3G (Note: 2)' AS PARTICULARS,
			SUM(CASE WHEN REPORT_MONTH = '".$date[0]."' THEN IIG_COST ELSE 0 END) AS FIRST_MONTH_VALUE, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[1]."' THEN IIG_COST ELSE 0 END) AS SECOND_MONTH_VALUE, 
			SUM(CASE WHEN REPORT_MONTH = '".$date[2]."' THEN IIG_COST ELSE 0 END) AS THIRD_MONTH_VALUE
			FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
	 	";
	 	$iig_cost_data = $this->db->query($iig_cost)->result_array();
	 	
	 	$internet_service_3g = array();
		@$internet_service_3g["PARTICULARS"] = "Internet Service - 3G (Note: 2)";
		@$internet_service_3g["FIRST_MONTH_OTHERS"] =  $iig_cost_data[0]["FIRST_MONTH_VALUE"];
		@$internet_service_3g["SECOND_MONTH_OTHERS"] = $iig_cost_data[0]["SECOND_MONTH_VALUE"];
		@$internet_service_3g["THIRD_MONTH_OTHERS"] = $iig_cost_data[0]["THIRD_MONTH_VALUE"];
	 	
	 	$sql = "
			SELECT SUB_TYPE, GL_CODE, GL_DESCRIPTION,
			SUM(TB_VALUE_ONE) AS TB_VALUE_ONE,
			SUM(POSTPAID_ONE) AS POSTPAID_ONE,
			SUM(CNC_VALUE_ONE) AS CNC_VALUE_ONE, 
			SUM(POSTPAID_ONE) - SUM(CNC_VALUE_ONE) AS NET_POSTPAID_ONE,
			POSTPAID_COLLECTION_ONE,
			
			SUM(TB_VALUE_TWO) AS TB_VALUE_TWO,
			SUM(POSTPAID_TWO) AS POSTPAID_TWO,
			SUM(CNC_VALUE_TWO) AS CNC_VALUE_TWO, 
			SUM(POSTPAID_TWO) - SUM(CNC_VALUE_TWO) AS NET_POSTPAID_TWO,
			POSTPAID_COLLECTION_TWO,
			
			SUM(TB_VALUE_THREE) AS TB_VALUE_THREE,
			SUM(POSTPAID_THREE) AS POSTPAID_THREE,
			SUM(CNC_VALUE_THREE) AS CNC_VALUE_THREE, 
			SUM(POSTPAID_THREE) - SUM(CNC_VALUE_THREE) AS NET_POSTPAID_THREE,
			POSTPAID_COLLECTION_THREE,
			TYPE
			
			FROM  TBL_TB_GL LEFT JOIN (
				SELECT ACCOUNT, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_TWO, 
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN PERIOD_NET_BALANCE ELSE 0 END) AS TB_VALUE_THREE, 
				0 AS POSTPAID_ONE, 
				0 AS POSTPAID_TWO, 
				0 AS POSTPAID_THREE, 
				0 AS CNC_VALUE_ONE, 
				0 AS CNC_VALUE_TWO,
				0 AS CNC_VALUE_THREE,
				0 AS POSTPAID_COLLECTION_ONE, 
				0 AS POSTPAID_COLLECTION_TWO, 
				0 AS POSTPAID_COLLECTION_THREE 
				FROM TBL_TRIAL_BALANCE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
				GROUP BY ACCOUNT
				UNION ALL
				
				SELECT ACCOUNT, 
				0 AS TB_VALUE_ONE, 
				0 AS TB_VALUE_TWO, 
				0 AS TB_VALUE_THREE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_TWO, 
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN ABS(PERIOD_NET_BALANCE) ELSE 0 END) AS POSTPAID_THREE, 
				0 AS CNC_VALUE_ONE, 
				0 AS CNC_VALUE_TWO,
				0 AS CNC_VALUE_THREE,
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[0]."') AS POSTPAID_COLLECTION_ONE, 
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[1]."') AS POSTPAID_COLLECTION_TWO, 
				(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '".$date[2]."') AS POSTPAID_COLLECTION_THREE 
				FROM TBL_TRIAL_BALANCE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."') 
				AND ACCOUNT IN ('4012101','4012153','4012202','4012203','4012204','4012206','4012501','4012607','4012608','4012609','4012610','4012651','4012652','4012653','4012659','4012660','4012663','4012664','4012665','4012666','4012667','4012669','4012670','4012671','4012672','4012673','4012674','4012676','4012677','4012751','4012754','4012756','4017101','4017151','4017201','4017202','4017203','4017301','4017351','4017352','4017353','4017354','4017401','4017402','4017403','4017405','4017406','4017409','4017410','4017411','4017412','4017413','4017414','4017415','4017417','4017418','4017419','4017421','4017422','4017451','4017454','4017456')
				GROUP BY ACCOUNT
				UNION ALL
				
				SELECT GL AS ACCOUNT,
				0 AS POSTPAID_ONE,
				0 AS POSTPAID_TOW,
				0 AS POSTPAID_THREE, 
				0 AS TB_VALUE_ONE, 
				0 AS TB_VALUE_TWO, 
				0 AS TB_VALUE_THREE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[0]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_ONE, 
				SUM(CASE WHEN REPORT_DATE = '".$date[1]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_TWO,
				SUM(CASE WHEN REPORT_DATE = '".$date[2]."' THEN VALUE ELSE 0 END) AS CNC_VALUE_THREE,
				0 AS POSTPAID_COLLECTION_ONE,
				0 AS POSTPAID_COLLECTION_TWO,
				0 AS POSTPAID_COLLECTION_THREE
				FROM TBL_CNC_REVENUE WHERE REPORT_DATE IN('".$date[0]."', '".$date[1]."', '".$date[2]."')
				GROUP BY GL
			) TBL_TEMP
			ON TBL_TB_GL.GL_CODE = TBL_TEMP.ACCOUNT
			GROUP BY GL_CODE
			ORDER BY SUB_TYPE
	 	";
	 	
	 	$get_ocb = $this->db->query($sql)->result_array();
	 	
		$net_postpaid_one = array_sum(array_column($get_ocb,"NET_POSTPAID_ONE"));
		$net_postpaid_two = array_sum(array_column($get_ocb,"NET_POSTPAID_TWO"));
		$net_postpaid_three = array_sum(array_column($get_ocb,"NET_POSTPAID_THREE"));
		$value_one = 0;
		$value_two = 0;
		$value_three = 0;
		$revenue_share = array();
		$intra_dom_calls = array();
		$inter_dom_calls = array();
		$voice_outgoing_revenue = array();
		$in_bound = array();
		$out_bound = array();
		$intra_operator_sms_ems_vms = array();
		#dd($get_ocb);
		$mtc = array();
		
  	foreach($get_ocb as $key => $value){
			$value_one = round($value['TB_VALUE_ONE']);
			$value_two = round($value['TB_VALUE_TWO']);
			$value_three = round($value['TB_VALUE_THREE']);
  		if(in_array($value['GL_CODE'], array("4012101","4012153","4012202","4012203","4012204","4012206","4012501","4012607","4012608","4012609","4012610","4012651","4012652","4012653","4012659","4012660","4012663","4012664","4012665","4012666","4012667","4012669","4012670","4012671","4012672","4012673","4012674","4012676","4012677","4012751","4012754","4012756","4017101","4017151","4017201","4017202","4017203","4017301","4017351","4017352","4017353","4017354","4017401","4017402","4017403","4017405","4017406","4017409","4017410","4017411","4017412","4017413","4017414","4017415","4017417","4017418","4017419","4017421","4017422","4017451","4017454","4017456"))){
  			$value_one = -round((($value['NET_POSTPAID_ONE']/$net_postpaid_one) * $value['POSTPAID_COLLECTION_ONE']) + $value['CNC_VALUE_ONE']);
  			$value_two = -round((($value['NET_POSTPAID_TWO']/$net_postpaid_two) * $value['POSTPAID_COLLECTION_TWO']) + $value['CNC_VALUE_TWO']);
  			$value_three = -round((($value['NET_POSTPAID_THREE']/$net_postpaid_three) * $value['POSTPAID_COLLECTION_THREE']) + $value['CNC_VALUE_THREE']);
  		}
  		
			if($value['SUB_TYPE']=="On net Stadard voice"){
					@$intra_dom_calls["PARTICULARS"] = "Intra-operator domestic service Voice Calls";
					@$intra_dom_calls["FIRST_MONTH_VALUE"] +=  $value_one;
					@$intra_dom_calls["SECOND_MONTH_VALUE"] += $value_two;
					@$intra_dom_calls["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#===============
			if($value['SUB_TYPE']=="Voice outgoing revenue"){
					@$voice_outgoing_revenue["PARTICULARS"] = "Off Net Call (Outgoing)";
					@$voice_outgoing_revenue["FIRST_MONTH_VALUE"] +=  $value_one;
					@$voice_outgoing_revenue["SECOND_MONTH_VALUE"] += $value_two;
					@$voice_outgoing_revenue["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="MOC"){
					@$voice_outgoing_revenue["PARTICULARS"] = "Off Net Call (Outgoing)";
					@$voice_outgoing_revenue["FIRST_MONTH_OTHERS"] +=  $value_one;
					@$voice_outgoing_revenue["SECOND_MONTH_OTHERS"] += $value_two;
					@$voice_outgoing_revenue["THIRD_MONTH_OTHERS"] += $value_three;
			}
			
			#================
			if($value['SUB_TYPE']=="MTC"){
					@$mtc["PARTICULARS"] = "Off Net Call (Incoming)";
					@$mtc["FIRST_MONTH_VALUE"] +=  $value_one;
					@$mtc["SECOND_MONTH_VALUE"] += $value_two;
					@$mtc["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#================
			if($value['SUB_TYPE']=="Int. outgoing revenue"){
					@$int_outgoing_revenue["PARTICULARS"] = "International Outgoing (Note: 1)";
					@$int_outgoing_revenue["FIRST_MONTH_VALUE"] +=  $value_one;
					@$int_outgoing_revenue["SECOND_MONTH_VALUE"] += $value_two;
					@$int_outgoing_revenue["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#================
			if($value['SUB_TYPE']=="Guest roaming"){
					@$in_bound["PARTICULARS"] = "In-Bound";
					@$in_bound["FIRST_MONTH_VALUE"] +=  $value_one;
					@$in_bound["SECOND_MONTH_VALUE"] += $value_two;
					@$in_bound["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#===============
			if($value['SUB_TYPE']=="outbound roaming revenue"){
					@$out_bound["PARTICULARS"] = "Out-Bound";
					@$out_bound["FIRST_MONTH_VALUE"] +=  $value_one;
					@$out_bound["SECOND_MONTH_VALUE"] += $value_two;
					@$out_bound["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="Outbound roaming cost"){
					@$out_bound["PARTICULARS"] = "Out-Bound";
					@$out_bound["FIRST_MONTH_OTHERS"] +=  $value_one;
					@$out_bound["SECOND_MONTH_OTHERS"] += $value_two;
					@$out_bound["THIRD_MONTH_OTHERS"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="SMS revenue" && $value['TYPE']=="SMS/EMS/VMS, ON-Net"){
					@$intra_operator_sms_ems_vms["PARTICULARS"] = "Intra-operator SMS/EMS/VMS";
					@$intra_operator_sms_ems_vms["FIRST_MONTH_VALUE"] +=  $value_one;
					@$intra_operator_sms_ems_vms["SECOND_MONTH_VALUE"] += $value_two;
					@$intra_operator_sms_ems_vms["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="SMS revenue" && $value['TYPE']=="SMS/EMS/VMS, Off-Net"){
					@$off_net_outgoing["PARTICULARS"] = "Off Net (Outgoing)";
					@$off_net_outgoing["FIRST_MONTH_VALUE"] +=  $value_one;
					@$off_net_outgoing["SECOND_MONTH_VALUE"] += $value_two;
					@$off_net_outgoing["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="MOSMS"){
					@$off_net_outgoing["PARTICULARS"] = "Off Net (Outgoing)";
					@$off_net_outgoing["FIRST_MONTH_OTHERS"] +=  $value_one;
					@$off_net_outgoing["SECOND_MONTH_OTHERS"] += $value_two;
					@$off_net_outgoing["THIRD_MONTH_OTHERS"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="MTSMS"){
					@$off_net_incoming_mtsms["PARTICULARS"] = "Off Net (Incoming)";
					@$off_net_incoming_mtsms["FIRST_MONTH_VALUE"] +=  $value_one;
					@$off_net_incoming_mtsms["SECOND_MONTH_VALUE"] += $value_two;
					@$off_net_incoming_mtsms["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			if($value['SUB_TYPE']=="ISMS REVENUE"){
					@$off_net_incoming_isms["PARTICULARS"] = "Off Net (Incoming)";
					@$off_net_incoming_isms["FIRST_MONTH_VALUE"] +=  $value_one;
					@$off_net_incoming_isms["SECOND_MONTH_VALUE"] += $value_two;
					@$off_net_incoming_isms["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#3G
			if( in_array($value['GL_CODE'], array("4011773","4012677","4013311","4017422","4018260") )){
					@$mobile_internet["PARTICULARS"] = "Mobile Internet";
					@$mobile_internet["PARTICULARS2"] = "Internet Service - 3G Bundle";
					@$mobile_internet["FIRST_MONTH_VALUE_3G"] +=  $value_one;
					@$mobile_internet["SECOND_MONTH_VALUE_3G"] += $value_two;
					@$mobile_internet["THIRD_MONTH_VALUE_3G"] += $value_three;
			}
			
			#3G DATA
			if($value['SUB_TYPE']=="3G DATA"){
					@$mobile_internet["PARTICULARS"] = "Mobile Internet";
					@$mobile_internet["FIRST_MONTH_VALUE"] +=  $value_one;
					@$mobile_internet["SECOND_MONTH_VALUE"] += $value_two;
					@$mobile_internet["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#2G
			if( in_array($value['GL_CODE'], array("4011764","4012659","4013308","4017405","4018257") )){
					@$internet_service_2g["PARTICULARS"] = "Internet Service - 2G";
					@$internet_service_2g["FIRST_MONTH_VALUE"] +=  $value_one;
					@$internet_service_2g["SECOND_MONTH_VALUE"] += $value_two;
					@$internet_service_2g["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#2G DATA
			if($value['GL_CODE']=="4013314"){
					@$internet_service_2g_bundle["PARTICULARS"] = "Internet Service - 2G";
					@$internet_service_2g_bundle["FIRST_MONTH_VALUE"] +=  $value_one;
					@$internet_service_2g_bundle["SECOND_MONTH_VALUE"] += $value_two;
					@$internet_service_2g_bundle["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#3G and 3G Bundle for Internet Service - 3G Bundle
			if( in_array($value['GL_CODE'], array("4011773","4012677","4013311","4017422","4018260") )){
					@$internet_service_3g["PARTICULARS"] = "Internet Service - 3G (Note: 2)";
					@$internet_service_3g["FIRST_MONTH_VALUE"] +=  $value_one;
					@$internet_service_3g["SECOND_MONTH_VALUE"] += $value_two;
					@$internet_service_3g["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#Value Added Service
			if( $value['SUB_TYPE'] == "Content revenue" ||  $value['SUB_TYPE'] == "Other vas revenue" || ($value['SUB_TYPE'] == "Other Service Revenue" && $value['TYPE'] == "Not to be shared")){
					@$value_added_service["PARTICULARS"] = "VAS Service 2G";
					@$value_added_service["PARTICULARS2"] = "VAS Service 3G";
					@$value_added_service["FIRST_MONTH_VALUE"] +=  $value_one;
					@$value_added_service["SECOND_MONTH_VALUE"] += $value_two;
					@$value_added_service["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#Fiber Optic Network
			if( $value['SUB_TYPE'] == "FON"){
					@$fiber_optic_network["PARTICULARS"] = "Fiber Optic Network";
					@$fiber_optic_network["FIRST_MONTH_VALUE"] +=  $value_one;
					@$fiber_optic_network["SECOND_MONTH_VALUE"] += $value_two;
					@$fiber_optic_network["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#Infrastructure
			if( $value['SUB_TYPE'] == "INFRA"){
					@$infrastructure["PARTICULARS"] = "Infrastructure";
					@$infrastructure["FIRST_MONTH_VALUE"] +=  $value_one;
					@$infrastructure["SECOND_MONTH_VALUE"] += $value_two;
					@$infrastructure["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#Itemized billing
			if( $value['SUB_TYPE'] == "Itemised bill"){
					@$itemized_billing["PARTICULARS"] = "Itemized billing";
					@$itemized_billing["FIRST_MONTH_VALUE"] +=  $value_one;
					@$itemized_billing["SECOND_MONTH_VALUE"] += $value_two;
					@$itemized_billing["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#M-Commerce & Toll Free
			if( $value['SUB_TYPE'] == "MFS Revenue"){
					@$mcommerce_toll_free["PARTICULARS"] = "M-Commerce & Toll Free";
					@$mcommerce_toll_free["FIRST_MONTH_VALUE"] +=  $value_one;
					@$mcommerce_toll_free["SECOND_MONTH_VALUE"] += $value_two;
					@$mcommerce_toll_free["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			#monthy access fee
			if( $value['SUB_TYPE'] == "monthy access fee"){
					@$monthy_access_fee["PARTICULARS"] = "Monthly Access Fee";
					@$monthy_access_fee["FIRST_MONTH_VALUE"] +=  $value_one;
					@$monthy_access_fee["SECOND_MONTH_VALUE"] += $value_two;
					@$monthy_access_fee["THIRD_MONTH_VALUE"] += $value_three;
			}
			
			
			
	  }
	 	
	 $data["intra_dom_calls"] = $intra_dom_calls;
	 $data["inter_dom_calls"] = $inter_dom_calls;
	 $data["voice_outgoing_revenue"] = $voice_outgoing_revenue;
	 $data["mtc"] = $mtc;
	 $data["int_outgoing_revenue"] = $int_outgoing_revenue;
	 $data["in_bound"] = $in_bound;
	 $data["out_bound"] = $out_bound;
	 $data["intra_operator_sms_ems_vms"] = $intra_operator_sms_ems_vms;
	 $data["off_net_outgoing"] = $off_net_outgoing;
	 $data['off_net_incoming_mtsms'] = $off_net_incoming_mtsms;
	 $data['off_net_incoming_isms'] = $off_net_incoming_isms;
	 $data['mobile_internet'] = $mobile_internet;
	 $data['internet_service_2g'] = $internet_service_2g;
	 $data['internet_service_2g_bundle'] = $internet_service_2g_bundle;
	 $data['internet_service_3g'] = $internet_service_3g;
	 #3g bundle form mobile_internet
	 $data['value_added_service'] = $value_added_service;
	 $data['fiber_optic_network'] = $fiber_optic_network;
	 $data['infrastructure'] = $infrastructure;
	 $data['itemized_billing'] = $itemized_billing;
	 $data['mcommerce_toll_free'] = $mcommerce_toll_free;
	 $data['monthy_access_fee'] = $monthy_access_fee;
	 
	 $data['date'] = $date;
    # get input post
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export')){
  		$data['action_type'] = 'csv';
  	}
		
		if(empty($data["subscriber_data"])){
			$this->webspice->message_board('Record is not found!');
			$this->load->view('btrc/btrc_revenue_sharing', $data);
			return false;
		}
		
		$this->load->view('btrc/print_btrc_revenue_sharing', $data);
	}
	
	function summary_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'summary_data');
		$this->webspice->permission_verify('summary_data');
			if( !$_POST ){
			$this->load->view('btrc/summary_data', $data);
			return false;
		  }
		$input = $this->webspice->get_input();	
		 $QUAD= $input->QUAD;
		 $YEAR= $input->YEAR;
     if($QUAD==1){
     	$date[0]=$YEAR.'-1-1';
     	$date[1]=$YEAR.'-2-1';
     	$date[2]=$YEAR.'-3-1';
     }elseif($QUAD==2){
    	$date[0]=$YEAR.'-4-1';
     	$date[1]=$YEAR.'-5-1';
     	$date[2]=$YEAR.'-6-1';
     }elseif($QUAD==3){
    	$date[0]=$YEAR.'-7-1';
     	$date[1]=$YEAR.'-8-1';
     	$date[2]=$YEAR.'-9-1';
     }else{
     	$date[0]=$YEAR.'-10-1';
     	$date[1]=$YEAR.'-11-1';
     	$date[2]=$YEAR.'-12-1';
     	}
		$sql = "SELECT SUB_TYPE, GL_CODE, GL_DESCRIPTION,
((NET_POSTPAID_ONE/TOTAL_NET_POSTPAID_ONE) * POSTPAID_AMOUNT_ONE) + CNC_ONE AS POSTPAID_COLLECTION_CNC_GL_ONE,
((NET_POSTPAID_TWO/TOTAL_NET_POSTPAID_TWO) * POSTPAID_AMOUNT_TWO) + CNC_TWO AS POSTPAID_COLLECTION_CNC_GL_TWO,
((NET_POSTPAID_THREE/TOTAL_NET_POSTPAID_THREE) * POSTPAID_AMOUNT_THREE) + CNC_THREE AS POSTPAID_COLLECTION_CNC_GL_THREE
FROM

(SELECT TBL_TB_GL.SUB_TYPE, TBL_TB_GL.GL_CODE, 
TBL_TB_GL.GL_DESCRIPTION, 
TBL_POSTPAID_DATA.REPORT_DATE, 

CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-01-01' THEN TBL_POSTPAID_DATA.VALUE ELSE 0 END AS POSTPAID_ONE,  
CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-02-01' THEN TBL_POSTPAID_DATA.VALUE ELSE 0 END AS POSTPAID_TWO,
CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-03-01' THEN TBL_POSTPAID_DATA.VALUE ELSE 0 END AS POSTPAID_THREE, 

CASE WHEN TBL_CNC_REVENUE.REPORT_DATE = '2017-01-01' THEN TBL_CNC_REVENUE.VALUE ELSE 0 END AS CNC_ONE,  
CASE WHEN TBL_CNC_REVENUE.REPORT_DATE = '2017-02-01' THEN TBL_CNC_REVENUE.VALUE ELSE 0 END AS CNC_TWO,
CASE WHEN TBL_CNC_REVENUE.REPORT_DATE = '2017-03-01' THEN TBL_CNC_REVENUE.VALUE ELSE 0 END AS CNC_THREE, 

CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-01-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-01-01' THEN (TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) ELSE 0 END AS NET_POSTPAID_ONE,  
CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-02-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-02-01' THEN (TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) ELSE 0 END AS NET_POSTPAID_TWO,
CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-03-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-03-01' THEN (TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) ELSE 0 END AS NET_POSTPAID_THREE, 

CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-01-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-01-01' THEN 
(SELECT SUM(TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) FROM TBL_TB_GL
LEFT JOIN TBL_POSTPAID_DATA ON TBL_TB_GL.GL_CODE = TBL_POSTPAID_DATA.GL AND TBL_POSTPAID_DATA.REPORT_DATE = '2017-01-01'
LEFT JOIN TBL_CNC_REVENUE ON TBL_TB_GL.GL_CODE = TBL_CNC_REVENUE.GL AND TBL_CNC_REVENUE.REPORT_DATE = '2017-01-01'
LEFT JOIN TBL_TRIAL_BALANCE ON TBL_TB_GL.GL_CODE = TBL_TRIAL_BALANCE.ACCOUNT AND TBL_TRIAL_BALANCE.REPORT_DATE = '2017-01-01' )
 ELSE 0 END AS TOTAL_NET_POSTPAID_ONE,  
 
CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-02-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-02-01' THEN 
(SELECT SUM(TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) FROM TBL_TB_GL
LEFT JOIN TBL_POSTPAID_DATA ON TBL_TB_GL.GL_CODE = TBL_POSTPAID_DATA.GL AND TBL_POSTPAID_DATA.REPORT_DATE = '2017-02-01'
LEFT JOIN TBL_CNC_REVENUE ON TBL_TB_GL.GL_CODE = TBL_CNC_REVENUE.GL AND TBL_CNC_REVENUE.REPORT_DATE = '2017-02-01'
LEFT JOIN TBL_TRIAL_BALANCE ON TBL_TB_GL.GL_CODE = TBL_TRIAL_BALANCE.ACCOUNT AND TBL_TRIAL_BALANCE.REPORT_DATE = '2017-02-01' )
ELSE 0 END AS TOTAL_NET_POSTPAID_TWO,

CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-03-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-03-01' THEN 
(SELECT SUM(TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) FROM TBL_TB_GL
LEFT JOIN TBL_POSTPAID_DATA ON TBL_TB_GL.GL_CODE = TBL_POSTPAID_DATA.GL AND TBL_POSTPAID_DATA.REPORT_DATE = '2017-03-01'
LEFT JOIN TBL_CNC_REVENUE ON TBL_TB_GL.GL_CODE = TBL_CNC_REVENUE.GL AND TBL_CNC_REVENUE.REPORT_DATE = '2017-03-01'
LEFT JOIN TBL_TRIAL_BALANCE ON TBL_TB_GL.GL_CODE = TBL_TRIAL_BALANCE.ACCOUNT AND TBL_TRIAL_BALANCE.REPORT_DATE = '2017-03-01' )
ELSE 0 END AS TOTAL_NET_POSTPAID_THREE,

CASE WHEN TBL_TRIAL_BALANCE.REPORT_DATE = '2017-01-01' THEN TBL_TRIAL_BALANCE.PERIOD_NET_BALANCE ELSE 0 END AS GL_ONE,  
CASE WHEN TBL_TRIAL_BALANCE.REPORT_DATE = '2017-02-01' THEN TBL_TRIAL_BALANCE.PERIOD_NET_BALANCE ELSE 0 END AS GL_TWO,
CASE WHEN TBL_TRIAL_BALANCE.REPORT_DATE = '2017-03-01' THEN TBL_TRIAL_BALANCE.PERIOD_NET_BALANCE ELSE 0 END AS GL_THREE, 

CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-01-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-01-01' AND TBL_TRIAL_BALANCE.REPORT_DATE = '2017-01-01' THEN 
((TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) + TBL_TRIAL_BALANCE.PERIOD_NET_BALANCE )
ELSE 0 END AS CALL_AND_CONTROL_ONE,

CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-02-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-02-01' AND TBL_TRIAL_BALANCE.REPORT_DATE = '2017-02-01' THEN 
((TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) + TBL_TRIAL_BALANCE.PERIOD_NET_BALANCE )
ELSE 0 END AS CALL_AND_CONTROL_TWO,

CASE WHEN TBL_POSTPAID_DATA.REPORT_DATE = '2017-03-01' AND TBL_CNC_REVENUE.REPORT_DATE = '2017-03-01' AND TBL_TRIAL_BALANCE.REPORT_DATE = '2017-03-01' THEN 
((TBL_POSTPAID_DATA.VALUE - TBL_CNC_REVENUE.VALUE) + TBL_TRIAL_BALANCE.PERIOD_NET_BALANCE )
ELSE 0 END AS CALL_AND_CONTROL_THREE,

(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '2017-01-01') AS POSTPAID_AMOUNT_ONE,
(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '2017-02-01') AS POSTPAID_AMOUNT_TWO,
(SELECT POSTPAID_COLLECTION FROM TBL_SUBSCRIBER_AND_IIG_COST WHERE REPORT_MONTH = '2017-03-01') AS POSTPAID_AMOUNT_THREE

FROM TBL_TB_GL
LEFT JOIN TBL_POSTPAID_DATA ON TBL_TB_GL.GL_CODE = TBL_POSTPAID_DATA.GL AND TBL_POSTPAID_DATA.REPORT_DATE IN('2017-01-01', '2017-02-01', '2017-03-01')
LEFT JOIN TBL_CNC_REVENUE ON TBL_TB_GL.GL_CODE = TBL_CNC_REVENUE.GL AND TBL_CNC_REVENUE.REPORT_DATE IN ('2017-01-01', '2017-02-01', '2017-03-01')
LEFT JOIN TBL_TRIAL_BALANCE ON TBL_TB_GL.GL_CODE = TBL_TRIAL_BALANCE.ACCOUNT AND TBL_TRIAL_BALANCE.REPORT_DATE IN ('2017-01-01', '2017-02-01', '2017-03-01')

) BASE_TABLE";
	 
	  $data['date']=$date;
    # get input post
		$data['action_type'] = 'view';
  	if( $this->input->post('print') ){
  		$data['action_type'] = 'print';
  	}elseif( $this->input->post('export')){
  		$data['action_type'] = 'csv';
  	}
	 	 $data['report_name']="Oracle Collection";
		 $data["get_record"] = $this->db->query($sql)->result();
     if(empty($data["get_record"])){
    	$this->webspice->message_board('Record is not found!');
    	$this->load->view('btrc/oracle_collection', $data);
			return false;
    	}
		$this->load->view('btrc/print_oracle_collection', $data);
	}	
	
}
	
	
	

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */