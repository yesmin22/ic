<?php
	
    $sql = "SELECT TBL_EVENTS.* FROM TBL_EVENTS WHERE TBL_EVENTS.STATUS=7";
    $result = $this->db->query($sql)->result();
  	
		$get_record = $result;
		//dd($get_record);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
	<style>

		body {
			font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
			font-size: 4px;
		
		}
		.fc-content span{color:white}

	</style>

	<script>
		$(document).ready(function() {
			
			$('a[href="#tab_events"]').on('shown.bs.tab', function (e) {
        $('#calendar').fullCalendar({
				header: {
					left: 'prev,next today',
					center: 'title',
					right: 'month,basicWeek,basicDay'
				},
				
				defaultDate: '<?php echo date("Y-m-d");?>',
				editable: false,
				default: true,
				eventLimit: true, // allow "more" link when too many events
				
				
				events: [
				<?php foreach( $get_record as $k=>$v ){?>
					{
						title: '<?php echo $v->EVENT_TITLE.'(Start Time:'.date("h:i a",strtotime($v->START_DATE)).',End Time:	'.date("h:i a",strtotime($v->END_DATE)).')';?>',
						start: '<?php echo date('Y-m-d',strtotime($v->START_DATE));?>',
						end: '<?php echo date('Y-m-d',strtotime($v->END_DATE ."+1 days")); ?>'
					},
				<?php } ?>
				],
				  textColor: 'red'
			});
        
    		});
		});
		
	</script>

</head>

<body>
<div id="wrapper">

	<div><?php include(APPPATH."views/header.php"); ?></div>
		
	<div id="page_index" class="main_container page_identifier">
		<div class="page_caption">Dashboard</div>
		<div class="page_body">
			
			
				<?php if( $this->webspice->get_user('USER_TYPE')=='organizational' ): ?>
					<?php $company_id = $this->webspice->get_user('COMPANY_ID'); ?>
					
					<div class="row" style="min-height:600px;">
						<div class="col-xs-2"> <!-- required for floating -->
						  <!-- Nav tabs -->
						  <ul class="nav nav-tabs tabs-left" id="my_tab">
								<li class="active"><a href="#home" data-toggle="tab">Home</a></li>
								<li><a href="#tab_notice" data-toggle="tab">Notices</a></li>
								<li><a href="#tab_news" data-toggle="tab">News</a></li>
								<li><a href="#tab_events" data-toggle="tab">Events</a></li>
								<li><a href="#tab_personnel" data-toggle="tab">Personnel</a></li>
								<li><a href="#tab_my_course" data-toggle="tab">My Courses</a></li>
						  </ul>
						</div>

						<div class="col-xs-10">
						  <!-- Tab panes -->
						  <div class="tab-content">
						  	<!--
								**************************************
								tab for home
								**************************************
								-->
								<div class="tab-pane active" id="home">
									<center><h4>Welcome to Learning and Earning Monitoring System.</h4></center>
								</div>
								
								<!--
								**************************************
								tab for news archive
								**************************************
								-->
								<div id="tab_news" class="tab-pane">
									<?php 
									$query = $this->db->query("SELECT * FROM (SELECT TBL_NEWS_ARCHIVE.*
									FROM TBL_NEWS_ARCHIVE 
									WHERE  TBL_NEWS_ARCHIVE.PUBLISH_DATE<=CURDATE()
									AND TBL_NEWS_ARCHIVE.STATUS=7) T1 WHERE T1.PUBLISH_DATE>=DATE_SUB(CURDATE(),INTERVAL 10 DAY)
									");
									$get_news = $query->result();?>
									<?php if(	$get_news	):?>
										<?php foreach($get_news as $k=>$v): ?>
										<div class="notice_section">
											<div class="panel_zero">&nbsp;</div>
											<div class="panel_heading">
											<?php echo $v->NEWS_TITLE; ?>
											</div>
											<div class="panel_details">
											<?php echo $v->NEWS_DETAILS; ?>
											</div>
											<div class="panel_date">
												<span class="publish">Published Date:</span> <?php echo date('d F, Y',strtotime($v->PUBLISH_DATE)); ?>
											</div>
											<div class="panel_file">
												<span >Download:</span> 
												<?php
												if($v->ATTACHMENTS)
												{
													$attachments=explode('|',$v->ATTACHMENTS);
													if(count($attachments)>1)
													{
														foreach($attachments as $attachment){
															if( file_exists($this->webspice->get_path('news_full'). $attachment) ): ?>
																<a href="<?php echo $this->webspice->get_path('news'). $attachment;?>" target="_blank"><?php echo substr($attachment,strlen($v->NEWS_ID));?></a>&nbsp;
															<?php endif; 
														}
													}
													else
														{?>
														<?php if( file_exists($this->webspice->get_path('news_full'). $v->ATTACHMENTS) ): ?>
															<a href="<?php echo $this->webspice->get_path('news'). $v->ATTACHMENTS;?>" target="_blank"><?php echo substr($v->ATTACHMENTS,strlen($v->NEWS_ID));?></a>&nbsp;
														<?php  endif;
														}
												}?> 
											</div>
										</div>
										<?php endforeach; ?>
										<?php else: ?>No available news.
									<?php endif;?>
									
								</div>


								<!--
								**************************************
								tab for events
								**************************************
								-->
								
								<div id="tab_events" class="tab-pane">
									
										<h3 class="fsecond no_spacing">All Events</h3>
										<div class="post_panel">
											<div id="calendar" style="margin-top:10px;">&nbsp;</div>
											
										</div>

									<br />
								</div>	
								
										
								<!--
								**************************************
								tab for notices
								**************************************
								-->
								<div id="tab_notice" class="tab-pane">
									<?php 
										$query = $this->db->query("SELECT * FROM (SELECT TBL_NOTICE.*
									FROM TBL_NOTICE 
									WHERE  TBL_NOTICE.PUBLISH_DATE<=CURDATE()
									AND TBL_NOTICE.STATUS=7) T1 WHERE T1.PUBLISH_DATE>=DATE_SUB(CURDATE(),INTERVAL 10 DAY)");
										$get_notice = $query->result();
									?>
									<?php if(	$get_notice	):?>
										<?php foreach($get_notice as $k=>$v): ?>
										
											<div class="notice_section">
												<div class="panel_zero">&nbsp;</div>
												<div class="panel_heading">
													<?php echo $v->NOTICE_TITLE; ?>
												</div>
												<div class="panel_details">
													<?php echo $v->NOTICE_DETAILS; ?>
												</div>
												<div class="panel_date">
													<span class="publish">Published Date:</span> <?php echo date('d F, Y',strtotime($v->PUBLISH_DATE)); ?>
												</div>
												<div class="panel_file">
													<span >Download:</span> 
													<?php
													if($v->ATTACHMENTS)
													{
														$attachments=explode('|',$v->ATTACHMENTS);
														if(count($attachments)>1)
														{
															foreach($attachments as $attachment){
																if( file_exists($this->webspice->get_path('notice_full'). $attachment) ): ?>
																	<a href="<?php echo $this->webspice->get_path('notice'). $attachment;?>" target="_blank"><?php echo substr($attachment,strlen($v->NOTICE_ID));?></a>&nbsp;
																<?php endif; 
															}
														}
														else
														{?>
															<?php if( file_exists($this->webspice->get_path('notice_full'). $v->ATTACHMENTS) ): ?>
																<a href="<?php echo $this->webspice->get_path('notice'). $v->ATTACHMENTS;?>" target="_blank"><?php echo substr($v->ATTACHMENTS,strlen($v->NOTICE_ID));?></a>&nbsp;
															<?php  endif;
														}
													}?>
												</div>
											</div>
										<?php endforeach; ?>
									<?php endif;?>
								
								</div>
	
							<!--
								**************************************
								tab for company personnel
								**************************************
							-->
							<div id="tab_personnel" class="tab-pane ">
								<?php  
									$query=$this->db->query("SELECT TBL_PERSONNEL.* FROM TBL_PERSONNEL WHERE COMPANY_CARAVAN_ID= '".$company_id."' ");
									$get_personnel = $query->result();
								?>
								<div class="table-responsive">
									<table class="table table-bordered table-striped new_table">
										
										<tr>      
											<th>Name</th>
											<th>Photograph</th>
											<th>Phone</th> 
											<th>Gender</th>
											<th>National Id</th>
											<th>Present Address</th>
											<th>Details</th>
											
										</tr>
										<?php foreach($get_personnel as $k=>$v): ?>
										<tr>    
											<td><?php echo $v->PERSONNEL_NAME; ?></td>
											<td>
												<?php if( file_exists($this->webspice->get_path('personnel_full').$v->PERSONNEL_ID.'.jpg') ): ?>
														<img src="<?php echo $this->webspice->get_path('personnel').$v->PERSONNEL_ID.'.jpg'; ?>"  alt="" class="img-responsive" width="100px;" /> 
												<?php endif;  ?>
											</td>
											<td><?php echo $v->PHONE; ?></td> 
											<td><?php echo $v->GENDER; ?></td>
											<td><?php echo $v->NATIONAL_ID; ?></td>
											<td><?php echo $v->PRESENT_ADDRESS; ?></td>
											<td  style="width:auto;">         
											  <a href="<?php echo $url_prefix; ?>manage_personnel/details/<?php echo $this->webspice->encrypt_decrypt($v->PERSONNEL_ID,'encrypt'); ?>" class="btn_orange">Details</a>
											</td>
										</tr>
										<?php endforeach; ?>
									</table>
								</div>
							</div>
	
							<!--
								**************************************
								tab for my courses
								**************************************
							-->
							<?php
								$course_sql = "
								SELECT b.BATCH_ID AS ID, b.SLOT_ID AS BATCH_SLOT_ID, b.BATCH_NO, b.status AS BATCH_STATUS, 
								b.company_id AS BATCH_COMPANY_ID, b.DIVISION_ID, b.DISTRICT_ID, b.UPAZILA_ID, b.UNION_ID, b.START_DATE
								AS BATCH_START_DATE, b.END_DATE AS BATCH_END_DATE, b.INAUGURATIONS_BY, b.INAUGURATIONS_DATE, b.CLOSED_BY, 
								b.CLOSED_BY, b.ATTACHMENTS, b.CREATED_BY AS COMPANY_USER_ID, b.CREATED_DATE AS BATCH_APPLIED_DATE, 
								b.APPROVED_DATE AS BATCH_APPROVED_DATE, b.APPROVED_BY AS BATCH_APPROVED_BY, 
								s.*, c.* 
								FROM TBL_BATCH AS b 
								INNER JOIN TBL_SLOT AS s ON b.SLOT_ID = s.SLOT_ID
								INNER JOIN TBL_COURSE AS c ON s.COURSE_ID = c.COURSE_ID WHERE b.COMPANY_ID = ?";
								
								$get_my_course = $this->db->query($course_sql, array($company_id))->result();
							?>
	
							<div id="tab_my_course" class="tab-pane">
								<table class="table table-bordered table-striped new_table">
									<tr>   
										<th>Course Name</th> 
										<th>Applied Date</th>
										<th>Approved Date</th>
										<th>Batch No</th>
										<th>Status</th>
									</tr>
									<?php foreach($get_my_course as $key => $val) : ?>
										<tr>
											<td>
												<?php
													echo $val->COURSE_TITLE .' ('.$val->SLOT_YEAR.','.$this->webspice->month_convert($val->SLOT_MONTH).')';
												?>
											</td>
											<td><?php echo date('Y-m-d', strtotime($val->BATCH_APPLIED_DATE)); ?></td>
											<td>
											<?php echo substr($val->BATCH_APPROVED_DATE, 0, strpos($val->BATCH_APPROVED_DATE, "-")) == "0000" ? "N/A" : date('Y-m-d', time($val->BATCH_APPROVED_DATE)); ?>
											</td>
											<td><?php echo $this->webspice->ordinal($val->BATCH_NO); ?></td>
											<td><?php echo $this->webspice->static_status($val->BATCH_STATUS); ?></td>
										</tr>
									<?php endforeach; ?>
									
								</table>
							</div>	
							</div>
				  	</div>
					</div>
				<?php else:?>

					<!-- Start admin panel from here -->

					Welcome to Learning and Earning Monitoring System.
					
			  <?php endif; ?>

			<div class="clearfix"></div>

						
		<div class="float_clear_full">&nbsp;</div>	
		<div><?php include(APPPATH."views/footer.php"); ?></div>	
		</div>
	</div>
</div>
</body>
</html>