<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Master_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
	}
	
	/*
	>> Error log should be added prefix Error:
	
	>> status
	1=Pending | 2=Approved | 3=Resolved | 4=Forwarded  | 5=Deployed  | 6=New  | 7=Active  | 
	8=Initiated  | 9=On Progress  | 10=Delivered  | -2=Declined | -3=Canceled | 
	-5=Taking out | -6=Renewed/Replaced | -7=Inactive
	*/
	
	
	function create_user($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_user');
		$this->webspice->permission_verify('create_user');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'USER_ID'=>null,
			'USER_NAME'=>null,  
			'USER_EMAIL'=>null,
			'USER_PHONE'=>null,
			'USER_ROLE'=>null,
			'IS_LOGGED'=>null
			);
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('register_name','register_name','required|trim|xss_clean');
		$this->form_validation->set_rules('register_email','register_email','required|valid_email|trim|xss_clean');
		$this->form_validation->set_rules('register_phone','register_phone','required|trim|xss_clean');
		$this->form_validation->set_rules('user_role','user_role','required|trim|xss_clean');
		$this->form_validation->set_rules('is_logged','is_logged','trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('user/create_user', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('user_id');
		
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_BUNDLE_USER WHERE USER_EMAIL=?", array( $input->register_email), 'You are not allowed to enter duplicate email', 'USER_ID', $input->user_id, $data, 'user/create_user');
		
		# remove cache
		$this->webspice->remove_cache('user');
		
		# update process
		if( $input->user_id ){
			#update query
			$sql = "
			UPDATE TBL_BUNDLE_USER SET USER_NAME=?, USER_EMAIL=?, USER_PHONE=?, ROLE_ID=?, UPDATED_BY=?, UPDATED_DATE=TO_DATE(?,'yyyy-mm-dd hh:mi:ss') 
			WHERE USER_ID=?";
			$this->db->query($sql, array($input->register_name, $input->register_email, $input->register_phone, $input->user_role, $this->webspice->get_user_id(), $this->webspice->now(), $input->user_id)); 

			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('user_updated - '.$input->register_email); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_user');
			return false;
		}
		
		# insert data
		$new_squence = $this->webspice->getLastInserted('TBL_BUNDLE_USER','USER_ID');
		#$random_password = rand(1,5);
		$random_password = 1234;
		$sql = "
		INSERT INTO TBL_BUNDLE_USER
		(USER_ID, USER_NAME, USER_EMAIL, USER_PHONE, USER_PASSWORD, ROLE_ID, CREATED_BY, CREATED_DATE, STATUS, SESSION_ID)
		VALUES
		(?, ?, ?, ?, ?, ?, ?, TO_DATE(?,'yyyy-mm-dd hh:mi:ss'), 8, 1)";
		$result = $this->db->query($sql, array($new_squence+1, $input->register_name, $input->register_email, $input->register_phone, 
		$this->webspice->encrypt_decrypt($random_password, 'encrypt'), $input->user_role, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		$this->webspice->log_me('user_created'); # log
		
		# send verification email
		$this->load->library('email_template');
		$this->email_template->send_new_user_password_change_email($input->register_name, $input->register_email);
		
		$this->webspice->message_board('An account has been created and sent an email to the user.');
		$this->webspice->force_redirect($url_prefix);
		 
	}
	function manage_user(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_user');
		$this->webspice->permission_verify('manage_user');

		$this->load->database();
    $orderby = null;
    $groupby = null;
    $where = ' WHERE ROWNUM <= 50';
    $page_index = 0;
    $no_of_record = 20;
    $limit = null;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = "
		SELECT TBL_BUNDLE_USER.*,
		TBL_BUNDLE_ROLE.ROLE_NAME
		FROM TBL_BUNDLE_USER
		LEFT JOIN TBL_BUNDLE_ROLE ON TBL_BUNDLE_ROLE.ROLE_ID = TBL_BUNDLE_USER.ROLE_ID
		";
		
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'TBL_BUNDLE_USER', 
			$InputField = array(), 
			$Keyword = array('USER_ID','USER_NAME','USER_EMAIL','USER_PHONE'),
			$AdditionalWhere = null,
			$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( $_SESSION['sql'] );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('user/print_user',$data);
				return false;
        break;

			case 'edit':
          $this->webspice->edit_generator($TableName='TBL_BUNDLE_USER', $KeyField='USER_ID', $key, $RedirectController='master_controller', $RedirectFunction='create_user', $PermissionName='manage_user', $StatusCheck=null, $Log='edit_user');          
					return false;
          break;
          
 			case 'inactive':
      		$this->webspice->action_executer($TableName='TBL_BUNDLE_USER', $KeyField='USER_ID', $key, $RedirectURL='manage_user', $PermissionName='manage_user', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='user', $Log='inactive_user');
					return false;	
          break; 

			case 'active':
					$this->webspice->action_executer($TableName='TBL_BUNDLE_USER', $KeyField='USER_ID', $key, $RedirectURL='manage_user', $PermissionName='manage_user', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='user', $Log='active_user');
					return false;	
			    break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }*/
    
		# load all records
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_user/page/', 10 );
		}*/
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		
		$this->webspice->log_me('viewed_user_list'); # log
		$this->load->view('user/manage_user', $data);
	}
	
	function create_role($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_user');
		$this->webspice->permission_verify('create_role,manage_role');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'ROLE_ID'=>null,
			'ROLE_NAME'=>null,  
			'PERMISSION_NAME'=>null
			);
		}
		
		# get permission name
		$sql = "SELECT TBL_BUNDLE_PERMISSION.* 
			FROM TBL_BUNDLE_PERMISSION 
			where TBL_BUNDLE_PERMISSION.STATUS = 1 
			and TBL_BUNDLE_PERMISSION.GROUP_NAME IN(
				SELECT GROUP_NAME FROM TBL_BUNDLE_PERMISSION GROUP BY GROUP_NAME
			)
			AND TBL_BUNDLE_PERMISSION.PERMISSION_NAME IN(
			SELECT PERMISSION_NAME FROM TBL_BUNDLE_PERMISSION GROUP BY PERMISSION_NAME
			) ORDER BY TBL_BUNDLE_PERMISSION.GROUP_NAME
		";
		$data['get_permission_with_group'] = $this->db->query($sql)->result();

		$this->load->library('form_validation');
		$this->form_validation->set_rules('role_name','role_name','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('user/create_role', $data);
			return FALSE;
		}

		# get input post
		$input = $this->webspice->get_input('ROLE_ID');

		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_BUNDLE_ROLE WHERE ROLE_NAME=?", array( $input->role_name), 'You are not allowed to enter duplicate role name.', 'ROLE_ID', $input->ROLE_ID, $data, 'user/create_role');
		
		# remove cache
		$this->webspice->remove_cache('role');
		
		# update data
		if( $input->ROLE_ID ){
			#update query
			$sql = "
			UPDATE TBL_BUNDLE_ROLE SET ROLE_NAME=?, PERMISSION_NAME=?, UPDATED_BY=?, UPDATED_DATE=TO_DATE(?,'yyyy-mm-dd hh:mi:ss') 
			WHERE ROLE_ID=?";
			$this->db->query($sql, array($input->role_name, implode(',',$input->permission), $this->webspice->get_user_id(), $this->webspice->now(), $input->ROLE_ID)); 

			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('role_updated - '.$input->role_name); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_role');
			return false;
		}
		
		# insert data
		$new_squence = $this->webspice->getLastInserted('TBL_BUNDLE_ROLE','ROLE_ID');
		$sql = "
		INSERT INTO TBL_BUNDLE_ROLE
		(ROLE_ID, ROLE_NAME, PERMISSION_NAME, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, TO_DATE(?,'yyyy-mm-dd hh:mi:ss'), 7)";
		$result = $this->db->query($sql, array($new_squence+1, $input->role_name, implode(',',$input->permission), $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->message_board('New Role has been created.');
		if( $this->webspice->permission_verify('manage_role', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_role');
		}
		$this->webspice->log_me('role_created'); # log
		$this->webspice->force_redirect($url_prefix);
	}
	function manage_role(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_user');
		$this->webspice->permission_verify('manage_role');

		$this->load->database();
    $orderby = null;
    $groupby = null;
    $where = ' WHERE ROWNUM <= 50';
    $page_index = 0;
    $no_of_record = 20;
    $limit = null;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = "
		SELECT TBL_BUNDLE_ROLE.*
		FROM TBL_BUNDLE_ROLE
		";
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'VIEW_ROLE', 
			$InputField = array(),
			$Keyword = array('ROLE_ID','ROLE_NAME','PERMISSION_NAME'),
			$AdditionalWhere = null,
			$DateBetween = array('CREATED_DATE', 'date_from', 'date_end')
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( $_SESSION['sql'] );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('user/print_role',$data);
				return false;
        break;

			case 'edit':
          $this->webspice->edit_generator($TableName='TBL_BUNDLE_ROLE', $KeyField='ROLE_ID', $key, $RedirectController='master_controller', $RedirectFunction='create_role', $PermissionName='create_role', $StatusCheck=null, $Log='edit_role');          
					return false;
          break; 
          
 			case 'inactive':
      		$this->webspice->action_executer($TableName='TBL_BUNDLE_ROLE', $KeyField='ROLE_ID', $key, $RedirectURL='manage_role', $PermissionName='manage_role', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='role', $Log='inactive_role');
					return false;	
          break; 

			case 'active':
					$this->webspice->action_executer($TableName='TBL_BUNDLE_ROLE', $KeyField='ROLE_ID', $key, $RedirectURL='manage_role', $PermissionName='manage_role', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='role', $Log='active_role');
					return false;	
			    break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }*/
    
		# load all records for pager
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_role/page/', 10 );
		}*/
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->webspice->log_me('viewed_user_role'); # log
		$this->load->view('user/manage_role', $data);
	}
	
	function create_option($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_option');
		$this->webspice->permission_verify('create_option,manage_option');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'OPTION_ID'=>null,
			'OPTION_VALUE'=>null,  
			'GROUP_NAME'=>null,
			'PARENT_ID'=>null,
			'STATUS'=>null
			);
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('option_value','option_value','required|trim|xss_clean');
		$this->form_validation->set_rules('group_name','group_name','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_option', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('key');
		
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_BUNDLE_OPTION WHERE OPTION_VALUE=? AND GROUP_NAME=?", array( $input->option_value, $input->group_name), 'You are not allowed to enter duplicate option value', 'OPTION_ID', $input->key, $data, 'master/create_option');
		
		# remove cache
		$this->webspice->remove_cache('option');
		
		# update process
		if( $input->key ){
			#update query
			$sql = "
			UPDATE TBL_BUNDLE_OPTION SET OPTION_VALUE=?, UPDATED_BY=?, UPDATED_DATE=TO_DATE(?,'yyyy-mm-dd hh:mi:ss') 
			WHERE OPTION_ID=?";
			$this->db->query($sql, array($input->option_value, $this->webspice->get_user_id(), $this->webspice->now(), $input->key)); 
	#dd( $this->db->last_query() );	
			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('option_updated - '.$input->option_value); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_option');
			return false;
		}

		# insert data
		$new_squence = $this->webspice->getLastInserted('TBL_BUNDLE_OPTION','OPTION_ID');
		$sql = "
		INSERT INTO TBL_BUNDLE_OPTION
		(OPTION_ID, OPTION_VALUE, GROUP_NAME, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, TO_DATE(?,'yyyy-mm-dd hh:mi:ss'), 7)";
		$result = $this->db->query($sql, array($new_squence+1, $input->option_value, $input->group_name, $this->webspice->get_user_id(), $this->webspice->now()));

		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->log_me('created_option'); # log
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_option', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_option');
		}

		$this->webspice->force_redirect($url_prefix);
	}
	function manage_option(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
		
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_option');
		$this->webspice->permission_verify('manage_option');

		$this->load->database();
    $orderby = null;
    $groupby = null;
    $where = ' WHERE ROWNUM <= 50';
    $page_index = 0;
    $no_of_record = 20;
    $limit = null;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = "
		SELECT VIEW_OPTION.*
		FROM VIEW_OPTION
		";
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'VIEW_OPTION', 
			$InputField = array(), 
			$Keyword = array('OPTION_ID','OPTION_VALUE','GROUP_NAME'),
			$AdditionalWhere = null,
			$DateBetween = array()
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( $_SESSION['sql'] );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('master/print_option',$data);
				return false;
        break;

			case 'edit':
          $this->webspice->edit_generator($TableName='TBL_BUNDLE_OPTION', $KeyField='OPTION_ID', $key, $RedirectController='master_controller', $RedirectFunction='create_option', $PermissionName='create_option,manage_option', $StatusCheck=null, $Log='edit_user');          
					return false;
          break;
          
 			case 'inactive':
      		$this->webspice->action_executer($TableName='TBL_BUNDLE_OPTION', $KeyField='OPTION_ID', $key, $RedirectURL='manage_option', $PermissionName='manage_option', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='option', $Log='inactive_option');
					return false;	
          break; 

			case 'active':
					$this->webspice->action_executer($TableName='TBL_BUNDLE_OPTION', $KeyField='OPTION_ID', $key, $RedirectURL='manage_option', $PermissionName='manage_option', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='option', $Log='active_option');
					return false;	
			    break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;

    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }*/
    
		# load all records
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_option/page/', 10 );
		}*/
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
  	
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;
		$this->webspice->log_me('viewed_option_list'); # log
		$this->load->view('master/manage_option', $data);
	}
	
	function create_service($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;

		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_service');
		$this->webspice->permission_verify('create_service,manage_service');
		
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'SERVICE_ID'=>null,
			'SERVICE_NAME'=>null,  
			'UNIT'=>null,
			'UNIT_PRICE'=>null,
			'PRICE_TYPE'=>null,
			'GL_CODE'=>null,
			'VAT_APPLICABLE'=>null,
			'STATUS'=>null
			);
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('service_name','service_name','required|trim|xss_clean');
		$this->form_validation->set_rules('unit','unit','required|trim|xss_clean');
		$this->form_validation->set_rules('unit_price','unit_price','required|trim|xss_clean');
		$this->form_validation->set_rules('price_type','price_type','required|trim|xss_clean');
		$this->form_validation->set_rules('gl_code','gl_code','required|trim|xss_clean');
		$this->form_validation->set_rules('vat_applicable','vat_applicable','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_service', $data);
			return FALSE;
		}
		
		# get input post
		$input = $this->webspice->get_input('key');
		
		#duplicate test
		$this->webspice->db_field_duplicate_test("SELECT * FROM TBL_BUNDLE_SERVICE WHERE SERVICE_NAME=?", array( $input->service_name), 'You are not allowed to enter duplicate service name', 'SERVICE_ID', $input->key, $data, 'master/create_service');
		
		# remove cache
		$this->webspice->remove_cache('service');
		
		# update process
		if( $input->key ){
			#update query
			$sql = "
			UPDATE TBL_BUNDLE_SERVICE SET SERVICE_NAME=?, UNIT=?, UNIT_PRICE=?, PRICE_TYPE=?, GL_CODE=?, VAT_APPLICABLE=?, UPDATED_BY=?, UPDATED_DATE=TO_DATE(?,'yyyy-mm-dd hh:mi:ss') 
			WHERE SERVICE_ID=?";
			$this->db->query($sql, array($input->service_name, $input->unit, $input->unit_price, $input->price_type, $input->gl_code, $input->vat_applicable, $this->webspice->get_user_id(), $this->webspice->now(), $input->key)); 

			$this->webspice->message_board('Record has been updated!');
			$this->webspice->log_me('service_updated - '.$input->service_name); # log activities
			$this->webspice->force_redirect($url_prefix.'manage_service');
			return false;
		}
		
		# insert data
		$new_squence = $this->webspice->getLastInserted('TBL_BUNDLE_SERVICE','SERVICE_ID');
		$random_password = rand(1,5);
		$sql = "
		INSERT INTO TBL_BUNDLE_SERVICE
		(SERVICE_ID, SERVICE_NAME, UNIT, UNIT_PRICE, PRICE_TYPE, GL_CODE, VAT_APPLICABLE, CREATED_BY, CREATED_DATE, STATUS)
		VALUES
		(?, ?, ?, ?, ?, ?, ?, ?, TO_DATE(?,'yyyy-mm-dd hh:mi:ss'), 7)";
		$result = $this->db->query($sql, array($new_squence+1, $input->service_name, $input->unit, $input->unit_price, $input->price_type, $input->gl_code, $input->vat_applicable, $this->webspice->get_user_id(), $this->webspice->now()));
		
		if( !$result ){
			$this->webspice->message_board('We could not execute your request. Please tray again later or report to authority.');
			$this->webspice->force_redirect($url_prefix);
			return false;
		}
		
		$this->webspice->log_me('created_service'); # log
		$this->webspice->message_board('Record has been inserted successfully.');
		if( $this->webspice->permission_verify('manage_service', true) ){
			$this->webspice->force_redirect($url_prefix.'manage_service');
		}

		$this->webspice->force_redirect($url_prefix);
	}
	function manage_service(){
	
	#$get_data = $this->db->query("SELECT * FROM TBL_BUNDLE_SERVICE")->result();
	#dd($get_data);
	$url_prefix = $this->webspice->settings()->site_url_prefix;
	
	$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_service');
	$this->webspice->permission_verify('manage_service');

	$this->load->database();
    $orderby = null;
    $groupby = null;
    $where = ' WHERE ROWNUM <= 50';
    $page_index = 0;
    $no_of_record = 20;
    $limit = null;
    $filter_by = 'Last Created';
    $data['pager'] = null;
    $criteria = $this->uri->segment(2);
    $key = $this->uri->segment(3);
    if ($criteria == 'page') {
    	$page_index = (int)$key; 
    	$page_index < 0 ? $page_index=0 : $page_index=$page_index;
    }

		$initialSQL = "
		SELECT VIEW_SERVICE.*
		FROM VIEW_SERVICE
		";
    
   	# filtering records
    if( $this->input->post('filter') ){
			$result = $this->webspice->filter_generator(
			$TableName = 'VIEW_SERVICE', 
			$InputField = array(), 
			$Keyword = array('SERVICE_NAME','UNIT','GL_CODE'),
			$AdditionalWhere = null,
			$DateBetween = array()
			);

			$result['where'] ? $where = $result['where'] : $where=$where;
			$result['filter'] ? $filter_by = $result['filter'] : $filter_by=$filter_by;
   	}

    # action area
    switch ($criteria) {
      case 'print':
      case 'csv':
        if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
					$_SESSION['sql'] = $initialSQL . $where . $orderby;
					$_SESSION['filter_by'] = $filter_by;
    		}
    		
    		$record = $this->db->query( $_SESSION['sql'] );										 		
				$data['get_record'] = $record->result();
				$data['filter_by'] = $_SESSION['filter_by'];
			
				$this->load->view('master/print_service',$data);
				return false;
        break;

			case 'edit':
          $this->webspice->edit_generator($TableName='TBL_BUNDLE_SERVICE', $KeyField='SERVICE_ID', $key, $RedirectController='master_controller', $RedirectFunction='create_service', $PermissionName='manage_service', $StatusCheck=null, $Log='edit_service');          
					return false;
          break;
          
 			case 'inactive':
      		$this->webspice->action_executer($TableName='TBL_BUNDLE_SERVICE', $KeyField='SERVICE_ID', $key, $RedirectURL='manage_service', $PermissionName='manage_service', $StatusCheck=7, $ChangeStatus=-7, $RemoveCache='service', $Log='inactive_service');
					return false;	
          break; 

			case 'active':
					$this->webspice->action_executer($TableName='TBL_BUNDLE_SERVICE', $KeyField='SERVICE_ID', $key, $RedirectURL='manage_service', $PermissionName='manage_service', $StatusCheck=-7, $ChangeStatus=7, $RemoveCache='service', $Log='active_service');
					return false;	
			    break;                  
    }
    
    # default
    $sql = $initialSQL . $where . $groupby . $orderby . $limit;
    
    # only for pager
/*    if( $criteria == 'page' ){
    	if( !isset($_SESSION['sql']) || !$_SESSION['sql'] ){
    		$sql = $sql;
    	}
    	$limit = sprintf("LIMIT %d, %d", $page_index, $no_of_record);		# this is to avoid SQL Injection
    	$sql = substr($_SESSION['sql'], 0, strpos($_SESSION['sql'],'LIMIT'));
    	$sql = $sql . $limit;
    }*/
    
		# load all records
/*		if( !$this->input->post('filter') ){
			$count_data = $this->db->query( substr($sql,0,strpos($sql,'LIMIT')) );
			$count_data = $count_data->result();
			$data['pager'] = $this->webspice->pager( count($count_data), $no_of_record, $page_index, $url_prefix.'manage_service/page/', 10 );
		}*/
    
    $_SESSION['sql'] = $sql;
    $_SESSION['filter_by'] = $filter_by;
    $result = $this->db->query($sql)->result();
  	
	$this->webspice->log_me('viewed_service_list'); # log
		$data['get_record'] = $result;
		$data['filter_by'] = $filter_by;

		$this->load->view('master/manage_service', $data);
	}
	
	#load all confihuration data
	function view_configuration_data(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'view_configuration_data');
		$this->webspice->permission_verify('view_configuration_data');
		$criteria = $this->uri->segment(2);
		if( $criteria == 'edit' ){
			$key = $this->uri->segment(3);
			$attribute = $this->webspice->encrypt_decrypt($this->uri->segment(4),'decrypt');
			$data_set = $this->ft->get('config',$key);
			$value = $data_set->{'0'}->$attribute;
			$data['edit'] = array(
											'attribute'=> $attribute,
											'value'=> $value,
											'key'=> $key
											);
			$data['get_record'] = $this->ft->get($parent='config');								
			$this->load->library('form_validation');								
			$this->load->view('master/update_configuration_data', $data);
			return FALSE;								
				
		}
		$filter_by = 'All Data';
		$data['filter_by'] = $filter_by;
		$data['get_record'] = $this->ft->get($parent='config');
		$this->load->view('master/view_configuration_data',$data);
		return false;
	}
	
	#update configuration data
	function update_configuration_data($data=null){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'update_configuration_data');
		$this->webspice->permission_verify('update_configuration_data');
		$data['get_record'] = $this->ft->get($parent='config');
		#for ajax calling
		if( $this->input->post('ajax_call') ){
			$result = $this->ft->search($parent='config',$attribute=$this->input->post('attribute'));
			echo json_encode($result);
			return false;
		}	
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'attribute'=>null,
			'value'=>null,
			'key' => null
			);
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('attribute','attribute','required|trim|xss_clean');
		$this->form_validation->set_rules('value','value','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/update_configuration_data', $data);
			return FALSE;
		}
		#update
		$this->ft->set('config',$this->input->post('key'),$this->input->post('attribute'),$this->input->post('value'));
		$this->webspice->message_board("Record has been updated successfully!");
		$this->webspice->force_redirect($url_prefix.'view_configuration_data');
		return false;
	}
	#create/update customer 
	function create_customer($data=null){
		#dd ($this->ft->get('customer'));
		#$cName = 'cName';
		#dd($val->{'0'}->$cName);
		#dd($this->ft->del('customer',5,'cName'));
		#dd($this->ft->set('config',0,'MB_rate',0.401));
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'create_customer');
		$this->webspice->permission_verify('create_customer');
		#load all customer
		$data['get_record'] = $this->ft->get($parent='customer');
		#dd($data['get_record']);
		if( !isset($data['edit']) ){
			$data['edit'] = array(
			'attribute'=> null,
			'value'=> null,
			'key' => null,
			'customer' => null
			);
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('value','value','required|trim|xss_clean');

		if( !$this->form_validation->run() ){ 
			$this->load->view('master/create_customer', $data);
			return FALSE;
		}
		#insert 
		if( $this->input->post('customer_name') == 'customer' ){
			$key =  ( $this->input->post('original_key') != '') ? $this->input->post('original_key') : $this->ft->iid('customer')+1;
			$this->ft->set('customer',$key,'cName',$this->input->post('value'));
		}
		if( $this->input->post('customer_name') == 'customer_alias' ){
			$key = $this->input->post('key');
			$attribute = ( $this->input->post('attribute') ) ? $this->input->post('attribute') : date('Y_m_d_i_h_s_a');
			$this->ft->set('customer',$key,$attribute,$this->input->post('value'));
		}
		#update
		$this->webspice->message_board("Record inserted updated successfully!");
		$this->webspice->force_redirect($url_prefix.'manage_customer');
		return false;
	}
	
	#manage customer
	function manage_customer(){
		$url_prefix = $this->webspice->settings()->site_url_prefix;
	
		$this->webspice->user_verify($url_prefix.'login', $url_prefix.'manage_customer');
		$this->webspice->permission_verify('manage_customer');
		$criteria = $this->uri->segment(2);
		$data['get_record'] = $this->ft->get('customer');
		if( $criteria == 'edit' ){
			$key = $this->uri->segment(3);
			$customer = 'cName';
			$attribute = $this->webspice->encrypt_decrypt($this->uri->segment(4),'decrypt');
			$data_set = $this->ft->get('customer');
			$value = $data_set->{$key}->$attribute;
			$customer = $data_set->{$key}->$customer;
			$data['edit'] = array(
											'attribute'=> $attribute,
											'value'=> $value,
											'key'=> $key,
											'customer' => $customer
											);
						
			$this->load->library('form_validation');								
			$this->load->view('master/create_customer', $data);
			return FALSE;								
				
		}
		$this->load->view('master/manage_customer',$data);
		return false;
	}
	# call confirmation for redirect another url with message
	function confirmation($message){
		$_SESSION['confirmation'] = $message;
		$this->webspice->force_redirect($this->webspice->settings()->site_url_prefix.'confirmation');
	}
	
	function show_confirmation(){
		if( !isset($_SESSION['confirmation']) ){
			$_SESSION['confirmation'] = array();	
		}
		$data = $_SESSION['confirmation'];
		$this->load->view('view_message',$data);
	}
	
}

/* End of file */
/* Location: ./application/controllers/ */