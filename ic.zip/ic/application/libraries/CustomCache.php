<?php
class CustomCache{
	
	var $static_url = 'http://static.domain.com';

	# starts session
	function CustomCache(){
		if(!isset($_SESSION)){
			session_start();
		}
	}

	# get user information by user id from database
	function user_maker($user_id, $output_filed){
		# $output_filed - get db field name

		$CI =&get_instance();
		$cache_name = 'user_maker';
		
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		
		if( !$html = $CI->cache->get($cache_name, 'user') ){
			$data['html'] = array();
			
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_USER ORDER BY USER_ID DESC");
			$get_record = $get_record->result();
			
			foreach( $get_record as $k=>$v ){
				$html[] = $v->USER_ID.'|'.$v->ROLE_ID.'|'.$v->USER_NAME.'|'.$v->USER_EMAIL.'|'.$v->USER_PHONE.'|'.$v->CREATED_DATE.'|'.
									$v->UPDATED_DATE.'|'.$v->STATUS;
			}

			$CI->cache->save($cache_name, $html, 'user', 604800);		
		}
		
		foreach($html as $k=>$v){
			$Value = explode('|', $v);
			if( $Value[0]==$user_id ){
				switch($output_filed){
					case 'USER_ID': return $Value[0]; break;
					case 'ROLE_ID': return $Value[1]; break;
					case 'USER_NAME': return $Value[2]; break;
					case 'USER_EMAIL': return $Value[3]; break;
					case 'USER_PHONE': return $Value[4]; break;
					case 'USER_CREATED_DATE': return $Value[5]; break;
					case 'USER_UPDATED_DATE': return $Value[6]; break;
					case 'STATUS': return $Value[7]; break;
					case 'COMPANY_ID': return $Value[8]; break;
				}
				
			}

		}

		return false;
	}
	
	# get user role
	function get_user_role($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$cache_name = 'user_role_option';
		$group_name	=	'role';
		
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		$type == 'option_mix' ? $cache_name = 'user_role_option_mix' : $cache_name = $cache_name;
		$type == 'list' ? $cache_name = 'user_role_list' : $cache_name = $cache_name;
		
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_ROLE WHERE STATUS=7  ORDER BY ROLE_NAME");
			$get_record = $get_record->result();
		
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->ROLE_ID.'">'.ucwords(str_replace('_',' ',$v->ROLE_NAME)).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ROLE_ID.'|'.$v->ROLE_NAME.'">'.ucwords(str_replace('_',' ',$v->ROLE_NAME)).'</option>';
						break;
					case 'list':
						$data['html'] .= '<li class="list_item" data-id="'.$v->ROLE_ID.'">'.ucwords(str_replace('_',' ',$v->ROLE_NAME)).'</li>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		
		return $data['html'];
	}
	
	# get location
	function get_location($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$cache_name = 'location_option';
		$group_name	=	'location';
		
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		$type == 'option_mix' ? $cache_name = 'location_option_mix' : $cache_name = $cache_name;
		$type == 'list' ? $cache_name = 'location_list' : $cache_name = $cache_name;
		
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_LOCATION WHERE STATUS=7 ORDER BY LOCATION_NAME");
			$get_record = $get_record->result();
		
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords(str_replace('_',' ',$v->LOCATION_NAME)).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->LOCATION_NAME.'">'.ucwords(str_replace('_',' ',$v->LOCATION_NAME)).'</option>';
						break;
					case 'list':
						$data['html'] .= '<li class="list_item" data-id="'.$v->ID.'">'.ucwords(str_replace('_',' ',$v->LOCATION_NAME)).'</li>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		
		return $data['html'];
	}
	# get user
	function get_user($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$cache_prefix = 'user';
		$cache_name = $cache_prefix.'_option';
		$cache_group = 'user';
		
		# to delete cache use: 
		# $CI->cache->remove_group('subhead');
		$CI->load->library('cache');
		$type == 'option' ? $cache_name = $cache_prefix.'_option' : $cache_name = $cache_name;
		$type == 'employee_id' ? $cache_name = $cache_prefix.'_employee_id' : $cache_name = $cache_name;
		$type == 'option_mix' ? $cache_name = $cache_prefix.'_option_mix' : $cache_name = $cache_name;
		$type == 'list' ? $cache_name = $cache_prefix.'_list' : $cache_name = $cache_name;
		
		if( !$data['html'] = $CI->cache->get($cache_name, $cache_group) ){
			$data['html'] = null;
			
			$CI->load->database();
			
			$sqls="SELECT tbl_user.*
						FROM tbl_user 
						WHERE tbl_user.STATUS=7";
			
			$get_record = $CI->db->query($sqls);
			$get_record = $get_record->result();
		
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->USER_ID.'">'.ucwords($v->EMPLOYEE_ID.' &raquo; '.$v->USER_NAME.' &raquo; '.$v->DESIGNATION.' &raquo; '.$v->DEPARTMENT_DIVISION).'</option>';
						break;
					case 'employee_id':
						$data['html'] .= '<option value="'.$v->EMPLOYEE_ID.'">'.ucwords($v->EMPLOYEE_ID.' &raquo; '.$v->USER_NAME.' &raquo; '.$v->DESIGNATION.' &raquo; '.$v->DEPARTMENT_DIVISION).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->USER_ID.'|'.$v->USER_NAME.'">'.ucwords($v->DESIGNATION.' &raquo; '.$v->DEPARTMENT_DIVISION).'</option>';
						break;
					case 'option_value':
						$data['html'] .= '<option value="'.$v->USER_NAME.'">'.ucwords($v->USER_NAME.' &raquo; '.$v->DESIGNATION.' &raquo; '.$v->DEPARTMENT_DIVISION).'</option>';
						break;
					case 'list':
						$data['html'] .= '<li class="list_item" data-id="'.$v->USER_ID.'">'.ucwords($v->USER_ID).'</li>';
						break;
				}
			}
			
			$CI->cache->save($cache_name, $data['html'], $cache_group, 604800);		
		}
		
		return $data['html'];
	}
	
	# get product
	function get_product($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$cache_name = 'product_option';
		$group_name	=	'product';
		
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		$type == 'option_mix' ? $cache_name = 'location_option_mix' : $cache_name = $cache_name;
		$type == 'list' ? $cache_name = 'location_list' : $cache_name = $cache_name;
		
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_PRODUCT WHERE STATUS=7 ORDER BY PRODUCT_NAME");
			$get_record = $get_record->result();
		
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords(str_replace('_',' ',$v->PRODUCT_NAME)).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->PRODUCT_NAME.'">'.ucwords(str_replace('_',' ',$v->PRODUCT_NAME)).'</option>';
						break;
					case 'list':
						$data['html'] .= '<li class="list_item" data-id="'.$v->ID.'">'.ucwords(str_replace('_',' ',$v->PRODUCT_NAME)).'</li>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		
		return $data['html'];
	}
	
		
	function get_operator($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$group_name = 'operator';
		$temp_cache_name = 'operator';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		switch($type){
			case 'option': $cache_name = $temp_cache_name.'_option'; break;
			case 'option_mix': $cache_name = $temp_cache_name.'_option_mix'; break;
			case 'option_name': $cache_name = $temp_cache_name.'_option_name'; break;
			case 'list': $cache_name = $temp_cache_name.'_list'; break;
			default: $cache_name = $temp_cache_name.'_option'; break;
		}
	
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			$CI->load->database();
			$get_record = $CI->db->query("SELECT ID, OPERATOR_NAME, OPERATOR_TYPE FROM TBL_OPERATOR");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
					
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords($v->OPERATOR_NAME).' ('.$v->OPERATOR_TYPE.')</option>';
						break;
					case 'option_name':
						$data['html'] .= '<option value="'.$v->OPERATOR_NAME.'">'.ucwords($v->OPERATOR_NAME).' ('.$v->OPERATOR_TYPE.')</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->OPERATOR_NAME.'">'.$v->OPERATOR_NAME.' ('.$v->OPERATOR_TYPE.')</option>';
						break;
						
					case 'option_for_type':
						$data['html'] .= '<option value="'.$v->OPERATOR_TYPE.'|'.$v->OPERATOR_NAME.'">'.$v->OPERATOR_NAME.' ('.$v->OPERATOR_TYPE.')</option>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		return $data['html'];
	}
	
	# get user information by user id from database
	function operator_maker($operator_name, $output_filed=null,$operator_type=null){
		# $output_filed - get db field name
		$CI =&get_instance();
		$cache_name = 'operator_maker';
		$group_name = 'operator';
		
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		
		if( !$html = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = array();
			
			$CI->load->database();
			$get_record = $CI->db->query(" SELECT * FROM TBL_OPERATOR");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				$html[] = $v->ID.'|'.$v->OPERATOR_NAME.'|'.$v->OPERATOR_SHORT_CODE.'|'.$v->OPERATOR_TYPE.'|'.$v->PROJECT_CODE.'|'.$v->CREATED_DATE.'|'.
									$v->UPDATED_DATE.'|'.$v->STATUS.'|'.$v->ATTENTION.'|'.$v->ADDRESS.'|'.$v->TEL_NO.'|'.$v->VAT_REG_NO.'|'.$v->REF_NO.'|'.$v->SUPPLIER_CODE;
			}
			$CI->cache->save($cache_name, $html, $group_name, 604800);		
		}
		foreach($html as $k=>$v){
			$Value = explode('|', $v);
			if( $Value[1]==$operator_name && $Value[3]==$operator_type){
				if($output_filed){
					switch($output_filed){
						case 'ID': return $Value[0]; break;
						case 'OPERATOR_NAME': return $Value[1]; break;
						case 'OPERATOR_SHORT_CODE': return $Value[2]; break;
						case 'OPERATOR_TYPE': return $Value[3]; break;
						case 'PROJECT_CODE': return $Value[4]; break;
					}
				}else{
					return $Value;
				}
			
			}
		}
		
		return false;
	}
	
	
	
	
	
	
	
	
	
	function operator_maker_new($operator_name, $output_filed=null){
		# $output_filed - get db field name
		$CI =&get_instance();
		$cache_name = 'operator_maker';
		$group_name = 'operator';
		
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		
		if( !$html = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = array();
			
			$CI->load->database();
			$get_record = $CI->db->query(" SELECT * FROM TBL_OPERATOR");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				$html[] = $v->ID.'|'.$v->OPERATOR_NAME.'|'.$v->OPERATOR_SHORT_CODE.'|'.$v->OPERATOR_TYPE.'|'.$v->PROJECT_CODE.'|'.$v->CREATED_DATE.'|'.
									$v->UPDATED_DATE.'|'.$v->STATUS.'|'.$v->ATTENTION.'|'.$v->ADDRESS.'|'.$v->TEL_NO.'|'.$v->VAT_REG_NO.'|'.$v->REF_NO.'|'.$v->SUPPLIER_CODE;
			}
			$CI->cache->save($cache_name, $html, $group_name, 604800);		
		}
		foreach($html as $k=>$v){
			$Value = explode('|', $v);
			if( $Value[1]==$operator_name){
				if($output_filed){
					switch($output_filed){
						case 'ID': return $Value[0]; break;
						case 'OPERATOR_NAME': return $Value[1]; break;
						case 'OPERATOR_SHORT_CODE': return $Value[2]; break;
						case 'OPERATOR_TYPE': return $Value[3]; break;
						case 'PROJECT_CODE': return $Value[4]; break;
					}
				}else{
					return $Value;
				}
			
			}
		}
		
		return false;
	}
	
	# get user information by user id from database
	function gl_maker_rev($operator_name){
		# $output_filed - get db field name
		$CI =&get_instance();
		$cache_name = 'demestic_rev_gl';
		$group_name = 'gl';
		
		# to delete cache use: $this->cache->remove_group('group_name');
		
		$CI->load->library('cache');
		if( !$html = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = array();
			
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_DOMESTIC_REV_GL_MAPPING");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				$html[] = $v->ID.'|'.$v->OPERATOR_NAME.'|'.$v->INVOICE.'|'.$v->POST_VOICE_DEBIT.'|'.$v->PRE_VOICE_DEBIT.'|'.$v->POST_VOICE_CREDIT.'|'.$v->PRE_VOICE_CREDIT.'|'.$v->POST_SMS_DEBIT.'|'.$v->POST_SMS_CREDIT.'|'.$v->PRE_SMS_DEBIT.'|'.$v->PRE_SMS_CREDIT;
			}

			$CI->cache->save($cache_name, $html, $group_name, 604800);		
		}
		$gl_array = array();
		foreach($html as $k=>$v){
			$Value = explode('|', $v);
			if( $Value[1]==$operator_name){
				return $Value;
			}
		}
		return false;
	}
	
	function gl_maker_cost($operator_name){
		# $output_filed - get db field name
		$CI =&get_instance();
		$cache_name = 'demestic_cost_gl';
		$group_name = 'gl';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		if( !$html = $CI->cache->get($cache_name, $group_name)){
			$data['html'] = array();
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_DOMESTIC_COST_GL_MAPPING");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				$html[] = $v->ID.'|'.$v->OPERATOR_NAME.'|'.$v->ACCURED.'|'.$v->POST_VOICE.'|'.$v->PRE_VOICE.'|'.$v->POST_SMS.'|'.$v->PRE_SMS;
			}

			$CI->cache->save($cache_name, $html, $group_name, 604800);		
		}
		$gl_array = array();
		foreach($html as $k=>$v){
			$Value = explode('|', $v);
			if( $Value[1]==$operator_name){
				return $Value;
			}
		}
		return false;
	}
	
	
	function get_common_gl($operator_name){
		# $output_filed - get db field name
		$CI =&get_instance();
		$cache_name = 'domestic_rev_common_gl_mapping';
		$group_name = 'gl';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		if( !$html = $CI->cache->get($cache_name, $group_name)){
			$data['html'] = array();
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_COMMON_GL_MAPPING");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				$html[] = $v->ID.'|'.$v->VAT.'|'.$v->TF_INVOICE.'|'.$v->TF_REVENUE.'|'.$v->TF_SD.'|'.$v->TF_SC.'|'.$v->COST_INTN_POST.'|'.$v->COST_INTN_PRE.'|'.$v->ICX_PORTION.'|'.$v->BTRC_PORTION.'|'.$v->IGW_PORTION.'|'.$v->INTN_REV_INVOICE.'|'.$v->INTN_REV_POST_DEBIT.'|'.$v->INTN_REV_PRE_DEBIT.'|'.$v->INTN_REV_POST_CREDIT.'|'.$v->INTN_REV_PRE_CREDIT;
			}

			$CI->cache->save($cache_name, $html, $group_name, 604800);		
		}
		$gl_array = array();
		foreach($html as $k=>$v){
			$Value = explode('|', $v);
			return $Value;
		}
		return false;
	}
	
	
		function get_vendor_type_code($type='option'){

		# type = option/option_mix/list
		$CI =&get_instance();
		$group_name ='vendor_type';
		$temp_cache_name ='vendor_type';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		switch($type){
			case 'option': $cache_name = $temp_cache_name.'_option'; break;
			case 'option_mix': $cache_name = $temp_cache_name.'_option_mix'; break;
			case 'option_name': $cache_name = $temp_cache_name.'_option_name'; break;
			case 'list': $cache_name = $temp_cache_name.'_list'; break;
			default: $cache_name = $temp_cache_name.'_option'; break;
		}
	
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_VENDOR_TYPE WHERE STATUS=7");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords($v->VENDOR_TYPE).'</option>';
						break;
					case 'option_name':
						$data['html'] .= '<option value="'.$v->VENDOR_TYPE.'">'.ucwords($v->VENDOR_TYPE).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->VENDOR_TYPE.'">'.$v->VENDOR_TYPE.'</option>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		return $data['html'];
	}
	
	function get_igw($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$group_name = 'operator';
		$temp_cache_name = 'get_igw';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		switch($type){
			case 'option': $cache_name = $temp_cache_name.'_option'; break;
			case 'option_mix': $cache_name = $temp_cache_name.'_option_mix'; break;
			case 'option_name': $cache_name = $temp_cache_name.'_option_name'; break;
			case 'list': $cache_name = $temp_cache_name.'_list'; break;
			default: $cache_name = $temp_cache_name.'_option'; break;
		}
	
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			$CI->load->database();
			$get_record = $CI->db->query("SELECT ID, OPERATOR_NAME FROM TBL_OPERATOR WHERE OPERATOR_TYPE='IGW'");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords($v->OPERATOR_NAME).'</option>';
						break;
					case 'option_name':
						$data['html'] .= '<option value="'.$v->OPERATOR_NAME.'">'.ucwords($v->OPERATOR_NAME).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->OPERATOR_NAME.'">'.$v->OPERATOR_NAME.'</option>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		return $data['html'];
	}
	
	function get_icx($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$group_name = 'operator';
		$temp_cache_name = 'get_icx';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		switch($type){
			case 'option': $cache_name = $temp_cache_name.'_option'; break;
			case 'option_mix': $cache_name = $temp_cache_name.'_option_mix'; break;
			case 'option_name': $cache_name = $temp_cache_name.'_option_name'; break;
			case 'list': $cache_name = $temp_cache_name.'_list'; break;
			default: $cache_name = $temp_cache_name.'_option'; break;
		}
	
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			$CI->load->database();
			$get_record = $CI->db->query("SELECT ID, OPERATOR_NAME FROM TBL_OPERATOR WHERE OPERATOR_TYPE='ICX' ORDER BY OPERATOR_NAME");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords($v->OPERATOR_NAME).'</option>';
						break;
					case 'option_name':
						$data['html'] .= '<option value="'.$v->OPERATOR_NAME.'">'.ucwords($v->OPERATOR_NAME).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->OPERATOR_NAME.'">'.$v->OPERATOR_NAME.'</option>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		return $data['html'];
	}
	
	function get_type_wise_operator($type='option',$operator_type){
		# type = option/option_mix/list
		$CI =&get_instance();
		$group_name = 'operator';
		$temp_cache_name = 'get_type_wise_operator';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		switch($type){
			case 'option': $cache_name = $temp_cache_name.'_option'; break;
			case 'option_mix': $cache_name = $temp_cache_name.'_option_mix'; break;
			case 'option_name': $cache_name = $temp_cache_name.'_option_name'; break;
			case 'list': $cache_name = $temp_cache_name.'_list'; break;
			default: $cache_name = $temp_cache_name.'_option'; break;
		}
	
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){ 

			$data['html'] = null;
			$CI->load->database();
			if(array_key_exists(1,$operator_type)){
			$sql="SELECT ID, OPERATOR_NAME FROM TBL_OPERATOR WHERE OPERATOR_TYPE='".$operator_type[0]."' OR OPERATOR_TYPE='".$operator_type[1]."' OR OPERATOR_TYPE='".$operator_type[2]."'";
			$get_record = $CI->db->query($sql);	
			}else{
			$get_record = $CI->db->query("SELECT ID, OPERATOR_NAME FROM TBL_OPERATOR WHERE OPERATOR_TYPE='".$operator_type[0]."'");
		  }
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords($v->OPERATOR_NAME).'</option>';
						break;
					case 'option_name':
						$data['html'] .= '<option value="'.$v->OPERATOR_NAME.'">'.ucwords($v->OPERATOR_NAME).'</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->OPERATOR_NAME.'">'.$v->OPERATOR_NAME.'</option>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		return $data['html'];
	}
	
	function get_operator_details($operator_name, $type="option"){
		# type = option/option_mix/list
		$CI =&get_instance();
		$group_name = 'operator';
		$temp_cache_name = 'get_operator_details';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		
		switch($type){
			case 'option': $cache_name = $temp_cache_name.'_option'; break;
			case 'option_mix': $cache_name = $temp_cache_name.'_option_mix'; break;
			case 'option_name': $cache_name = $temp_cache_name.'_option_name'; break;
			case 'list': $cache_name = $temp_cache_name.'_list'; break;
			default: $cache_name = $temp_cache_name.'_option'; break;
		}
		
		$html = array();
		
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){ 

			$data['html'] = null;
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_OPERATOR");
			$get_record = $get_record->result();
				foreach( $get_record as $k=>$v ){
	            
				$html[] = $v->ID.'|'.$v->OPERATOR_NAME.'|'.$v->OPERATOR_SHORT_CODE.'|'.$v->OPERATOR_TYPE.'|'.$v->PROJECT_CODE.'|'.$v->ATTENTION.'|'.$v->ADDRESS;
			}

			$CI->cache->save($cache_name, $html, $group_name, 604800);		
		}
		$gl_array = array();
		foreach($html as $k=>$v){
			if( $v[1]==$operator_name ){
			$Value = explode('|', $v);
			if( $Value[1]==$operator_name){
				return $Value;
			}
			}
		}
		return false;
	}

	function get_operator_invoice($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$group_name = 'invoice_icx_ios';
		$temp_cache_name = 'invoice_icx_ios';
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		switch($type){
			case 'option': $cache_name = $temp_cache_name.'_option'; break;
			case 'option_mix': $cache_name = $temp_cache_name.'_option_mix'; break;
			case 'option_name': $cache_name = $temp_cache_name.'_option_name'; break;
			case 'option_for_type': $cache_name = $temp_cache_name.'_option_for_type'; break;
			case 'list': $cache_name = $temp_cache_name.'_list'; break;
			default: $cache_name = $temp_cache_name.'_option'; break;
		}
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			$CI->load->database();
			$get_record = $CI->db->query("SELECT DISTINCT OPERATOR_NAME,OPERATOR_TYPE FROM TBL_INVOICE_DETAIL");
			$get_record = $get_record->result();
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
					
						$data['html'] .= '<option value="'.$v->ID.'">'.ucwords($v->OPERATOR_NAME).' ('.$v->OPERATOR_TYPE.')</option>';
						break;
					case 'option_name':
						$data['html'] .= '<option value="'.$v->OPERATOR_NAME.'">'.ucwords($v->OPERATOR_NAME).' ('.$v->OPERATOR_TYPE.')</option>';
						break;
					case 'option_mix':
						$data['html'] .= '<option value="'.$v->ID.'|'.$v->OPERATOR_NAME.'">'.$v->OPERATOR_NAME.' ('.$v->OPERATOR_TYPE.')</option>';
						break;
					case 'option_for_type':
                        $data['html'] .= '<option value="'.$v->OPERATOR_TYPE.'|'.$v->OPERATOR_NAME.'">'.$v->OPERATOR_NAME.' ('.$v->OPERATOR_TYPE.')</option>';
                        break;

				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		return $data['html'];
	}
	
		function get_usd_to_bdt($type='option'){
		# type = option/option_mix/list
		$CI =&get_instance();
		$cache_name = 'usd_to_bdt_option';
		$group_name	=	'corp_ex_rate';
		
		$month = date('M');
		$year = date('Y');
	
		# to delete cache use: $this->cache->remove_group('group_name');
		$CI->load->library('cache');
		
		if( !$data['html'] = $CI->cache->get($cache_name, $group_name) ){
			$data['html'] = null;
			
			$CI->load->database();
			$get_record = $CI->db->query("SELECT * FROM TBL_CORPORATE_EXCHANGE_RATE WHERE REPORT_MONTH BETWEEN SYSDATE() - INTERVAL 12 MONTH AND SYSDATE() AND STATUS=7 ORDER BY ID");
			$get_record = $get_record->result();
		
			foreach( $get_record as $k=>$v ){
				switch($type){
					case 'option':
						$data['html'] .= '<option value="'.$v->USD_TO_BDT.'|'.$v->EURO_TO_BDT.'">'.date('Y',strtotime($v->REPORT_MONTH)).' &raquo; '.date('M',strtotime($v->REPORT_MONTH)).' &raquo; '.$v->USD_TO_BDT.' &raquo; '.$v->EURO_TO_BDT.'</option>';
						break;
				}
			}

			$CI->cache->save($cache_name, $data['html'], $group_name, 604800);		
		}
		
		return $data['html'];
	}
	
	
}