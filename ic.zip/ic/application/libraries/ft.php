<?php
#### File Text Project ###
### created by Golam Mohiuddin (razualam00@gmail.com) @ 2017.10.24 ###
### Version: 1.0 ###
## please create a text file in this file's path name ft.db

class FT{
### EXAMPLES
#ftset('division', 6, 'country', 'bangladesh');
#ftset('division', $id, null, 'Sylhet');
#ftdel('division', 6);
#ftset('division', 6, null, (object) array('country'=>'India', 'name'=>'Mumbai', 'code'=>'00006'));
#ftset('district', $id, null, 'Chandpur');
#ftset('division', 7, null, 'bangladesh');
#dd(ftget('division'), 'c');
#dd(ftsearch('division', 'country', 'bangladesh'));
/*
[parent] => stdClass Object
(
    [key] => Dhaka
    [key] => Chittagong
    [key] => Rajshahi
    [key] => stdClass Object
            (
	            [attribute] => bangladesh
	            [attribute] => Khulna
	            [attribute] => 0004
            )
)
*/


function FT(){
	# constructor
}

# settings
function settings(){
	$settings = new stdClass();
	$settings->ft_data_path = FCPATH.'application/libraries/ft.db';
	
	return $settings;
}

function get($parent=null, $key=null){
	try{
		$ft_data_path = $this->settings()->ft_data_path;
		$file_text = json_decode(file_get_contents($ft_data_path));
		if( !$parent && !$key ){
			return $file_text; # return all data -- need to re-think, is it OK or not?
		}
		
		if( !$parent && $key ){
			return 101; # no parent found
		}
		
		if( $parent && !isset($file_text->$parent) ){
			return array(); # no parent found
		}
		
		if( isset($file_text->$parent->{0}) ){
			if($parent && $key && !isset($file_text->$parent->{0}->$key))
				return 102; # no child found
		}else if( $parent && $key && !isset($file_text->$parent->$key) ){
			return 102; # no child found
		}
		
		if( $parent && !$key ){
			return $file_text->$parent; # return all parent data
		}elseif( $parent && $key ){
			if(isset($file_text->$parent->{0}->$key)){
				return $file_text->$parent->{0}->$key;
			}
			return $file_text->$parent->$key; # return child data
		}
		
		return false; # nothing matched
		
	}catch(Exception $e){
		return 404; # execution faild
	}
}
function set($parent, $key, $attribute=null, $value){
	# $key must be an integer
	# value can be a single value or an object like (object) array('country'=>'India', 'name'=>'Mumbai', 'code'=>'00006')
	# through the above line, multiple attributes will be created within a single key
	# if key already exist then the key will be updated
	$key = (int)$key;
	
	# parent, attribute and value can not be an array
	if(is_array($parent) || is_array($value) || is_array($attribute)){
		return 404; # could not execute
	}
	
	try{
		$ft_data_path = $this->settings()->ft_data_path;
		$file_text = json_decode(file_get_contents($ft_data_path));
		
		# if the parent has not been created, then create
		if( !isset($file_text->$parent) ){
			$file_text->$parent = new stdClass();
		}
		
		# if the key has not been created, then create
		if( !isset($file_text->$parent->$key) ){
			$file_text->$parent->$key = new stdClass();
		}
		
		# if the attribute has not been created, then create
		if( $attribute && !isset($file_text->$parent->$key->$attribute) ){
			$file_text->$parent->$key->$attribute = new stdClass();
		}
		
		if( $attribute ){
			# set attribute
			$file_text->$parent->$key->$attribute = $value;
		}else{
			# set key
			$file_text->$parent->$key = $value;
		}

		$new_text = json_encode($file_text);
		$myfile = fopen($ft_data_path, "w") or die("Unable to open file!");
		fwrite($myfile, $new_text);
		fclose($myfile);
		return 100; # successfully set
		
	}catch(Exception $e){
		return 404; # execution faild
	}
}
function iid($parent){
	# insert id
	try{
		$ft_data_path = $this->settings()->ft_data_path;
		$file_text = json_decode(file_get_contents($ft_data_path));
		
		if( !isset($file_text->$parent) ){
			
			return 0; # no parent found
		}
		
		$select_parent = (array)$file_text->$parent;

		end($select_parent); # move pointer
		$key = key($select_parent);
		
		return (int)$key;
		
	}catch(Exception $e){
		return 404; # could not execute
	}
}
function del($parent, $key=null, $attribute=null){
	# ftdel('division');
	# ftdel('division', 6);
	
	try{
		$ft_data_path = $this->settings()->ft_data_path;
		$file_text = json_decode(file_get_contents($ft_data_path));
		
		if( !isset($file_text->$parent) ){
			return 101; # no parent found
		}
		
		if( ($key===0 || $key) && !isset($file_text->$parent->$key) ){
			return 102; # no key found
		}
		
		if( ($key===0 || $key) && $attribute && !isset($file_text->$parent->$key->$attribute) ){
			return 103; # no attribute found
		}

		if( $parent && ($key===0 || $key) && $attribute ){
			unset($file_text->$parent->$key->$attribute);
		}elseif($parent && ($key===0 || $key)){
			unset($file_text->$parent->$key);
		}elseif($parent){
			unset($file_text->$parent);
		}else{
			return 404; # could not execute
		}
		
		$new_text = json_encode($file_text);
		$myfile = fopen($ft_data_path, "w") or die("Unable to open file!");
		fwrite($myfile, $new_text);
		fclose($myfile);
		return 100; # successfully deleted
		
	}catch(Exception $e){
		return 404; # execution faild
	}
}
function search($parent, $attribute=null, $value=null){
	# if there is attribute then search only within attribute otherwise search only value
	# ftsearch('division', 'country', 'bangladesh') -- search by attribute and value
	# ftsearch('division', null, 'bangladesh') -- search by value
	
	try{
		$ft_data_path = $this->settings()->ft_data_path;
		$file_text = json_decode(file_get_contents($ft_data_path));
		if( !isset($file_text->$parent) ){
			return 101; # no parent found
		}
		
		$temp_value = $file_text->$parent;

		$result = array();
		//dd($temp_value);
		foreach($temp_value as $k=>$v){
			if( is_object($v) ){
				$v = (array)$v;
				foreach($v as $k1=>$v1){
					if($attribute && $k1==$attribute && strtolower($v1)==strtolower($value)){ 
						$result[] = $temp_value->$k; 
					}elseif( !$attribute && strtolower($v1)==strtolower($value)){
						$result[] = $temp_value->$k;
					}elseif(!$value && $attribute && $k1==$attribute){
						$result[] = $v1;
					}
				}
				
			}else{
				if( !$attribute && strtolower($v)==strtolower($value) ){ $result[] = $temp_value->$k; }
			}
		}
		
		return $result;
		
	}catch(Exception $e){
		dd(111111);
		return 404; # execution faild
	}
}

}
?>