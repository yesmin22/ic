<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">
      <div class="page_caption">Create Invoice for ICX</div>
			<div class="page_body">
				<div class="left_section">
					<fieldset class="divider"><legend>Please select an operator to create an invoice</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_filter" method="post" action="" target="_blank" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<table width="100%">
							<tr>
								<td>
									<div class="form_label">Operator Name*</div>
									<div>
		               <select name="operator_name" class="input_full input_style" required>
				              <option value="">Select One</option>
				              <?php echo $this->customcache->get_operator('option_name'); ?>
	             			</select>
										<span	class="fred"><?php //echo form_error('operator_name'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
		              	<input type="text" name="CALCULATIVE_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<div>
										<input type="submit" name="view" class="btn_gray" value="View" />
										<input type="submit" name="print" class="btn_gray" value="Print" />
										<input type="submit" name="export" class="btn_gray" value="Export" />
										<input type="submit" name="pdf" class="btn_gray" value="PDF" />
									</div>
								</td>
							</tr>
						</table>
					</form>

				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
			
		</div><!--end #page_create_role -->
	
		<div><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
 
</body>
</html>