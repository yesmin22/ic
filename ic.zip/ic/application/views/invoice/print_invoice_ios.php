
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
			<title>Invoice 
				
				</title>
			<style>
				table {
				    border-collapse: collapse;
				}
			 .top {
  					border-top: thin solid;
  					border-color: black;
			 }

       .bottom {
         border-bottom: thin solid;
         border-color: black;
       }

			.left {
			  border-left: thin solid;
			  border-color: black;
			}

			.right {
			  border-right: thin solid;
			  border-color: black;
			}
			.logo_img {
			    position: absolute;
			    right: 200px;
			    top: 50px;
			}
		</style>
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
		</head>
		<body>
			<div>
				<?php 
				$total_invoice_value=0;
				foreach($get_record as $a_get_record){
					$total_invoice_value=$total_invoice_value+$a_get_record->BL_REV_BDT;
				}
				
				$number_in_word=$this->webspice->convert_number_to_words($total_invoice_value);
				$img_root=$this->webspice->get_path('img');
				$operator_name=$get_operator_info->OPERATOR_NAME;
				$operator = $this->ft->search("name_alternative", null, $operator_name);
						if(!isset($operator[0])){
							$operator_srt_name = $operator_name;
						}else{
							$operator_srt_name = $operator[0]->cName;
						}
				if ($img_root) { ?>
					<img class="logo_img" src="<?php echo $img_root.'bl_logo.png'; ?>" alt="bl_logo" height="85" width="85">
				<?php }?>
				
			</div>
			<div>
				<table>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					
					
					<tr>
						<td  style=min-width:50px></td>
						<td colspan="11" style=width:10px><strong>Banglalink Digital Communications Ltd - Banglalink</strong></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td colspan="11" style=width:10px>Tigers' Den, House 4 (SW),</td>
	
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td colspan="11" style=width:10px>Bir Uttam Mir Shawkat Sharak, Gulshan-1,</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td colspan="11" style=width:10px>Dhaka - 1212, Bangladesh</td>
				
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>Tel. # </td>
						<td colspan="10" style=min-width:50px>+8801926932914</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>Fax # </td>
						<td colspan="10" style=min-width:50px>+880 2 8827265</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td align="center" colspan="11" style=width:10px;><u><strong>INVOICE</strong></u></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					<tr class="border_top">
						<td style=min-width:50px></td>
						<td class="top left" style=width:10px></td>
						<td class="top" style=min-width:50px><strong>To</strong></td>
						<td class="top" colspan="3" style=min-width:50px><strong><?php echo $get_operator_info->ATTENTION;?></strong></td>
						<td class="top left" style=min-width:50px></td>
						<td class="top" colspan="2" style=min-width:50px>Invoice No.</td>
						<td class="top" style=min-width:50px>IOS/<?php echo $get_operator_info->OPERATOR_NAME.'/'.$date;?></td>
						<td class="top" style=min-width:50px></td>
						<td class="top" style=min-width:50px></td>
						<td class="top" style=min-width:50px></td>
						<td class="top right" style=min-width:50px></td>
					</tr>
					<tr >
						<td style=min-width:50px></td>
						<td class="left" style=width:10px></td>
						<td  style=min-width:50px></td>
						<td  colspan="2" style=min-width:50px><?php echo $get_operator_info->ADDRESS;?></td>
						<td  style=min-width:50px></td>
						<td  class= "left" style=min-width:50px></td>
						<td  colspan="2" style=min-width:50px>Date of Invoice</td>
						<td  style=min-width:50px><?php echo $current_date;?></td>
						<td  style=min-width:50px></td>
						<td  style=min-width:50px></td>
						<td  style=min-width:50px></td>
						<td class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px></td>
						<td style=min-width:50px></td>
						<td colspan="2" style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="left" style=min-width:50px></td>
						<td style=min-width:50px>Terms of payment</td>
						<td style=width:10px>:</td>
						<td colspan="4" style=min-width:50px>Account Payee Cheque / Pay-Order</td>
						<td class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td  style=min-width:50px></td>
						<td class="left" style=width:10px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="left" style=min-width:50px></td>
						<td style=min-width:50px>Our Referance</td>
						<td style=width:10px>:</td>
						<td style=min-width:50px>Accounting Director</td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td  class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px><?php echo $get_operator_info->VAT_REG_NO;?></td>
						<td style=min-width:50px></td>
						<td style=min-width:100px></td>
						<td class="left" style=min-width:50px></td>
						<td style=min-width:50px>VAT Reg. No.</td>
						<td style=width:10px>:</td>
						<td style=min-width:50px>18141011900</td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px></td>
						<td style=min-width:10px></td>
						<td  colspan="3" style=min-width:50px><?php echo $get_operator_info->TEL_NO;?></td>
						<td class="left" style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="right" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="left"  style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="right" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="bottom left" style=width:10px></td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom left" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom right" style=min-width:50px></td>
					</tr>
					<tr class="border_top">
						<td style=min-width:50px></td>
						<td class="left bottom" style=width:10px><strong>REFERENCE</strong></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom left" style=min-width:50px><strong>DESCRIPTION</strong></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom left right" style=min-width:50px><strong>VALUE (TK.)</strong></td>
						<td class="bottom" style=min-width:50px><strong>REMARKS</strong></td>
						<td class="bottom" style=min-width:50px></td>
						<td class="bottom right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td  class="left" style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td  class="left right" style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="right" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" colspan="3" style=width:10px><?php echo $get_operator_info->REF_NO;?></td>
						<td class="left" style=min-width:50px>1.</td>
						<td style=min-width:50px>For the Month of <?php echo $formated_date; ?></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="left right" style=min-width:50px><?php echo number_format($total_invoice_value);?></td>
						<td style=min-width:50px></td>
							<td style=min-width:50px></td>
						<td class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left right" colspan="3" style=width:10px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td  style=min-width:50px></td>
						<td class="left right" style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
					
						<td class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left right" colspan="3" style=width:10px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="left right"  style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left right" colspan="3" style=width:10px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td   style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="left right" style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class="right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="left" style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="left right" style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="right" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="left" style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="left right" style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="right" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left" style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="left" style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="left right" style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td class="right" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="left bottom" style=width:10px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom left" style=min-width:50px>&nbsp;</td>
						<td class="bottom " style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom left right" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom" style=min-width:50px>&nbsp;</td>
						<td class="bottom right" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td  class= "left" style=width:10px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td colspan="4" style=min-width:50px><?php echo 'Inword: '.$number_in_word?></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px><?php echo number_format($total_invoice_value);?></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class= "right" style=min-width:50px></td>
					</tr>
					<tr>
						<td  style=min-width:50px></td>
						<td  class= "left bottom" style=width:10px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "bottom" style=min-width:50px>&nbsp;</td>
						<td class= "right bottom" style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td  class= "left" style=width:10px>REMARKS</td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td style=min-width:50px></td>
						<td class= "right" colspan="5" style=min-width:50px>Bank details (Any Branch)</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td  class= "left" colspan="10" style=width:10px>Account Payee Cheque or Pay Order in favour of 'Banglalink Digital Communications Ltd.'</td>
						<td style=min-width:50px>Standard Chartered Bank</td>
						<td style=min-width:50px>CD A/C No. 01-1108964-01</td>
						<td class= "right" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td  class= "left bottom" colspan="5" style=width:10px>Or Bank deposit as per Bank details</td>
						<td class= "bottom" style=min-width:50px></td>
						<td class= "bottom" style=min-width:50px></td>
						<td class= "bottom" style=min-width:50px></td>
						<td class= "bottom" style=min-width:50px></td>
						<td class= "bottom" style=min-width:50px></td>
						<td class= "bottom" style=min-width:50px>Eastern Bank Limited</td>
						<td class= "bottom" style=min-width:50px>CD A/C No. 1041060005400</td>
						<td class= "right bottom" style=min-width:50px></td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td  style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td  style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td class="top" colspan="3" style=width:10px>Syed Mehedi Hasan</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td colspan="11" style=width:10px>Revenue Operations Senior Manager</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td colspan="15" style=width:10px>As per BTRC directive no. BTRC/Mobile/Sheba(3)Part-1/2007- 377 dated 28-05-2009 and BTRC/SS/IGW-COMMON(344)PART-1/2011/501 dated 18-09-2014, </td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td colspan="15" style=width:10px>BL has hereby claimed its revenue share from you based on minimum Int l Termination Rate (ITR) USD 0.015/min. If we are informed of ITR higher than USD 0.015/min </td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td colspan="15" style=width:10px>for int l incoming call(s) terminated at BL networks, BL receivables from you will be revised retrospectively</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
					<tr>
						<td style=min-width:50px></td>
						<td style=width:10px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
						<td style=min-width:50px>&nbsp;</td>
					</tr>
				</table>
			</div>

				<hr>
				</body>
			</html>