<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_invoice_for_mobile_pstn_iptsp" class="main_container page_identifier">
      <div class="page_caption">Create Invoice MOBILE, PSTN & IPTSP</div>
			<div class="page_body">
				<div class="left_section">
					<fieldset class="divider"><legend>Please select an operator to create an invoice</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_filter" method="post" action="" target="_blank" data-parsley-validate>
						<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="invoice_generation" name="invoice_generation" value="no" />
						<table width="100%">
							<tr>
								<td>
									<div class="form_label">Operator Name*</div>
									<div>
		               <select name="operator_name" id="operator_name" class="input_full input_style" required>
				              <option value="">Select One</option>
				              <?php echo $this->customcache->get_operator('option_for_type'); ?>
	             			</select>
										<span	class="fred"><?php //echo form_error('operator_name'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
		              	<input type="text" name="calculative_month" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<div>
<!--										<input type="submit" name="view" class="btn_gray" value="View" />
										
										<input type="submit" name="export" class="btn_gray" value="Export" />-->
										<input type="submit" name="pdf" class="btn_gray" value="Generate Invoice" id="generate_invoice" />
										<input type="submit" name="print" class="btn_gray" value="Print" />
									</div>
								</td>
							</tr>
						</table>
					</form>

				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
			
		</div><!--end #page_create_role -->
	
		<div><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
 <script type="text/javascript">
 	$(document).ready(function(){
 		$('#operator_name, .yearpick, .monthpick').on('change',function(){
			var calculative_month = $(".month_picker").val();
			var token = $('#token').val();
			var operator_name = $("#operator_name").val();
			var ajaxCall = $.ajax({
			 type: "POST",
			 url: url_prefix + "invoice_icx",
			 data: { ajax_call:"yes", csrf_webspice_tkn:token, calculative_month:calculative_month, operator_name:operator_name}
			}).done(function(msg){
				if(msg == "inv_exist"){
					if(confirm('This invoice has been generated. do you need another one?')){
						$("#invoice_generation").val("yes");
						return true;
					}else{
						$("#invoice_generation").val("");
						return false;
					}
				}
			}).fail(function() {
				alert( "Failed: We could not execute your request. Please try again later or report to authority." );
			});	
 		});
 		
 		$('#generate_invoice').click(function() {
    location.reload();
    });
 		
 	});	
 	
 	

 </script>
</body>
</html>