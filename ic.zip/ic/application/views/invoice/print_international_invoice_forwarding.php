<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='doc' ){
	dd(11111);
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/vnd.ms-word");
  header("Content-Disposition: filename=\"invoice_$inr.doc\"");
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
			<title>Invoice Forwarding International</title>
			
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
	
		<?php endif; ?>
		<style>
			.pdate{
				margin-top:60px;
				margin-bottom:40px;
				margin-left:20px;
				}
			.ptel{
				margin-bottom:40px;
				margin-left:20px;
				}
			.pnew{
				margin-bottom:20px;
				margin-left:20px;
				}
			.pcom{
				margin-left:20px;
				}
			.p13{
				margin-left:75px;
				margin-top:-30px;
				}
		</style>
		</head>
		<body>
			<div>
				<?php 
				$total_invoice_value=0;
				foreach($get_record as $a_get_record){
					$total_invoice_value=$total_invoice_value+$a_get_record->BL_REV_BDT;
				}
				
				$number_in_word=$this->webspice->convert_number_to_words($total_invoice_value);
				$operator_name=$get_operator_info->OPERATOR_NAME;
				$operator = $this->ft->search("name_alternative", null, $operator_name);
						if(!isset($operator[0])){
							$operator_srt_name = $operator_name;
						}else{
							$operator_srt_name = $operator[0]->cName;
						}
				?>
				
			</div>
			<div style="margin-left:100px;margin-right:100px;margin-top:20px;margin-top:20px">
				<p class='pdate'>Date: <?php echo $current_date;?></p>
				<p class='pcom'><strong><?php echo $get_operator_info->ATTENTION;?></strong></p>
				<p class='pcom' style="width:250px"><?php echo $get_operator_info->ADDRESS;?></p>
				<p class='pcom'><?php if($get_operator_info->TEL_NO=='NA'){echo '';}else{echo $get_operator_info->TEL_NO;};?></p>
				<p class='ptel'><strong>Subject:<?php echo $operator_srt_name;?> to Banglalink <?php if($type==1){echo 'IOS International Incoming ';}else($type==2){echo 'ITFS';}?> Call Carrying Charge for the Month of <?php echo $current_date;?>.</strong></p>
				<p class='pnew'>Dear Sir,</p>
				<p class='pnew' style="width:1000px">Please find enclosed herewith Invoice No &#8208 IOS/<?php echo $operator_srt_name.'/'.$formated_date;?> against <?php if($type==1){echo 'IOS international incoming';}else($type==2){echo 'ITFS incoming';}?> Call Carrying Charge for the month of <?php echo $current_date;?> amounting total Tk. <?php echo $total_invoice;?>/= (<?php echo $number_in_word;?>Only) as per deed of agreement for International Toll Free Traffic.</p>
				<p class='pnew' style="width:1000px">If you have any query regarding the invoice, please feel free to contact with Mr. Mostofa Alif Mehedi &#8208; Revenue Operations Sr. Assistant Manager &#8208; Accounting & Finance on Cell No. 01962-400110 or email at MMehedi@banglalink.net. </p>
				<p class='ptel'>Thanks & Regards</p>
				<p class='pcom'>_________________________ </p>
        <p class='pcom'>Mohammad Abid Hossain Khan
        Financial Controller, Finance
        </p>
        <p class='ptel'>Copy to:	Taimur Rahman</p>
        <p class='p13'>Regulatory Affairs Senior Director</p>
			</div>
				</body>
			</html>