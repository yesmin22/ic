<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
	<style>

		body {
			font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
			font-size: 4px;
		
		}
		.fc-content span{color:white}
		.fc-toolbar h2 {
			font-size: 16px;
		}
		.post_panel {
			font-size: 10px !important;
		}

	</style>

</head>

<body>
	<div id="wrapper">

		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
			
		<div id="page_index" class="main_container page_identifier">
			<div class="page_caption">Dashboard</div>
			<div class="page_body" style="min-height:400px">
					<?php if(!$this->webspice->get_user_id()):?>
								<p style="text-align:center;">	<strong> Welcome to <?php echo $this->webspice->settings()->site_title;?></strong></p><br/>
						
					<?php endif;?>

					<div class="clearfix"></div>						
					<div class="float_clear_full">&nbsp;</div>	
			</div><!-end of page body->
		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>

</body>
</html>




















