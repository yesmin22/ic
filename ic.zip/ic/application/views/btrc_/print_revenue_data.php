<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oracle Collection</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin-->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<?php
			// $global_cut_of=$get_record[0]->MAX_DAY;
			?>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
				<tr>
					<td colspan=5 align="center">
					<table>
						<tr>
								<td align="center">Banglalink Digital Communications Limited</td>
						</tr>
						<tr>
					      <td align="center">Revenue Collection Calculation for the period of <?php echo (date("M-Y", strtotime($date[0])));?> to <?php echo (date("M-Y", strtotime($date[2])));?></td>
				    </tr>
					</table>
					</td>
				
				</tr>
				
				<tr>
					<td>&nbsp;</td>
					<td><?php echo (date("M-Y", strtotime($date[0])));?></td>
					<td><?php echo (date("M-Y", strtotime($date[1])));?></td>
					<td><?php echo (date("M-Y", strtotime($date[2])));?></td>
					<td><?php echo 'Q-3-'.(date("Y", strtotime($date[2]))).' Total';?></td>
				</tr>
			  <tr>
			  	<td><?php echo $a_value->GL_TYPE;?></td>
			  	<td><?php echo $a_value->GL_CODE;?></td>
			  	<td><?php echo $a_value->GL_DESCRIPTION;?></td>
			  	<td><?php echo $a_value->POSTPAID_COLLECTION_CNC_GL_ONE;?></td>
			  	<td><?php echo $a_value->POSTPAID_COLLECTION_CNC_GL_TWO;?></td>
			 	 	<td><?php echo $a_value->POSTPAID_COLLECTION_CNC_GL_THREE;?></td>
			 	 	<td><?php if($total!=0){echo $total;}?></td>
			  </tr>
			  
			</table>
		</div>
	</body>
</html>