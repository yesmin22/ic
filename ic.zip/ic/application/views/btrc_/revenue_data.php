<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Oracle Collection</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_domestic_mms_jv" class="main_container page_identifier">
			<div class="page_caption">Revenue Data</div>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please fill-up the parameter(s)</legend></fieldset>
				
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_filter" method="post" action="" target="_blank" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
		            
						<table width="100%">
								<tr>
									<td>
										<div class="form_label">Year*</div>
										<div>
		                  <select name="YEAR" id="YEAR" class="input_full input_style" required>
		                      <option value="">Select One</option>
		                      <?php for($i = date("Y")-10; $i <= date("Y")+10; $i++):	?>
		                          <option value="<?php echo $i; ?>" <?php if($i==date("Y")){echo "selected"; } ?> ><?php echo $i;?></>
		                      <?php endfor;?>
		                  </select>
										</div>
										<div class="p_error_container">&nbsp;</div>
									</td>
									<td>
										<div class="form_label">Select Quad*</div>
										<div>
			               <select name="QUAD" class="input_full input_style" required>
			               	<option value=''>SELECT ONE</option>
					            <option value='1'>1st</option>
					            <option value='2'>2nd</option>
					            <option value='3'>3rd</option>
					            <option value='4'>4th</option>
		             			</select>
		             			<div class="p_error_container">&nbsp;</div>
										</div>
									</td>
								</tr>
							<tr>
								<td>
									<div>
										<input type="submit" name="view" class="btn_gray" value="View" />
										<input type="submit" name="print" class="btn_gray" value="Print" />
										<input type="submit" name="export" class="btn_gray" value="Export" />
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
				
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
	<script>
      $('.date-own').datepicker({
         minViewMode: 2,
         format: 'yyyy'
       });

	</script>
</body>
</html>