<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Create Public Site</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
	<!--JQuery UI-->
	<link rel="stylesheet" type="text/css" href="<?php echo $url_prefix; ?>global/jquery_ui/jquery-ui.min.css" />
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/jquery_ui/jquery-ui.min.js"></script>
	<style>
		td{padding-right:20px !important}
		.form_label{font-weight:bold !important; font-size:13px}
		.xdsoft_datetimepicker {width: 305px !important;}
		legend{font-size:16px;}
	</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/iims/iims_header.php"); ?></div>
		<div id="page_create_ip_info" class="main_container page_identifier">
			<div class="page_caption">Create Public Site</div>
			<div class="page_body" style="min-height:450px">
				<form id="frm_create_public_site" method="post" action="" enctype="multipart/form-data" data-parsley-validate >
					<div class="col-md-12">
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />       
						<fieldset class="divider"><legend>Please enter site information.</legend></fieldset>
						<div class="stitle">* Mandatory Field</div>
					</div>
					<div class="col-md-6">
						<table width="100%">
							<tr>
								<td colspan=3 >
									<div class="form_label">Site Name*</div>
									<div>
			               <select name="SITE_NAME" class="form-control" required>
					              <option value="">Select One</option>
					              <?php if( set_value('SITE_NAME', $edit['SITE_NAME']) ): ?>
					              <?php echo str_replace('value="'.set_value('SITE_NAME', $edit['SITE_NAME']).'"','value="'.set_value('SITE_NAME', $edit['SITE_NAME']).'" selected="selected"', $this->customcache->get_site_name_option("option")); ?>
					              <?php else: ?>
					              <?php echo $this->customcache->get_site_name_option("option"); ?>
					              <?php endif; ?>
		             			</select>
		            			<span class="fred"><?php echo form_error('SITE_NAME'); ?></span> 
									</div>
								</td>
								<td colspan=3 >
									<div class="form_label">Service Group*</div>
									<div>
										<input type="text" id="SERVICE_GROUP" name="SERVICE_GROUP" class="form-control" value="<?php echo set_value('SERVICE_GROUP',html_entity_decode($edit['SERVICE_GROUP'])); ?>" required />
			        			<span class="fred"><?php echo form_error('SERVICE_GROUP'); ?></span> 
									</div>
								</td>
							</tr>
							
							<tr>
								<td colspan=2 >
									<div class="form_label">Public NAT IP*</div>
									<div>
										<input type="text" name="PUBLIC_NAT_IP" class="form-control" value="<?php echo set_value('PUBLIC_NAT_IP',html_entity_decode($edit['PUBLIC_NAT_IP'])); ?>" required />
			        			<span class="fred"><?php echo form_error('PUBLIC_NAT_IP'); ?></span>
									</div>
								</td>
								<td colspan=2 >
									<div class="form_label">Virtual IP*</div>
									<div>
										<input type="text" name="VIRTUAL_IP" class="form-control" value="<?php echo set_value('VIRTUAL_IP',html_entity_decode($edit['VIRTUAL_IP'])); ?>" required />
			        			<span class="fred"><?php echo form_error('VIRTUAL_IP'); ?></span> 
									</div>
								</td>
								<td colspan=2 >
									<div class="form_label">Service Ports*</div>
									<div>
										<input type="text" name="SERVICE_PORTS" class="form-control" value="<?php echo set_value('SERVICE_PORTS',html_entity_decode($edit['SERVICE_PORTS'])); ?>" required />
			        			<span class="fred"><?php echo form_error('SERVICE_PORTS'); ?></span> 
									</div>
								</td>
							</tr>
							
							<tr>
								<td colspan=3 >
									<div class="form_label">DNS Host in Public/Local*</div>
									<div>
										<input type="text" name="DNS_HOST" class="form-control" value="<?php echo set_value('DNS_HOST',html_entity_decode($edit['DNS_HOST'])); ?>" required />
			        			<span class="fred"><?php echo form_error('DNS_HOST'); ?></span> 
									</div>
								</td>
								<td colspan=3 >
									<div class="form_label">Service IP*</div>
									<div>
										<input type="text" name="SERVICE_IP" class="form-control" value="<?php echo set_value('SERVICE_IP',html_entity_decode($edit['SERVICE_IP'])); ?>" required />
			        			<span class="fred"><?php echo form_error('SERVICE_IP'); ?></span> 
									</div>
								</td>
							</tr>							
							<tr>
								<td>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</div>
					
					<div class="col-md-6">
					
					</div>
					
				</form>
				<div class="float_clear_full">&nbsp;</div>
			</div>

		</div>
		
		<div id="footer_container">
			<?php include(APPPATH."views/other_footer.php"); ?>
		</div>
		
	</div>
</div>
<script>
	$(document).ready(function(){
		$('.page_caption, .page-body-title').css('color','#EF1B24');
		$("#edit").click(function(event){
		   event.preventDefault();
		   $('.configuration').prop("readonly", false);
		});
	});
</script>
	
</body>

</html>