<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
	
	<style>
		.table td { font-size:80%; padding:2px !important; }
	</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="payable_ageing_report" class="main_container page_identifier">
			<div class="page_caption">Payable Ageing Report</div>
			<div class="page_body" class="table-responsive">
				<!--custom message board-->
				<?php if( $this->webspice->message_board(null, 'get') ): ?>
					<div id="message_board">
						<?php echo $this->webspice->message_board(null,'get_and_destroy'); ?>
					</div>
				<?php endif; ?>
				<!--end custom message board-->
				
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					<?php 
						#$project_list = $this->ft->get('customer');
					?>
					<table style="width:auto;">
						<tr>
							<td>Project Name</td>
						</tr>
						<tr>
							<td>
								<select name="PROJECT_NAME" id="project_name" class="input_full input_style">
									<option value="">--Select One--</option>
									
								</select>
							</td>
							
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>generate_payable_ageing">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>generate_payable_ageing/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>generate_payable_ageing/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo str_replace('TBL_PAYABLE_AGEING.ID','Customer Name- ',$filter_by); ?></div>
				
				<table class="table table-bordered table-striped" style="overflow:auto;">
					<tr>
						<th>Operator</th>
						<th>OPTYPE</th>
						<th>Unexpired</th>
						<th class="text-center">(0-30)</th>
						<th class="text-center">31-60</th>
						<th class="text-center">61-90</th>
						<th class="text-center">91-120</th>
						<th class="text-center">121-150</th>
						<th class="text-center">151-180</th>
						<th class="text-center">180-365</th>
						<th class="text-center">365+ Days</th>
						<!--<th class="text-center">Total</th>-->
					</tr>
					<?php foreach($get_record as $k=>$v): 
					//dd($v);
					?>
					<tr>
						<td><?php echo $v->OPERATOR_NAME; ?></td>
						<td><?php echo $v->OPERATOR_TYPE; ?></td>
						<td></td>
						<td style="text-align:right;"><?php echo $v->NOT_DUE;?></td>
						<td style="text-align:right;"><?php echo $v->SLAB_30;?></td>
						<td style="text-align:right;"><?php echo $v->SLAB_60;?></td>
						<td style="text-align:right;"><?php echo $v->SLAB_90;?></td>
						<td style="text-align:right;"><?php echo $v->SLAB_120;?></td>
						<td style="text-align:right;"><?php echo $v->SLAB_150;?></td>
						<td style="text-align:right;"><?php echo $v->SLAB_365;?></td>
						<td style="text-align:right;"><?php echo $v->SLAB_YR_1_3;?></td>
					</tr>
					<?php endforeach; ?>
					<tr>
						

					</tr>
				</table>
				
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
				
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>

</body>
</html>

<?php 
	#function remaining_calculation($dr_amount,$cr_amount){
	#	$remaining = $cr_amount;
	#	if( $dr_amount > 0){
	#		$remaining = ($dr_amount > $cr_amount) ? $dr_amount - $cr_amount: $cr_amount - $dr_amount;
	#	}
	#	return $remaining;
	#}
?>