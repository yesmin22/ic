<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 13;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BL vs IOS reconciliation</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }

		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<div style="margin-left: 16em;">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;align:center;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">BL DATA</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">IOS  Invoice DATA (ICX WISE DATA)</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow;">ICX Operator Name</td>
					<td class="brt2" style="width:250px;background-color:yellow;">Billed Duration</td>
					<td class="brrt2" style="width:250px;background-color:yellow;">X in BDT</td>
					<td class="brt2" style="width:100px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>		
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>								
					<td class="rt2" style="width:100px;"></td>
					<td class="rt2" style="width:100px;"></td>
					<td class="brrt2" style="width:120px;background-color:yellow;border-left:2px solid #cccccc;">Billed Duration</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">X in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>
				</tr>	
				<?php 
				$total_bl_billed_duration=0;
				$total_bl_x_value=0;
				$total_bl_y_value=0;
				$total_bl_z_value=0;
				$total_bl_icx_value=0;
				$total_bl_igw_cost=0;
				$total_ios_billed_duration=0;
				$total_ios_x_value=0;
				$total_ios_y_value=0;
				$total_ios_z_value=0;
				$total_ios_icx_value=0;
				$total_ios_igw_cost=0;

				foreach($get_record as $k=>$v){
				?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->ICX;?></td>
					<td class="brt2" style="width:250px;"><?php echo number_format(($v->BL_TOTAL_CHARGED_UNIT_IN_MIN),2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format(($v->BL_TOTAL_X_VALUE),2);?></td>
					<td class="brt2" style="width:100px;"> <?php echo number_format(($v->BL_TOTAL_Y_VALUE),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($v->BL_TOTAL_Z_VALUE),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($v->BL_TOTAL_PERCENTAGE_OF_Z),2);?></td>		
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE),2);?></td>								
					<td  style="width:100px;"></td>
					<td  style="width:100px;"></td>
					<td class="brrt2" style="width:120px;border-left:2px solid #cccccc;"> <?php echo number_format(($v->IGW_BILLED_DURATION_MIN),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($v->IGW_X_VALUE),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($v->IGW_Y_VALUE),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($v->IGW_Z_VALUE),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format((($v->IGW_Z_VALUE*(.15))),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(((($v->IGW_Z_VALUE*(.15)))+($v->IGW_Y_VALUE)),2);?></td>
				</tr>	
			 <?php 
			  $total_bl_billed_duration=$total_bl_billed_duration+$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
				$total_bl_x_value=$total_bl_x_value+$v->BL_TOTAL_X_VALUE;
				$total_bl_y_value=$total_bl_y_value+$v->BL_TOTAL_Y_VALUE;
				$total_bl_z_value=$total_bl_z_value+$v->BL_TOTAL_Z_VALUE;
				$total_bl_icx_value=$total_bl_icx_value+$v->BL_TOTAL_PERCENTAGE_OF_Z;
				$total_bl_igw_cost=$total_bl_igw_cost+($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE);
				$total_ios_billed_duration=$total_ios_billed_duration+$v->IGW_BILLED_DURATION_MIN;
				$total_ios_x_value=$total_ios_x_value+$v->IGW_X_VALUE;
				$total_ios_y_value=$total_ios_y_value+$v->IGW_Y_VALUE;
				$total_ios_z_value=$total_ios_z_value+$v->IGW_Z_VALUE;
				$total_ios_icx_value=$total_ios_icx_value+(($v->IGW_Z_VALUE*(.15)));
				$total_ios_igw_cost=$total_ios_igw_cost+((($v->IGW_Z_VALUE*(.15)))+($v->IGW_Y_VALUE));
			  } ?>
			 	<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;border-bottom:2px solid #cccccc;">Total</td>
					<td class="brt2" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_bl_billed_duration),2);?></td>
					<td class="brrt2" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_bl_x_value),2);?></td>
					<td class="brt2" style="width:100px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_y_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_z_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_icx_value),2);?></td>		
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_igw_cost),2);?></td>								
					<td  style="width:100px;"></td>
					<td  style="width:100px;"></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;border-left:2px solid #cccccc;"> <?php echo number_format(($total_ios_billed_duration),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_x_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_y_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_z_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_icx_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_igw_cost),2);?></td>
				</tr>	
			</table>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0"style="margin-top:20px">
				<?php echo $blanck_row; ?>
				<tr >
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td align="center" colspan="15">
						<div style="font-size:150%;color: coral;">Generate Difference & Percentage from BL_vs_IOS_reconciliation Report</div>
					</td>
				</tr>
				<tr style="height:20px"></tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;align:center;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">Difference between BL data & IOS data</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">%age of BL data & IOS data</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow;">ICX Operator Name</td>
					<td class="brt2" style="width:250px;background-color:yellow;">Billed Duration</td>
					<td class="brrt2" style="width:20px;background-color:yellow;">X in BDT</td>
					<td class="brt2" style="width:100px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>		
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>								
					<td class="rt2" style="width:100px;"></td>
					<td class="rt2" style="width:100px;"></td>
					<td class="brrt2" style="width:120px;background-color:yellow;border-left:2px solid #cccccc;">Billed Duration</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">X in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>
				</tr>	
				<?php 
				$total_difference_billed_duration=0;
				$total_difference_x_value=0;
				$total_difference_y_value=0;
				$total_difference_z_value=0;
				$total_difference_icx_value=0;
				$total_difference_igw_cost=0;
				$total_age_billed_duration=0;
				$total_age_x_value=0;
				$total_age_y_value=0;
				$total_age_z_value=0;
				$total_age_icx_value=0;
				$total_age_igw_cost=0;
				foreach($get_record as $k=>$v){
				  $diffrence_min=$v->IGW_BILLED_DURATION_MIN-$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
					$diffrence_x=$v->IGW_X_VALUE-$v->BL_TOTAL_X_VALUE;
					$diffrence_y=$v->IGW_Y_VALUE-$v->BL_TOTAL_Y_VALUE;
					$diffrence_z=$v->IGW_Z_VALUE-$v->BL_TOTAL_Z_VALUE;
					$diffrence_icx=(($v->IGW_Z_VALUE*(.15)))-$v->BL_TOTAL_PERCENTAGE_OF_Z;
					$diffrence_igw_cost=(($v->IGW_Z_VALUE*(.15)))-($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE);	
					$total_difference_billed_duration=$total_difference_billed_duration+$diffrence_min;
				  $total_difference_x_value=$total_difference_x_value+$diffrence_x;
				  $total_difference_y_value=$total_difference_y_value+$diffrence_y;
				  $total_difference_z_value=$total_difference_z_value+$diffrence_z;
				  $total_difference_icx_value=$total_difference_icx_value+$diffrence_icx;
				  $total_difference_igw_cost=$total_difference_igw_cost+$diffrence_igw_cost;
				}
				foreach($get_record as $k=>$v){
					$diffrence_min=$v->IGW_BILLED_DURATION_MIN-$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
					$diffrence_x=$v->IGW_X_VALUE-$v->BL_TOTAL_X_VALUE;
					$diffrence_y=$v->IGW_Y_VALUE-$v->BL_TOTAL_Y_VALUE;
					$diffrence_z=$v->IGW_Z_VALUE-$v->BL_TOTAL_Z_VALUE;
					$diffrence_icx=(($v->IGW_Z_VALUE*(.15)))-$v->BL_TOTAL_PERCENTAGE_OF_Z;
					$diffrence_igw_cost=((($v->IGW_Z_VALUE*(.15)))+($v->IGW_Y_VALUE))-($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE);
				?>		
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->ICX;?></td>
					<td class="brt2" style="width:250px;"><?php echo number_format($diffrence_min,2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format($diffrence_x,2);?></td>
					<td class="brt2" style="width:100px;"> <?php echo number_format($diffrence_y,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($diffrence_z,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($diffrence_icx,2);?></td>		
					<td class="brrt2" style="width:120px;"> <?php echo number_format($diffrence_igw_cost,2);?></td>								
					<td  style="width:100px;"></td>
					<td  style="width:100px;"></td>
					<td class="brrt2" style="width:120px;border-left:2px solid #cccccc;"> <?php echo number_format((($diffrence_min/$v->BL_TOTAL_CHARGED_UNIT_IN_MIN)*100),2);?>%</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format((($diffrence_x/$v->BL_TOTAL_X_VALUE)*100),2);?>%</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format((($diffrence_y/$v->BL_TOTAL_Y_VALUE)*100),2);?>%</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format((($diffrence_z/$v->BL_TOTAL_Z_VALUE)*100),2);?>%</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format((($diffrence_icx/$v->BL_TOTAL_PERCENTAGE_OF_Z)*100),2);?>%</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format((($diffrence_igw_cost/($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE))*100),2);?>%</td>
				</tr>	
			 <?php 
				$total_age_billed_duration=($total_difference_billed_duration/$total_bl_billed_duration)*100;
				$total_age_x_value=($total_difference_x_value/$total_bl_x_value)*100;
				$total_age_y_value=($total_difference_y_value/$total_bl_y_value)*100;
				$total_age_z_value=($total_difference_z_value/$total_bl_z_value)*100;
				$total_age_icx_value=($total_difference_icx_value/$total_bl_icx_value)*100;
				$total_age_igw_cost=($total_difference_igw_cost/$total_bl_igw_cost)*100;
			  } ?>
			 	<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;border-bottom:2px solid #cccccc;">Total</td>
					<td class="brt2" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_difference_billed_duration),2);?></td>
					<td class="brrt2" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_difference_x_value),2);?></td>
					<td class="brt2" style="width:100px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_y_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_z_value),2);?></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_icx_value),2);?></td>		
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_igw_cost),2);?></td>								
					<td  style="width:100px;"></td>
					<td  style="width:100px;"></td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;border-left:2px solid #cccccc;"> <?php echo number_format(($total_age_billed_duration),2);?>%</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_x_value),2);?>%</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_y_value),2);?>%</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_z_value),2);?>%</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_icx_value),2);?>%</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_igw_cost),2);?>%</td>
				</tr>	
			</table>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0"style="margin-top:20px">
				<?php echo $blanck_row; ?>
				<tr >
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td align="center" colspan="3">
						<div style="font-size:150%;color: coral;">IGW Summery Data from BL_vs_IOS_reconciliation Report</div>
					</td>
				</tr>
				<tr style="height:20px"></tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;align:center;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">IGW Summery Data</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow;">IOS OPERATOR NAME</td>
					<td class="brt2" style="width:250px;background-color:yellow;">Billed Duration</td>
					<td class="brrt2" style="width:20px;background-color:yellow;">X in BDT</td>
					<td class="brt2" style="width:100px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or IOS Value</td>		
					<td class="brrt2" style="width:120px;background-color:yellow;">Y+15%Z</td>								
				</tr>	
				<?php 
				$total_igw_min_data=0;
				$total_igw_x_data=0;
				$total_igw_y_data=0;
				$total_igw_z_data=0;
				$total_igw_age_y_data=0;
				$total_invoice_data=0;
				foreach($igw_get_record as $k=>$v){
				?>		
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->IGW;?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($v->TOTAL_BILLED_DURATION_MINS,2);?></td>	
					<td class="brt2" style="width:250px;"><?php echo number_format($v->TOTAL_IGW_X_VALUE,2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format($v->TOTAL_IGW_Y_VALUE,2);?></td>
					<td class="brt2" style="width:100px;"> <?php echo number_format($v->TOTAL_IGW_Z_VALUE,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($v->TOTAL_INVOICE_VALUE_OF_Z,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($v->TOTAL_INVOICE_AMOUNT,2);?></td>		
				</tr>	
			 <?php  
			 	$total_igw_min_data=$total_igw_min_data+$v->TOTAL_BILLED_DURATION_MINS;
				$total_igw_x_data=$total_igw_x_data+$v->TOTAL_IGW_X_VALUE;
				$total_igw_y_data=$total_igw_y_data+$v->TOTAL_IGW_Y_VALUE;
				$total_igw_z_data=$total_igw_z_data+$v->TOTAL_IGW_Z_VALUE;
				$total_igw_age_y_data=$total_igw_age_y_data+$v->TOTAL_INVOICE_VALUE_OF_Z;
				$total_invoice_data=$total_invoice_data+$v->TOTAL_INVOICE_AMOUNT;
			  } ?>
			 	<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Total</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($total_igw_min_data,2);?></td>	
					<td class="brt2" style="width:250px;"><?php echo number_format($total_igw_x_data,2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format($total_igw_y_data,2);?></td>
					<td class="brt2" style="width:100px;"> <?php echo number_format($total_igw_z_data,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($total_igw_age_y_data,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($total_invoice_data,2);?></td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">&nbsp;</td>
					<td class="brrt2" style="width:120px;">&nbsp;</td>	
					<td class="brt2" style="width:250px;">&nbsp;</td>
					<td class="brrt2" style="width:250px;">&nbsp;</td>
					<td class="brt2" style="width:100px;">&nbsp;</td>
					<td class="brrt2" style="width:120px;">&nbsp;</td>
					<td class="brrt2" style="width:120px;">&nbsp;</td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">BL IT Report</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($total_bl_billed_duration,2);?></td>	
					<td class="brt2" style="width:250px;"><?php echo number_format($total_bl_x_value,2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format($total_bl_y_value,2);?></td>
					<td class="brt2" style="width:100px;"> <?php echo number_format($total_bl_z_value,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($total_bl_icx_value,2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format($total_bl_igw_cost,2);?></td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Difference between IGW & BL data</td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($total_igw_min_data-$total_bl_billed_duration),2);?></td>	
					<td class="brt2" style="width:250px;"><?php echo number_format(($total_igw_x_data-$total_bl_x_value),2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format(($total_igw_y_data-$total_bl_y_value),2);?></td>
					<td class="brt2" style="width:100px;"> <?php echo number_format(($total_igw_z_data-$total_bl_z_value),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($total_igw_age_y_data-$total_bl_icx_value),2);?></td>
					<td class="brrt2" style="width:120px;"> <?php echo number_format(($total_invoice_data-$total_bl_igw_cost),2);?></td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;border-bottom:2px solid #cccccc;">%Age of IGW & BL data</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_igw_min_data-$total_bl_billed_duration)/$total_bl_billed_duration)*100),2);?>%</td>	
					<td class="brt2" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(((($total_igw_x_data-$total_bl_x_value)/$total_bl_x_value)*100),2);?>%</td>
					<td class="brrt2" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(((($total_igw_y_data-$total_bl_y_value)/$total_bl_y_value)*100),2);?>%</td>
					<td class="brt2" style="width:100px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_igw_z_data-$total_bl_z_value)/$total_bl_z_value)*100),2);?>%</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_igw_age_y_data-$total_bl_icx_value)/$total_bl_icx_value)*100),2);?>%</td>
					<td class="brrt2" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_invoice_data-$total_bl_igw_cost)/$total_bl_igw_cost)*100),2);?>%</td>		
				</tr>	
			</table>
			
			
		</div>
	</body>
</html>




































