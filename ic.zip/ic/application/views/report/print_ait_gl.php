
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AIT Auto GL</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid black; }
			.brr1 { border-right:1px solid black; }
			.brb1 { border-bottom:1px solid black; }
			.brl1 { border-left:1px solid black; }
			.brt2 { border-top:1px solid black; }
			.brtl2 { border-top:1px solid black; border-left:1px solid black; }
			.brtr2 { border-top:1px solid black; border-right:1px solid black; }
			.brr2 { border-right:1px solid black; }
			.brrt2 { border-right:1px solid black; border-top:1px solid black; }
			.brrb2 { border-right:1px solid black; border-bottom:1px solid black; }
	
			.brl2 { border-left:1px solid black; }
			.brlt2 { border-left:1px solid black; border-top:1px solid black; }
			.brlb2 { border-left:1px solid black; border-bottom:1px solid black; }
			
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<?php
			// $global_cut_of=$get_record[0]->MAX_DAY;
			?>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Balance Type</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>Actual</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Database</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7">BLERPPRD03.BANGLALINKGSM.COM.PROD</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Set of Books</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7">Banglalink Set of Books</td>
				</tr>
				<?php echo $blanck_row; ?>
				<tr> 
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Category</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right" style="border-right:1px solid #CCCCCC">* List - Text</td>
					<td class="" style="border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC"  colspan="6" ><strong>BL_GL_Revenue</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Sourch</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right" style="border-right:1px solid #CCCCCC">* List - Text</td>
					<td class="brlt2 brr2"  style="border-right:1px solid #CCCCCC" colspan="6"><strong>Spreadsheet</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Currency</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right" style="border-right:1px solid #CCCCCC">* List - Text</td>
					<td class="brlt2 brr2" style="border-right:1px solid #CCCCCC" colspan="6"><strong>BDT</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Accounting Date</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" style="border-right:1px solid #CCCCCC" align="right" >* List - Text</td>
					<td class="brt2 " style="border-right:1px solid #CCCCCC" align="left"  colspan="6" ><strong><?php echo date("d-M-Y");?></strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2"><strong>Journal Name</strong></td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2" colspan=6><strong>Interconnection LTFS Toll Free Revenue from Inter Operators for <?php echo $date.' _Actual';?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2"><strong>Journal Description</strong></td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2" colspan=6><strong>Interconnection LTFS Toll Free Revenue from Inter Operators for <?php echo $date.' _Actual';?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2" style="border-bottom:1px solid #CCCCCC"><strong>Journal Reference</strong></td>
					<td class=""  style="border-bottom:1px solid #CCCCCC" >&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="brr2" style="border-bottom:1px solid #CCCCCC" align="right">Text</td>
					<td class="brr2" style="border-bottom:1px solid #CCCCCC" colspan=6><strong>Interconnection LTFS Toll Free Revenue from Inter Operators for <?php echo $date.' _Actual';?></strong></td>
				</tr>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?> 
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Upl</td>
					<td class="brt2" style="width:80px;">COMPANY</td>
					<td class="brt2" style="width:60px;">BRANCH</td>
					<td class="brt2" style="width:100px;">COST CENTER</td>
					<td class="brt2" style="width:120px;">NATURAL ACOUNT</td>
					<td class="brt2" style="width:70px;">ANLYTICAL</td>
					<td class="brt2" style="width:60px;">PROJECT</td>
					<td class="brt2" style="width:60px;">FUTURE</td>
					<td class="brt2" style="width:110px;">Debit</td>
					<td class="brt2" style="width:110px;">Credit</td>
					<td class="brt2" style="width:700px;">Line Description</td>
					<td class="brt2" style="width:70px;"></td>
					<td class="brt2" style="width:110px; border-right:1px solid #CCCCCC">Messages</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brlb2" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td style="border-bottom:1px solid #CCCCCC" colspan="7">* List - Text</td>
					<td style="border-bottom:1px solid #CCCCCC">* Number</td>
					<td style="border-bottom:1px solid #CCCCCC">* Number</td>
					<td style="border-bottom:1px solid #CCCCCC">Text</td>
					<td style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td style="border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC">&nbsp;</td>
				</tr>
				<?php 
				$total_credit=0;
				$total_debit=0;
				foreach($get_record as $k=>$v):
				?>
				<tr>
			 	<td>&nbsp;</td>
					<td class="brl2">&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td><?php $account=$v->ACCOUNT; $all_info=explode(".",$account); echo $all_info[2];?></td>
				  <td><?php echo $all_info[3];?></td>
					<td>0000&nbsp;</td>
					<td>0000</td>
					<td>0000&nbsp;</td>
				  <td class="brl2" style="text-align:right;"><?php echo number_format($v->ENTRED_DEBIT,2);?></td>
					<td class="brl2" style="text-align:right;"><?php echo number_format($v->ENTRED_CREDIT,2);?></td>
					 <td class="brl2">
					 	<?php echo $v->DESCRIPTION;?>
					 </td>
					<td class="brl2">&#x263A;</td>
					<td class="brr2">&nbsp;</td>
			 </tr>
			<?php  
			$total_debit=$total_debit+$v->ENTRED_DEBIT;
			$total_credit=$total_credit+$v->ENTRED_CREDIT;
			endforeach; 
			?>
				<tr>
					<td>&nbsp;</td>
					<td class="brl2 brt2" style="border-bottom:1px solid #CCCCCC;border-top:1px solid #CCCCCC;border-left:1px solid #CCCCCC;">Totals:</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;"><?php echo number_format($total_debit);?></td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;"><?php echo  number_format($total_credit);?></td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC;">&nbsp;</td>
					<td class=" brt2 brr2" style="border-bottom:1px solid #CCCCCC ;border-top:1px solid #CCCCCC; ;border-right:1px solid #CCCCCC;">&nbsp;</td>
				</tr>			
				<tr>
					<td>&nbsp;</td>
					<td colspan=8 >Tip: This is not the end of the Template.  Unprotect the sheet and insert as many rows as needed.</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
			</table>
		</div>
	</body>
</html>




































