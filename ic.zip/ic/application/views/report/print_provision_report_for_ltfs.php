
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 15 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Provision Report for ITFS";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Duration</th>
						<th>Rate Per Min BDT</th>
						<th>BL Revenue</th>
						<!--<th>SD Rate</th>
						<th>SD Amount</th>
						<th>SC Rate</th>
						<th>SC</th>
						<th>VAT on (Revenue+SD)</th>
						<th>Total</th>-->
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$total_duration = 0;
					$rate_usd = 0;
					$ter_charge_usd = 0;
					$usd_bdt = 0;
					$ter_charge_bdt = 0;
					$bl_revenue = 0;
					$sd_amount_total=0;
					$sc_amount_total=0;
					$vat_on_revenue=0;
					$final_total=0;
					
					$grand_total_no_calls = 0;
					$grand_total_duration = 0;
					$grand_rate_usd = 0;
					$grand_ter_charge_usd = 0;
					$grand_usd_bdt = 0;
					$grand_ter_charge_bdt = 0;
					$grand_bl_revenue = 0;
					$grand_sd_amount_total=0;
					$grand_sc_amount_total=0;
					$grand_vat_on_revenue=0;
					$grand_final_total=0;
					$gtc = 0;
					$gtm=0;
					$gtr =0;
					 ?>
					<?php //dd($get_record); ?>
					<?php foreach($get_record as $k=>$v): $total_record=count($get_record); ?>
					<tr>
						<td><?php echo $v->OPERATOR_NAME; ?></td> 
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td align="right"><?php echo number_format($v->NUMBER_OF_CALLS,2); $total_no_calls += $v->NUMBER_OF_CALLS; $gtc += $v->NUMBER_OF_CALLS;?></td>
						<td align="right"><?php echo number_format($v->DURATION_MIN,2); $total_duration += $v->DURATION_MIN; $gtm += $v->DURATION_MIN;?></td>
						<td align="right"><?php echo number_format($v->RATE_PER_MIN_BDT,2); ?></td>
						<td align="right"><?php echo number_format($v->REVENUE,2); $bl_revenue += $v->REVENUE;$gtr += $v->REVENUE;?></td>
					</tr>
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->OPERATOR_NAME != $get_record[$k + 1]->OPERATOR_NAME){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $total_duration = 0; ?></td>
						<td align="right"></td> 
						<td align="right"><?php echo number_format($bl_revenue,2); $bl_revenue = 0; ?></td>
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				  <tr style="background-color:#FFED4A;">
						<td>Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($total_no_calls,2); $grand_total_no_calls=$grand_total_no_calls+$total_no_calls; $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $grand_total_duration=$grand_total_duration+$total_duration; $total_duration = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $grand_bl_revenue=$grand_bl_revenue+$bl_revenue;$bl_revenue = 0; ?></td>
					</tr>
				    <?php }?>
					<?php endforeach; ?>
					
					
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtc,2); ?></td>
						<td align="right"><?php echo number_format($gtm,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($gtr,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>
	</body>
</html>