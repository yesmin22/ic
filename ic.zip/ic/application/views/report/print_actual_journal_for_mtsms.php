<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Journal for MTSMS</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<?php
			// $global_cut_of=$get_record[0]->MAX_DAY;
			?>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Balance Type</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>Actual</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Database</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7">BLERPPRD03.BANGLALINKGSM.COM.PROD</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Set of Books</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7">Banglalink Set of Books</td>
				</tr>
				<?php echo $blanck_row; ?>
				<tr> 
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Category</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right" style="border-right:1px solid #CCCCCC">* List - Text</td>
					<td class="" style="border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC"  colspan="6" ><strong>BL_GL_Revenue</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Sourch</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right" style="border-right:1px solid #CCCCCC">* List - Text</td>
					<td class="brlt2 brr2"  style="border-right:1px solid #CCCCCC" colspan="6"><strong>Spreadsheet</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Currency</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right" style="border-right:1px solid #CCCCCC">* List - Text</td>
					<td class="brlt2 brr2" style="border-right:1px solid #CCCCCC" colspan="6"><strong>BDT</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Accounting Date</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" style="border-right:1px solid #CCCCCC" align="right" >* List - Text</td>
					<td class="brt2 " style="border-right:1px solid #CCCCCC"  colspan="6" align="left" ><strong><?php echo date("d-M-Y");?></strong></td>
				</tr>
				
				
				
				
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2"><strong>Journal Name</strong></td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2" colspan=6><strong>Interconnection SMS Revenue from Inter Operators for <?php echo $date.' _Actual';?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2"><strong>Journal Description</strong></td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2" colspan=6><strong>Interconnection SMS Revenue from Inter Operators for <?php echo $date.' _Actual';?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2" style="border-bottom:1px solid #CCCCCC"><strong>Journal Reference</strong></td>
					<td class=""  style="border-bottom:1px solid #CCCCCC" >&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC">&nbsp;</td>
					<td class="brr2" style="border-bottom:1px solid #CCCCCC" align="right">Text</td>
					<td class="brr2" style="border-bottom:1px solid #CCCCCC" colspan=6><strong>Interconnection SMS Revenue from Inter Operators for <?php echo $date.' _Actual';?></strong></td>
				</tr>
				
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?> 
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Upl</td>
					<td class="brt2" style="width:80px;">COMPANY</td>
					<td class="brt2" style="width:60px;">BRANCH</td>
					<td class="brt2" style="width:100px;">COST CENTER</td>
					<td class="brt2" style="width:120px;">NATURAL ACOUNT</td>
					<td class="brt2" style="width:70px;">ANLYTICAL</td>
					<td class="brt2" style="width:60px;">PROJECT</td>
					<td class="brt2" style="width:60px;">FUTURE</td>
					<td class="brt2" style="width:110px;">Debit</td>
					<td class="brt2" style="width:110px;">Credit</td>
					<td class="brt2" style="width:700px;">Line Description</td>
					<td class="brt2" style="width:70px;"></td>
					<td class="brrt2" style="width:110px;">Messages</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brlb2">&nbsp;</td>
					<td class="brb2" colspan="7">* List - Text</td>
					<td class="brb2">* Number</td>
					<td class="brb2">* Number</td>
					<td class="brb2">Text</td>
					<td class="brb2">&nbsp;</td>
					<td class="brrb2">&nbsp;</td>
				</tr>
				<?php 
				$total_credit=0;
				$total_debit=0;
				foreach($get_record as $k=>$v):
				$operator_info = $this->customcache->operator_maker_new($v->OPERATOR_NAME,null);
				$revenue_gl = $this->customcache->gl_maker_rev($v->OPERATOR_NAME);
				$get_common_gl = $this->customcache->get_common_gl($v->OPERATOR_NAME);
				$total_vat=$v->POST_VAT_VALUE+$v->PREP_VAT_VALUE;
				?>
				<tr>
					<td style="mso-number-format:'\@';"></td>
					<td class="brl2" style="mso-number-format:'\@';"></td>
					<td style="mso-number-format:'\@';">01</td>
					<td style="mso-number-format:'\@';">101</td>
					<td style="mso-number-format:'\@';">A000</td>
				    <td style="mso-number-format:'\@';"><?php if($revenue_gl){echo $revenue_gl[2];}?></td>
					<td style="mso-number-format:'\@';">0000</td>
					<td style="mso-number-format:'\@';"><?php if($v->PROJECT_CODE){echo $v->PROJECT_CODE;}?>&nbsp;</td>
					<td style="mso-number-format:'\@';">0000</td>
				    <td class="brl2" style="text-align:right;mso-number-format:'\@';"><?php $debit_value=$v->POST_VALUE+$v->PREP_VALUE+$total_vat; echo number_format($debit_value,2);?></td>
					<td  class="brl2" style="text-align:right;mso-number-format:'\@';"></td>
					<td class="brl2" style="mso-number-format:'\@';">
					 	<?php echo  $v->OPERATOR_NAME.','.$v->OPERATOR_TYPE.','.$date.' INVOICE,SMS, for Interconnection Call Carrying Postpaid Revenue';
					 	 ?>
					</td>
					<td class="brl2" style="mso-number-format:'\@';">&#x263A;</td>
					<td class="brr2" style="mso-number-format:'\@';"></td>
			    </tr>
			    <tr>
					<td style="mso-number-format:'\@';"></td>
					<td class="brl2" style="mso-number-format:'\@';"></td>
					<td style="mso-number-format:'\@';">01</td>
					<td style="mso-number-format:'\@';">101</td>
					<td style="mso-number-format:'\@';">A000</td>
				    <td style="mso-number-format:'\@';"><?php if($revenue_gl){echo $revenue_gl[8];}?></td>
					<td style="mso-number-format:'\@';">0000</td>
					<td style="mso-number-format:'\@';"><?php if($v->PROJECT_CODE){echo $v->PROJECT_CODE;}?></td>
					<td style="mso-number-format:'\@';">0000</td>
				    <td class="brl2" style="text-align:right;mso-number-format:'\@';"></td>
					<td class="brl2" style="text-align:right;mso-number-format:'\@';"><?php echo number_format($v->POST_VALUE,2);?></td>
					<td class="brl2" style="mso-number-format:'\@';">
					 	<?php echo  $v->OPERATOR_NAME.','.$v->OPERATOR_TYPE.','.$date.' ACTUAL,SMS, for Interconnection Call Carrying Postpaid Revenue'; ?>
					</td>
					<td class="brl2" style="mso-number-format:'\@';">&#x263A;</td>
					<td class="brr2" style="mso-number-format:'\@';"></td>
				</tr>
				<tr>
					<td style="mso-number-format:'\@';"></td>
					<td class="brl2" style="mso-number-format:'\@';"></td>
					<td style="mso-number-format:'\@';">01</td>
					<td style="mso-number-format:'\@';">101</td>
					<td style="mso-number-format:'\@';">A000</td>
				    <td style="mso-number-format:'\@';"><?php if($revenue_gl){echo $revenue_gl[10];}?></td>
					<td style="mso-number-format:'\@';">0000</td>
					<td style="mso-number-format:'\@';"><?php if($v->PROJECT_CODE){echo $v->PROJECT_CODE;}?></td>
					<td style="mso-number-format:'\@';">0000</td>
					<td class="brl2" style="text-align:right;mso-number-format:'\@';"></td>
					<td class="brl2" style="text-align:right;mso-number-format:'\@';"><?php echo number_format($v->PREP_VALUE,2);?></td>
					<td class="brl2" style="mso-number-format:'\@';">
					 	<?php echo  $v->OPERATOR_NAME.','.$v->OPERATOR_TYPE.','.$date.' ACTUAL,SMS, for Interconnection Call Carrying Prepaid Revenue';
					 	 ?>
					</td>
					<td class="brl2" style="mso-number-format:'\@';">&#x263A;</td>
					<td class="brr2" style="mso-number-format:'\@';">&nbsp;</td>
				</tr>
				<tr>
					<td style="mso-number-format:'\@';"></td>
					<td class="brl2" style="mso-number-format:'\@';"></td>
					<td style="mso-number-format:'\@';">01</td>
					<td style="mso-number-format:'\@';">101</td>
					<td style="mso-number-format:'\@';">A000</td>
				    <td style="mso-number-format:'\@';"><?php if($get_common_gl){echo $get_common_gl[1];}?></td>
					<td style="mso-number-format:'\@';">0000</td>
					<td style="mso-number-format:'\@';"><?php if($v->PROJECT_CODE){echo $v->PROJECT_CODE;}?></td>
					<td style="mso-number-format:'\@';">0000</td>
				    <td class="brl2" style="text-align:right;mso-number-format:'\@';"></td>
					<td class="brl2" style="text-align:right; mso-number-format:'\@';"><?php echo number_format($total_vat,2);?></td>
					<td class="brl2" style="mso-number-format:'\@';">
					 	<?php echo  $v->OPERATOR_NAME.','.$v->OPERATOR_TYPE.','.$date.' INVOICE,SMS, for Interconnection Call Carrying Postpaid Revenue VAT';
					 	 ?>
					</td>
					<td class="brl2" style="mso-number-format:'\@';">&#x263A;</td>
					<td class="brr2"style="mso-number-format:'\@';"></td>
			 </tr>
		
			<?php  
			$total_credit=$total_credit+$v->PREP_VALUE+$v->POST_VALUE+$total_vat;
			$total_debit=$total_debit+$debit_value;
			endforeach; 
			?>
				
				
				<tr>
					<td style="mso-number-format:'\@';">&nbsp;</td>
					<td class="brl1" style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';">Totals:</td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;text-align:right;mso-number-format:'\@';"> <?php echo number_format($total_debit,2);?></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;text-align:right;mso-number-format:'\@';"><?php echo  number_format($total_credit,2);?></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
					<td class="brr1" style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC;mso-number-format:'\@';"></td>
				</tr>		
				<tr>
					<td style="mso-number-format:'\@';">&nbsp;</td>
					<td style="mso-number-format:'\@';"colspan=8 >Tip: This is not the end of the Template.  Unprotect the sheet and insert as many rows as needed.</td>
					<td style="mso-number-format:'\@';">&nbsp;</td>
					<td style="mso-number-format:'\@';">&nbsp;</td>
					<td style="mso-number-format:'\@';">&nbsp;</td>
					<td style="mso-number-format:'\@';">&nbsp;</td> 
					<td style="mso-number-format:'\@';">&nbsp;</td>
				</tr>
			</table>
		</div>
	</body>
</html>




































