<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 13;
$report_name="IOS Reconcilation Report";
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IOS Reconcilation Report</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }

		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<?php if($ios_summery=='yes'){?>
		<div>
		<div style="margin-left: 10em;">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<table class="table table-bordered table-striped" border="1" style="overflow:auto;">
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?> 
					<tr>
						<td>&nbsp;</td>
						<td>Operator Name</td>
						<td style="background-color:#97C8D9"> IGW Invoice</td>
						<td style="background-color:#97C8D9"> ICX Data</td>
						<td style="background-color:#97C8D9"> Difference_IGW_ICX</td>
						<td style="background-color:#97C8D9"> %age_IGW_ICX</td>
						<td style="background-color:#97C8D9"> IGW Invoice data</td>
						<td style="background-color:#97C8D9"> 7.5% tax</td>
						<td style="background-color:#97C8D9"> IGW inv after tax </td>
						<td style="background-color:yellow">BL Calculation</td>
						<td style="background-color:yellow"> 7.5% tax</td>
						<td style="background-color:yellow"> BL Calculation after tax</td>
						<td style="background-color:yellow"> Difference_IGW_BL</td>
						<td style="background-color:yellow">%age_IGW_BL</td>
						<td style="background-color:yellow"> Payable</td>
						<td style="background-color:yellow">TDS 7.5%</td>
						<td style="background-color:yellow">Payment After TDS</td>
						<td style="background-color:yellow">Taken Data</td>
					</tr>
					<?php 
					$total_IGW_Invoice=0;
					$total_ICX_Data=0;
					$total_Difference_IGW_ICX=0;
					$total_age_IGW_ICX=0;
					$total_IGW_Invoice_data=0;
					$total_tax_igw=0;
					$total_IGW_inv_after_tax=0;
					$total_BL_Calculation=0;
					$total_tax_bl=0;
					$total_BL_Calculation_after_tax=0;
					$total_Difference_IGW_BL=0;
					$total_age_IGW_BL=0;
					$total_Payable=0;
					$total_TDS=0;
					$total_Payment_After_TDS=0;

				 		foreach($get_igw_record_for_ios_summery_report as $k=>$v){
				 		$total_bl_data=0;
				 		foreach($get_bl_record_for_ios_summery_report as $bl_k=>$bl_v){
				 			if($v->IGW==$bl_v->IGW){
				 				$icx_x_value_ratio=($bl_v->X_VALUE/$bl_v->TOTAL_ICX_X_VALUE)*100;
								$icx_y_value_ratio=($bl_v->Y_VALUE/$bl_v->TOTAL_ICX_Y_VALUE)*100;
								$icx_z_value_ratio=($bl_v->Z_VALUE/$bl_v->TOTAL_ICX_Z_VALUE)*100;
								$bl_x_value=(($bl_v->TOTAL_BL_X_VALUE*$icx_x_value_ratio)/100);
								$bl_y_value=(($bl_v->TOTAL_BL_Y_VALUE*$icx_y_value_ratio)/100);
								//$bl_z_value=round((($bl_v->TOTAL_BL_Z_VALUE*$icx_z_value_ratio)/100),2);
								$bl_z_value=(($bl_x_value-$bl_y_value));
								$z_invoice=($bl_z_value*15)/100;
								$bl_invoice_amount=$bl_y_value+$z_invoice;
								$total_bl_data=($total_bl_data+$bl_invoice_amount);
				 			}
				 		}
			  ?>
				<tr>
					<td>&nbsp;</td>
					<td><?php echo $v->IGW;?></td>
					<td align="right"><?php echo number_format($v->TOTAL_IGW_INVOICE_AMOUNT,2);?></td>
					<td align="right"><?php echo number_format($v->TOTAL_ICX_INVOICE_AMOUNT,2);?></td>
					<td align="right"> <?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT),2);?></td>
					<td align="right"> <?php echo number_format(((($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT)/$v->TOTAL_ICX_INVOICE_AMOUNT)*100),2);?>%</td>
					<td align="right"><?php echo number_format($v->TOTAL_IGW_INVOICE_AMOUNT,2);?></td>
					<td align="right">(
						<?php if($v->IGW!='BTCL'){ 
						$igw_tax=(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100);
					}else{
						$igw_tax=0;
						}
						$igw_tax_formated=number_format($igw_tax,2);
						echo  $igw_tax_formated ;?>)</td>
						
						
					<td align="right"><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$igw_tax),2);?></td>
					<td align="right"><?php echo number_format($total_bl_data,2);?></td>
					<td align="right">(<?php if($v->IGW!='BTCL'){
						 $bl_tax= (($total_bl_data*(7.5))/100);}else{$bl_tax=0;}
						 $bl_tax_formated=number_format($bl_tax,2);
						 echo $bl_tax_formated;?>)</td>
					<td align="right"><?php echo number_format(($total_bl_data-$bl_tax),2);?></td>
					<td align="right"><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data),2);?></td>
					<td align="right"><?php $total_dispute=((($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data)/$total_bl_data)*100); echo number_format(((($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data)/$total_bl_data)*100),2);?>%</td>
					<td align="right"><?php  if($total_dispute>1){$reconsider_data=$total_bl_data; echo number_format($reconsider_data,2);}else{$reconsider_data=$v->TOTAL_IGW_INVOICE_AMOUNT;echo number_format($reconsider_data,2);}?></td>
					<td align="right"><?php  
						if($v->IGW!='BTCL'){
						 if($total_dispute>1){
						 	$tds=(($total_bl_data*(7.5))/100);
						 	}else{
						 		$tds= (($v->TOTAL_IGW_INVOICE_AMOUNT*(7.5))/100);
						 		}
						}else{
							$tds=0 ;} echo number_format($tds,2);?> </td>
					<td align="right"><?php  if($total_dispute>1){$Payment_After_TDS= ($total_bl_data-$tds); echo number_format($Payment_After_TDS,2);}else{$Payment_After_TDS=($v->TOTAL_IGW_INVOICE_AMOUNT-$tds); echo number_format($Payment_After_TDS,2);}?></td>
					<td><?php  if($reconsider_data==$total_bl_data){echo 'Banglalink Data';}else{echo 'IGW DATA';}?></td>
					
				</tr>	
			<?php 
				$total_IGW_Invoice=$total_IGW_Invoice+$v->TOTAL_IGW_INVOICE_AMOUNT;
				$total_IGW_Invoice=$total_IGW_Invoice;
				$total_ICX_Data_value=$total_ICX_Data+$v->TOTAL_ICX_INVOICE_AMOUNT;
				$total_ICX_Data=$total_ICX_Data_value;
        $total_Difference_IGW_ICX_value=$total_Difference_IGW_ICX+($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT);
				$total_Difference_IGW_ICX=$total_Difference_IGW_ICX_value;
				$total_age_IGW_ICX=$total_age_IGW_ICX+((($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT)/$v->TOTAL_ICX_INVOICE_AMOUNT)*100);
				$total_IGW_Invoice_data=$total_IGW_Invoice_data+$v->TOTAL_IGW_INVOICE_AMOUNT;
				$total_IGW_Invoice_formated=$total_IGW_Invoice_data;
				$total_tax_igw=$total_tax_igw+(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100);
				$total_tax_igw_formated=$total_tax_igw;
				$total_IGW_inv_after_tax=$total_IGW_inv_after_tax+($v->TOTAL_IGW_INVOICE_AMOUNT-(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100));
				$total_IGW_inv_after_tax_formated=$total_IGW_inv_after_tax;
		    $total_BL_Calculation=$total_BL_Calculation+$total_bl_data;
		   	$total_BL_Calculation_formated=$total_BL_Calculation;
				$total_tax_bl=$total_tax_bl+$bl_tax;
			  $total_BL_Calculation_after_tax=$total_BL_Calculation_after_tax+($total_bl_data-$tax);
				$total_BL_Calculation_after_tax_formated=$total_BL_Calculation_after_tax;
				$total_Difference_IGW_BL=$total_Difference_IGW_BL+($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data);
				$total_Difference_IGW_BL_formated=$total_Difference_IGW_BL;
				$total_age_IGW_BL=$total_age_IGW_BL+$total_dispute;
				$total_Payable=$total_Payable+$reconsider_data;
				$total_Payable_formated=$total_Payable;
				$total_TDS=$total_TDS+$tds;
				$total_Payment_After_TDS=$total_Payment_After_TDS+$Payment_After_TDS;
			} 
			?>
			 	<tr>
					<td>&nbsp;</td>
					<td>Total</td>
					<td align="right"><?php echo number_format($total_IGW_Invoice,2);?></td>
					<td align="right"><?php echo number_format($total_ICX_Data,2);?></td>
					<td align="right"> <?php echo number_format($total_Difference_IGW_ICX,2);?></td>
					<td align="right"> <?php echo number_format((($total_Difference_IGW_ICX_value/$total_ICX_Data_value)*100),2)?>%</td>
					<td align="right"><?php echo number_format($total_IGW_Invoice_formated,2);?></td>
					<td align="right">(<?php echo number_format($total_tax_igw_formated,2);?>)</td>
					<td align="right"><?php echo number_format($total_IGW_inv_after_tax_formated,2);?></td>
					<td align="right"><?php echo number_format($total_BL_Calculation_formated,2);?></td>
					<td align="right">(<?php echo number_format($total_tax_bl,2);?>)</td>
					<td align="right"><?php echo number_format($total_BL_Calculation_after_tax_formated,2);?></td>
					<td align="right"><?php echo number_format($total_Difference_IGW_BL_formated,2);?></td>
					<td align="right"><?php echo number_format((($total_Difference_IGW_BL/$total_BL_Calculation)*100),2);?>%</td>
					<td align="right"><?php echo number_format($total_Payable_formated,2);?></td>
					<td align="right"><?php echo number_format($total_TDS,2);?></td>
					<td align="right"><?php echo number_format($total_Payment_After_TDS,2);?></td>
					<td></td>
					
				</tr>	
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td></td>
					
				</tr>	
				
			
				
				
			<?php 
					  $total_igw_invoice_exclude_data=0;
				 		$total_igw_tax_exclude_data=0;
				 		$total_igw_inv_after_tax_exclude_data=0;
				 		$total_bl_calculation_exclude_data=0;
				 		$total_bl_tax_exclude_data=0;
				 		$total_bl_calculation_after_tax_exclude_data=0;
				 		$total_difference_igw_bl_exclude_data=0;
				 		$total_total_payable_exclude_data=0;
						$total_total_payment_after_tds_exclude_data=0;
				 		foreach($get_igw_record_for_ios_summery_report as $k=>$v){
				 		foreach($excluded_igw as $excuded_k=>$excluded_v){	
				 		if($v->IGW==$excluded_v){
				 		$total_bl_data=0;
				 		foreach($get_bl_record_for_ios_summery_report as $bl_k=>$bl_v){
				 			if($v->IGW==$bl_v->IGW){
				 				
				 				$icx_x_value_ratio=($bl_v->X_VALUE/$bl_v->TOTAL_ICX_X_VALUE)*100;
								$icx_y_value_ratio=($bl_v->Y_VALUE/$bl_v->TOTAL_ICX_Y_VALUE)*100;
								$icx_z_value_ratio=($bl_v->Z_VALUE/$bl_v->TOTAL_ICX_Z_VALUE)*100;
								$bl_x_value=(($bl_v->TOTAL_BL_X_VALUE*$icx_x_value_ratio)/100);
								$bl_y_value=(($bl_v->TOTAL_BL_Y_VALUE*$icx_y_value_ratio)/100);
								//$bl_z_value=round((($bl_v->TOTAL_BL_Z_VALUE*$icx_z_value_ratio)/100),2);
								$bl_z_value=(($bl_x_value-$bl_y_value));
								$z_invoice=($bl_z_value*15)/100;
								$bl_invoice_amount=$bl_y_value+$z_invoice;
								$total_bl_data=($total_bl_data+$bl_invoice_amount);
				 			}
				 		}
			  	
				 		?>	
				 			
				 			
				 			
				 			
				 			
				 			
				 			
				 		
				 		
				 		
				 	<tr style="color:red">
					<td>&nbsp;</td>
					<td><?php echo $v->IGW;?> to be excluded</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"><?php echo number_format($v->TOTAL_IGW_INVOICE_AMOUNT,2);?></td>
					<td align="right">(<?php if($v->IGW!='BTCL'){$igw_tax=(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100);}else{$igw_tax=0;} echo number_format($igw_tax,2);?>)</td>
					<td align="right"><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100)),2);?></td>
					<td align="right"><?php echo number_format($total_bl_data,2);?></td>
					<td align="right">(<?php  if($v->IGW!='BTCL'){$bl_tax=(($total_bl_data*(7.5))/100);}else{$bl_tax=0;} echo number_format($bl_tax,2);?>)</td>
					<td align="right"><?php echo number_format(($total_bl_data-$bl_tax),2);?></td>
					<td align="right"><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data),2);?></td>
					<td></td>
					<td align="right"><?php  if($total_dispute>1){$reconsider_data=$total_bl_data; echo number_format($reconsider_data,2);}else{$reconsider_data=$v->TOTAL_IGW_INVOICE_AMOUNT;echo number_format($reconsider_data,2);}?></td>
					<td align="right"><?php  if($v->IGW!='BTCL'){ if($total_dispute>1){$tds=(($total_bl_data*(7.5))/100);}else{$tds= (($v->TOTAL_IGW_INVOICE_AMOUNT*(7.5))/100);}}else{$tds=0;} echo number_format($tds,2);?></td>
					<td align="right"><?php  if($total_dispute>1){$Payment_After_TDS= ($total_bl_data-$tds); echo number_format($Payment_After_TDS,2);}else{$Payment_After_TDS= ($v->TOTAL_IGW_INVOICE_AMOUNT-$tds); echo number_format($Payment_After_TDS,2);}?></td>
					<td></td>
				  </tr>	
				 		<?php 
				 		$total_igw_invoice_exclude_data=$total_igw_invoice_exclude_data+$v->TOTAL_IGW_INVOICE_AMOUNT;
				 		$total_igw_tax_exclude_data=$total_igw_tax_exclude_data+$igw_tax;
				 		$total_igw_inv_after_tax_exclude_data=$total_igw_inv_after_tax_exclude_data+($v->TOTAL_IGW_INVOICE_AMOUNT-(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100));
				 		$total_bl_calculation_exclude_data=$total_bl_calculation_exclude_data+$total_bl_data;
				 		$total_bl_tax_exclude_data=$total_bl_tax_exclude_data+$bl_tax;
				 		$total_bl_calculation_after_tax_exclude_data=$total_bl_calculation_after_tax_exclude_data+($total_bl_data-$bl_tax);
				 		$total_difference_igw_bl_exclude_data=$total_difference_igw_bl_exclude_data+($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data);
				 		$total_total_payable_exclude_data=$total_total_payable_exclude_data+$reconsider_data;
						$total_total_payment_after_tds_exclude_data=$total_total_payment_after_tds_exclude_data+$tds;
				 		
				 		}	
				 		}
			      } ?>
			       
				
				<tr style="color:red">
					<td>&nbsp;</td>
					<td>Total Payable exluding <?php echo $v->IGW;?></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"><?php echo number_format(($total_IGW_Invoice-$total_igw_invoice_exclude_data),2);?></td>
					<td align="right">(<?php echo number_format(($total_tax_igw-$total_igw_tax_exclude_data),2);?>)</td>
					<td align="right"><?php echo number_format(($total_IGW_inv_after_tax-$total_igw_inv_after_tax_exclude_data),2);?></td>
					<td align="right"><?php echo number_format(($total_BL_Calculation-$total_bl_calculation_exclude_data),2);?></td>
					<td align="right">(<?php  echo number_format(($total_tax_bl-$total_bl_tax_exclude_data),2);?>)</td>
					<td align="right"><?php echo number_format(($total_BL_Calculation_after_tax-$total_bl_calculation_after_tax_exclude_data),2);?></td>
					<td align="right"><?php echo number_format(($total_Difference_IGW_BL-$total_difference_igw_bl_exclude_data),2);?></td>
					<td></td>
					<td align="right"><?php echo number_format(($total_Payable-$total_total_payable_exclude_data),2);?></td>
					<td align="right"><?php  echo number_format(($total_TDS-$total_total_payment_after_tds_exclude_data),2);?></td>
					<td align="right"><?php echo number_format(($total_Payment_After_TDS-$Payment_After_TDS),2)?></td>
					<td></td>
				</tr>	
				<tr style="color:red">
					<td>&nbsp;</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td></td>
				</tr>	
				<tr style="color:red">
					<td>&nbsp;</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td></td>
				</tr>	
				<tr style="color:red">
					<td>&nbsp;</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
					<td></td>
				</tr>	
		</table>
		<table class="table" border="1" style="overflow:auto; margin-top:50px;width:auto;margin-left:400px">
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?> 
					<tr>
					<?php if($action_type=='Email'){?>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<?php }?>
					<td style="background-color:yellow" colspan=4 ><h4 style="align:center;margin-left:230px">Short Summery</h4></td>
					
				  </tr>	
					<tr>
						<?php if($action_type=='Email'){?>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<?php } ?>
						<td>Operator Name</td>
						<td> Payable</td>
						<td> 7.5% tax</td>
						<td>Difference between Payable amount & tax</td>
					</tr>
					<?php 
					$total_tax_bl=0;	
					$total_Payable=0;
					$total_difference_between_payable_amount_and_tax=0;
				 		foreach($get_igw_record_for_ios_summery_report as $k=>$v){
				 		foreach($excluded_igw as $excluded_igw_k=>$excluded_igw_v){
				 		if($v->IGW!=$excluded_igw_v){
				 		$total_bl_data=0;
				 		foreach($get_bl_record_for_ios_summery_report as $bl_k=>$bl_v){
				 			if($v->IGW==$bl_v->IGW){
				 				$icx_x_value_ratio=($bl_v->X_VALUE/$bl_v->TOTAL_ICX_X_VALUE)*100;
								$icx_y_value_ratio=($bl_v->Y_VALUE/$bl_v->TOTAL_ICX_Y_VALUE)*100;
								$icx_z_value_ratio=($bl_v->Z_VALUE/$bl_v->TOTAL_ICX_Z_VALUE)*100;
								$bl_x_value=(($bl_v->TOTAL_BL_X_VALUE*$icx_x_value_ratio)/100);
								$bl_y_value=(($bl_v->TOTAL_BL_Y_VALUE*$icx_y_value_ratio)/100);
								//$bl_z_value=round((($bl_v->TOTAL_BL_Z_VALUE*$icx_z_value_ratio)/100),2);
								$bl_z_value=(($bl_x_value-$bl_y_value));
								$z_invoice=($bl_z_value*15)/100;
								$bl_invoice_amount=$bl_y_value+$z_invoice;
								$total_bl_data=($total_bl_data+$bl_invoice_amount);
				 			}
				 		}
			  ?>
				<tr>
					<?php if($action_type=='Email'){?>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td><?php echo $v->IGW;?></td>
					<td align="right"><?php  if($total_dispute>1){$reconsider_data=$total_bl_data; echo number_format($reconsider_data,2);}else{$reconsider_data=$v->TOTAL_IGW_INVOICE_AMOUNT;echo number_format($reconsider_data,2);}?></td>
				
					<td align="right">(<?php if($v->IGW!='BTCL'){
						 $bl_tax= (($total_bl_data*(7.5))/100);}else{$bl_tax=0;}
						 $bl_tax_formated=number_format($bl_tax,2);
						 echo $bl_tax_formated;?>)</td>
					
					<td align="right"><?php echo number_format(($reconsider_data-$bl_tax),2)?></td>
					
				</tr>	
			<?php 
				$total_tax_bl=$total_tax_bl+$bl_tax;
				$total_Payable=$total_Payable+$reconsider_data;
				$total_Payable_formated=$total_Payable;
				$total_difference_between_payable_amount_and_tax=$total_difference_between_payable_amount_and_tax+($reconsider_data-$bl_tax);
			}} }
			?>
			   
			 	<tr>
			 		<?php if($action_type=='Email'){?>
			 		<td></td>
			 		<td></td>
					<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td>Total</td>
					<td align="right"><?php echo number_format($total_Payable_formated,2);?></td>
					<td align="right">(<?php echo number_format($total_tax_bl,2);?>)</td>
					<td align="right"><?php echo number_format($total_difference_between_payable_amount_and_tax,2);?></td>
				</tr>	
				<?php if($action_type=='Email'){?>
				<tr>
					
			 		<td></td>
			 		<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
				</tr>	
				<tr>
			 		<td></td>
			 		<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
				</tr>
				<tr>
			 		<td></td>
			 		<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right"></td>
					<td align="right"></td>
					<td align="right"></td>
				</tr>
				<?php } ?>
		</table>
	  </div>
		<?php }?>
		<?php if($bl_vs_ios_reconcilation=='yes'){$report_name="BL vs IOS Reconcilation";$total_column=15;?>
		<div id="printArea" style="margin-top:30px">
			<div style="">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;align:center;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">BL DATA</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;border-right:2px solid #cccccc;border-left:2px solid #cccccc;" bgcolor="#E6E6FA">IOS  Invoice DATA (ICX WISE DATA)</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow;">ICX Operator Name</td>
					<td class="brt2" style="width:250px;background-color:yellow;">Billed Duration</td>
					<td class="brrt2" style="width:250px;background-color:yellow;">X in BDT</td>
					<td class="brt2" style="width:100px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>		
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>								
					<td class="rt2" style="width:100px;"></td>
					<td class="brrt2" style="width:120px;background-color:yellow;border-left:2px solid #cccccc;">Billed Duration</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">X in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>
				</tr>	
				<?php 
				$total_bl_billed_duration=0;
				$total_bl_x_value=0;
				$total_bl_y_value=0;
				$total_bl_z_value=0;
				$total_bl_icx_value=0;
				$total_bl_igw_cost=0;
				$total_ios_billed_duration=0;
				$total_ios_x_value=0;
				$total_ios_y_value=0;
				$total_ios_z_value=0;
				$total_ios_icx_value=0;
				$total_ios_igw_cost=0;

				foreach($get_record_for_bl_vs_ios_report as $k=>$v){
				?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->ICX;?></td>
					<td align="right" class="brt2" style="width:250px;"><?php echo number_format(($v->BL_TOTAL_CHARGED_UNIT_IN_MIN),2);?></td>
					<td align="right" class="brrt2" style="width:250px;"><?php echo number_format(($v->BL_TOTAL_X_VALUE),2);?></td>
					<td align="right" class="brt2" style="width:100px;"> <?php echo number_format(($v->BL_TOTAL_Y_VALUE),2);?></td>
					<td align="right" class="brrt2" style="width:120px;"> <?php echo number_format(($v->BL_TOTAL_Z_VALUE),2);?></td>
					<td align="right" class="brrt2" style="width:120px;"> <?php echo number_format(($v->BL_TOTAL_PERCENTAGE_OF_Z),2);?></td>		
					<td align="right" class="brrt2" style="width:120px;"> <?php echo number_format(($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE),2);?></td>								
					<td  style="width:100px;"></td>
					<td align="right" class="brrt2" style="width:120px;border-left:2px solid #cccccc;"> <?php echo number_format(($v->IGW_BILLED_DURATION_MIN),2);?></td>
					<td align="right" class="brrt2" style="width:120px;"> <?php echo number_format(($v->IGW_X_VALUE),2);?></td>
					<td align="right" class="brrt2" style="width:120px;"> <?php echo number_format(($v->IGW_Y_VALUE),2);?></td>
					<td align="right" class="brrt2" style="width:120px;"> <?php echo number_format(($v->IGW_Z_VALUE),2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format((($v->IGW_Z_VALUE*(.15))),2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format(((($v->IGW_Z_VALUE*(.15)))+($v->IGW_Y_VALUE)),2);?></td>
				</tr>	
			 <?php 
			  $total_bl_billed_duration=$total_bl_billed_duration+$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
				$total_bl_x_value=$total_bl_x_value+$v->BL_TOTAL_X_VALUE;
				$total_bl_y_value=$total_bl_y_value+$v->BL_TOTAL_Y_VALUE;
				$total_bl_z_value=$total_bl_z_value+$v->BL_TOTAL_Z_VALUE;
				$total_bl_icx_value=$total_bl_icx_value+$v->BL_TOTAL_PERCENTAGE_OF_Z;
				$total_bl_igw_cost=$total_bl_igw_cost+($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE);
				$total_ios_billed_duration=$total_ios_billed_duration+$v->IGW_BILLED_DURATION_MIN;
				$total_ios_x_value=$total_ios_x_value+$v->IGW_X_VALUE;
				$total_ios_y_value=$total_ios_y_value+$v->IGW_Y_VALUE;
				$total_ios_z_value=$total_ios_z_value+$v->IGW_Z_VALUE;
				$total_ios_icx_value=$total_ios_icx_value+(($v->IGW_Z_VALUE*(.15)));
				$total_ios_igw_cost=$total_ios_igw_cost+((($v->IGW_Z_VALUE*(.15)))+($v->IGW_Y_VALUE));
			  } ?>
			 	<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;border-bottom:2px solid #cccccc;">Total</td>
					<td class="brt2" align="right" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_bl_billed_duration),2);?></td>
					<td class="brrt2" align="right" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_bl_x_value),2);?></td>
					<td class="brt2" align="right" style="width:100px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_y_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_z_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_icx_value),2);?></td>		
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_bl_igw_cost),2);?></td>								
					<td  style="width:100px;"></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;border-left:2px solid #cccccc;"> <?php echo number_format(($total_ios_billed_duration),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_x_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_y_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_z_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_icx_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_ios_igw_cost),2);?></td>
				</tr>	
			</table>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0"style="margin-top:20px">
				<?php echo $blanck_row; ?>
				<tr >
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td align="center" colspan="15">
						<div style="font-size:150%;color: coral;">Generate Difference & Percentage from BL_vs_IOS_reconciliation Report</div>
					</td>
				</tr>
				<tr style="height:20px"></tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;align:center;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">Difference between BL data & IOS data</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">%age of BL data & IOS data</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow;">ICX Operator Name</td>
					<td class="brt2" style="width:250px;background-color:yellow;">Billed Duration</td>
					<td class="brrt2" style="width:20px;background-color:yellow;">X in BDT</td>
					<td class="brt2" style="width:100px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>		
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>								
					<td class="rt2" style="width:100px;"></td>
					<td class="brrt2" style="width:120px;background-color:yellow;border-left:2px solid #cccccc;">Billed Duration</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">X in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or ICX Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">IGW COST</td>
				</tr>	
				<?php 
				$total_difference_billed_duration=0;
				$total_difference_x_value=0;
				$total_difference_y_value=0;
				$total_difference_z_value=0;
				$total_difference_icx_value=0;
				$total_difference_igw_cost=0;
				$total_age_billed_duration=0;
				$total_age_x_value=0;
				$total_age_y_value=0;
				$total_age_z_value=0;
				$total_age_icx_value=0;
				$total_age_igw_cost=0;
				foreach($get_record_for_bl_vs_ios_report as $k=>$v){
				  $diffrence_min=$v->IGW_BILLED_DURATION_MIN-$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
					$diffrence_x=$v->IGW_X_VALUE-$v->BL_TOTAL_X_VALUE;
					$diffrence_y=$v->IGW_Y_VALUE-$v->BL_TOTAL_Y_VALUE;
					$diffrence_z=$v->IGW_Z_VALUE-$v->BL_TOTAL_Z_VALUE;
					$diffrence_icx=(($v->IGW_Z_VALUE*(.15)))-$v->BL_TOTAL_PERCENTAGE_OF_Z;
					$diffrence_igw_cost=(($v->IGW_Z_VALUE*(.15)))-($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE);	
					$total_difference_billed_duration=$total_difference_billed_duration+$diffrence_min;
				  $total_difference_x_value=$total_difference_x_value+$diffrence_x;
				  $total_difference_y_value=$total_difference_y_value+$diffrence_y;
				  $total_difference_z_value=$total_difference_z_value+$diffrence_z;
				  $total_difference_icx_value=$total_difference_icx_value+$diffrence_icx;
				  $total_difference_igw_cost=$total_difference_igw_cost+$diffrence_igw_cost;
				}
				foreach($get_record_for_bl_vs_ios_report as $k=>$v){
					$diffrence_min=$v->IGW_BILLED_DURATION_MIN-$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
					$diffrence_x=$v->IGW_X_VALUE-$v->BL_TOTAL_X_VALUE;
					$diffrence_y=$v->IGW_Y_VALUE-$v->BL_TOTAL_Y_VALUE;
					$diffrence_z=$v->IGW_Z_VALUE-$v->BL_TOTAL_Z_VALUE;
					$diffrence_icx=(($v->IGW_Z_VALUE*(.15)))-$v->BL_TOTAL_PERCENTAGE_OF_Z;
					$diffrence_igw_cost=((($v->IGW_Z_VALUE*(.15)))+($v->IGW_Y_VALUE))-($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE);
				?>		
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->ICX;?></td>
					<td class="brt2" align="right" style="width:250px;"><?php echo number_format($diffrence_min,2);?></td>
					<td class="brrt2" align="right" style="width:250px;"><?php echo number_format($diffrence_x,2);?></td>
					<td class="brt2" align="right" style="width:100px;"> <?php echo number_format($diffrence_y,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($diffrence_z,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($diffrence_icx,2);?></td>		
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($diffrence_igw_cost,2);?></td>								
					<td  style="width:100px;"></td>
					<td class="brrt2" align="right" style="width:120px;border-left:2px solid #cccccc;"> <?php echo number_format((($diffrence_min/$v->BL_TOTAL_CHARGED_UNIT_IN_MIN)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format((($diffrence_x/$v->BL_TOTAL_X_VALUE)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format((($diffrence_y/$v->BL_TOTAL_Y_VALUE)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format((($diffrence_z/$v->BL_TOTAL_Z_VALUE)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format((($diffrence_icx/$v->BL_TOTAL_PERCENTAGE_OF_Z)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format((($diffrence_igw_cost/($v->BL_TOTAL_IGW_PORTION_FOR_INVOICE+$v->BL_TOTAL_Y_VALUE_FOR_INVOICE))*100),2);?>%</td>
				</tr>	
			 <?php 
				$total_age_billed_duration=($total_difference_billed_duration/$total_bl_billed_duration)*100;
				$total_age_x_value=($total_difference_x_value/$total_bl_x_value)*100;
				$total_age_y_value=($total_difference_y_value/$total_bl_y_value)*100;
				$total_age_z_value=($total_difference_z_value/$total_bl_z_value)*100;
				$total_age_icx_value=($total_difference_icx_value/$total_bl_icx_value)*100;
				$total_age_igw_cost=($total_difference_igw_cost/$total_bl_igw_cost)*100;
			  } ?>
			 	<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;border-bottom:2px solid #cccccc;">Total</td>
					<td class="brt2" align="right" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_difference_billed_duration),2);?></td>
					<td class="brrt2" align="right" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(($total_difference_x_value),2);?></td>
					<td class="brt2" align="right" style="width:100px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_y_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_z_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_icx_value),2);?></td>		
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_difference_igw_cost),2);?></td>								
					<td  style="width:100px;"></td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;border-left:2px solid #cccccc;"> <?php echo number_format(($total_age_billed_duration),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_x_value),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_y_value),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_z_value),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_icx_value),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(($total_age_igw_cost),2);?>%</td>
				</tr>	
			</table>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0"style="margin-top:20px">
				<?php echo $blanck_row; ?>
				<tr >
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td colspan="5" style="font-size:150%;color: coral;margin-left:300px">
						IGW Summery Data from BL_vs_IOS_reconciliation Report
					</td>
				</tr>
				<tr style="height:20px"></tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=6 style="width:30px;align:center;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">IGW Summery Data</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow;">IOS OPERATOR NAME</td>
					<td class="brt2" style="width:250px;background-color:yellow;">Billed Duration</td>
					<td class="brrt2" style="width:20px;background-color:yellow;">X in BDT</td>
					<td class="brt2" style="width:100px;background-color:yellow;">Y in BDT</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">Z Value</td>
					<td class="brrt2" style="width:120px;background-color:yellow;">15% Of Z or IOS Value</td>		
					<td class="brrt2" style="width:120px;background-color:yellow;">Y+15%Z</td>								
				</tr>	
				<?php 
				$total_igw_min_data=0;
				$total_igw_x_data=0;
				$total_igw_y_data=0;
				$total_igw_z_data=0;
				$total_igw_age_y_data=0;
				$total_invoice_data=0;
				foreach($igw_get_record_for_bl_vs_ios_report as $k=>$v){
				?>		
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->IGW;?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($v->TOTAL_BILLED_DURATION_MINS,2);?></td>	
					<td class="brt2" align="right" style="width:250px;"><?php echo number_format($v->TOTAL_IGW_X_VALUE,2);?></td>
					<td class="brrt2" align="right" style="width:250px;"><?php echo number_format($v->TOTAL_IGW_Y_VALUE,2);?></td>
					<td class="brt2" align="right" style="width:100px;"> <?php echo number_format($v->TOTAL_IGW_Z_VALUE,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($v->TOTAL_INVOICE_VALUE_OF_Z,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($v->TOTAL_INVOICE_AMOUNT,2);?></td>		
				</tr>	
			 <?php  
			 	$total_igw_min_data=$total_igw_min_data+$v->TOTAL_BILLED_DURATION_MINS;
				$total_igw_x_data=$total_igw_x_data+$v->TOTAL_IGW_X_VALUE;
				$total_igw_y_data=$total_igw_y_data+$v->TOTAL_IGW_Y_VALUE;
				$total_igw_z_data=$total_igw_z_data+$v->TOTAL_IGW_Z_VALUE;
				$total_igw_age_y_data=$total_igw_age_y_data+$v->TOTAL_INVOICE_VALUE_OF_Z;
				$total_invoice_data=$total_invoice_data+$v->TOTAL_INVOICE_AMOUNT;
			  } ?>
			 	<tr>
			 		<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Total</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($total_igw_min_data,2);?></td>	
					<td class="brt2"  align="right" style="width:250px;"><?php echo number_format($total_igw_x_data,2);?></td>
					<td class="brrt2" align="right" style="width:250px;"><?php echo number_format($total_igw_y_data,2);?></td>
					<td class="brt2" align="right" style="width:100px;"> <?php echo number_format($total_igw_z_data,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($total_igw_age_y_data,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($total_invoice_data,2);?></td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">&nbsp;</td>
					<td class="brrt2" style="width:120px;">&nbsp;</td>	
					<td class="brt2" style="width:250px;">&nbsp;</td>
					<td class="brrt2" style="width:250px;">&nbsp;</td>
					<td class="brt2" style="width:100px;">&nbsp;</td>
					<td class="brrt2" style="width:120px;">&nbsp;</td>
					<td class="brrt2" style="width:120px;">&nbsp;</td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">BL IT Report</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($total_bl_billed_duration,2);?></td>	
					<td class="brt2" align="right" style="width:250px;"><?php echo number_format($total_bl_x_value,2);?></td>
					<td class="brrt2" align="right" style="width:250px;"><?php echo number_format($total_bl_y_value,2);?></td>
					<td class="brt2" align="right" style="width:100px;"> <?php echo number_format($total_bl_z_value,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($total_bl_icx_value,2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format($total_bl_igw_cost,2);?></td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Difference between IGW & BL data</td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format(($total_igw_min_data-$total_bl_billed_duration),2);?></td>	
					<td class="brt2" align="right" style="width:250px;"><?php echo number_format(($total_igw_x_data-$total_bl_x_value),2);?></td>
					<td class="brrt2" align="right" style="width:250px;"><?php echo number_format(($total_igw_y_data-$total_bl_y_value),2);?></td>
					<td class="brt2" align="right" style="width:100px;"> <?php echo number_format(($total_igw_z_data-$total_bl_z_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format(($total_igw_age_y_data-$total_bl_icx_value),2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format(($total_invoice_data-$total_bl_igw_cost),2);?></td>		
				</tr>	
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;border-bottom:2px solid #cccccc;">%Age of IGW & BL data</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_igw_min_data-$total_bl_billed_duration)/$total_bl_billed_duration)*100),2);?>%</td>	
					<td class="brt2" align="right" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(((($total_igw_x_data-$total_bl_x_value)/$total_bl_x_value)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:250px;border-bottom:2px solid #cccccc;"><?php echo number_format(((($total_igw_y_data-$total_bl_y_value)/$total_bl_y_value)*100),2);?>%</td>
					<td class="brt2" align="right" style="width:100px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_igw_z_data-$total_bl_z_value)/$total_bl_z_value)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_igw_age_y_data-$total_bl_icx_value)/$total_bl_icx_value)*100),2);?>%</td>
					<td class="brrt2" align="right" style="width:120px;border-bottom:2px solid #cccccc;"> <?php echo number_format(((($total_invoice_data-$total_bl_igw_cost)/$total_bl_igw_cost)*100),2);?>%</td>		
				</tr>	
				<tr>	
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>	
				<tr>	
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>	
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
			</table>
			
			
		</div>
		<?php }?>
		<?php if($single_ios_sort_summery=='yes'){$report_name="Single IOS Sort Summery";$total_column=5;?>
		<div id="printArea" style="margin-top:30px">
			<div>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<?php if($action_type=='Email'){ ?>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td></td>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<?php if($action_type=='Email'){ ?>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				<?php } ?>
				  <td></td>
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<?php if($action_type=='Email'){ ?>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td></td>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0" style="margin-left:410px;">
				<?php echo $blanck_row; ?>
				<?php 
				$total_bl_dispute=0;
				$total_igw_invoice=0;
				$total_icx_data=0;
				$total_diff_igw_icx=0;
				$total_age=0;
				$total_icx_call_ratio=0;
				$total_diff=0;
				$total_BL_VS_IOS_DISPUTE=0;
				$total_amount_considered=0;
				foreach($get_record_for_single_ios_short_summery as $k=>$v){
					$icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=(($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=(($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=($bl_y_value + $z_of_15);
					$bl_dispute=((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100);
					$total_bl_dispute=$total_bl_dispute+$bl_dispute;
					//dd($bl_amount);
				}
				foreach($get_record_for_single_ios_short_summery as $k=>$v){
					$diffrence_between_bl_icx_invoice_value_of_z=$v->ICX_INVOICE_VALUE_OF_Z-$v->BL_TOTAL_ICX_PORTION;
					$BL_vs_ICX_dispute=(($diffrence_between_bl_icx_invoice_value_of_z/$v->BL_TOTAL_ICX_PORTION)*100);
				  $bl_total_invoice_amount=$v->BL_TOTAL_Y_VALUE+$v->BL_TOTAL_IGW_PORTION;
				  $icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=(($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=(($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=($bl_y_value + $z_of_15);
				  $bl_dispute=((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100);
				?>
			 <?php
			   $total_igw_invoice=($total_igw_invoice+$v->IGW_INVOICE_AMOUNT);
				 $total_icx_data=($total_icx_data+$v->ICX_INVOICE_AMOUNT);
				 $total_diff_igw_icx=($total_diff_igw_icx+($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT));
				// $total_age= round(($total_age+((($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT)/$v->ICX_INVOICE_AMOUNT)*100)),2);
				 $total_icx_call_ratio=$total_icx_call_ratio+$bl_amount;
				 $total_diff=($total_diff+(($v->IGW_INVOICE_AMOUNT)-$bl_amount));
				 $total_BL_VS_IOS_DISPUTE= $total_BL_VS_IOS_DISPUTE+$bl_dispute;
				 if($total_bl_dispute > 1){$amount=$bl_amount;}else{$amount= $v->IGW_INVOICE_AMOUNT;}
				 $total_amount_considered=$total_amount_considered+$amount; 
			 
			  }?>
			  <tr>
			  	<?php if($action_type=='Email'){ ?>
			  	<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;">Bill Month</td>
					<td class="brt2" style="width:60px; border-bottom:1px solid #cccccc;">Invoice Data</td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;">BL/ICX DATA</td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;">Dispute</td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;">%age of BL & ICX Data</td>
				</tr>
			 	<tr>
			 		<?php if($action_type=='Email'){ ?>
			 		<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;"><?php echo $date;?></td>
					<td class="brt2" align="right" style="width:60px; border-bottom:1px solid #cccccc;"><?php echo number_format($total_igw_invoice,2); ?></td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format($total_icx_call_ratio,2); ?></td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format(($total_igw_invoice-$total_icx_call_ratio),2); ?></td>
					<td class="brt2" align="right"  style="width:110px; border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;"><?php echo number_format(((($total_igw_invoice-$total_icx_call_ratio)/$total_icx_call_ratio)*100),2); ?>%</td>
				</tr>
				<tr>
					<?php if($action_type=='Email'){ ?>
					<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;">12% AIT</td>
					<td class="brt2" align="right" style="width:60px; border-bottom:1px solid #cccccc;">(<?php echo number_format((($total_igw_invoice*(.12))),2); ?>)</td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;">(<?php echo number_format((($total_icx_call_ratio*(.12))),2); ?>)</td>
					<td class="brt2"  style="width:110px; border-bottom:1px solid #cccccc;"></td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;"></td>
				</tr>
				<tr>
					<?php if($action_type=='Email'){ ?>
					<td></td>
					<td></td>
					<td></td>
					<?php } ?>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;">AFTER AIT</td>
					<td class="brt2" align="right" style="width:60px; border-bottom:1px solid #cccccc;"><?php echo number_format(($total_igw_invoice-(($total_igw_invoice*(.12)))),2); ?></td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format(($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))),2); ?></td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format(($total_igw_invoice-(($total_igw_invoice*(.12))))-($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))),2); ?></td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;"><?php echo number_format((((($total_igw_invoice-(($total_igw_invoice*(.12))))-($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))))/($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))))*100),2); ?>%</td>
				</tr>
				<?php if($action_type=='Email'){ ?>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
		    <?php } ?>
			</table>
		</div>
		<?php }?>
		<?php if($single_ios_detail_summery=='yes'){$report_name="Single IOS Detail Summery";$total_column=13;?>
		<div id="printArea" style="margin-top:30px">
			<div style="">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=2 style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">Difference & Percentage between IGW & ICX</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=3 style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">BL CALCULATION</td>
					<td class="brlt2" colspan=2 style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">PAYMENT</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow;">Route Through ICX</td>
					<td class="brt2" style="width:80px;background-color:yellow;"> IGW Invoice</td>
					<td class="brt2" style="width:60px;background-color:yellow;"> ICX Data</td>
					<td class="brt2" style="width:100px;background-color:yellow;">Difference Between IGW & ICX Invoice</td>
					<td class="brt2" style="width:120px;background-color:yellow;"> %age of IGW & ICX Invoice</td>
					<td class="brrt2" style="width:250px;background-color:yellow;"> ICX Data received</td>
					<td class="brt2" style="width:60px;background-color:yellow;"> BL vs ICX dispute</td>
					<td class="brt2" style="width:60px;background-color:yellow;"> BL AMOUNT with ICX call ratio</td>
					<td class="brt2" style="width:110px;background-color:yellow;">Difference between IGW & BL Data</td>
					<td class="brt2" style="width:110px;background-color:yellow;"> BL VS IOS DISPUTE</td>
					<td class="brt2" style="width:700px;background-color:yellow;"> Amount considered</td>
					<td class="brt2" style="width:70px;background-color:yellow;"> Data considered</td>
				</tr>
				<?php 
				$total_bl_dispute=0;
				$total_igw_invoice=0;
				$total_icx_data=0;
				$total_diff_igw_icx=0;
				$total_age=0;
				$total_icx_call_ratio=0;
				$total_diff=0;
				$total_BL_VS_IOS_DISPUTE=0;
				$total_amount_considered=0;
				foreach($get_record_for_single_ios_detail_summery as $k=>$v){
					$icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=(($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=(($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=($bl_y_value + $z_of_15);
					$bl_dispute=((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100);
					$total_bl_dispute=$total_bl_dispute+$bl_dispute;
					//dd($bl_amount);
				}
				foreach($get_record_for_single_ios_detail_summery as $k=>$v){
					$diffrence_between_bl_icx_invoice_value_of_z=$v->ICX_INVOICE_VALUE_OF_Z-$v->BL_TOTAL_ICX_PORTION;
					$BL_vs_ICX_dispute=(($diffrence_between_bl_icx_invoice_value_of_z/$v->BL_TOTAL_ICX_PORTION)*100);
				  $bl_total_invoice_amount=$v->BL_TOTAL_Y_VALUE+$v->BL_TOTAL_IGW_PORTION;
				  $icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=(($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=(($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=($bl_y_value + $z_of_15);
				  $bl_dispute=((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100);
				?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->IGW_ICX;?></td>
					<td class="brt2" align="right" style="width:250px;"><?php echo number_format($v->IGW_INVOICE_AMOUNT,2);?></td>
					<td class="brrt2" align="right" style="width:250px;"><?php echo number_format($v->ICX_INVOICE_AMOUNT,2);?></td>
					<td class="brt2" align="right" style="width:100px;"> <?php echo number_format(($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT),2);?></td>
					<td class="brrt2" align="right" style="width:120px;"> <?php echo number_format(((($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT)/$v->ICX_INVOICE_AMOUNT)*100),2);?>%</td>
					<td class="brt2" style="width:250px;"><?php if($v->ICX_TOTAL_Y_VALUE > 0){echo 'YES';}else{echo "NO";}?></td>
					<td class="brrt2" align="right" style="width:60px;"> <?php echo number_format($BL_vs_ICX_dispute,2);?>%</td>
					<td class="brt2" align="right" style="width:60px;"><?php echo number_format($bl_amount,2);?></td>
					<td class="brt2" align="right" style="width:110px;"><?php echo number_format((($v->IGW_INVOICE_AMOUNT)-$bl_amount),2);?></td>
					<td class="brt2" align="right" style="width:110px;"> <?php echo number_format($bl_dispute,2);?>%</td>
					<td class="brt2" align="right" style="width:700px;"><?php if($total_bl_dispute > 1){echo number_format($bl_amount,2);}else{echo number_format($v->IGW_INVOICE_AMOUNT,2);}?></td>
					<td class="brrt2" style="width:70px;"> <?php if($total_bl_dispute > 1){echo "BL DATA";}else{echo "IGW DATA";}?></td>
				</tr>	
			 <?php
			   $total_igw_invoice=($total_igw_invoice+$v->IGW_INVOICE_AMOUNT);
				 $total_icx_data=($total_icx_data+$v->ICX_INVOICE_AMOUNT);
				 $total_diff_igw_icx=($total_diff_igw_icx+($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT));
				 $total_icx_call_ratio=$total_icx_call_ratio+$bl_amount;
				 $total_diff=($total_diff+(($v->IGW_INVOICE_AMOUNT)-$bl_amount));
				 $total_BL_VS_IOS_DISPUTE= $total_BL_VS_IOS_DISPUTE+$bl_dispute;
				 if($total_bl_dispute > 1){$amount=$bl_amount;}else{$amount= $v->IGW_INVOICE_AMOUNT;}
				 $total_amount_considered=$total_amount_considered+$amount;
			 
			  }?>
			 	<tr>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;"> Total </td>
					<td class="brt2" align="right" style="width:60px; border-bottom:1px solid #cccccc;"><?php echo number_format($total_igw_invoice,2); ?></td>
					<td class="brrt2" align="right" style="width:100px; border-bottom:1px solid #cccccc;"><?php echo number_format($total_icx_data,2); ?></td>
					<td class="brt2" align="right" style="width:120px; border-bottom:1px solid #cccccc;"><?php echo number_format($total_diff_igw_icx,2); ?></td>
					<td class="brrt2" align="right" style="width:250px; border-bottom:1px solid #cccccc;"><?php echo number_format((($total_diff_igw_icx/$total_icx_data)*100),2); ?>%</td>
					<td class="brt2" style="width:60px; border-bottom:1px solid #cccccc;"></td>
					<td class="brrt2" style="width:60px; border-bottom:1px solid #cccccc;"></td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format($total_icx_call_ratio,2); ?></td>
					<td class="brt2" align="right" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format($total_diff,2); ?></td>
					<td class="brt2" align="right" style="width:700px; border-bottom:1px solid #cccccc;"><?php echo number_format((($total_diff/$total_icx_call_ratio)*100),2); ?>%</td>
					<td class="brt2" align="right" style="width:70px; border-bottom:1px solid #cccccc;"><?php echo  number_format($total_amount_considered,2); ?></td>
					<td class="brrt2" style="width:60px; border-bottom:1px solid #cccccc;"></td>
				</tr>
			</table>
		</div>
		<?php }?>
	</body>
</html>




































