<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>title</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }
		</style>
  </head>
  <body>
		<div id="printArea">
			<?php $global_cut_of=$get_record[0]->MAX_DAY;?>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<?php

			############# Vat exclution method ####################################
			$config = $this->ft->get('config');
			$config = $config->{'0'};
			$vat = $config->vat;
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Balance Type</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><strong>Actual</strong></td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Database</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7"><strong>BLERPPRD03.BANGLALINKGSM.COM.PROD</strong></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Set of Books</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7"><strong>Banglalink Set of Books</strong></td>
				</tr>
				<?php echo $blanck_row; ?>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Category</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right">* List - Text</td>
					<td class="brlt2"  colspan="2" ><strong>BL_GL_Revenue</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Sourch</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right">* List - Text</td>
					<td class="brlt2"  colspan="2" ><strong>Spreadsheet</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Currency</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right">* List - Text</td>
					<td class="brlt2"  colspan="2" ><strong>BDT</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Accounting Date</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right">* List - Text</td>
					<td class="brlt2"  colspan="2" ><strong><?php echo $current_date;?></strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2"><strong>Journal Name</strong></td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2"><strong>Interconnection Expenses Payable to Interconnect Operators for <?php echo $date.' (1-'.$global_cut_of.')';?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2">Journal Description</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2"><strong>Interconnection Expenses Payable to Interconnect Operators for <?php echo $date.' (1-'.$global_cut_of.')';?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2">Journal Reference</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2"><strong>Interconnection Expenses Payable to Interconnect Operators for <?php echo $date.' (1-'.$global_cut_of.')';?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?> 
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Upl</td>
					<td class="brt2" style="width:80px;">COMPANY</td>
					<td class="brt2" style="width:60px;">BRANCH</td>
					<td class="brt2" style="width:100px;">COST CENTER</td>
					<td class="brt2" style="width:120px;">NATURAL ACOUNT</td>
					<td class="brt2" style="width:70px;">ANLYTICAL</td>
					<td class="brt2" style="width:60px;">PROJECT</td>
					<td class="brt2" style="width:60px;">FUTURE</td>
					<td class="brt2" style="width:110px;">Debit</td>
					<td class="brt2" style="width:110px;">Credit</td>
					<td class="brt2" style="width:700px;">Line Description</td>
					<td class="brt2" style="width:70px;"></td>
					<td class="brrt2" style="width:110px;">Messages</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brlb2">&nbsp;</td>
					<td class="brb2" colspan="7">* List - Text</td>
					<td class="brb2">* Number</td>
					<td class="brb2">* Number</td>
					<td class="brb2">Text</td>
					<td class="brrb2">&nbsp;</td>
					<td class="brrb2">&nbsp;</td>
				</tr>
				<?php $total_debit=0; $total_credit=0; ?> 
				<?php foreach($get_record as $k=>$v): ?>
				<?php 
	
				$id=$this->customcache->operator_maker($v->OPERATOR,'ID');
				$operator_name=$this->customcache->operator_maker($v->OPERATOR,'OPERATOR_NAME');
				$project_code=$this->customcache->operator_maker($v->OPERATOR,'PROJECT_CODE');
				$project_type=$this->customcache->operator_maker($v->OPERATOR,'OPERATOR_TYPE');
			  $sql = "SELECT * FROM tbl_gl_mapping WHERE OPERATOR_NAME = '$id'"; 
			  $operator_info= $this->db->query($sql)->result();
			  #dd($operator_info);
		    ?>
				<?php  
					$post_paid = $v->POST_VALUE;
					$pre_paid = $v->PREP_VALUE;
					$post_paid_provisioning = round($post_paid + (($post_paid/$v->MAX_DAY) * ($v->LAST_DAY - $v->MAX_DAY)),2);
					$pre_paid_provisioning = round($pre_paid + (($pre_paid/$v->MAX_DAY) * ($v->LAST_DAY - $v->MAX_DAY)),2);
					if( $report_type == 'provisioning' ){  
						$post_paid = $post_paid_provisioning;
						$pre_paid = $pre_paid_provisioning;
					}
					$operator = $this->ft->search("name_alternative", null, $v->OPERATOR);
						if(!isset($operator[0])){
							$v->OPERATOR = $v->OPERATOR;
						}else{
							$v->OPERATOR = $operator[0]->cName;
						}
					?>
				<?php if($call_type == "revenue"):?>
	
		     <?php if($post_paid > 0 && $pre_paid==''):?>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td>A000&nbsp;</td>
					<td><?php foreach($operator_info as $a_operator_info){if($a_operator_info->GL_TYPE=='Postpaid'){echo $a_operator_info->GL_CODE;}};?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td><?php echo $project_code;?>&nbsp;</td>
					<td>0000&nbsp;</td>
				  <td style="text-align:right;"></td>
					<td style="text-align:right;">
						<?php
						$vat_amount = ($post_paid * $vat) / 100;
						$credit= number_format(($post_paid - $vat_amount) ,2); 
						echo $credit;
						?>
					</td>
					 <td><?php echo  $operator_name.','.$project_type.','.$date.' ACCRUAL,MMS,Interconnection MMS '.$v->PREPOST_FLAG. ' Expense (1-'.$v->MAX_DAY.' Cut off)';?></td>
					<td>&#x263A;</td>
					<td>&nbsp;</td>
				</tr>
			<?php endif; ?>
			<?php if($pre_paid > 0 && $post_paid==''):?>	
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td>A000&nbsp;</td>
					<td><?php foreach($operator_info as $a_operator_info){if($a_operator_info->GL_TYPE=='Prepaid'){echo $a_operator_info->GL_CODE;}};?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td><?php echo $project_code;?>&nbsp;</td>
					<td>0000&nbsp;</td>
				  <td style="text-align:right;"></td>
					<td style="text-align:right;">
						<?php
						$vat_amount = ($pre_paid * $vat) / 100;
						$credit= number_format(($pre_paid - $vat_amount) ,2);
						echo $credit;
						?>
					</td>
					<td><?php echo  $operator_name.','.$project_type.','.$date.' ACCRUAL,MMS,Interconnection MMS '.$v->PREPOST_FLAG. ' Expense (1-'.$v->MAX_DAY.' Cut off)';?></td>
					<td>&#x263A;</td>
					<td>&nbsp;</td>
				</tr>
			<?php endif; ?>
			<?php if($pre_paid && $post_paid):?>		
			 <tr>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>01&nbsp;</td>
			 	<td>101&nbsp;</td>
			 	<td>A000&nbsp;</td>
			 	<td><?php foreach($operator_info as $a_operator_info){if($a_operator_info->GL_TYPE =='Accrued'){echo $a_operator_info->GL_CODE;}};?>&nbsp;</td>
			 	<td>0000&nbsp;</td>
			 	<td><?php echo $project_code;?>&nbsp;</td>
			 	<td>0000&nbsp;</td>
			 	<td style="text-align:right;"></td>
			 	<td style="text-align:right;">
			 		<?php $credit= number_format(((($pre_paid + $post_paid) * $config->vat)/100) ,2); echo $credit; ?>
			 	</td>
			 	<td><?php echo  $operator_name.','.$project_type.','.$date.' ACCRUAL,MMS,Interconnection MMS '.$v->PREPOST_FLAG. ' Expense (1-'.$v->MAX_DAY.' Cut off)';?></td>
			 	<td>&#x263A;</td>
			 	<td>&nbsp;</td>
			 </tr>
			<?php endif; ?>
		<?php endif; ?>	<!--end revenue -->
    <?php if($call_type == "cost"):?>
			 <?php if($post_paid > 0 && $pre_paid==''):?>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td>A000&nbsp;</td>
					<td><?php foreach($operator_info as $a_operator_info){if($a_operator_info->GL_TYPE=='Postpaid'){echo $a_operator_info->GL_CODE;}};?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td><?php echo $project_code;?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td style="text-align:right;"><?php $debit= number_format($post_paid ,2); echo $debit; ?></td>
					<td></td>
					<td><?php echo  $operator_name.','.$project_type.','.$date.' ACCRUAL,MMS,Interconnection MMS '.$v->PREPOST_FLAG. ' Expense (1-'.$v->MAX_DAY.' Cut off)';?></td>
					<td>&#x263A;</td>
					<td>&nbsp;</td>
				</tr>
			<?php endif; ?>
		  <?php if($pre_paid > 0 && $post_paid==''):?>	
        <tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td>A000&nbsp;</td>
					<td><?php foreach($operator_info as $a_operator_info){if($a_operator_info->GL_TYPE=='Prepaid'){echo $a_operator_info->GL_CODE;}};?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td><?php echo $project_code;?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td style="text-align:right;"><?php $debit= number_format($pre_paid ,2); echo $debit;?></td>
					<td style="text-align:right;"></td>
					<td><?php echo  $operator_name.','.$project_type.','.$date.' ACCRUAL,MMS,Interconnection MMS '.$v->PREPOST_FLAG. ' Expense (1-'.$v->MAX_DAY.' Cut off)';?></td>
					<td>&#x263A;</td>
					<td>&nbsp;</td>
				</tr>
			<?php endif; ?>
				<?php if($pre_paid && $post_paid):?>		
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td>A000&nbsp;</td>
				  <td><?php foreach($operator_info as $a_operator_info){if($a_operator_info->GL_TYPE =='Accrued'){echo $a_operator_info->GL_CODE;}};?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td><?php echo $project_code;?>&nbsp;</td>
					<td>0000&nbsp;</td>
					<td style="text-align:right;"></td>
					<td style="text-align:right;"><?php $debit= number_format(($post_paid + $pre_paid),2); echo  $debit;?></td>
					<td><?php echo  $operator_name.','.$project_type.','.$date.' ACCRUAL,MMS,Interconnection MMS '.$v->PREPOST_FLAG. ' Expense (1-'.$v->MAX_DAY.' Cut off)';?></td>
					<td>&#x263A;</td>
					<td>&nbsp;</td>
				</tr>
			<?php endif; ?>	
		<?php endif; ?><!--end revenue -->
  
  
   <?php    
   if(isset($credit)){
   	$credit_value = str_replace(',', '', $credit);
    $total_credit=$total_credit+$credit_value;
   	}
   if(isset($debit)){
     $debit_value = str_replace(',', '', $debit); 
     $total_debit=$total_debit+$debit_value;
   	}

   ?>

	<?php endforeach; ?>
				<tr>
					<td>&nbsp;</td>
					<td>Totals:</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><?php if($total_debit==0){echo '';}else{echo $total_debit; }?></td>
					<td><?php if($total_credit==0){echo '';}else{echo $total_credit;}?></td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>			
				<tr>
					<td>&nbsp;</td>
					<td>Tip: This is not the end of the Template.  Unprotect the sheet and insert as many rows as needed.</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
			</table>
		</div>
	</body>
</html>

