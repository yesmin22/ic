
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 9 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Provision Report for IOS";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Duration</th>
						<th>Rate Per Min</th>
						<th>Termin Charge USD</th>
						<th>USD Rate</th>
						<th>Termin Charge BDT</th>
						<th>BL Revenue(22.5%)</th>
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$total_duration = 0;
					$termin_charge_usd = 0;
					$termin_charge_bdt = 0;
					$gtc=0;
					$gtm=0;
					$tcu=0;
					$tcb=0;
					$tcbl=0;
					$bl_revenue=0;
					foreach($get_record as $k=>$v): 
					
					
					?>
					<tr>
						<td><?php echo $v->IOS; ?></td> 
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td align="right"><?php echo number_format($v->NUMBER_OF_CALLS,2); $total_no_calls += $v->NUMBER_OF_CALLS; $gtc += $v->NUMBER_OF_CALLS;?></td>
						<td align="right"><?php echo number_format($v->DURATION_MIN,2); $total_duration += $v->DURATION_MIN; $gtm += $v->DURATION_MIN;?></td>
						<td align="right"><?php echo number_format($v->RATE_PER_MINUTES,2); ?></td>
						<td align="right"><?php echo number_format(($v->DURATION_MIN*$v->RATE_PER_MINUTES),2); $termin_charge_usd += $v->DURATION_MIN*$v->RATE_PER_MINUTES; $tcu += $v->DURATION_MIN*$v->RATE_PER_MINUTES;?></td>
						<td align="right"><?php echo number_format($v->USD_RATE,2); ?></td>
						<td align="right"><?php echo number_format((($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE),2); $termin_charge_bdt += (($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE); $tcb += (($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE);?></td>
						<td align="right"><?php echo number_format((((($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE)*22.5)/100),2); $bl_revenue += (((($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE)*22.5)/100); $tcbl += (((($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE)*22.5)/100);?></td>
					</tr>
					
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->IOS != $get_record[$k + 1]->IOS){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $total_duration = 0; ?></td>
						<td align="right"></td> 
						<td align="right"><?php echo number_format($termin_charge_usd,2); $termin_charge_usd = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($termin_charge_bdt,2); $termin_charge_bdt = 0; ?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $bl_revenue = 0; ?></td>
						
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				 <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $total_duration = 0; ?></td>
						<td align="right"></td> 
						<td align="right"><?php echo number_format($termin_charge_usd,2); $termin_charge_usd = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($termin_charge_bdt,2); $termin_charge_bdt = 0; ?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $bl_revenue = 0; ?></td>
					</tr>
				    <?php }?>
					
					
					<?php endforeach; ?>
					
					
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtc,2); ?></td>
						<td align="right"><?php echo number_format($gtm,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($tcu,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($tcb,2); ?></td>
						<td align="right"><?php echo number_format($tcbl,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;">Interconnection Provision Report for IOS Extrapuleted</div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Duration</th>
						<th>Rate Per Min</th>
						<th>Termin Charge USD</th>
						<th>USD Rate</th>
						<th>Termin Charge BDT</th>
						<th>BL Revenue(22.5%)</th>
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$total_duration = 0;
					$total_termin_charge_usd = 0;
					$total_termin_charge_bdt = 0;
					$gtc=0;
					$gtm=0;
					$tcu=0;
					$tcb=0;
					$tcbl=0;
					$total_bl_revenue=0;
					
					foreach($get_record as $k=>$v): 
					$number_of_call=($v->NUMBER_OF_CALLS/$v->MAX_DAY)*$v->LAST_DAY;
					$duration_in_min=($v->DURATION_MIN/$v->MAX_DAY)*$v->LAST_DAY;
					$termin_charge_usd=(($v->DURATION_MIN*$v->RATE_PER_MINUTES)/$v->MAX_DAY)*$v->LAST_DAY;
					$termin_charge_bdt=((($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE)/$v->MAX_DAY)*$v->LAST_DAY;
					$bl_revenue=((((($v->DURATION_MIN*$v->RATE_PER_MINUTES)*$v->USD_RATE)*22.5)/100)/$v->MAX_DAY)*$v->LAST_DAY;
					?>
					<tr>
						<td><?php echo $v->IOS; ?></td> 
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td align="right"><?php echo number_format($number_of_call,2); $total_no_calls += $number_of_call; $gtc += $number_of_call;?></td>
						<td align="right"><?php echo number_format($duration_in_min,2); $total_duration += $duration_in_min; $gtm += $duration_in_min;?></td>
						<td align="right"><?php echo number_format($v->RATE_PER_MINUTES,2); ?></td>
						<td align="right"><?php echo number_format($termin_charge_usd,2); $total_termin_charge_usd += $termin_charge_usd; $tcu += $termin_charge_usd;?></td>
						<td align="right"><?php echo number_format($v->USD_RATE,2); ?></td>
						<td align="right"><?php echo number_format($termin_charge_bdt,2); $total_termin_charge_bdt += $termin_charge_bdt; $tcb += $termin_charge_bdt;?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $total_bl_revenue += $bl_revenue; $tcbl += $bl_revenue;?></td>
					</tr>
					
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->IOS != $get_record[$k + 1]->IOS){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $total_duration = 0; ?></td>
						<td align="right"></td> 
						<td align="right"><?php echo number_format($termin_charge_usd,2); $termin_charge_usd = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($termin_charge_bdt,2); $termin_charge_bdt = 0; ?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $bl_revenue = 0; ?></td>
						
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				 <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $total_duration = 0; ?></td>
						<td align="right"></td> 
						<td align="right"><?php echo number_format($termin_charge_usd,2); $termin_charge_usd = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($termin_charge_bdt,2); $termin_charge_bdt = 0; ?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $bl_revenue = 0; ?></td>
					</tr>
				    <?php }?>
					
					
					<?php endforeach; ?>
					
					
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtc,2); ?></td>
						<td align="right"><?php echo number_format($gtm,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($tcu,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($tcb,2); ?></td>
						<td align="right"><?php echo number_format($tcbl,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>
	</body>
</html>