
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 14 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Provision Report for MOID";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>ACT_DURATION</th>
						<th>DURATION</th>
						<th>AMOUNT</th>
						<th>Y_VALUE</th>
						<th>Z_VALUE</th>
						<th>BL_REVENUE</th>
						<th>IGW_PORTION</th>
						<th>ICX_PORTION</th>
						<th>BTRC_PORTION</th>
						<th>IGW_Cost</th>
						<th>Total Cost</th>
					
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$gtnc=0;
					$total_air_unit = 0;
					$gtau = 0;
					$total_charged_unit=0;
					$gtcu=0;
					$total_amount=0;
					$gta=0;
					$total_y_value=0;
					$gtyv=0;
					$total_z_value = 0;
					$gtzv=0;
					$total_bl_revenue = 0;
					$gtbr = 0;
					$total_igw_portion=0;
					$gtigp=0;
					$total_icx_portion=0;
					$gticp=0;
					$total_btrc_portion=0;
					$gtbtp=0;
					$total_igw_cost=0;
					$gtigc=0;
					$total_cost_total=0;
					$gttct=0;
					foreach($get_record as $k=>$v): 
					$number_of_calls=$v->NUMBER_OF_CALLS;
					$air_unit=$v->AIR_UNIT;
					$charged_unit=$v->CHARGED_UNITS;
					$amount=$v->AMOUNT;
					$y_value=$v->Y_VALUE;
					$z_value=$v->Z_VALUE;
					$bl_revenue=$v->BL_REVENUE;
					$igw_portion=$v->IGW_PORTION;
					$icx_portion=$v->ICX_PORTION;
					$btrc_portion=$v->BTRC_PORTION;
					$igw_cost=$v->IGW_PORTION + $v->Y_VALUE;
					$total_cost= $icx_portion + $btrc_portion + $igw_cost;
					?>
					<tr>
						<td><?php echo $v->OPERATOR; ?></td> 
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td align="right"><?php echo number_format($number_of_calls,2); $total_no_calls += $number_of_calls; $gtnc += $number_of_calls;?></td>
						<td align="right"><?php echo number_format($air_unit,2); $total_air_unit += $air_unit; $gtau += $air_unit;?></td>
						<td align="right"><?php echo number_format($charged_unit,2); $total_charged_unit += $charged_unit; $gtcu += $charged_unit;?></td>
						<td align="right"><?php echo number_format($amount,2); $total_amount += $amount; $gta += $amount;?></td>
						<td align="right"><?php echo number_format($y_value,2); $total_y_value += $y_value; $gtyv += $y_value;?></td>
						<td align="right"><?php echo number_format($z_value,2); $total_z_value += $z_value; $gtzv += $z_value;?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $total_bl_revenue += $bl_revenue; $gtbr += $bl_revenue;?></td>
						<td align="right"><?php echo number_format($igw_portion,2); $total_igw_portion += $igw_portion; $gtigp += $igw_portion;?></td>
						<td align="right"><?php echo number_format($icx_portion,2); $total_icx_portion += $icx_portion; $gticp += $icx_portion;?></td>
						<td align="right"><?php echo number_format($btrc_portion,2); $total_btrc_portion += $btrc_portion; $gtbtp += $btrc_portion;?></td>
						<td align="right"><?php echo number_format($igw_cost,2); $total_igw_cost += $igw_cost; $gtigc += $igw_cost;?></td>
						<td align="right"><?php echo number_format($total_cost,2); $total_cost_total += $total_cost; $gttct += $total_cost;?></td>
					</tr>
					
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->OPERATOR != $get_record[$k + 1]->OPERATOR){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_air_unit,2); $total_air_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_charged_unit,2); $total_charged_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount,2); $total_amount = 0; ?></td>
						<td align="right"><?php echo number_format($total_y_value,2); $total_y_value = 0; ?></td>
						<td align="right"><?php echo number_format($total_z_value,2); $total_z_value = 0; ?></td> 
						<td align="right"><?php echo number_format($total_bl_revenue,2); $total_bl_revenue = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_portion,2); $total_igw_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_icx_portion,2); $total_icx_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_btrc_portion,2); $total_btrc_portion = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_cost,2); $total_igw_cost = 0; ?></td> 
						<td align="right"><?php echo number_format($total_cost_total,2); $total_cost_total = 0; ?></td>
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				 <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_air_unit,2); $total_air_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_charged_unit,2); $total_charged_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount,2); $total_amount = 0; ?></td>
						<td align="right"><?php echo number_format($total_y_value,2); $total_y_value = 0; ?></td>
						<td align="right"><?php echo number_format($total_z_value,2); $total_z_value = 0; ?></td> 
						<td align="right"><?php echo number_format($total_bl_revenue,2); $total_bl_revenue = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_portion,2); $total_igw_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_icx_portion,2); $total_icx_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_btrc_portion,2); $total_btrc_portion = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_cost,2); $total_igw_cost = 0; ?></td> 
						<td align="right"><?php echo number_format($total_cost_total,2); $total_cost_total = 0; ?></td>
					</tr>
				    <?php }?>
					
					
					<?php endforeach; ?>
					
					
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtnc,2); ?></td>
						<td align="right"><?php echo number_format($gtau,2); ?></td>
						<td align="right"><?php echo number_format($gtcu,2); ?></td>
						<td align="right"><?php echo number_format($gta,2); ?></td>
						<td align="right"><?php echo number_format($gtyv,2); ?></td>
						<td align="right"><?php echo number_format($gtzv,2); ?></td>
						<td align="right"><?php echo number_format($gtbr,2); ?></td>
						<td align="right"><?php echo number_format($gtigp,2); ?></td>
						<td align="right"><?php echo number_format($gticp,2); ?></td>
						<td align="right"><?php echo number_format($gtbtp,2); ?></td>
						<td align="right"><?php echo number_format($gtigc,2); ?></td>
						<td align="right"><?php echo number_format($gttct,2); ?></td>
						
						
						
						
					</tr>
					</tbody>
			</table>
		</div>

		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;">Interconnection Provision Report for MOID Extrapuleted</div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>ACT_DURATION</th>
						<th>DURATION</th>
						<th>AMOUNT</th>
						<th>Y_VALUE</th>
						<th>Z_VALUE</th>
						<th>BL_REVENUE</th>
						<th>IGW_PORTION</th>
						<th>ICX_PORTION</th>
						<th>BTRC_PORTION</th>
						<th>IGW_Cost</th>
						<th>Total Cost</th>
					
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$gtnc=0;
					$total_air_unit = 0;
					$gtau = 0;
					$total_charged_unit=0;
					$gtcu=0;
					$total_amount=0;
					$gta=0;
					$total_y_value=0;
					$gtyv=0;
					$total_z_value = 0;
					$gtzv=0;
					$total_bl_revenue = 0;
					$gtbr = 0;
					$total_igw_portion=0;
					$gtigp=0;
					$total_icx_portion=0;
					$gticp=0;
					$total_btrc_portion=0;
					$gtbtp=0;
					$total_igw_cost=0;
					$gtigc=0;
					$total_cost_total=0;
					$gttct=0;
					foreach($get_record as $k=>$v): 
					$number_of_calls=($v->NUMBER_OF_CALLS / $v->MAX_DAY)*$v->LAST_DAY;
					$air_unit=($v->AIR_UNIT / $v->MAX_DAY)*$v->LAST_DAY;
					$charged_unit=($v->CHARGED_UNITS / $v->MAX_DAY)*$v->LAST_DAY;
					$amount=($v->AMOUNT / $v->MAX_DAY)*$v->LAST_DAY;
					$y_value=($v->Y_VALUE / $v->MAX_DAY)*$v->LAST_DAY;
					$z_value=($v->Z_VALUE / $v->MAX_DAY)*$v->LAST_DAY;
					$bl_revenue=($v->BL_REVENUE / $v->MAX_DAY)*$v->LAST_DAY;
					$igw_portion=($v->IGW_PORTION / $v->MAX_DAY)*$v->LAST_DAY;
					$icx_portion=($v->ICX_PORTION / $v->MAX_DAY)*$v->LAST_DAY;
					$btrc_portion=($v->BTRC_PORTION / $v->MAX_DAY)*$v->LAST_DAY;
					$igw_cost=(($v->IGW_PORTION + $v->Y_VALUE)/ $v->MAX_DAY)*$v->LAST_DAY;
					$total_cost= (($icx_portion + $btrc_portion + $igw_cost)/ $v->MAX_DAY)*$v->LAST_DAY;
					?>
					
					<tr>
						<td><?php echo $v->OPERATOR; ?></td> 
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td align="right"><?php echo number_format($number_of_calls,2); $total_no_calls += $number_of_calls; $gtnc += $number_of_calls;?></td>
						<td align="right"><?php echo number_format($air_unit,2); $total_air_unit += $air_unit; $gtau += $air_unit;?></td>
						<td align="right"><?php echo number_format($charged_unit,2); $total_charged_unit += $charged_unit; $gtcu += $charged_unit;?></td>
						<td align="right"><?php echo number_format($amount,2); $total_amount += $amount; $gta += $amount;?></td>
						<td align="right"><?php echo number_format($y_value,2); $total_y_value += $y_value; $gtyv += $y_value;?></td>
						<td align="right"><?php echo number_format($z_value,2); $total_z_value += $z_value; $gtzv += $z_value;?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $total_bl_revenue += $bl_revenue; $gtbr += $bl_revenue;?></td>
						<td align="right"><?php echo number_format($igw_portion,2); $total_igw_portion += $igw_portion; $gtigp += $igw_portion;?></td>
						<td align="right"><?php echo number_format($icx_portion,2); $total_icx_portion += $icx_portion; $gticp += $icx_portion;?></td>
						<td align="right"><?php echo number_format($btrc_portion,2); $total_btrc_portion += $btrc_portion; $gtbtp += $btrc_portion;?></td>
						<td align="right"><?php echo number_format($igw_cost,2); $total_igw_cost += $igw_cost; $gtigc += $igw_cost;?></td>
						<td align="right"><?php echo number_format($total_cost,2); $total_cost_total += $total_cost; $gttct += $total_cost;?></td>
					</tr>
					
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->OPERATOR != $get_record[$k + 1]->OPERATOR){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_air_unit,2); $total_air_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_charged_unit,2); $total_charged_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount,2); $total_amount = 0; ?></td>
						<td align="right"><?php echo number_format($total_y_value,2); $total_y_value = 0; ?></td>
						<td align="right"><?php echo number_format($total_z_value,2); $total_z_value = 0; ?></td> 
						<td align="right"><?php echo number_format($total_bl_revenue,2); $total_bl_revenue = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_portion,2); $total_igw_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_icx_portion,2); $total_icx_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_btrc_portion,2); $total_btrc_portion = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_cost,2); $total_igw_cost = 0; ?></td> 
						<td align="right"><?php echo number_format($total_cost_total,2); $total_cost_total = 0; ?></td>
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				 <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_air_unit,2); $total_air_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_charged_unit,2); $total_charged_unit = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount,2); $total_amount = 0; ?></td>
						<td align="right"><?php echo number_format($total_y_value,2); $total_y_value = 0; ?></td>
						<td align="right"><?php echo number_format($total_z_value,2); $total_z_value = 0; ?></td> 
						<td align="right"><?php echo number_format($total_bl_revenue,2); $total_bl_revenue = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_portion,2); $total_igw_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_icx_portion,2); $total_icx_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_btrc_portion,2); $total_btrc_portion = 0; ?></td> 
						<td align="right"><?php echo number_format($total_igw_cost,2); $total_igw_cost = 0; ?></td> 
						<td align="right"><?php echo number_format($total_cost_total,2); $total_cost_total = 0; ?></td>
					</tr>
				    <?php }?>			
					<?php endforeach; ?>
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtnc,2); ?></td>
						<td align="right"><?php echo number_format($gtau,2); ?></td>
						<td align="right"><?php echo number_format($gtcu,2); ?></td>
						<td align="right"><?php echo number_format($gta,2); ?></td>
						<td align="right"><?php echo number_format($gtyv,2); ?></td>
						<td align="right"><?php echo number_format($gtzv,2); ?></td>
						<td align="right"><?php echo number_format($gtbr,2); ?></td>
						<td align="right"><?php echo number_format($gtigp,2); ?></td>
						<td align="right"><?php echo number_format($gticp,2); ?></td>
						<td align="right"><?php echo number_format($gtbtp,2); ?></td>
						<td align="right"><?php echo number_format($gtigc,2); ?></td>
						<td align="right"><?php echo number_format($gttct,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>
	</body>
</html>