
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 14 ; 
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Revenue Sharing Report for MOSMS";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>Type</th>
						<th>No of Calls</th>
						<th>Act duration</th>
						<th>Duration</th>
						<th>X Value</th>
						<th>Y Value</th>
						<th>Z Value</th>
						<th>Bl Revenue</th>
						<th>IGW Portion</th>
						<th>ICX Portion</th>
						<th>BTRC Portion</th>
						<th>Total Cost</th>
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$total_duration = 0;
					$charged_unit_in_min = 0;
					$x_value = 0;
					$y_value = 0;
					$z_value = 0;
					$bl_revenue = 0;
					$igw_portion = 0;
					$icx_portion = 0;
					$btrc_portion = 0;
					$total_cost = 0;
					$tnc=0;
					$td=0;
					$cum=0;
					$xv=0;
					$yv=0;
					$zv=0;
					$blr=0;
					$igwp=0;
					$icxp=0;
					$btrcp=0;
					$tc=0;
					
					 ?>
					<?php //dd($get_record); ?>
					<?php foreach($get_record as $k=>$v): $total_record=count($get_record); ?>
					<tr>
						<td><?php echo $v->OPERATOR_NAME; ?></td> 
						<td><?php echo $v->PREP_POST; ?></td> 
						<td><?php echo $v->TYPE; ?></td>
						<td align="right"><?php echo number_format($v->NO_OF_CALLS,2); $total_no_calls += $v->NO_OF_CALLS; $tnc += $v->NO_OF_CALLS; ?></td>
						<td align="right"><?php echo number_format($v->ACTUAL_CHARGED_UNITS_IN_MIN,2); $total_duration += $v->ACTUAL_CHARGED_UNITS_IN_MIN; $td += $v->ACTUAL_CHARGED_UNITS_IN_MIN;?></td>
						<td align="right"><?php echo number_format($v->CHARGED_UNIT_IN_MIN,2); $charged_unit_in_min += $v->CHARGED_UNIT_IN_MIN; $cum += $v->CHARGED_UNIT_IN_MIN;?></td>
						<td align="right"><?php echo number_format($v->X_VALUE,2); $x_value += $v->X_VALUE; $xv += $v->X_VALUE;?></td>
						<td align="right"><?php echo number_format($v->Y_VALUE,2); $y_value += $v->Y_VALUE; $yv+= $v->Y_VALUE;?></td>
						<td align="right"><?php echo number_format($v->Z_VALUE,2); $z_value += $v->Z_VALUE; $zv+= $v->Z_VALUE;?></td>
						<td align="right"><?php echo number_format($v->BL_REVENUE,2); $bl_revenue += $v->BL_REVENUE; $blr+= $v->BL_REVENUE;?></td>
						<td align="right"><?php echo number_format($v->IGW_PORTION,2); $igw_portion += $v->IGW_PORTION; $igwp += $v->IGW_PORTION;?></td>
						<td align="right"><?php echo number_format($v->ICX_PORTION,2); $icx_portion += $v->ICX_PORTION; $icxp+= $v->ICX_PORTION;?></td>
						<td align="right"><?php echo number_format($v->BTRC_PORTION,2); $btrc_portion += $v->BTRC_PORTION; $btrcp += $v->BTRC_PORTION;?></td>
						<td align="right"><?php echo number_format($v->TOTAL_COST,2); $total_cost += $v->TOTAL_COST; $tc+= $v->TOTAL_COST;?></td>
					</tr>
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->OPERATOR_NAME != $get_record[$k + 1]->OPERATOR_NAME){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td></td>
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $total_duration = 0; ?></td>
						<td align="right"><?php echo number_format($charged_unit_in_min,2); $charged_unit_in_min = 0; ?></td>
						<td align="right"><?php echo number_format($x_value,2); $x_value = 0; ?></td>
						<td align="right"><?php echo number_format($y_value,2); $y_value = 0; ?></td>
						<td align="right"><?php echo number_format($z_value,2); $z_value = 0; ?></td>
						<td align="right"><?php echo number_format($bl_revenue,2); $bl_revenue = 0; ?></td>
						<td align="right"><?php echo number_format($igw_portion,2); $igw_portion = 0; ?></td>
						<td align="right"><?php echo number_format($icx_portion,2); $icx_portion = 0; ?></td>
						<td align="right"><?php echo number_format($btrc_portion,2); $btrc_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_cost,2); $total_cost = 0; ?></td>
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				  <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td></td>
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right" ><?php echo number_format($total_duration,2); $total_duration = 0; ?></td>
						<td align="right"><?php echo number_format($charged_unit_in_min,2); $charged_unit_in_min = 0; ?></td>
						<td align="right"><?php echo number_format($x_value,2); $x_value = 0; ?></td>
						<td align="right"><?php echo number_format($y_value,2); $y_value = 0; ?></td>
						<td align="right"><?php echo number_format($z_value,2); $z_value = 0; ?></td>
						<td align="right" ><?php echo number_format($bl_revenue,2); $bl_revenue = 0; ?></td>
						<td align="right"><?php echo number_format($igw_portion,2); $igw_portion = 0; ?></td>
						<td align="right"><?php echo number_format($icx_portion,2); $icx_portion = 0; ?></td>
						<td align="right"><?php echo number_format($btrc_portion,2); $btrc_portion = 0; ?></td>
						<td align="right"><?php echo number_format($total_cost,2); $total_cost = 0; ?></td>
					</tr>
				<?php }?>
					<?php endforeach; ?>
					
				<tr style="background-color:green;">
						<td>Total</td> 
						<td></td> 
						<td></td>
						<td align="right"><?php echo number_format($tnc,2); ?></td>
						<td align="right" ><?php echo number_format($td,2); ?></td>
						<td align="right"><?php echo number_format($cum,2);  ?></td>
						<td align="right"><?php echo number_format($xv,2);?></td>
						<td align="right"><?php echo number_format($yv,2); ?></td>
						<td align="right"><?php echo number_format($zv,2);?></td>
						<td align="right" ><?php echo number_format($blr,2); ?></td>
						<td align="right"><?php echo number_format($igwp,2);?></td>
						<td align="right"><?php echo number_format($icxp,2); ?></td>
						<td align="right"><?php echo number_format($btrcp,2); ?></td>
						<td align="right"><?php echo number_format($tc,2); ?></td>
					</tr>
					
					</tbody>
			</table>
		</div>
	</body>
</html>