<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>Invoice vs full month reconsilation domestic Report</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
	<style>
		label {
		    font-weight: normal !important;
		    cursor:pointer;
		}
		.state-icon {
    left: -5px;
}
.list-group-item-primary {
    color: rgb(255, 255, 255);
    background-color: rgb(66, 139, 202);
}

/* DEMO ONLY - REMOVES UNWANTED MARGIN */
.well .list-group {
    margin-bottom: 0px;
}
	</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>		
		<div id="page_upload_ic_data" class="main_container page_identifier">
			<div class="page_caption">Invoice vs full month reconsilation domestic Report</div>
			<div class="page_body stamp">
				
				<!--file upload error-->
				<?php if( isset($error) && $error ): ?>
				<div class="message_board"><?php echo $error; ?></div>
				<?php endif; ?>
				<div class="left_section">
					<fieldset class="divider"><legend>Please fill-up the parameter(s)</legend></fieldset>
				
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_filter" method="post" action="" target="_blank" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">     
						<table width="100%">
							<tr>
								<td colspan=3>
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
		              	<input type="text" name="CALCULATIVE_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
							
		
							<tr>
								<td>
									<div class="form_label">&nbsp</div>
									<div class="form-check">
  								<label class="form-check-label">
    							<input class="form-check-input" type="checkbox" name="bl_vs_ios_reconcilation" value="bl_vs_ios_reconcilation">
    							BL_vs_IOS_reconciliation
  								</label>
									</div>
								</td>
								<td>
									<div class="form_label">&nbsp</div>
									<div class="form-check">
  								<label class="form-check-label">
    							<input class="form-check-input" type="checkbox" name="single_ios_sort_summery" value="single_ios_sort_summery" >
    							Single IOS short summery
  								</label>
									</div>
								</td>
								<td>
									<div class="form_label">&nbsp</div>
									<div class="form-check">
  								<label class="form-check-label">
    							<input class="form-check-input" type="checkbox" name="single_ios_detail_summery" value="single_ios_detail_summery">
    							Single IOS detail summery
  								</label>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div>
										<input type="submit" name="view" class="btn_gray" value="View" />
										<input type="submit" name="print" class="btn_gray" value="Print" />
										<input type="submit" name="export" class="btn_gray" value="Export" />
									</div>
								</td>
								<td><input type="submit" name="email" class="btn_gray" value="Email" /></td>
							</tr>
						</table>
					</form>
				</div>
				<div class="right_section">
				</div>				
				<div class="float_clear_full">&nbsp;</div>
			 </div>
		</div>
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>
<script>
	 $(document).ready(function(){
	 	$("#exclude_list").hide();
    	$('#isSelected').change(function(){
        if(this.checked)
            $('#exclude_list').fadeIn('slow');
            //.find(':input').attr('required', true);

        else
            $('#exclude_list').fadeOut('slow');
            //.find(':input').attr('required', false);

      });
   });
</script>