
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 8 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Revenue Sharing Report for MOC";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Operator Type</th>		
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Duration</th>
						<th>Rate Per Min.</th>
						<th>Amount</th>
						<th>VAT</th>
						<th>Total</th>
					</tr>
					</thead>
					<tbody>
					<?php 
					$grand_total_no_of_calls=0;
					$grand_duration=0;
					$grand_total=0;
					$grand_vat=0;
					$grand_amount=0;
					$total_no_calls=0;
					$total_duration=0;
					$rate_per_min_bdt=0;
					$vat=0;
					$total=0;
					$amount=0;
					foreach($get_record as $k=>$v): 
					$operator_info = $this->customcache->operator_maker_new($v->OPERATOR_NAME,null);
					$total_record=count($get_record);
					if($v->POST_NO_OF_CALLS_VALUE || $v->POST_NO_OF_CALLS_VALUE!=''){
						$post_no_of_calls=$v->POST_NO_OF_CALLS_VALUE;
					}else{
						$post_no_of_calls=$v->PREP_NO_OF_CALLS_VALUE;
					}
					if($v->POST_DURATION_IN_MIN_VALUE || $v->POST_DURATION_IN_MIN_VALUE!=''){
						$post_duration=$v->POST_DURATION_IN_MIN_VALUE;
					}else{
						$post_duration=$v->PREP_DURATION_IN_MIN_VALUE;
					}
					if($v->POST_AMOUNT_VALUE || $v->POST_AMOUNT_VALUE!=''){
						$post_amount=$v->POST_AMOUNT_VALUE;
					}else{
						$post_amount=$v->PREP_AMOUNT_VALUE;
					}
					if($v->POST_VAT_VALUE_VALUE || $v->POST_VAT_VALUE_VALUE!=''){
						$post_vat=$v->POST_VAT_VALUE_VALUE;
					}else{
						$post_vat=$v->PREP_VAT_VALUE_VALUE;
					}
					if($v->POST_TOTAL || $v->POST_TOTAL!=''){
						$post_total=$v->POST_TOTAL;
					}else{
						$post_total=$v->PREP_TOTAL;
					}
					?>
					<tr>
						<td><?php echo $v->OPERATOR_NAME; ?></td> 
						<td><?php echo $operator_info[3];?></td>
						<td><?php echo $v->PRE_POST; ?></td> 
						<td align="right"><?php echo number_format($post_no_of_calls,2); $total_no_calls += $post_no_of_calls; ?></td>
						<td align="right"><?php echo number_format($post_duration,2); $total_duration += $post_duration;?></td>
						<td align="right"><?php echo number_format($v->RATE_PER_MIN,2); $rate_per_min_bdt += $v->RATE_PER_MIN;?></td>
						<td align="right"><?php echo number_format($post_amount,2); $amount += $post_amount;?></td>
						<td align="right"><?php echo number_format($post_vat,2); $vat += $post_vat;?></td>
						<td align="right"><?php echo number_format($post_total,2); $total += $post_total;?></td>
					</tr>
			
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->OPERATOR_NAME != $get_record[$k + 1]->OPERATOR_NAME){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2);  $grand_total_no_of_calls=$grand_total_no_of_calls+$total_no_calls;$total_no_calls =0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $grand_duration=$grand_duration+$total_duration;$total_duration =0;?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($amount,2); $grand_amount=$grand_amount+$amount; $amount=0;?></td>
						<td align="right"><?php echo number_format($vat,2); $grand_vat=$grand_vat+$vat; $vat =0;?></td>
						<td align="right"><?php echo number_format($total,2);$grand_total=$grand_total+$total; $total =0;?></td>
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				  <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2);  $grand_total_no_of_calls=$grand_total_no_of_calls+$total_no_calls;$total_no_calls =0; ?></td>
						<td align="right"><?php echo number_format($total_duration,2); $grand_duration=$grand_duration+$total_duration;$total_duration =0;?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($amount,2); $grand_amount=$grand_amount+$amount; $amount=0;?></td>
						<td align="right"><?php echo number_format($vat,2); $grand_vat=$grand_vat+$vat; $vat =0;?></td>
						<td align="right"><?php echo number_format($total,2);$grand_total=$grand_total+$total; $total =0;?></td>
					</tr>
				<?php }?>
					<?php endforeach; ?>
					 <tr style="background-color:green;">
						<td>Grand Total</td> 
						<td></td> 
						<td></td> 
						<td align="right"><?php echo number_format($grand_total_no_of_calls,2); ?></td>
						<td align="right"><?php echo number_format($grand_duration,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($grand_amount,2); ?></td>
						<td align="right"><?php echo number_format($grand_vat,2);?></td>
						<td align="right"><?php echo number_format($grand_total,2);?></td>
					</tr>
					
					
					</tbody>
			</table>
		</div>
	</body>
</html>