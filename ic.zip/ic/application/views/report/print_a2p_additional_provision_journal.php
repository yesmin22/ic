<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>A2P Provision Journal</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.bt {border-top:1px solid #000000;border-bottom:1px solid #000000;}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:1px solid #000000; }
			.brtl2 { border-top:1px solid #000000; border-left:1px solid #000000; }
			.brtr2 { border-top:1px solid #000000; border-right:1px solid #000000; }
			.brr2 { border-right:1px solid #000000; }
			.brrt2 { border-right:1px solid #000000; border-top:1px solid #000000; }
			.brrb2 { border-right:1px solid #000000; border-bottom:1px solid #000000; }
			.brb2 { border-bottom:1px solid #000000; }
			.brl2 { border-left:1px solid #000000; }
			.brlt2 { border-left:1px solid #000000; border-top:1px solid #000000; }
			.brlb2 { border-left:1px solid #000000; border-bottom:1px solid #000000; }
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<?php 
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
								<tr>
					<td>&nbsp;</td>
					<td colspan="3">Balance Type</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>Actual</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Database</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7">BLERPPRD03.BANGLALINKGSM.COM.PROD</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3">Set of Books</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan="7">Banglalink Set of Books</td>
				</tr>
				<?php echo $blanck_row; ?>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Category</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right">* List - Text</td>
					<td class="brlt2" style="border-right:1px solid #CCCCCC;"  colspan="6" ><strong>BL_GL_Revenue</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Sourch</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right">* List - Text</td>
					<td class="brlt2" style="border-right:1px solid #CCCCCC;"  colspan="6"><strong>Spreadsheet</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Currency</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right">* List - Text</td>
					<td class="brlt2" style="border-right:1px solid #CCCCCC;" colspan="6"><strong>BDT</strong></td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brtl2"><strong>Accounting Date</strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" align="right" style="border-right:1px solid #CCCCCC;">* List - Text</td>
					<td class="brt2" colspan="3" ><strong><?php echo $current_date;?></strong></td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2">&nbsp;</td>
					<td class="brt2" style="border-right:1px solid #CCCCCC;">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2"><strong>Journal Name</strong></td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2" colspan=6><strong>Interconnection A2P SMS SPAM FILTER Revenue from wintel/infobip for <?php echo $date;?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2">Journal Description</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="">&nbsp;</td>
					<td class="brr2" align="right">Text</td>
					<td class="brr2" colspan=6><strong>Interconnection A2P SMS SPAM FILTER Revenue from wintel/infobip for <?php echo $date;?></strong></td>
					<td class="">&nbsp;</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brl2" style="border-bottom:1px solid #CCCCCC;" >Journal Reference</td>
					<td class="" style="border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td class="" style="border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td class="brr2" style="border-bottom:1px solid #CCCCCC;" align="right">Text</td>
					<td class="brr2" style="border-bottom:1px solid #CCCCCC;" colspan=6><strong>Interconnection A2P SMS SPAM FILTER Revenue from wintel/infobip for <?php echo $date;?></strong></td>
			
				</tr>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?> 
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Upl</td>
					<td class="brt2" style="width:80px;">COMPANY</td>
					<td class="brt2" style="width:60px;">BRANCH</td>
					<td class="brt2" style="width:100px;">COST CENTER</td>
					<td class="brt2" style="width:120px;">NATURAL ACOUNT</td>
					<td class="brt2" style="width:70px;">ANLYTICAL</td>
					<td class="brt2" style="width:60px;">PROJECT</td>
					<td class="brt2" style="width:60px;">FUTURE</td>
					<td class="brt2" style="width:110px;">Debit</td>
					<td class="brt2" style="width:110px;">Credit</td>
					<td class="brt2" style="width:700px;">Line Description</td>
					<td class="brt2" style="width:70px;"></td>
					<td class="brrt2" style="width:110px;">Messages</td>
				</tr>
				<tr>
					<td class="">&nbsp;</td>
					<td class="brlb2">&nbsp;</td>
					<td class="brb2" colspan="7">* List - Text</td>
					<td class="brb2">* Number</td>
					<td class="brb2">* Number</td>
					<td class="brb2">Text</td>
					<td class="brb2">&nbsp;</td>
					<td class="brb2" style="border-right:1px solid #CCCCCC;">&nbsp;</td>
				</tr>		
				<?php 
					if($get_record){
						$bl_ratio=	(100-$get_record->RATIO);
						$commited_sms_from_conf=	$get_record->TOTAL_SMS_COMMITMENT_PER_MONTH;
						$commited_sms_from_provition=	$provition_record->TOTAL_SMS;
						$extra_sms=$commited_sms_from_provition-$commited_sms_from_conf;
						$usd_extra_amount=$get_record->AGREED_RATE * $extra_sms;
						$bdt_extra_amount=$provition_record->USD_TO_BDT_RATE * $usd_extra_amount;
						$bl_extra_portion=$bdt_extra_amount*($bl_ratio/100);
						$bl_extra_vat=$bl_extra_portion/(1.15)*(0.15);
						$bl_revenue_extra=$bl_extra_portion-$bl_extra_vat;
						
				  }else{
				  	$bl_revenue_extra=0;
				  }
				?>
				<tr>
					<td >&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC;">&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td>A000&nbsp;</td>
					<td>1019452</td>
					<td>0000&nbsp;</td>
					<td>0000</td>
					<td>0000&nbsp;</td>
				  <td style="text-align:right;"><?php echo number_format($bl_revenue_extra,2);?></td>
					<td style="text-align:right;"></td>
						<td>InfoBip,A2P,<?php echo $date;?>,INVOICE,SMS, for additional A2P SMS B2B Revenue</td>
					<td>&#x263A;</td>
					<td style="border-right:1px solid #CCCCCC;">&nbsp;</td>
				</tr>
				<tr>
					<td >&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC;">&nbsp;</td>
					<td>01&nbsp;</td>
					<td>101&nbsp;</td>
					<td>A000&nbsp;</td>
					<td>4012763</td>
					<td>0000&nbsp;</td>
					<td>0000</td>
					<td>0000&nbsp;</td>
				  <td style="text-align:right;"></td>
					<td style="text-align:right;"><?php echo number_format($bl_revenue_extra,2);?></td>
					<td>InfoBip,A2P,<?php echo $date;?>,INVOICE,SMS, for additional A2P SMS B2B Revenue</td>
					<td>&#x263A;</td>
					<td style="border-right:1px solid #CCCCCC;">&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="bt" style="border-left:1px solid #CCCCCC;">Totals:</td>
					<td class="bt">&nbsp;</td>
					<td class="bt">&nbsp;</td>
					<td class="bt">&nbsp;</td>
					<td class="bt">&nbsp;</td>
					<td class="bt">&nbsp;</td>
					<td class="bt">&nbsp;</td>
					<td class="bt">&nbsp;</td>
					<td class="bt"><?php echo number_format($bl_revenue_extra,2);?></td>
					<td class="bt"><?php echo number_format($bl_revenue_extra,2);?></td>
					<td class="bt">&nbsp;</td>
					<td class="bt">&nbsp;</td>
					<td class="bt" style="border-right:1px solid #CCCCCC;">&nbsp;</td>
				</tr>			
				<tr>
					<td>&nbsp;</td>
					<td colspan=8 >Tip: This is not the end of the Template.  Unprotect the sheet and insert as many rows as needed.</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
			</table>
		</div>
	</body>
</html>




































