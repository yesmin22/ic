
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 9 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Provision Report for MOC";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Rate per minute</th>
						<th>Duration minutes</th>
						<th>Amount</th>
						<th>VAT</th>
						<th>Total Amount</th>
					
					</tr>
					</thead>
					<tbody>
					<?php 
					$gtc=0;
					$gtm=0;
					$gta=0;
					$gtawv=0;
					$gtv=0;
					foreach($get_record as $k=>$v): 
					$operator=$v->OPERATOR;
					$max_day=$v->MAX_DAY_ICX;
					$last_day=$v->LAST_DAY_ICX;
					$rate_per_minute=$v->RATE_PER_MINUTES;
					$post_value=$v->POST_VALUE_ICX;
					$pre_value=$v->PREP_VALUE_ICX;
					$post_call=$v->POST_NUMBER_OF_CALLS_ICX;
					$pre_call=$v->PREP_NUMBER_OF_CALLS_ICX;
					$post_min=$v->POST_MINUTES_ICX;
					$pre_min=$v->PREP_MINUTES_ICX;
					$post_vat=($post_value*$Vat)/100;
					$pre_vat=($pre_value*$Vat)/100;
					$post_total_with_vat=$post_vat + $post_value;
					$pre_total_with_vat=$pre_vat + $pre_value;
					
					?>
					<tr>
						<td><?php echo $operator; ?></td> 
						<td>POST</td> 
						<td align="right"><?php echo number_format($post_call,2);?></td>
						<td align="right"><?php echo number_format($rate_per_minute,2);?></td>
						<td align="right"><?php echo number_format($post_min,2);?></td>
						<td align="right"><?php echo number_format($post_value,2);?></td>
						<td align="right"><?php echo number_format($post_vat,2);?></td>
						<td align="right"><?php echo number_format($post_total_with_vat,2);?></td>
					</tr>
					<tr>
						<td><?php echo $operator; ?></td> 
						<td>PREP</td> 
						<td align="right"><?php echo number_format($pre_call,2);?></td>
						<td align="right"><?php echo number_format($rate_per_minute,2);?></td>
						<td align="right"><?php echo number_format($pre_min,2);?></td>
						<td align="right"><?php echo number_format($pre_value,2);?></td>
						<td align="right"><?php echo number_format($pre_vat,2);?></td>
						<td align="right"><?php echo number_format($pre_total_with_vat,2);?></td>
					</tr>
					<tr style="background-color:#FFED4A;">
						<td >Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format(($pre_call + $post_call ),2); $gtc+= $pre_call + $post_call;?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format(($pre_min + $post_min),2); $gtm+=$pre_min + $post_min;?></td>
						<td align="right"><?php echo number_format(($pre_value + $post_value),2); $gta +=$pre_value + $post_value;?></td>
						<td align="right"><?php echo number_format(($pre_vat + $post_vat),2); $gtv +=$pre_vat + $post_vat;?></td>
						<td align="right"><?php echo number_format(($pre_total_with_vat + $post_total_with_vat),2); $gtawv +=$pre_total_with_vat + $post_total_with_vat;?></td>
					</tr>
					<?php endforeach; ?>
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtc,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($gtm,2); ?></td>
						<td align="right"><?php echo number_format($gta,2); ?></td>
						<td align="right"><?php echo number_format($gtv,2); ?></td>
						<td align="right"><?php echo number_format($gtawv,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>

		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;">Interconnection Provision Report for IMMS Extrapuleted</div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Rate per minute</th>
						<th>Duration minutes</th>
						<th>Amount</th>
						<th>VAT</th>
						<th>Total Amount</th>
					
					</tr>
					</thead>
					<tbody>
					<?php 
					$gtc=0;
					$gtm=0;
					$gta=0;
					$gtawv=0;
					foreach($get_record as $k=>$v): 
					$operator=$v->OPERATOR;
					$max_day=$v->MAX_DAY_ICX;
					$last_day=$v->LAST_DAY_ICX;
					$rate_per_minute=$v->RATE_PER_MINUTES;
					$post_value=($v->POST_VALUE_ICX / $max_day) * $last_day;
					$pre_value=($v->PREP_VALUE_ICX / $max_day) * $last_day;
					$post_call=($v->POST_NUMBER_OF_CALLS_ICX / $max_day) * $last_day;
					$pre_call=($v->PREP_NUMBER_OF_CALLS_ICX / $max_day) * $last_day;
					$post_min=($v->POST_MINUTES_ICX / $max_day) * $last_day;
					$pre_min=($v->PREP_MINUTES_ICX / $max_day) * $last_day;
					$post_vat=($post_value*$Vat)/100;
					$pre_vat=($pre_value*$Vat)/100;
					$post_total_with_vat=$post_vat + $post_value;
					$pre_total_with_vat=$pre_vat + $pre_value;
					
					?>
					<tr>
						<td><?php echo $operator; ?></td> 
						<td>POST</td> 
						<td align="right"><?php echo number_format($post_call,2);?></td>
						<td align="right"><?php echo number_format($rate_per_minute,2);?></td>
						<td align="right"><?php echo number_format($post_min,2);?></td>
						<td align="right"><?php echo number_format($post_value,2);?></td>
						<td align="right"><?php echo number_format($post_vat,2);?></td>
						<td align="right"><?php echo number_format($post_total_with_vat,2);?></td>
					</tr>
					<tr>
						<td><?php echo $operator; ?></td> 
						<td>PREP</td> 
						<td align="right"><?php echo number_format($pre_call,2);?></td>
						<td align="right"><?php echo number_format($rate_per_minute,2);?></td>
						<td align="right"><?php echo number_format($pre_min,2);?></td>
						<td align="right"><?php echo number_format($pre_value,2);?></td>
						<td align="right"><?php echo number_format($pre_vat,2);?></td>
						<td align="right"><?php echo number_format($pre_total_with_vat,2);?></td>
					</tr>
					<tr style="background-color:#FFED4A;">
						<td >Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format(($pre_call + $post_call ),2); $gtc+= $pre_call + $post_call;?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format(($pre_min + $post_min),2); $gtm+=$pre_min + $post_min;?></td>
						<td align="right"><?php echo number_format(($pre_value + $post_value),2); $gta +=$pre_value + $post_value;?></td>
						<td align="right"><?php echo number_format(($pre_vat + $post_vat),2); $gtv +=$pre_vat + $post_vat;?></td>
						<td align="right"><?php echo number_format(($pre_total_with_vat + $post_total_with_vat),2); $gtawv +=$pre_total_with_vat + $post_total_with_vat;?></td>
					</tr>
					<?php endforeach; ?>
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtc,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($gtm,2); ?></td>
						<td align="right"><?php echo number_format($gta,2); ?></td>
						<td align="right"><?php echo number_format($gtv,2); ?></td>
						<td align="right"><?php echo number_format($gtawv,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>
	</body>
</html>