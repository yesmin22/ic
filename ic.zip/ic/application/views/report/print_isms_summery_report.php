
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Domestic Voice JV</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.bt {border-top:1px solid #000000;border-bottom:1px solid #000000;}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:1px solid #000000; }
			.brtl2 { border-top:1px solid #000000; border-left:1px solid #000000; }
			.brtr2 { border-top:1px solid #000000; border-right:1px solid #000000; }
			.brr2 { border-right:1px solid #000000; }
			.brrt2 { border-right:1px solid #000000; border-top:1px solid #000000; }
			.brrb2 { border-right:1px solid #000000; border-bottom:1px solid #000000; }
			.brb2 { border-bottom:1px solid #000000; }
			.brl2 { border-left:1px solid #000000; }
			.brlt2 { border-left:1px solid #000000; border-top:1px solid #000000; }
			.brlb2 { border-left:1px solid #000000; border-bottom:1px solid #000000; }
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<?php // $global_cut_of=$get_record[0]->MAX_DAY;?>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			if(!empty($get_record)){			
				$max_day=$get_record[0]->LAST_DAY;
			}else{
				$max_day=0;
			}
			?>
			<?php

			############# Vat exclution method ####################################
			$config = $this->ft->get('config');
			$config = $config->{'0'};
			$vat = $config->vat;
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
							
				<?php echo $blanck_row; ?>
			
			
			<?php
			
			
			if(!empty ($usd_euro)){
				if(array_key_exists(0,$usd_euro)){
					$usd_to_bdt=$usd_euro[0];
				}else{
					$usd_to_bdt=0;
				}
				if(array_key_exists(1,$usd_euro)){
					$euro_to_bdt=$usd_euro[1];
				}else{
					$euro_to_bdt=0;
				}
				
				}
			
			
			
			
			
			
				  if(!empty($get_record)){
						$eur_rate_mt=abs($get_record[0]->UNIT_PRICE_EUR_2);
					}else{
						$eur_rate_mt=0;
					}
					if(!empty($get_record)){
						$total_message_from=$get_record[0]->TOTAL_CUSTOMER_RECEIVES_FROM;
					}else{
						$total_message_from=0;
					}
					if(isset($b2b_and_b2c_ratio->B2B_RATIO)){
						$b2b_ratio=$b2b_and_b2c_ratio->B2B_RATIO;
					}else{
						$b2b_ratio=0;	
					}
					if(isset($b2b_and_b2c_ratio->B2C_RATIO)){
						$b2c_ratio=$b2b_and_b2c_ratio->B2C_RATIO;
					}else{
						$b2c_ratio=0;
					}
					
					if(isset($b2b_and_b2c_ratio->B2B_RATIO_COST)){
						$b2b_ratio_cost=$b2b_and_b2c_ratio->B2B_RATIO_COST;
					}else{
						$b2b_ratio_cost=0;
					}
					if(isset($b2b_and_b2c_ratio->B2C_RATIO_COST)){
						$b2c_ratio_cost=$b2b_and_b2c_ratio->B2C_RATIO_COST;
					}else{
						$b2c_ratio_cost=0;
					}
					$bdt_rate_mt=$eur_rate_mt * $euro_to_bdt;
					$usd_rate_mt=$bdt_rate_mt / $usd_to_bdt;
					?>
					
					
					
				<tr>
					<td>&nbsp;</td>
					<td colspan=3></td>
					<td colspan=5><h3>International SMS Revenue & Expense actual <?php echo $date.' (1-'.$max_day.')';?></h3></td>
					
				</tr>	
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>	
				<tr>
					<td>&nbsp;</td>
					<td colspan=5></td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>Euro to BDT</td>
					
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo $euro_to_bdt;?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=5></td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>BDT</td>
					
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo $usd_to_bdt;?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=3>Table 1: MT</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Hits</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">MT Rate(Euro)</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Euro</td>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">&nbsp;</td>
				</tr>
				<tr>
					<td style=" ">&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=3>EUR</td>
					<td style="border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td style="border-bottom:1px solid #CCCCCC;"><?php echo number_format($total_message_from,2);?></td>
					<td style="border-bottom:1px solid #CCCCCC;"><?php echo $eur_rate_mt;?></td>
					<td style="border-bottom:1px solid #CCCCCC;"><?php $total_mt_euro=($total_message_from * $eur_rate_mt); echo number_format($total_mt_euro,2);?></td>
					<td style="border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-bottom:1px solid #CCCCCC;" colspan=3>BDT</td>
					<td style="border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td style="border-bottom:1px solid #CCCCCC;"><?php echo number_format($total_message_from,2);?></td>
					<td style="border-bottom:1px solid #CCCCCC;"><?php echo $bdt_rate_mt;?></td>
					<td style="border-bottom:1px solid #CCCCCC;"><?php $total_mt_bdt = ($total_message_from * $bdt_rate_mt); echo number_format($total_mt_bdt,2);?></td>
					<td style="border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-bottom:1px solid #CCCCCC;" colspan=3>USD</td>
					<td style=" border-bottom:1px solid #CCCCCC;">&nbsp;</td>
					<td style=" border-bottom:1px solid #CCCCCC;"><?php echo number_format($total_message_from,2);?></td>
					<td style=" border-bottom:1px solid #CCCCCC;"><?php echo $usd_rate_mt;?></td>
					<td style=" border-bottom:1px solid #CCCCCC;"><?php $total_mt_usd = ($total_message_from * $usd_rate_mt); echo number_format($total_mt_usd ,2);?></td>
					<td style=" border-bottom:1px solid #CCCCCC; border-right:1px solid #CCCCCC;">&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>Table 2: Zone wise MO Sms Hits breakdown</td>
				</tr>
				
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>ZONE Segregation</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 1</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 2</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 3</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 4</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 5</td>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Total</td>
				</tr>
				
				
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>Rate (Euro)</td>
					
					<?php
						foreach($get_record_cost as  $k=>$v){
							if($v->ZONE==0) continue;?>
							<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo $v->UNIT_PRICE;?></td>
					<?php }
					?>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">hits</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>HITS</td>
					
					<?php
					$total_for_all_currency=0;
						foreach($get_record_cost as  $k=>$v){
							if($v->ZONE==0) continue;?>
							<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format($v->TOTAL_CUSTOMER_DELIVERS_TO,2);?></td>
					<?php
					$total_for_all_currency = $total_for_all_currency + $v->TOTAL_CUSTOMER_DELIVERS_TO;
					 }
					?>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format($total_for_all_currency,2)?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td colspan=4><b>International SMS Expenses</b></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>Table 2: Zone wise MO Cost breakdown EUR</td>
				</tr>
				
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>ZONE Segregation</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 1</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 2</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 3</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 4</td>
					<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Zone 5</td>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;">Total</td>
				</tr>
				
				
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>EUR</td>
					
					<?php
					$total_euro_value = 0;
						foreach($get_record_cost as  $k=>$v){
							if($v->ZONE==0) continue;?>
							<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php $total_euro_expenses = ($v->UNIT_PRICE * $v->TOTAL_CUSTOMER_DELIVERS_TO); echo number_format($total_euro_expenses , 2);?></td>
					<?php $total_euro_value = $total_euro_value + $total_euro_expenses ;}
					?>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format($total_euro_value,2);?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>BDT</td>
					
					<?php
					$total_bdt_value =0;
						foreach($get_record_cost as  $k=>$v){
							if($v->ZONE==0) continue;?>
							<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php $total_bdt_expenses = ($v->UNIT_PRICE * $v->TOTAL_CUSTOMER_DELIVERS_TO * $euro_to_bdt); echo number_format($total_bdt_expenses ,2);   ?></td>
					<?php $total_bdt_value = $total_bdt_value + $total_bdt_expenses;}
					?>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format($total_bdt_value,2);?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>USD</td>
					
					<?php
					$total_usd_value =0;
						foreach($get_record_cost as  $k=>$v){
							if($v->ZONE==0) continue;?>
							<td style=" border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php $total_usd_sms_expenses = (($v->UNIT_PRICE * $v->TOTAL_CUSTOMER_DELIVERS_TO * $euro_to_bdt)/$usd_to_bdt) ; echo number_format($total_usd_sms_expenses,2);   ?></td>
					<?php $total_usd_value = $total_usd_value + $total_usd_sms_expenses; }
					?>
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format($total_usd_value,2)?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=8>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=5></td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>NET INPACT</td>
					
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=5></td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>EUR</td>
					
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format(($total_euro_value - $total_mt_euro),2);?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan=5></td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>BDT</td>
					
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format(($total_bdt_value - $total_mt_bdt),2);?></td>
				</tr>
					<tr>
					<td>&nbsp;</td>
					<td colspan=5></td>
					<td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;" colspan=2>USD</td>
					
					<td style=" border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;"><?php echo number_format(($total_usd_value - $total_mt_usd),2);?></td>
				</tr>
			</table>
		</div>
	</body>
</html>