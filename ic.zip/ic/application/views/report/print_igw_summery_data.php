<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 18;
$report_name = 'IGW Summery Data';
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>IGW Summery Data</title>
	<style type="text/css">
		#printArea { width:1024px;}
		body, table {font-family:tahoma; font-size:13px;}
		table td { padding:8px; }
  </style>
	<?php if( $action_type=='print'):?>
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>

		<!-- Bootstrap -->
		<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
		<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>

		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
	<?php endif; ?>
	<?php if($action_type=='view'): ?>
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
	<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>
	<?php endif; ?>
	</head>
	<body>
		<div>
		<div style="margin-left: 10em;">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<table class="table table-bordered table-striped" border="1" style="overflow:auto;">
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?> 
					<tr>
						<td>&nbsp;</td>
						<td>Operator Name</td>
						<td style="background-color:#97C8D9"> IGW Invoice</td>
						<td style="background-color:#97C8D9"> ICX Data</td>
						<td style="background-color:#97C8D9"> Difference_IGW_ICX</td>
						<td style="background-color:#97C8D9"> %age_IGW_ICX</td>
						<td style="background-color:#97C8D9"> IGW Invoice data</td>
						<td style="background-color:#97C8D9"> 7.5% tax</td>
						<td style="background-color:#97C8D9"> IGW inv after tax </td>
						<td style="background-color:yellow">BL Calculation</td>
						<td style="background-color:yellow"> 7.5% tax</td>
						<td style="background-color:yellow"> BL Calculation after tax</td>
						<td style="background-color:yellow"> Difference_IGW_BL</td>
						<td style="background-color:yellow">%age_IGW_BL</td>
						<td style="background-color:yellow"> Payable</td>
						<td style="background-color:yellow">TDS 7.5%</td>
						<td style="background-color:yellow">Payment After TDS</td>
						<td style="background-color:yellow">Taken Data</td>
					</tr>
					<?php 
					$total_IGW_Invoice=0;
					$total_ICX_Data=0;
					$total_Difference_IGW_ICX=0;
					$total_age_IGW_ICX=0;
					$total_IGW_Invoice_data=0;
					$total_tax_igw=0;
					$total_IGW_inv_after_tax=0;
					$total_BL_Calculation=0;
					$total_tax_bl=0;
					$total_BL_Calculation_after_tax=0;
					$total_Difference_IGW_BL=0;
					$total_age_IGW_BL=0;
					$total_Payable=0;
					$total_TDS=0;
					$total_Payment_After_TDS=0;

				 		foreach($get_igw_record as $k=>$v){
				 		$total_bl_data=0;
				 		foreach($get_bl_record as $bl_k=>$bl_v){
				 			if($v->IGW==$bl_v->IGW){
				 				$icx_x_value_ratio=($bl_v->X_VALUE/$bl_v->TOTAL_ICX_X_VALUE)*100;
								$icx_y_value_ratio=($bl_v->Y_VALUE/$bl_v->TOTAL_ICX_Y_VALUE)*100;
								$icx_z_value_ratio=($bl_v->Z_VALUE/$bl_v->TOTAL_ICX_Z_VALUE)*100;
								$bl_x_value=(($bl_v->TOTAL_BL_X_VALUE*$icx_x_value_ratio)/100);
								$bl_y_value=(($bl_v->TOTAL_BL_Y_VALUE*$icx_y_value_ratio)/100);
								//$bl_z_value=round((($bl_v->TOTAL_BL_Z_VALUE*$icx_z_value_ratio)/100),2);
								$bl_z_value=(($bl_x_value-$bl_y_value));
								$z_invoice=($bl_z_value*15)/100;
								$bl_invoice_amount=$bl_y_value+$z_invoice;
								$total_bl_data=($total_bl_data+$bl_invoice_amount);
				 			}
				 		}
			  ?>
				<tr>
					<td>&nbsp;</td>
					<td><?php echo $v->IGW;?></td>
					<td  align="right" ><?php echo number_format($v->TOTAL_IGW_INVOICE_AMOUNT,2);?></td>
					<td align="right"  align="right"  align="right" ><?php echo number_format($v->TOTAL_ICX_INVOICE_AMOUNT,2);?></td>
					<td align="right"  align="right"  align="right" > <?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT),2);?></td>
					<td align="right"  align="right"  align="right" > <?php echo number_format(((($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT)/$v->TOTAL_ICX_INVOICE_AMOUNT)*100),2);?>%</td>
					<td align="right"  align="right"  align="right" ><?php echo number_format($v->TOTAL_IGW_INVOICE_AMOUNT,2);?></td>
					<td align="right"  align="right" >(
						<?php if($v->IGW!='BTCL'){ 
						$igw_tax=(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100);
					}else{
						$igw_tax=0;
						}
						$igw_tax_formated=number_format($igw_tax,2);
						echo  $igw_tax_formated ;?>)</td>
						
						
					<td align="right"  align="right" ><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$igw_tax),2);?></td>
					<td align="right"  align="right" ><?php echo number_format($total_bl_data,2);?></td>
					<td align="right"  align="right" >(<?php if($v->IGW!='BTCL'){
						 $bl_tax= (($total_bl_data*(7.5))/100);}else{$bl_tax=0;}
						 $bl_tax_formated=number_format($bl_tax,2);
						 echo $bl_tax_formated;?>)</td>
					<td align="right" ><?php echo number_format(($total_bl_data-$bl_tax),2);?></td>
					<td align="right" ><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data),2);?></td>
					<td align="right" ><?php $total_dispute=((($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data)/$total_bl_data)*100); echo number_format(((($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data)/$total_bl_data)*100),2);?>%</td>
					<td align="right" ><?php  if($total_dispute>1){$reconsider_data=$total_bl_data; echo number_format($reconsider_data,2);}else{$reconsider_data=$v->TOTAL_IGW_INVOICE_AMOUNT;echo number_format($reconsider_data,2);}?></td>
					<td align="right" ><?php  
						if($v->IGW!='BTCL'){
						 if($total_dispute>1){
						 	$tds=(($total_bl_data*(7.5))/100);
						 	}else{
						 		$tds= (($v->TOTAL_IGW_INVOICE_AMOUNT*(7.5))/100);
						 		}
						}else{
							$tds=0 ;} echo number_format($tds,2);?> </td>
					<td align="right" ><?php  if($total_dispute>1){$Payment_After_TDS= ($total_bl_data-$tds); echo number_format($Payment_After_TDS,2);}else{$Payment_After_TDS=($v->TOTAL_IGW_INVOICE_AMOUNT-$tds); echo number_format($Payment_After_TDS,2);}?></td>
					<td align="right" ><?php  if($reconsider_data==$total_bl_data){echo 'Banglalink Data';}else{echo 'IGW DATA';}?></td>
					
				</tr>	
			<?php 
				$total_IGW_Invoice=$total_IGW_Invoice+$v->TOTAL_IGW_INVOICE_AMOUNT;
				$total_IGW_Invoice=$total_IGW_Invoice;
				$total_ICX_Data_value=$total_ICX_Data+$v->TOTAL_ICX_INVOICE_AMOUNT;
				$total_ICX_Data=$total_ICX_Data_value;
        $total_Difference_IGW_ICX_value=$total_Difference_IGW_ICX+($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT);
				$total_Difference_IGW_ICX=$total_Difference_IGW_ICX_value;
				$total_age_IGW_ICX=$total_age_IGW_ICX+((($v->TOTAL_IGW_INVOICE_AMOUNT-$v->TOTAL_ICX_INVOICE_AMOUNT)/$v->TOTAL_ICX_INVOICE_AMOUNT)*100);
				$total_IGW_Invoice_data=$total_IGW_Invoice_data+$v->TOTAL_IGW_INVOICE_AMOUNT;
				$total_IGW_Invoice_formated=$total_IGW_Invoice_data;
				$total_tax_igw=$total_tax_igw+(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100);
				$total_tax_igw_formated=$total_tax_igw;
				$total_IGW_inv_after_tax=$total_IGW_inv_after_tax+($v->TOTAL_IGW_INVOICE_AMOUNT-(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100));
				$total_IGW_inv_after_tax_formated=$total_IGW_inv_after_tax;
		    $total_BL_Calculation=$total_BL_Calculation+$total_bl_data;
		   	$total_BL_Calculation_formated=$total_BL_Calculation;
				$total_tax_bl=$total_tax_bl+$bl_tax;
			  $total_BL_Calculation_after_tax=$total_BL_Calculation_after_tax+($total_bl_data-$tax);
				$total_BL_Calculation_after_tax_formated=$total_BL_Calculation_after_tax;
				$total_Difference_IGW_BL=$total_Difference_IGW_BL+($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data);
				$total_Difference_IGW_BL_formated=$total_Difference_IGW_BL;
				$total_age_IGW_BL=$total_age_IGW_BL+$total_dispute;
				$total_Payable=$total_Payable+$reconsider_data;
				$total_Payable_formated=$total_Payable;
				$total_TDS=$total_TDS+$tds;
				$total_Payment_After_TDS=$total_Payment_After_TDS+$Payment_After_TDS;
			} 
			?>
			 	<tr>
					<td>&nbsp;</td>
					<td>Total</td>
					<td align="right" ><?php echo number_format($total_IGW_Invoice,2);?></td>
					<td align="right" ><?php echo number_format($total_ICX_Data,2);?></td>
					<td align="right" > <?php echo number_format($total_Difference_IGW_ICX,2);?></td>
					<td align="right" > <?php echo number_format((($total_Difference_IGW_ICX_value/$total_ICX_Data_value)*100),2)?>%</td>
					<td align="right" ><?php echo number_format($total_IGW_Invoice_formated,2);?></td>
					<td align="right" >(<?php echo number_format($total_tax_igw_formated,2);?>)</td>
					<td align="right" ><?php echo number_format($total_IGW_inv_after_tax_formated,2);?></td>
					<td align="right" ><?php echo number_format($total_BL_Calculation_formated,2);?></td>
					<td align="right" >(<?php echo number_format($total_tax_bl,2);?>)</td>
					<td align="right" ><?php echo number_format($total_BL_Calculation_after_tax_formated,2);?></td>
					<td align="right" ><?php echo number_format($total_Difference_IGW_BL_formated,2);?></td>
					<td align="right" ><?php echo number_format((($total_Difference_IGW_BL/$total_BL_Calculation)*100),2);?>%</td>
					<td align="right" ><?php echo number_format($total_Payable_formated,2);?></td>
					<td align="right" ><?php echo number_format($total_TDS,2);?></td>
					<td align="right" ><?php echo number_format($total_Payment_After_TDS,2);?></td>
					<td align="right" ></td>
					
				</tr>	
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td></td>
					
				</tr>	
				
			
				
				
			<?php 
					  $total_igw_invoice_exclude_data=0;
				 		$total_igw_tax_exclude_data=0;
				 		$total_igw_inv_after_tax_exclude_data=0;
				 		$total_bl_calculation_exclude_data=0;
				 		$total_bl_tax_exclude_data=0;
				 		$total_bl_calculation_after_tax_exclude_data=0;
				 		$total_difference_igw_bl_exclude_data=0;
				 		$total_total_payable_exclude_data=0;
						$total_total_payment_after_tds_exclude_data=0;
				 		foreach($get_igw_record as $k=>$v){
				 		foreach($excluded_igw as $excuded_k=>$excluded_v){	
				 		if($v->IGW==$excluded_v){
				 		$total_bl_data=0;
				 		foreach($get_bl_record as $bl_k=>$bl_v){
				 			if($v->IGW==$bl_v->IGW){
				 				
				 				$icx_x_value_ratio=($bl_v->X_VALUE/$bl_v->TOTAL_ICX_X_VALUE)*100;
								$icx_y_value_ratio=($bl_v->Y_VALUE/$bl_v->TOTAL_ICX_Y_VALUE)*100;
								$icx_z_value_ratio=($bl_v->Z_VALUE/$bl_v->TOTAL_ICX_Z_VALUE)*100;
								$bl_x_value=(($bl_v->TOTAL_BL_X_VALUE*$icx_x_value_ratio)/100);
								$bl_y_value=(($bl_v->TOTAL_BL_Y_VALUE*$icx_y_value_ratio)/100);
								//$bl_z_value=round((($bl_v->TOTAL_BL_Z_VALUE*$icx_z_value_ratio)/100),2);
								$bl_z_value=(($bl_x_value-$bl_y_value));
								$z_invoice=($bl_z_value*15)/100;
								$bl_invoice_amount=$bl_y_value+$z_invoice;
								$total_bl_data=($total_bl_data+$bl_invoice_amount);
				 			}
				 		}
			  	
				 		?>	
				 			
				 			
				 			
				 			
				 			
				 			
				 			
				 		
				 		
				 		
				 	<tr style="color:red">
					<td>&nbsp;</td>
					<td><?php echo $v->IGW;?> to be excluded</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right" ><?php echo number_format($v->TOTAL_IGW_INVOICE_AMOUNT,2);?></td>
					<td align="right" >(<?php if($v->IGW!='BTCL'){$igw_tax=(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100);}else{$igw_tax=0;} echo number_format($igw_tax,2);?>)</td>
					<td align="right" ><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100)),2);?></td>
					<td align="right" ><?php echo number_format($total_bl_data,2);?></td>
					<td align="right" >(<?php  if($v->IGW!='BTCL'){$bl_tax=(($total_bl_data*(7.5))/100);}else{$bl_tax=0;} echo number_format($bl_tax,2);?>)</td>
					<td align="right" ><?php echo number_format(($total_bl_data-$bl_tax),2);?></td>
					<td align="right" ><?php echo number_format(($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data),2);?></td>
					<td></td>
					<td align="right" ><?php  if($total_dispute>1){$reconsider_data=$total_bl_data; echo number_format($reconsider_data,2);}else{$reconsider_data=$v->TOTAL_IGW_INVOICE_AMOUNT;echo number_format($reconsider_data,2);}?></td>
					<td align="right" ><?php  if($v->IGW!='BTCL'){ if($total_dispute>1){$tds=(($total_bl_data*(7.5))/100);}else{$tds= (($v->TOTAL_IGW_INVOICE_AMOUNT*(7.5))/100);}}else{$tds=0;} echo number_format($tds,2);?></td>
					<td align="right" ><?php  if($total_dispute>1){$Payment_After_TDS= ($total_bl_data-$tds); echo number_format($Payment_After_TDS,2);}else{$Payment_After_TDS= ($v->TOTAL_IGW_INVOICE_AMOUNT-$tds); echo number_format($Payment_After_TDS,2);}?></td>
					<td></td>
				  </tr>	
				 		<?php 
				 		$total_igw_invoice_exclude_data=$total_igw_invoice_exclude_data+$v->TOTAL_IGW_INVOICE_AMOUNT;
				 		$total_igw_tax_exclude_data=$total_igw_tax_exclude_data+$igw_tax;
				 		$total_igw_inv_after_tax_exclude_data=$total_igw_inv_after_tax_exclude_data+($v->TOTAL_IGW_INVOICE_AMOUNT-(($v->TOTAL_IGW_INVOICE_AMOUNT * (7.5))/100));
				 		$total_bl_calculation_exclude_data=$total_bl_calculation_exclude_data+$total_bl_data;
				 		$total_bl_tax_exclude_data=$total_bl_tax_exclude_data+$bl_tax;
				 		$total_bl_calculation_after_tax_exclude_data=$total_bl_calculation_after_tax_exclude_data+($total_bl_data-$bl_tax);
				 		$total_difference_igw_bl_exclude_data=$total_difference_igw_bl_exclude_data+($v->TOTAL_IGW_INVOICE_AMOUNT-$total_bl_data);
				 		$total_total_payable_exclude_data=$total_total_payable_exclude_data+$reconsider_data;
						$total_total_payment_after_tds_exclude_data=$total_total_payment_after_tds_exclude_data+$tds;
				 		
				 		}	
				 		}
			      } ?>
			       
				
				<tr style="color:red">
					<td>&nbsp;</td>
					<td>Total Payable exluding <?php echo $v->IGW;?></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td align="right" ><?php echo number_format(($total_IGW_Invoice-$total_igw_invoice_exclude_data),2);?></td>
					<td align="right" >(<?php echo number_format(($total_tax_igw-$total_igw_tax_exclude_data),2);?>)</td>
					<td align="right" ><?php echo number_format(($total_IGW_inv_after_tax-$total_igw_inv_after_tax_exclude_data),2);?></td>
					<td align="right" ><?php echo number_format(($total_BL_Calculation-$total_bl_calculation_exclude_data),2);?></td>
					<td align="right" >(<?php  echo number_format(($total_tax_bl-$total_bl_tax_exclude_data),2);?>)</td>
					<td align="right" ><?php echo number_format(($total_BL_Calculation_after_tax-$total_bl_calculation_after_tax_exclude_data),2);?></td>
					<td align="right" ><?php echo number_format(($total_Difference_IGW_BL-$total_difference_igw_bl_exclude_data),2);?></td>
					<td></td>
					<td align="right" ><?php echo number_format(($total_Payable-$total_total_payable_exclude_data),2);?></td>
					<td align="right" ><?php  echo number_format(($total_TDS-$total_total_payment_after_tds_exclude_data),2);?></td>
					<td align="right" ><?php echo number_format(($total_Payment_After_TDS-$Payment_After_TDS),2)?></td>
					<td></td>
				</tr>	
		</table>
		
		
		
		
		<table class="table" border="1" style="overflow:auto; margin-top:50px;margin-left:400px;width:auto">
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?>
					<?php echo $blanck_row; ?> 
					<tr style="background-color:yellow">
					<td colspan=4 ><p style="align:center">Short Summery</p></td>
					
				  </tr>	
					<tr>
						<td>Operator Name</td>
						<td> Payable</td>
						<td> 7.5% tax</td>
						<td>Difference between Payable amount & tax</td>
					</tr>
					<?php 
					$total_tax_bl=0;	
					$total_Payable=0;
					$total_difference_between_payable_amount_and_tax=0;
				 		foreach($get_igw_record as $k=>$v){
				 		foreach($excluded_igw as $excluded_igw_k=>$excluded_igw_v){
				 		if($v->IGW!=$excluded_igw_v){
				 		$total_bl_data=0;
				 		foreach($get_bl_record as $bl_k=>$bl_v){
				 			if($v->IGW==$bl_v->IGW){
				 				$icx_x_value_ratio=($bl_v->X_VALUE/$bl_v->TOTAL_ICX_X_VALUE)*100;
								$icx_y_value_ratio=($bl_v->Y_VALUE/$bl_v->TOTAL_ICX_Y_VALUE)*100;
								$icx_z_value_ratio=($bl_v->Z_VALUE/$bl_v->TOTAL_ICX_Z_VALUE)*100;
								$bl_x_value=(($bl_v->TOTAL_BL_X_VALUE*$icx_x_value_ratio)/100);
								$bl_y_value=(($bl_v->TOTAL_BL_Y_VALUE*$icx_y_value_ratio)/100);
								//$bl_z_value=round((($bl_v->TOTAL_BL_Z_VALUE*$icx_z_value_ratio)/100),2);
								$bl_z_value=(($bl_x_value-$bl_y_value));
								$z_invoice=($bl_z_value*15)/100;
								$bl_invoice_amount=$bl_y_value+$z_invoice;
								$total_bl_data=($total_bl_data+$bl_invoice_amount);
				 			}
				 		}
			  ?>
				<tr>
					<td><?php echo $v->IGW;?></td>
					<td align="right"  align="right" ><?php  if($total_dispute>1){$reconsider_data=$total_bl_data; echo number_format($reconsider_data,2);}else{$reconsider_data=$v->TOTAL_IGW_INVOICE_AMOUNT;echo number_format($reconsider_data,2);}?></td>
				
					<td align="right"  align="right" >(<?php if($v->IGW!='BTCL'){
						 $bl_tax= (($total_bl_data*(7.5))/100);}else{$bl_tax=0;}
						 $bl_tax_formated=number_format($bl_tax,2);
						 echo $bl_tax_formated;?>)</td>
					
					<td align="right"  align="right" ><?php echo number_format(($reconsider_data-$bl_tax),2)?></td>
					
				</tr>	
			<?php 
				$total_tax_bl=$total_tax_bl+$bl_tax;
				$total_Payable=$total_Payable+$reconsider_data;
				$total_Payable_formated=$total_Payable;
				$total_difference_between_payable_amount_and_tax=$total_difference_between_payable_amount_and_tax+($reconsider_data-$bl_tax);
			}} }
			?>
			   
			 	<tr>
					<td>Total</td>
					<td align="right" ><?php echo number_format($total_Payable_formated,2);?></td>
					<td align="right" >(<?php echo number_format($total_tax_bl,2);?>)</td>
					<td align="right" ><?php echo number_format($total_difference_between_payable_amount_and_tax,2);?></td>
				</tr>	
				
		</table>
	</div>
</body>
</html>
































