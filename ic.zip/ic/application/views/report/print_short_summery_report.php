<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 13;
$report_name="Summery Report";
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Summery Report</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }

		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<div style="margin-left: 10em;">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0" style="margin-left:410px;">
				<?php echo $blanck_row; ?>
				<?php 
				$total_bl_dispute=0;
				$total_igw_invoice=0;
				$total_icx_data=0;
				$total_diff_igw_icx=0;
				$total_age=0;
				$total_icx_call_ratio=0;
				$total_diff=0;
				$total_BL_VS_IOS_DISPUTE=0;
				$total_amount_considered=0;
				foreach($get_record as $k=>$v){
					$icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=(($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=(($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=($bl_y_value + $z_of_15);
					$bl_dispute=((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100);
					$total_bl_dispute=$total_bl_dispute+$bl_dispute;
					//dd($bl_amount);
				}
				foreach($get_record as $k=>$v){
					$diffrence_between_bl_icx_invoice_value_of_z=$v->ICX_INVOICE_VALUE_OF_Z-$v->BL_TOTAL_ICX_PORTION;
					$BL_vs_ICX_dispute=(($diffrence_between_bl_icx_invoice_value_of_z/$v->BL_TOTAL_ICX_PORTION)*100);
				  $bl_total_invoice_amount=$v->BL_TOTAL_Y_VALUE+$v->BL_TOTAL_IGW_PORTION;
				  $icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=(($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=(($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=($bl_y_value + $z_of_15);
				  $bl_dispute=((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100);
				?>
			 <?php
			   $total_igw_invoice=($total_igw_invoice+$v->IGW_INVOICE_AMOUNT);
				 $total_icx_data=($total_icx_data+$v->ICX_INVOICE_AMOUNT);
				 $total_diff_igw_icx=($total_diff_igw_icx+($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT));
				// $total_age= round(($total_age+((($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT)/$v->ICX_INVOICE_AMOUNT)*100)),2);
				 $total_icx_call_ratio=$total_icx_call_ratio+$bl_amount;
				 $total_diff=($total_diff+(($v->IGW_INVOICE_AMOUNT)-$bl_amount));
				 $total_BL_VS_IOS_DISPUTE= $total_BL_VS_IOS_DISPUTE+$bl_dispute;
				 if($total_bl_dispute > 1){$amount=$bl_amount;}else{$amount= $v->IGW_INVOICE_AMOUNT;}
				 $total_amount_considered=$total_amount_considered+$amount; 
			 
			  }?>
			  <tr>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;">Bill Month</td>
					<td class="brt2" style="width:60px; border-bottom:1px solid #cccccc;">Invoice Data</td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;">BL/ICX DATA</td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;">Dispute</td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;">%age of BL & ICX Data</td>
				</tr>
			 	<tr>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;"><?php echo $date;?></td>
					<td class="brt2" style="width:60px; align="right"  border-bottom:1px solid #cccccc;"><?php echo number_format($total_igw_invoice,2); ?></td>
					<td class="brt2" style="width:110px; align="right"  border-bottom:1px solid #cccccc;"><?php echo number_format($total_icx_call_ratio,2); ?></td>
					<td class="brt2" style="width:110px; align="right"  border-bottom:1px solid #cccccc;"><?php echo number_format(($total_igw_invoice-$total_icx_call_ratio),2); ?></td>
					<td class="brt2" style="width:110px; align="right"  border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;"><?php echo number_format(((($total_igw_invoice-$total_icx_call_ratio)/$total_icx_call_ratio)*100),2); ?>%</td>
				</tr>
				<tr>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;">12% AIT</td>
					<td class="brt2" style="width:60px;  align="right"  border-bottom:1px solid #cccccc;">(<?php echo number_format((($total_igw_invoice*(.12))),2); ?>)</td>
					<td class="brt2" style="width:110px;  align="right"  border-bottom:1px solid #cccccc;">(<?php echo number_format((($total_icx_call_ratio*(.12))),2); ?>)</td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;"></td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;"></td>
				</tr>
				<tr>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;">AFTER AIT</td>
					<td class="brt2"  align="right" style="width:60px; border-bottom:1px solid #cccccc;"><?php echo number_format(($total_igw_invoice-(($total_igw_invoice*(.12)))),2); ?></td>
					<td class="brt2" align="right"  style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format(($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))),2); ?></td>
					<td class="brt2"  align="right" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo number_format(($total_igw_invoice-(($total_igw_invoice*(.12))))-($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))),2); ?></td>
					<td class="brt2"  align="right" style="width:110px; border-bottom:1px solid #cccccc;border-right:1px solid #cccccc;"><?php echo number_format((((($total_igw_invoice-(($total_igw_invoice*(.12))))-($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))))/($total_icx_call_ratio-(($total_icx_call_ratio*(.12)))))*100),2); ?>%</td>
				</tr>
		
			</table>
		</div>
	</body>
</html>




































