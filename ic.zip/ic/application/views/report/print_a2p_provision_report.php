<?php 

$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 10;
$report_name = 'Interconnect Revenue Sharing Report For MTSMS (SMS)';

# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>A2P Provision Report</title>
	<style type="text/css">
	#printArea { width:1024px; margin:auto; }
	body, table {font-family:tahoma; font-size:13px;}
	table td { padding:8px; }
</style>
<?php if( $action_type=='print'): ?>
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
	<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>
	<!-- print plugin -->
	<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#printArea').jqprint();
			$('#print_icon').click(function(){
				$('#printArea').jqprint();
			});
		});
	</script>
<?php endif; ?>
<?php if($action_type=='view'): ?>
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>
<?php endif; ?>
</head>
<body>
	<div id="printArea">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td align="center" colspan="<?php echo $total_column; ?>">
					<div style="font-size:150%;"><?php echo $domain_name; ?></div>
				</td>
			</tr>
		</table>
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
			<tr style="border-top:1px solid #ccc;">
				<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
			</tr>
			<tr>
				<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		</table>
		<table class="table table-bordered table-striped" border="1" style="overflow:auto;">
			<tr>
				<th>Name</th>
				<th>Call Type</th>
				<th>Sms Count</th>
				<th>USD Rate</th>
				<th>USD Amount</th>
				<th>BDT Ex Rate</th>
				<th>BDT Amount</th>
				<th>BL Portion</th>
				<th>Vat</th>
				<th>BL Revenue</th>
			</tr>
			<tr>
				<td>INBIP</td>
				<td>International SMS MT</td>
				<td><?php echo number_format($get_record->TOTAL_SMS_COMMITMENT_PER_MONTH,2); ?></td>
				<td><?php echo $get_record->AGREED_RATE;?></td>
				<td><?php $usd_amount=$get_record->TOTAL_SMS_COMMITMENT_PER_MONTH * $get_record->AGREED_RATE; echo number_format($usd_amount,2);?></td>
				<td><?php echo number_format($get_record->USD_TO_BDT_RATE,2);?></td>
				<td><?php $bdt_amount=$get_record->USD_TO_BDT_RATE*$usd_amount; echo number_format($bdt_amount,2);?></td>
				<td><?php $bl_portion=($bdt_amount*(100-$get_record->RATIO))/100; echo number_format($bl_portion,2);?></td>
				<td><?php $vat=$bl_portion/(1.15)*(0.15); echo number_format($vat,2);?></td>
				<td><?php $bl_revenue=$bl_portion-$vat; echo number_format($bl_revenue,2);?></td>
			</tr>
			<tr>
				<td>INBIP</td>
				<td>International SMS MT</td>
				<td><?php echo number_format($provition_record->TOTAL_SMS,2); ?></td>
				<td><?php echo $get_record->AGREED_RATE;?></td>
				<td><?php $usd_amount=$provition_record->TOTAL_SMS * $get_record->AGREED_RATE; echo number_format($usd_amount,2);?></td>
				<td><?php echo number_format($provition_record->USD_TO_BDT_RATE,2);?></td>
				<td><?php $bdt_amount=$provition_record->USD_TO_BDT_RATE*$usd_amount; echo number_format($bdt_amount,2);?></td>
				<td><?php $bl_portion=($bdt_amount*(100-$get_record->RATIO))/100; echo number_format($bl_portion,2);?></td>
				<td><?php $vat=$bl_portion/(1.15)*(0.15); echo number_format($vat,2);?></td>
				<td><?php $bl_revenue=$bl_portion-$vat; echo number_format($bl_revenue,2);?></td>
			</tr>
			<tr>
				<td></td>
				<td>Extra hits</td>
				<td><?php $extra_sms_count=$provition_record->TOTAL_SMS - $get_record->TOTAL_SMS_COMMITMENT_PER_MONTH ; echo number_format($extra_sms_count,2); ?></td>
				<td><?php echo $get_record->AGREED_RATE;?></td>
				<td><?php $usd_amount=$extra_sms_count * $get_record->AGREED_RATE; echo number_format($usd_amount,2);?></td>
				<td><?php echo number_format($provition_record->USD_TO_BDT_RATE,2);?></td>
				<td><?php $bdt_amount=$provition_record->USD_TO_BDT_RATE*$usd_amount; echo number_format($bdt_amount,2);?></td>
				<td><?php $bl_portion=($bdt_amount*(100-$get_record->RATIO))/100; echo number_format($bl_portion,2);?></td>
				<td><?php $vat=$bl_portion/(1.15)*(0.15); echo number_format($vat,2);?></td>
				<td><?php $bl_revenue=$bl_portion-$vat; echo number_format($bl_revenue,2);?></td>
			</tr>
		</table>
	</div>
</body>
</html>
