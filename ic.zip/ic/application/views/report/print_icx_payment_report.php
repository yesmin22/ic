<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IGW Report</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }

		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<?php
			// $global_cut_of=$get_record[0]->MAX_DAY;
			?>
			<h3 style="margin-left:650px;">Banglalink Data</h3>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>	
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?>
				<?php echo $blanck_row; ?> 
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=2; style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">DIFFERENCE</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" colspan=3; style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">BL CALCULATION</td>
					<td class="brlt2" colspan=2; style="width:30px;border-right:2px solid #cccccc;" bgcolor="#E6E6FA">PAYMENT</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"> ICX Operator Name</td>
					<td class="brlt2" style="width:30px;">IGW</td>
					<td class="brt2" style="width:80px;"> IGW Invoice</td>
					<td class="brt2" style="width:60px;"> ICX Data</td>
					<td class="brt2" style="width:100px;"> BDT</td>
					<td class="brt2" style="width:120px;"> %age</td>
					<td class="brrt2" style="width:250px;"> ICX Data received</td>
					<td class="brt2" style="width:60px;"> BL vs ICX dispute</td>
					<td class="brt2" style="width:60px;"> BL AMOUNT with ICX call ratio</td>
					<td class="brt2" style="width:110px;">diff</td>
					<td class="brt2" style="width:110px;"> BL VS IOS DISPUTE</td>
					<td class="brt2" style="width:700px;"> Amount considered</td>
					<td class="brt2" style="width:70px;"> Data considered</td>
				</tr>
				<?php 
				$total_bl_dispute=0;
				$total_igw_invoice=0;
				$total_icx_data=0;
				$total_diff_igw_icx=0;
				$total_age=0;
				$total_icx_call_ratio=0;
				$total_diff=0;
				$total_BL_VS_IOS_DISPUTE=0;
				$total_amount_considered=0;
				foreach($get_record as $k=>$v){
					$icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=round((($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100),2);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=round((($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100),2);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=round(($bl_y_value + $z_of_15),2);
					$bl_dispute=round(((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100),2);
					$total_bl_dispute=$total_bl_dispute+$bl_dispute;
					//dd($bl_amount);
				}
				
				foreach($get_record as $k=>$v){
					$diffrence_between_bl_icx_invoice_value_of_z=$v->IGW_INVOICE_VALUE_OF_Z-$v->BL_TOTAL_ICX_PORTION;
					$BL_vs_ICX_dispute=round((($diffrence_between_bl_icx_invoice_value_of_z/$v->BL_TOTAL_ICX_PORTION)*100),2);
				  $bl_total_invoice_amount=$v->BL_TOTAL_Y_VALUE+$v->BL_TOTAL_IGW_PORTION;
				  $icx_y_value_ratio=(($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100);
				  $bl_y_value=round((($v->BL_TOTAL_Y_VALUE * $icx_y_value_ratio)/100),2);
				  $icx_x_value_ratio=(($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100);
				  $bl_x_value=round((($v->BL_TOTAL_X_VALUE*$icx_x_value_ratio)/100),2);
				  $bl_z_value=$bl_x_value-$bl_y_value;
				  $z_of_15=(($bl_z_value*15)/100);
				  $bl_amount=round(($bl_y_value + $z_of_15),2);
				  $bl_dispute=round(((($v->IGW_INVOICE_AMOUNT-$bl_amount)/($bl_amount))*100),2);
				?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->ICX_ICX;?></td>
					<td class="brlt2" style="width:30px;"><?php echo $v->ICX_IGW;?></td>
					<td class="brt2" style="width:250px;"><?php if($ICX!='BTCL'){echo round($v->ICX_INVOICE_AMOUNT,2);}?></td>
					<td class="brrt2" style="width:250px;"><?php if($ICX!='BTCL'){echo round($v->IGW_INVOICE_AMOUNT,2);}?></td>
					<td class="brt2" style="width:100px;"> <?php if($ICX!='BTCL'){echo round(($v->ICX_INVOICE_AMOUNT-$v->IGW_INVOICE_AMOUNT),2);}?></td>
					<td class="brrt2" style="width:120px;"> <?php if($ICX!='BTCL'){echo round(((($v->ICX_INVOICE_AMOUNT-$v->IGW_INVOICE_AMOUNT)/$v->IGW_INVOICE_AMOUNT)*100),2);}?>%</td>
					<td class="brt2" style="width:250px;"><?php if($ICX!='BTCL'){if($v->ICX_ICX && $v->ICX_TOTAL_Y_VALUE > 0 && $v->ICX_TOTAL_BILLED_DURATION_MINS > 0){echo 'YES';}else{echo "NO";}}?></td>
					<td class="brrt2" style="width:60px;"> <?php if($ICX!='BTCL'){echo $BL_vs_ICX_dispute;}?>%</td>
					<td class="brt2" style="width:60px;"><?php if($ICX!='BTCL'){echo $bl_amount;}?></td>
					<td class="brt2" style="width:110px;"><?php if($ICX!='BTCL'){echo round((($v->ICX_INVOICE_AMOUNT)-$bl_amount),2);}?></td>
					<td class="brt2" style="width:110px;"> <?php if($ICX!='BTCL'){echo $bl_dispute;}?>%</td>
					<td class="brt2" style="width:700px;"><?php if($ICX!='BTCL'){if($total_bl_dispute > 1){echo $bl_amount;}else{echo round($v->ICX_INVOICE_AMOUNT,2);}}?></td>
					<td class="brrt2" style="width:70px;"> <?php if($ICX!='BTCL'){if($total_bl_dispute > 1){echo "BL DATA";}else{echo "IGW DATA";}}?></td>
				</tr>	
			 <?php
		
			 
			  }?>
			 	<tr>
					<td class="" style="width:20px;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;"> Total VOICE</td>
					<td class="brt2" style="width:60px; border-bottom:1px solid #cccccc;"><?php echo $total_igw_invoice; ?></td>
					<td class="brrt2" style="width:100px; border-bottom:1px solid #cccccc;"><?php echo $total_icx_data; ?></td>
					<td class="brt2" style="width:120px; border-bottom:1px solid #cccccc;"><?php echo $total_diff_igw_icx; ?></td>
					<td class="brrt2" style="width:250px; border-bottom:1px solid #cccccc;"><?php echo $total_age; ?></td>
					<td class="brt2" style="width:60px; border-bottom:1px solid #cccccc;"></td>
					<td class="brrt2" style="width:60px; border-bottom:1px solid #cccccc;"></td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo $total_icx_call_ratio; ?></td>
					<td class="brt2" style="width:110px; border-bottom:1px solid #cccccc;"><?php echo $total_diff; ?></td>
					<td class="brt2" style="width:700px; border-bottom:1px solid #cccccc;"><?php echo $total_BL_VS_IOS_DISPUTE; ?></td>
					<td class="brt2" style="width:70px; border-bottom:1px solid #cccccc;"><?php echo  $total_amount_considered; ?></td>
					<td class="brrt2" style="width:60px; border-bottom:1px solid #cccccc;"></td>
				</tr>
			</table>
		</div>
	</body>
</html>




































