
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 9 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Provision Report for MOMMS";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Rate per event</th>
						<th>Amount</th>
						<th>VAT</th>
						<th>Total Amount</th>
					
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$amount_total = 0;
					$total_amount_total = 0;
					$gtc=0;
					$gtm=0;
					$gtt=0;
					$vt=0;
					$vat_total=0;
					foreach($get_record as $k=>$v): 
					$number_of_calls=$v->NUMBER_OF_CALLS;
					$rate_per_event=$v->RATE_PER_EVENT;
					$amount=$v->AMOUNT;
					$vat=($amount*$Vat)/100;
					$total_amount=$amount+$vat;
					?>
					<tr>
						<td><?php echo $v->OPERATOR; ?></td> 
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td align="right"><?php echo number_format($number_of_calls,2); $total_no_calls += $number_of_calls; $gtc += $number_of_calls;?></td>
						<td align="right"><?php echo number_format($rate_per_event,2);?></td>
						<td align="right"><?php echo number_format($amount,2); $amount_total += $amount; $gtm += $amount;?></td>
						<td align="right"><?php echo number_format($vat,2); $vat_total += $vat; $vt += $amount;?></td>
						<td align="right"><?php echo number_format($total_amount,2); $total_amount_total += $total_amount; $gtt += $total_amount;?></td>
					</tr>
					
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->OPERATOR != $get_record[$k + 1]->OPERATOR){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($amount_total,2); $amount_total = 0; ?></td> 
						<td align="right"><?php echo number_format($vat_total,2); $vat_total = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount_total,2); $total_amount_total = 0; ?></td>
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				 <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($amount_total,2); $amount_total = 0; ?></td> 
						<td align="right"><?php echo number_format($vat_total,2); $vat_total = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount_total,2); $total_amount_total = 0; ?></td>
					</tr>
					</tr>
				    <?php }?>
					
					
					<?php endforeach; ?>
					
					
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtc,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($gtm,2); ?></td>
						<td align="right"><?php echo number_format($vt,2); ?></td>
						<td align="right"><?php echo number_format($gtt,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>

		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;">Interconnection Provision Report for IMMS Extrapuleted</div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Rate per event</th>
						<th>Amount</th>
						<th>VAT</th>
						<th>Total Amount</th>
					
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_calls = 0;
					$amount_total = 0;
					$total_amount_total = 0;
					$gtc=0;
					$gtm=0;
					$gtt=0;
					foreach($get_record as $k=>$v): 
					$number_of_calls=($v->NUMBER_OF_CALLS / $v->MAX_DAY)*$v->LAST_DAY;
					$amount=($v->AMOUNT / $v->MAX_DAY)*$v->LAST_DAY;
					$vat=($amount*$Vat)/100;
					$total_amount=$amount+$vat;
					?>
					<tr>
						<td><?php echo $v->OPERATOR; ?></td> 
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td align="right"><?php echo number_format($number_of_calls,2); $total_no_calls += $number_of_calls; $gtc += $number_of_calls;?></td>
						<td align="right"><?php echo number_format($rate_per_event,2);?></td>
						<td align="right"><?php echo number_format($amount,2); $amount_total += $amount; $gtm += $amount;?></td>
						<td align="right"><?php echo number_format($vat,2); $vat_total += $vat; $vt += $vat;?></td>
						<td align="right"><?php echo number_format($total_amount,2); $total_amount_total += $total_amount; $gtt += $total_amount;?></td>
					</tr>
					
					<?php if(isset($get_record[$k + 1]) && $get_record[$k]->OPERATOR != $get_record[$k + 1]->OPERATOR){ ?>
					<tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($amount_total,2); $amount_total = 0; ?></td> 
						<td align="right"><?php echo number_format($vat_total,2); $vat_total = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount_total,2); $total_amount_total = 0; ?></td>
					</tr>
				<?php } ?>
				<?php if(!isset($get_record[$k + 1])){?>
				 <tr style="background-color:#FFED4A;">
						<td>Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_calls,2); $total_no_calls = 0; ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($amount_total,2); $amount_total = 0; ?></td> 
						<td align="right"><?php echo number_format($vat_total,2); $vat_total = 0; ?></td> 
						<td align="right"><?php echo number_format($total_amount_total,2); $total_amount_total = 0; ?></td>
					</tr>
					</tr>
				    <?php }?>
					
					
					<?php endforeach; ?>
					
					
					<tr style="background-color:green;">
						<td>Grand Total</td>  
						<td></td>
						<td align="right"><?php echo number_format($gtc,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($gtm,2); ?></td>
						<td align="right"><?php echo number_format($vt,2); ?></td>
						<td align="right"><?php echo number_format($gtt,2); ?></td>
					</tr>
					</tbody>
			</table>
		</div>
	</body>
</html>