<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 36;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IGW Report</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:2px solid #000000; }
			.brtl2 { border-top:2px solid #000000; border-left:2px solid #000000; }
			.brtr2 { border-top:2px solid #000000; border-right:2px solid #000000; }
			.brr2 { border-right:2px solid #000000; }
			.brrt2 { border-right:2px solid #000000; border-top:2px solid #000000; }
			.brrb2 { border-right:2px solid #000000; border-bottom:2px solid #000000; }
			.brb2 { border-bottom:2px solid #000000; }
			.brl2 { border-left:2px solid #000000; }
			.brlt2 { border-left:2px solid #000000; border-top:2px solid #000000; }
			.brlb2 { border-left:2px solid #000000; border-bottom:2px solid #000000; }

		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			<div style="">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;color: coral;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;color: coral;"><?php echo $report_name; ?></td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
  	  </div>
			<?php
			$blanck_row = '<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
			?>
			<table class="table" width="100%" border="0" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row; ?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;border-right:2px solid #cccccc;background-color:yellow;">&nbsp;</td>
					<td class="brt2" colspan=5 style="width:80px;border-right:2px solid #cccccc;background-color:yellow;">From IGW</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" colspan=6 style="width:110px;background-color:yellow;border-right:2px solid #cccccc;">From ICX</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" colspan=5 style="width:110px;background-color:yellow;border-right:2px solid #cccccc;">Difference Between IGW & ICX data</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" colspan=5 style="width:110px;background-color:yellow;border-right:2px solid #cccccc;">%AGE of IGW & ICX data</td>
					
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Route Through ICX</td>
					<td class="brt2" style="width:80px;">MIN</td>
					<td class="brt2" style="width:60px;">X In BDT</td>
					<td class="brt2" style="width:100px;">Y In BDT</td>
					<td class="brt2" style="width:120px;">Z</td>
					<td class="brrt2" style="width:250px;">Y+15%Z</td>
					<td  style="width:60px;">&nbsp;</td>
					<td  style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px; border-left:2px solid #cccccc;">Inovice Status</td>
					<td class="brt2" style="width:110px;">MIN</td>
					<td class="brt2" style="width:700px;">X In BDT</td>
					<td class="brt2" style="width:70px;">Y In BDT</td>
					<td class="brt2" style="width:110px;">Z</td>
					<td class="brrt2" style="width:250px;">Y+15%Z</td>
					<td style="width:60px;">&nbsp;</td>
					<td style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px;border-left:2px solid #cccccc;">MIN</td>
					<td class="brt2" style="width:700px;">X In BDT</td>
					<td class="brt2" style="width:70px;">Y In BDT</td>
					<td class="brt2" style="width:110px;">Z</td>
					<td class="brrt2" style="width:250px;">Y+15%Z</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px;border-left:2px solid #cccccc;">MIN</td>
					<td class="brt2" style="width:700px;">X In BDT</td>
					<td class="brt2" style="width:70px;">Y In BDT</td>
					<td class="brt2" style="width:110px;">Z</td>
					<td class="brrt2" style="width:250px;">Y+15%Z</td>
					
				</tr>
				<?php 
					$total_igw_min=0;
					$total_igw_x=0;
					$total_igw_y=0;
					$total_igw_z=0;
					$total_igw_z_invoice=0;
					$total_igw_invoice=0;
					$total_icx_min=0;
					$total_icx_x=0;
					$total_icx_y=0;
					$total_icx_z=0;
					$total_icx_z_invoice=0;
					$total_icx_invoice=0;
					$total_difference_min=0;
					$total_difference_x=0;
					$total_difference_y=0;
					$total_difference_z=0;
					$total_difference_z_invoice=0;
					$total_difference_invoice=0;
					$total_age_min=0;
					$total_age_x=0;
					$total_age_y=0;
					$total_age_z=0;
					$total_age_z_invoice=0;
					$total_age_invoice=0;
					$total_banglalink_min=0;
					$total_banglalink_x=0;
					$total_banglalink_y=0;
					$total_banglalink_z=0;
					$total_banglalink_z_invoice=0;
					$total_banglalink_invoice=0;
					$total_banglalink_diff_min=0;
					$total_banglalink_diff_x=0;
					$total_banglalink_diff_y=0;
					$total_banglalink_diff_z=0;
					$total_banglalink_diff_z_invoice=0;
					$total_banglalink_diff_invoice=0;
					$total_banglalink_age_min=0;
					$total_banglalink_age_x=0;
					$total_banglalink_age_y=0;
					$total_banglalink_age_z=0;
					$total_banglalink_age_z_invoice=0;
					$total_banglalink_age_invoice=0;
				  foreach($get_record as $k=>$v){
					$bl_charged_duration=$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
					if($v->ICX_BILLED_DURATION_MINS!=''||$v->ICX_BILLED_DURATION_MINS!=0){
						$icx_billed_duration_ratio=($v->ICX_BILLED_DURATION_MINS/$v->ICX_TOTAL_BILLED_DURATION_MINS)*100;
          	$bl_charged_duration_icx=(($bl_charged_duration*$icx_billed_duration_ratio)/100);
          }else{
          	$bl_charged_duration_icx=0;
          }
					$bl_total_x_value=$v->BL_TOTAL_X_VALUE;
					if($v->ICX_X_VALUE!=''||$v->ICX_X_VALUE!=0){
						$icx_x_value_ratio=($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100;
          	$bl_x_value_icx=(($bl_total_x_value*$icx_x_value_ratio)/100);
         	}else{
         		$bl_x_value_icx=0;
         	}
          $bl_total_y_value=$v->BL_TOTAL_Y_VALUE;
          if($v->ICX_Y_VALUE!=''||$v->ICX_Y_VALUE!=0){
						$icx_y_value_ratio=($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100;
          	$bl_y_value_icx=(($bl_total_y_value*$icx_y_value_ratio)/100);
          }else{
          	$bl_y_value_icx=0;
        	}
          $bl_total_z_value=$v->BL_TOTAL_Z_VALUE;
          if($v->ICX_Z_VALUE!=''||$v->ICX_Z_VALUE!=0){
						$icx_z_value_ratio=($v->ICX_Z_VALUE/$v->ICX_TOTAL_Z_VALUE)*100;
          	$bl_z_value_icx=(($bl_total_z_value*$icx_z_value_ratio)/100);
          }else{
        		$bl_z_value_icx=0;
        	}
          $bl_total_invoice_amount=$v->BL_TOTAL_Y_VALUE+$v->BL_TOTAL_IGW_PORTION;
          if($v->ICX_INVOICE_AMOUNT!=''||$v->ICX_INVOICE_AMOUNT!=0){
						$icx_invoice_ratio=($v->ICX_INVOICE_AMOUNT/$v->ICX_TOTAL_INVOICE_AMOUNT)*100;
          	$bl_invoice_amount_icx=(($bl_total_invoice_amount*$icx_invoice_ratio)/100);
        	}else{
        	 	$bl_invoice_amount_icx=0;
        	}
					?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->IGW_ICX;?></td>
					<td class="brt2" align="right"  style="width:80px;"><?php echo number_format($v->IGW_BILLED_DURATION_MINS,2);?></td>
					<td class="brt2" align="right"  style="width:60px;"><?php echo number_format($v->IGW_X_VALUE,2);?></td>
					<td class="brt2"  align="right" style="width:100px;"><?php echo number_format($v->IGW_Y_VALUE,2);?></td>
					<td class="brt2" align="right"  style="width:120px;"><?php echo number_format($v->IGW_Z_VALUE,2);?></td>
					<td class="brrt2" align="right"  style="width:250px;"><?php echo number_format($v->IGW_INVOICE_AMOUNT,2);?></td>
					<td  style="width:60px;">&nbsp;</td>
					<td  style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px;border-left:2px solid #cccccc;"><?php if($v->ICX_IGW=='' || $v->ICX_IGW==null){echo 'Not Received';}else{echo 'Received';}?></td>
					<td class="brt2" align="right"  style="width:110px;"><?php echo number_format($v->ICX_BILLED_DURATION_MINS,2);?></td>
					<td class="brt2" align="right"  style="width:700px;"><?php echo number_format($v->ICX_X_VALUE,2);?></td>
					<td class="brt2"  align="right" style="width:70px;"><?php echo number_format($v->ICX_Y_VALUE,2);?></td>
					<td class="brt2" align="right"  style="width:110px;"><?php echo number_format($v->ICX_Z_VALUE,2);?></td>
					<td class="brrt2" align="right"  style="width:250px;"><?php echo number_format($v->ICX_INVOICE_AMOUNT,2);?></td>
				  <td style="width:60px;">&nbsp;</td>
					<td style="width:60px;">&nbsp;</td>
					<td class="brt2"  align="right" style="width:110px;border-left:2px solid #cccccc;"><?php echo number_format(($v->IGW_BILLED_DURATION_MINS-$v->ICX_BILLED_DURATION_MINS),2);?></td>
					<td class="brt2"  align="right" style="width:700px;"><?php echo number_format(($v->IGW_X_VALUE-$v->ICX_X_VALUE),2);?></td>
					<td class="brt2"  align="right" style="width:70px;"><?php echo number_format(($v->IGW_Y_VALUE-$v->ICX_Y_VALUE),2);?></td>
					<td class="brt2"  align="right" style="width:110px;"><?php echo number_format(($v->IGW_Z_VALUE-$v->ICX_Z_VALUE),2);?></td>
					<td class="brrt2"  align="right" style="width:250px;"><?php echo number_format(($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT),2);?></td>		
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" align="right"  style="width:110px;border-left:2px solid #cccccc;"><?php if($v->ICX_BILLED_DURATION_MINS!=0){echo number_format(((($v->IGW_BILLED_DURATION_MINS-$v->ICX_BILLED_DURATION_MINS)/$v->ICX_BILLED_DURATION_MINS)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brt2" align="right"  style="width:700px;"><?php if($v->ICX_X_VALUE!=0){echo number_format(((($v->IGW_X_VALUE-$v->ICX_X_VALUE)/$v->ICX_X_VALUE)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brt2" align="right"  style="width:70px;"><?php if($v->ICX_Y_VALUE!=0){echo number_format(((($v->IGW_Y_VALUE-$v->ICX_Y_VALUE)/$v->ICX_Y_VALUE)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brt2" align="right"  style="width:110px;"><?php if($v->ICX_Z_VALUE!=0){echo number_format(((($v->IGW_Z_VALUE-$v->ICX_Z_VALUE)/$v->ICX_Z_VALUE)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brrt2" align="right"  style="width:250px;"><?php if($v->ICX_INVOICE_AMOUNT!=0){echo number_format(((($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT)/$v->ICX_INVOICE_AMOUNT)*100),2);}else{echo 0.00;}?>%</td>
				  
				</tr>
			 <?php 
			 	  $total_igw_min=$total_igw_min + $v->IGW_BILLED_DURATION_MINS;
					$total_igw_x=$total_igw_x + $v->IGW_X_VALUE;
					$total_igw_y=$total_igw_y + $v->IGW_Y_VALUE;
					$total_igw_z=$total_igw_z + $v->IGW_Z_VALUE;
					$total_igw_invoice=$total_igw_invoice +$v->IGW_INVOICE_AMOUNT;
					$total_icx_min=$total_icx_min + $v->ICX_BILLED_DURATION_MINS;
					$total_icx_x=$total_icx_x + $v->ICX_X_VALUE;
					$total_icx_y=$total_icx_y + $v->ICX_Y_VALUE;
					$total_icx_z=$total_icx_z + $v->ICX_Z_VALUE;
					$total_icx_invoice=$total_icx_invoice + $v->ICX_INVOICE_AMOUNT;
					$total_difference_min=$total_difference_min + ($v->IGW_BILLED_DURATION_MINS-$v->ICX_BILLED_DURATION_MINS);
					$total_difference_x=$total_difference_x +($v->IGW_X_VALUE-$v->ICX_X_VALUE);
					$total_difference_y=$total_difference_y + ($v->IGW_Y_VALUE-$v->ICX_Y_VALUE);
					$total_difference_z=$total_difference_z + ($v->IGW_Z_VALUE-$v->ICX_Z_VALUE);
					$total_difference_invoice=$total_difference_invoice + ($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT);
					$total_age_min=$total_age_min + (($total_difference_min/$total_icx_min)*100) ;
					$total_age_x=$total_age_x + (($total_difference_x/$total_icx_x)*100) ;
					$total_age_y=$total_difference_y + (($total_difference_y/$total_icx_y)*100);
					$total_age_z=$total_age_z + (($total_difference_z/$total_icx_z)*100);
					$total_age_invoice=$total_age_invoice+(($total_difference_invoice/$total_icx_invoice)*100);
					$total_banglalink_min=$total_banglalink_min + $bl_charged_duration_icx;
					$total_banglalink_x=$total_banglalink_x + $bl_x_value_icx;
					$total_banglalink_y=$total_banglalink_y + $bl_y_value_icx;
					$total_banglalink_z=$total_banglalink_z + $bl_z_value_icx;
					$total_banglalink_invoice=$total_banglalink_invoice +$bl_invoice_amount_icx;
					$total_banglalink_diff_min=$total_banglalink_diff_min + ($v->IGW_BILLED_DURATION_MINS-$bl_charged_duration_icx);
					$total_banglalink_diff_x=$total_banglalink_diff_x+ ($v->IGW_X_VALUE-$bl_x_value_icx);
					$total_banglalink_diff_y=$total_banglalink_diff_y+ ($v->IGW_Y_VALUE-$bl_y_value_icx);
					$total_banglalink_diff_z=$total_banglalink_diff_z+ ($v->IGW_Z_VALUE-$bl_z_value_icx);
					$total_banglalink_diff_invoice=$total_banglalink_diff_invoice+ ($v->IGW_INVOICE_AMOUNT-$bl_invoice_amount_icx);
					$total_banglalink_age_min=$total_banglalink_age_min+(($total_banglalink_diff_min/$total_banglalink_min)*100);
					$total_banglalink_age_x=$total_banglalink_age_x+(($total_banglalink_diff_x/$total_banglalink_x)*100);
					$total_banglalink_age_y=$total_banglalink_age_y+(($total_banglalink_diff_y/$total_banglalink_y)*100);
					$total_banglalink_age_z=$total_banglalink_age_z+(($total_banglalink_diff_z/$total_banglalink_z)*100);
					$total_banglalink_age_invoice=$total_banglalink_age_invoice+(($total_banglalink_diff_invoice/$total_banglalink_invoice)*100);
			  }?>
			 	<tr>
					<td class=""></td>
					<td class="brlb2" style="border-bottom:2px solid #cccccc;border-top:2px solid #cccccc;"></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_igw_min,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_igw_x,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_igw_y,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_igw_z,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_igw_invoice,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_icx_min,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_icx_x,2);?></td>
					<td class="brt2"  align="right"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_icx_y,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_icx_z,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_icx_invoice,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_difference_min,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_difference_x,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_difference_y,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_difference_z,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_difference_invoice,2);?></td>
					<td class="brt2" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_age_min,2);?>%</td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_age_x,2);?>%</td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_age_y,2);?>%</td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_age_z,2);?>%</td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_age_invoice,2);?>%</td>
					
				</tr>
			</table>
			<table class="table" width="100%" border="0" style="margin-top:30px" cellpadding="0" cellspacing="0">
				<?php echo $blanck_row;?>
				<tr>
					<td align="center" colspan="20">
						<div style="font-size:150%;color: coral;">Generate Banglalink Data from IGW Report</div>
					</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;background-color:yellow; border-right:2px solid #cccccc;">&nbsp;</td>
					<td class="brt2" colspan=6 style="width:80px;background-color:yellow;border-right:2px solid #cccccc;">From Banglalink IT</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" colspan=5 style="width:110px;background-color:yellow;border-right:2px solid #cccccc;">Difference between IGW & BL data</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" colspan=5 style="width:110px;background-color:yellow;border-right:2px solid #cccccc;">Percentage between IGW & BL data</td>
				</tr>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;">Route Through ICX</td>
					<td class="brt2" style="width:110px;">Inovice Status</td>
					<td class="brt2" style="width:110px;">MIN</td>
					<td class="brt2" style="width:700px;">X In BDT</td>
					<td class="brt2" style="width:70px;">Y In BDT</td>
					<td class="brt2" style="width:110px;">Z</td>
					<td class="brrt2" style="width:250px;">Y+15%Z</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px;border-left:2px solid #cccccc;">MIN</td>
					<td class="brt2" style="width:700px;">X In BDT</td>
					<td class="brt2" style="width:70px;">Y In BDT</td>
					<td class="brt2" style="width:110px;">Z</td>
					<td class="brrt2" style="width:250px;">Y+15%Z</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px;border-left:2px solid #cccccc;">MIN</td>
					<td class="brt2" style="width:700px;">X In BDT</td>
					<td class="brt2" style="width:70px;">Y In BDT</td>
					<td class="brt2" style="width:110px;">Z</td>
					<td class="brrt2" style="width:250px;">Y+15%Z</td>
				</tr>
				<?php 
					$total_igw_min=0;
					$total_igw_x=0;
					$total_igw_y=0;
					$total_igw_z=0;
					$total_igw_z_invoice=0;
					$total_igw_invoice=0;
					$total_icx_min=0;
					$total_icx_x=0;
					$total_icx_y=0;
					$total_icx_z=0;
					$total_icx_z_invoice=0;
					$total_icx_invoice=0;
					$total_difference_min=0;
					$total_difference_x=0;
					$total_difference_y=0;
					$total_difference_z=0;
					$total_difference_z_invoice=0;
					$total_difference_invoice=0;
					$total_age_min=0;
					$total_age_x=0;
					$total_age_y=0;
					$total_age_z=0;
					$total_age_z_invoice=0;
					$total_age_invoice=0;
					$total_banglalink_min=0;
					$total_banglalink_x=0;
					$total_banglalink_y=0;
					$total_banglalink_z=0;
					$total_banglalink_z_invoice=0;
					$total_banglalink_invoice=0;
					$total_banglalink_diff_min=0;
					$total_banglalink_diff_x=0;
					$total_banglalink_diff_y=0;
					$total_banglalink_diff_z=0;
					$total_banglalink_diff_z_invoice=0;
					$total_banglalink_diff_invoice=0;
					$total_banglalink_age_min=0;
					$total_banglalink_age_x=0;
					$total_banglalink_age_y=0;
					$total_banglalink_age_z=0;
					$total_banglalink_age_z_invoice=0;
					$total_banglalink_age_invoice=0;
				  foreach($get_record as $k=>$v){
					$bl_charged_duration=$v->BL_TOTAL_CHARGED_UNIT_IN_MIN;
					if($v->ICX_BILLED_DURATION_MINS!=''||$v->ICX_BILLED_DURATION_MINS!=0){
						$icx_billed_duration_ratio=($v->ICX_BILLED_DURATION_MINS/$v->ICX_TOTAL_BILLED_DURATION_MINS)*100;
          	$bl_charged_duration_icx=(($bl_charged_duration*$icx_billed_duration_ratio)/100);
          }else{
          	$bl_charged_duration_icx=0;
          }
					$bl_total_x_value=$v->BL_TOTAL_X_VALUE;
					if($v->ICX_X_VALUE!=''||$v->ICX_X_VALUE!=0){
						$icx_x_value_ratio=($v->ICX_X_VALUE/$v->ICX_TOTAL_X_VALUE)*100;
          	$bl_x_value_icx=(($bl_total_x_value*$icx_x_value_ratio)/100);
         	}else{
         		$bl_x_value_icx=0;
         	}
          $bl_total_y_value=$v->BL_TOTAL_Y_VALUE;
          if($v->ICX_Y_VALUE!=''||$v->ICX_Y_VALUE!=0){
						$icx_y_value_ratio=($v->ICX_Y_VALUE/$v->ICX_TOTAL_Y_VALUE)*100;
          	$bl_y_value_icx=(($bl_total_y_value*$icx_y_value_ratio)/100);
          }else{
          	$bl_y_value_icx=0;
        	}
          $bl_total_z_value=$v->BL_TOTAL_Z_VALUE;
          if($v->ICX_Z_VALUE!=''||$v->ICX_Z_VALUE!=0){
						$icx_z_value_ratio=($v->ICX_Z_VALUE/$v->ICX_TOTAL_Z_VALUE)*100;
          	$bl_z_value_icx=(($bl_total_z_value*$icx_z_value_ratio)/100);
          }else{
        		$bl_z_value_icx=0;
        	}
          $bl_total_invoice_amount=$v->BL_TOTAL_Y_VALUE+$v->BL_TOTAL_IGW_PORTION;
          if($v->ICX_INVOICE_AMOUNT!=''||$v->ICX_INVOICE_AMOUNT!=0){
						$icx_invoice_ratio=($v->ICX_INVOICE_AMOUNT/$v->ICX_TOTAL_INVOICE_AMOUNT)*100;
          	$bl_invoice_amount_icx=(($bl_total_invoice_amount*$icx_invoice_ratio)/100);
        	}else{
        	 	$bl_invoice_amount_icx=0;
        	}
					?>
				<tr>
					<td class="" style="width:20px;">&nbsp;</td>
					<td class="brlt2" style="width:30px;"><?php echo $v->IGW_ICX;?></td>
					
					<td class="brt2" style="width:110px;"><?php if($v->BL_TOTAL_NO_OF_CALLS=='' || $v->BL_TOTAL_X_VALUE==''||$v->BL_TOTAL_NO_OF_CALLS==0 || $v->BL_TOTAL_X_VALUE==0){echo 'Not Received';}else{echo 'Received';}?></td>
					<td class="brt2" style="width:110px;"><?php echo number_format($bl_charged_duration_icx,2);?></td>
					<td class="brt2" style="width:700px;"><?php echo number_format($bl_x_value_icx,2);?></td>
					<td class="brt2" style="width:70px;"><?php echo number_format($bl_y_value_icx,2);?></td>
					<td class="brt2" style="width:110px;"><?php echo number_format($bl_z_value_icx,2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format($bl_invoice_amount_icx,2);?></td>
				  <td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px;border-left:2px solid #cccccc;"><?php echo number_format(($v->IGW_BILLED_DURATION_MINS-$bl_charged_duration_icx),2);?></td>
					<td class="brt2" style="width:700px;"><?php echo number_format(($v->IGW_X_VALUE-$bl_x_value_icx),2);?></td>
					<td class="brt2" style="width:70px;"><?php echo number_format(($v->IGW_Y_VALUE-$bl_y_value_icx),2);?></td>
					<td class="brt2" style="width:110px;"><?php echo number_format(($v->IGW_Z_VALUE-$bl_z_value_icx),2);?></td>
					<td class="brrt2" style="width:250px;"><?php echo number_format(($v->IGW_INVOICE_AMOUNT-$bl_invoice_amount_icx),2);?></td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="" style="width:60px;">&nbsp;</td>
					<td class="brt2" style="width:110px;border-left:2px solid #cccccc;"><?php if($bl_charged_duration_icx!=0){echo number_format(((($v->IGW_BILLED_DURATION_MINS-$bl_charged_duration_icx)/$bl_charged_duration_icx)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brt2" style="width:700px;"><?php if($bl_x_value_icx!=0){echo number_format(((($v->IGW_X_VALUE-$bl_x_value_icx)/$bl_x_value_icx)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brt2" style="width:70px;"><?php if($bl_y_value_icx!=0){echo number_format(((($v->IGW_Y_VALUE-$bl_y_value_icx)/$bl_y_value_icx)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brt2" style="width:110px;"><?php if($bl_z_value_icx!=0){echo number_format(((($v->IGW_Z_VALUE-$bl_z_value_icx)/$bl_z_value_icx)*100),2);}else{echo 0.00;}?>%</td>
					<td class="brrt2" style="width:250px;"><?php if($bl_invoice_amount_icx!=0){echo number_format(((($v->IGW_INVOICE_AMOUNT-$bl_invoice_amount_icx)/$bl_invoice_amount_icx)*100),2);}else{echo 0.00;}?>%</td>
				</tr>
			 <?php 
			 	  $total_igw_min=$total_igw_min + $v->IGW_BILLED_DURATION_MINS;
					$total_igw_x=$total_igw_x + $v->IGW_X_VALUE;
					$total_igw_y=$total_igw_y + $v->IGW_Y_VALUE;
					$total_igw_z=$total_igw_z + $v->IGW_Z_VALUE;
					$total_igw_invoice=$total_igw_invoice +$v->IGW_INVOICE_AMOUNT;
					$total_icx_min=$total_icx_min + $v->ICX_BILLED_DURATION_MINS;
					$total_icx_x=$total_icx_x + $v->ICX_X_VALUE;
					$total_icx_y=$total_icx_y + $v->ICX_Y_VALUE;
					$total_icx_z=$total_icx_z + $v->ICX_Z_VALUE;
					$total_icx_invoice=$total_icx_invoice + $v->ICX_INVOICE_AMOUNT;
					$total_difference_min=$total_difference_min + ($v->IGW_BILLED_DURATION_MINS-$v->ICX_BILLED_DURATION_MINS);
					$total_difference_x=$total_difference_x +($v->IGW_X_VALUE-$v->ICX_X_VALUE);
					$total_difference_y=$total_difference_y + ($v->IGW_Y_VALUE-$v->ICX_Y_VALUE);
					$total_difference_z=$total_difference_z + ($v->IGW_Z_VALUE-$v->ICX_Z_VALUE);
					$total_difference_invoice=$total_difference_invoice + ($v->IGW_INVOICE_AMOUNT-$v->ICX_INVOICE_AMOUNT);
					$total_age_min=$total_age_min + (($total_difference_min/$total_icx_min)*100) ;
					$total_age_x=$total_age_x + (($total_difference_x/$total_icx_x)*100) ;
					$total_age_y=$total_difference_y + (($total_difference_y/$total_icx_y)*100);
					$total_age_z=$total_age_z + (($total_difference_z/$total_icx_z)*100);
					$total_age_invoice=$total_age_invoice+(($total_difference_invoice/$total_icx_invoice)*100);
					$total_banglalink_min=$total_banglalink_min + $bl_charged_duration_icx;
					$total_banglalink_x=$total_banglalink_x + $bl_x_value_icx;
					$total_banglalink_y=$total_banglalink_y + $bl_y_value_icx;
					$total_banglalink_z=$total_banglalink_z + $bl_z_value_icx;
					$total_banglalink_invoice=$total_banglalink_invoice +$bl_invoice_amount_icx;
					$total_banglalink_diff_min=$total_banglalink_diff_min + ($v->IGW_BILLED_DURATION_MINS-$bl_charged_duration_icx);
					$total_banglalink_diff_x=$total_banglalink_diff_x+ ($v->IGW_X_VALUE-$bl_x_value_icx);
					$total_banglalink_diff_y=$total_banglalink_diff_y+ ($v->IGW_Y_VALUE-$bl_y_value_icx);
					$total_banglalink_diff_z=$total_banglalink_diff_z+ ($v->IGW_Z_VALUE-$bl_z_value_icx);
					$total_banglalink_diff_invoice=$total_banglalink_diff_invoice+ ($v->IGW_INVOICE_AMOUNT-$bl_invoice_amount_icx);
					$total_banglalink_age_min=$total_banglalink_age_min+(($total_banglalink_diff_min/$total_banglalink_min)*100);
					$total_banglalink_age_x=$total_banglalink_age_x+(($total_banglalink_diff_x/$total_banglalink_x)*100);
					$total_banglalink_age_y=$total_banglalink_age_y+(($total_banglalink_diff_y/$total_banglalink_y)*100);
					$total_banglalink_age_z=$total_banglalink_age_z+(($total_banglalink_diff_z/$total_banglalink_z)*100);
					$total_banglalink_age_invoice=$total_banglalink_age_invoice+(($total_banglalink_diff_invoice/$total_banglalink_invoice)*100);
			  }?>
			 	<tr>
					<td class=""></td>
					<td class="brlb2" style="border-bottom:2px solid #cccccc;border-top:2px solid #cccccc;"></td>
					<td class="brt2" style="width:30px;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc;"> Total</td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_min,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_x,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_y,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_z,2);?></td>
					<td class="brt2"  align="right" style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_invoice,2);?></td>
					<td class="brt2" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_diff_min,2);?></td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_diff_x,2);?></td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_diff_y,2);?></td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_diff_z,2);?></td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_diff_invoice,2);?></td>
					<td class="brt2" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2" style="border-bottom:2px solid #cccccc;"></td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_age_min,2);?>%</td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_age_x,2);?>%</td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_age_y,2);?>%</td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;"><?php echo number_format($total_banglalink_age_z,2);?>%</td>
					<td class="brt2" align="right"  style="border-bottom:2px solid #cccccc;border-right:2px solid #cccccc;"><?php echo number_format($total_banglalink_age_invoice,2);?>%</td>
				</tr>
			</table>
		</div>
	</body>
</html>




































