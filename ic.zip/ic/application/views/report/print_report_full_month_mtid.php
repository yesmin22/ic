
<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 8 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Interconnect Revenue Sharing Report for MTID";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
					<thead>
						<tr>
						<th>IGW_NAME</th>
						<th>POST/PRE</th>
						<th>No of Calls </th>
						<th>Dur in Mins</th>
						<th>Rate USD</th>
						<th>Termin. Charge USD</th>
						<th>USD/BDT</th>
						<th> Termin. Charge BDT</th>
						<th>BL Revenue</th>
					</tr>
					</thead>
					<tbody>
					<?php 
					$total_no_call = 0;
					$total_min = 0;
					$total_ter_charge_usd = 0;
					$total_ter_charge_bdt = 0;
					$total_rev = 0;
					 ?>
					<?php //dd($get_record); ?>

					
					<?php foreach($get_record as $k=>$v): $total_record=count($get_record); ?>
					<tr>
						<td><?php echo $v->IOS; ?></td> 
						<td>POST</td> 
						<td align="right"><?php echo number_format($v->POST_NO_CALL,2);?></td>
						<td align="right"><?php echo number_format($v->POST_DURATION_IN_MIN,2); ?></td>
						<td align="right"><?php echo number_format($v->RATE_USD,2);?></td>
						<td align="right"><?php echo number_format($v->POST_TER_CHARGE_USD,2);?></td>
						<td align="right"><?php echo number_format($v->USD_BDT,2);?></td>
						<td align="right"><?php echo number_format($v->POST_TER_CHARGE_BDT,2);  ?></td>
						<td align="right"><?php echo number_format($v->POST_REVENUE,2);?></td>
					</tr>
					<tr>
						<td><?php echo $v->IOS; ?></td> 
						<td>PREP</td> 
						<td align="right"><?php echo number_format($v->PREP_NO_CALL,2);?></td>
						<td align="right"><?php echo number_format($v->PREP_DURATION_IN_MIN,2); ?></td>
						<td align="right"><?php echo number_format($v->RATE_USD,2);?></td>
						<td align="right"><?php echo number_format($v->PREP_TER_CHARGE_USD,2);?></td>
						<td align="right"><?php echo number_format($v->USD_BDT,2);?></td>
						<td align="right"><?php echo number_format($v->PREP_TER_CHARGE_BDT,2);  ?></td>
						<td align="right"><?php echo number_format($v->PREP_REVENUE,2);?></td>
					</tr>
					<tr style="background-color:yellow;">
						<td >Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format(($v->PREP_NO_CALL +$v->POST_NO_CALL),2); $total_no_call+= $v->PREP_NO_CALL +$v->POST_NO_CALL;?></td>
						<td align="right"><?php echo number_format(($v->PREP_DURATION_IN_MIN+$v->POST_DURATION_IN_MIN),2); $total_min+= $v->PREP_DURATION_IN_MIN+$v->POST_DURATION_IN_MIN;?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format(($v->PREP_TER_CHARGE_USD+$v->POST_TER_CHARGE_USD),2); $total_ter_charge_usd+= $v->PREP_TER_CHARGE_USD+$v->POST_TER_CHARGE_USD;?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format(($v->PREP_TER_CHARGE_BDT+$v->POST_TER_CHARGE_BDT),2); $total_ter_charge_bdt+= $v->PREP_TER_CHARGE_BDT+$v->POST_TER_CHARGE_BDT; ?></td>
						<td align="right"><?php echo number_format(($v->PREP_REVENUE+$v->POST_REVENUE),2); $total_rev+= $v->PREP_REVENUE+$v->POST_REVENUE;?></td>
					</tr>
					<?php endforeach; ?>
					
					<tr style="background-color:green;">
						<td >Grand Total</td> 
						<td></td> 
						<td align="right"><?php echo number_format($total_no_call,2);?></td>
						<td align="right"><?php echo number_format($total_min,2);?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($total_ter_charge_usd,2); ?></td>
						<td align="right"></td>
						<td align="right"><?php echo number_format($total_ter_charge_bdt,2);?></td>
						<td align="right"><?php echo number_format($total_rev,2);?></td>
					</tr>
					</tbody>
			</table>
		</div>
	</body>
</html>