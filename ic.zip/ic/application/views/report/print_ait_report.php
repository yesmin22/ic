<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
$report_name='AIT Report';
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Domestic SMS JV</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.bt {border-top:1px solid #000000;border-bottom:1px solid #000000;}
			.brt1 { border-top:1px solid #000000; }
			.brr1 { border-right:1px solid #000000; }
			.brb1 { border-bottom:1px solid #000000; }
			.brl1 { border-left:1px solid #000000; }
			.brt2 { border-top:1px solid #000000; }
			.brtl2 { border-top:1px solid #000000; border-left:1px solid #000000; }
			.brtr2 { border-top:1px solid #000000; border-right:1px solid #000000; }
			.brr2 { border-right:1px solid #000000; }
			.brrt2 { border-right:1px solid #000000; border-top:1px solid #000000; }
			.brrb2 { border-right:1px solid #000000; border-bottom:1px solid #000000; }
			.brb2 { border-bottom:1px solid #000000; }
			.brl2 { border-left:1px solid #000000; }
			.brlt2 { border-left:1px solid #000000; border-top:1px solid #000000; }
			.brlb2 { border-left:1px solid #000000; border-bottom:1px solid #000000; }
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
<body>
	<!--<a id="print_icon" href="#">Print</a>-->
	<div id="printArea">

		<div class="container">
			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td align="center" colspan="<?php echo $total_column; ?>">
							<div style="font-size:150%;"><?php echo $domain_name; ?></div>
						</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr style="border-top:1px solid #ccc;">
						<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
					</tr>
					<tr>
						<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
					</tr>
					<tr><td>&nbsp;</td></tr>
				</table>
			</div>

			
			<div class="row">
				
				 <table class="table table-bordered" style="style:100%;margin-left:350px">
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">Account</td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;"> DR. </td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;"> CR </td>
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">Description</td>
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">AIT</td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;"> &nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;"> &nbsp;</td>
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">AIT IC </td>
						</tr>
						 <?php //dd($get_record);
				 
				 foreach($get_record as $k => $v){
				 ?>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">01.101.A000.<?php if($v->INVOICE_GL){echo $v->INVOICE_GL; }?>.0000.<?php if($v->PROJECT_CODE){echo $v->PROJECT_CODE; }?>.0000</td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;"> -</td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;"><?php if($v->AIT){echo $v->AIT; }?></td>
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">AIT IC <?php if($v->OPERATOR_NAME){echo $v->OPERATOR_NAME; }?> Bill_Collection for <?php  $invoice_number=$v->INVOICE_NUMBER;$invoice_array=explode(" ",$invoice_number);  $last_key = key( array_slice( $invoice_array, -1, 1, TRUE ) ); $invoice_date=$invoice_array[$last_key]; echo date('"F Y"', strtotime($invoice_date)); if($v->AIT_COMMENT){echo '('.$v->AIT_COMMENT.')';};?> </td>
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">01.101.A000.1019651.0000.0000.0000</td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;"> <?php if($v->AIT){echo $v->AIT; }?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">-</td>
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #000000;border-bottom:1px solid #000000;border-left:1px solid #000000;border-right:1px solid #000000;">AIT IC <?php if($v->OPERATOR_NAME){echo $v->OPERATOR_NAME; }?> Bill_Collection for <?php  $invoice_number=$v->INVOICE_NUMBER;$invoice_array=explode(" ",$invoice_number);  $last_key = key( array_slice( $invoice_array, -1, 1, TRUE ) ); $invoice_date=$invoice_array[$last_key]; echo date('"F Y"', strtotime($invoice_date)); if($v->AIT_COMMENT){echo '('.$v->AIT_COMMENT.')';};?></td>
						</tr>
				 <?php } ?>
				 </table>
			</div>
		</div>
		
	</div>
</body>
</html>





















































