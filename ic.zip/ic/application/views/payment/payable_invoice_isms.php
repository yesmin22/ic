<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Payable Invoice IGW</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper" >
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">
			<div class="page_caption">Create Invoice for IGW</div>
			<div class="page_body" style="margin-left:20px;margin-right:20px">
				
					<fieldset class="divider"><legend>Please select an operator to create an invoice</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_payable_invoice_icx" method="post" action="" data-parsley-validate enctype="multipart/form-data" >
						<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<?php  $operator=$this->db->query("SELECT * FROM TBL_OPERATOR")->result();?>
						<table width="100%">
							<tr>
								<td>
									<div class="form_label">Operator Name*</div>
									<div>
										<select id="operator" name="OPERATOR" class="input_full input_style" required>
											<option value="">Select One</option>
											<?php foreach( $operator as $a_operator){ ?>
											
											<option value="<?php echo $a_operator->OPERATOR_NAME;?>"><?php echo $a_operator->OPERATOR_NAME;?></option>
											
											
											<?php }?>
										</select>
										<span	class="fred"><?php //echo form_error('OPERATOR'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
										<input type="text" id="BILL_MONTH" name="BILL_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('REPORT_DATE',strtotime($edit['REPORT_DATE'])); ?>" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td>
									<div class="form_label">Supplire Code*</div>
									<div>
										<input id="supplier_code" name="SUPPLIER_CODE" type="text" class="input_full input_style" value="<?php echo set_value('SUPPLIER_CODE',$edit['SUPPLIER_CODE']); ?>" />
										<span	class="fred"><?php echo form_error('SUPPLIER_CODE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Invoice Number*</div>
									<div>
										<input id="invoice_number" name="INVOICE_NUMBER" type="text" class="input_full input_style" value="<?php echo set_value('INVOICE_NUMBER',$edit['INVOICE_NUMBER']); ?>" required />
										<span	class="fred"><?php echo form_error('INVOICE_NUMBER'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Expenses Euro *</div>
									<div>
										<input id="expenses_euro" name="EXPENSES_EURO" type="text" class="input_full input_style" value="<?php echo set_value('EXPENSES_EURO',$edit['EXPENSES_EURO']); ?>" required />
										<span	class="fred"><?php echo form_error('EXPENSES_EURO'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Revenue Euro *</div>
									<div>
										<input id="revenue_euro" name="REVENUE_EURO" type="text" class="input_full input_style" value="<?php echo set_value('REVENUE_EURO',$edit['REVENUE_EURO']); ?>" required />
										<span	class="fred"><?php echo form_error('REVENUE_EURO'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Net Expense Euro *</div>
									<div>
										<input id="net_expense_euro" name="NET_EXPENSE_EURO" type="text" class="input_full input_style" value="<?php echo set_value('NET_EXPENSE_EURO',$edit['NET_EXPENSE_EURO']); ?>" required />
										<span	class="fred"><?php echo form_error('NET_EXPENSE_EURO'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Euro to Tk covertion rate *</div>
									<div>
										<input id="euro_to_tk_covertion_rate" name="EURO_TO_TK_COVERTION_RATE" type="text" class="input_full input_style" value="<?php echo set_value('EURO_TO_TK_COVERTION_RATE',$edit['EURO_TO_TK_COVERTION_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('EURO_TO_TK_COVERTION_RATE'); ?></span>
									</div>
								</td>
							</tr>
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">Expenses Tk *</div>
									<div>
										<input id="expenses_tk" name="EXPENSES_TK" type="text" class="input_full input_style" value="<?php echo set_value('EXPENSES_TK',$edit['EXPENSES_TK']); ?>" required />
										<span	class="fred"><?php echo form_error('EXPENSES_TK'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Revenue Tk *</div>
									<div>
										<input id="revenue_tk" name="REVENUE_TK" type="text" class="input_full input_style" value="<?php echo set_value('REVENUE_TK',$edit['REVENUE_TK']); ?>" required />
										<span	class="fred"><?php echo form_error('REVENUE_TK'); ?></span>
									</div>
								</td>	
								<td>
									<div class="form_label">Net Expense Tk *</div>
									<div>
										<input id="net_expense_tk" name="NET_EXPENSE_TK" type="text" class="input_full input_style" value="<?php echo set_value('NET_EXPENSE_TK',$edit['NET_EXPENSE_TK']); ?>" required />
										<span	class="fred"><?php echo form_error('NET_EXPENSE_TK'); ?></span>
									</div>
								</td>	
								<td>
									<div class="form_label">USD to Tk covertion rate *</div>
									<div>
										<input id="usd_to_tk_covertion_rate" name="USD_TO_TK_COVERTION_RATE" type="text" class="input_full input_style" value="<?php echo set_value('USD_TO_TK_COVERTION_RATE',$edit['USD_TO_TK_COVERTION_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('USD_TO_TK_COVERTION_RATE'); ?></span>
									</div>
								</td>						
							</tr>				
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">Expenses USD *</div>
									<div>
										<input id="expenses_usd" name="EXPENSES_USD" type="text" class="input_full input_style" value="<?php echo set_value('EXPENSES_USD',$edit['EXPENSES_USD']); ?>" required />
										<span	class="fred"><?php echo form_error('EXPENSES_USD'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Revenue USD *</div>
									<div>
										<input id="revenue_usd" name="REVENUE_USD" type="text" class="input_full input_style" value="<?php echo set_value('REVENUE_USD',$edit['REVENUE_USD']); ?>" required />
										<span	class="fred"><?php echo form_error('REVENUE_USD'); ?></span>
									</div>
								</td>
								<td colspan=2>
									<div class="form_label">Net Expense USD *</div>
									<div>
										<input id="net_expense_usd" name="NET_EXPENSE_USD" type="text" class="input_full input_style" value="<?php echo set_value('NET_EXPENSE_USD',$edit['NET_EXPENSE_USD']); ?>" required />
										<span	class="fred"><?php echo form_error('NET_EXPENSE_USD'); ?></span>
									</div>
								</td>
								
							</tr>	
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">B2B Cost Ratio *</div>
									<div>
										<input id="b2b_cost_ratio" name="B2B_COST_RATIO" type="text" class="input_full input_style" value="<?php echo set_value('B2B_COST_RATIO',$edit['B2B_COST_RATIO']); ?>" required />
										<span	class="fred"><?php echo form_error('B2B_COST_RATIO'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">B2B Revenue Ratio *</div>
									<div>
										<input id="b2b_revenue_ratio" name="B2B_REVENUE_RATIO" type="text" class="input_full input_style" value="<?php echo set_value('B2B_REVENUE_RATIO',$edit['B2B_REVENUE_RATIO']); ?>" required />
										<span	class="fred"><?php echo form_error('B2B_REVENUE_RATIO'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">B2C Cost Ratio *</div>
									<div>
										<input id="b2c_cost_ratio" name="B2C_COST_RATIO" type="text" class="input_full input_style" value="<?php echo set_value('B2C_COST_RATIO',$edit['B2C_COST_RATIO']); ?>" required />
										<span	class="fred"><?php echo form_error('B2C_COST_RATIO'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">B2C Revenue Ratio *</div>
									<div>
										<input id="b2c_revenue_ratio" name="B2C_REVENUE_RATIO" type="text" class="input_full input_style" value="<?php echo set_value('B2C_REVENUE_RATIO',$edit['B2C_REVENUE_RATIO']); ?>" required />
										<span	class="fred"><?php echo form_error('B2C_REVENUE_RATIO'); ?></span>
									</div>
								</td>
								
							</tr>	
							<tr>
								<td colspan=4>
									<div>
										<input type="submit" name="Submit" class="btn_gray" value="Submit" />
									</div>
								</td>
							</tr>
						</table>
					</form>
				<div class="float_clear_full">&nbsp;</div>
			</div>	
		</div><!--end #page_create_role -->
		<div id="footer_container" ><?php include(APPPATH."views/footer.php"); ?></div>	
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
		 	/*$("#operator").on("change",function(){
		 		var op_name = $(this).val();
		 		var urlinfo=url_prefix + "get_supplier_code"
		 		if(op_name==""){
		 			return false;
		 		}		 		
		 		var token = $('#token').val();
		 		var spinner = $(".spinner").show();
		 		spinner.show();		
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { op_name: op_name, csrf_webspice_tkn: token }
		 		}).done(function(rslt){
		 			obj = JSON.parse(rslt);
		 			$("#supplier_code").val(obj.SUPPLIER_CODE);
		 			
		 			spinner.hide();
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});	
		 		return false;
		 	})  */
		 	$("#expenses_euro,#revenue_euro").on("change",function(){
		 		expenses_euro=$('#expenses_euro').val();
        if(!expenses_euro){
        	expenses_euro=0;
        }
		 		revenue_euro=$('#revenue_euro').val();
		 		if(!revenue_euro){
		 			revenue_euro=0;
		 	  }
		 		net_expense_euro=expenses_euro-revenue_euro;
		 		$("#net_expense_euro").val(net_expense_euro.toFixed(2));
		 	})
		 	$("#expenses_euro,#euro_to_tk_covertion_rate").on("change",function(){
		 		expenses_euro=$('#expenses_euro').val();
		 		if(!expenses_euro){
		 			expenses_euro=0;
		 		}
		 		euro_to_tk_covertion_rate=$('#euro_to_tk_covertion_rate').val();
		 		if(!euro_to_tk_covertion_rate){
		 			euro_to_tk_covertion_rate=0;
		 		}
		 		expenses_tk=expenses_euro * euro_to_tk_covertion_rate;
		 		$("#expenses_tk").val(expenses_tk.toFixed(2));
		  })
		  $("#revenue_euro,#euro_to_tk_covertion_rate").on("change",function(){
		  	revenue_euro=$('#revenue_euro').val();
		  	if(!revenue_euro){
		  		revenue_euro=0;
		  	}
		 		euro_to_tk_covertion_rate=$('#euro_to_tk_covertion_rate').val();
		 		revenue_tk=revenue_euro * euro_to_tk_covertion_rate;
		 		$("#revenue_tk").val(revenue_tk.toFixed(2));
		  })
		  $("net_expense_euro,#euro_to_tk_covertion_rate").on("change",function(){
		  	net_expense_euro=$('#net_expense_euro').val();
		  	if(!net_expense_euro){
		  		net_expense_euro=0;
		  	}
		 		euro_to_tk_covertion_rate=$('#euro_to_tk_covertion_rate').val();
		 		if(!euro_to_tk_covertion_rate){
		 			euro_to_tk_covertion_rate=0;
		 		}
		 		net_expense_tk=net_expense_euro * euro_to_tk_covertion_rate;
		 		$("#net_expense_tk").val(net_expense_tk.toFixed(2));
		  })
		  
		  
		  
		  $("#expenses_euro,#euro_to_tk_covertion_rate,#expenses_tk,#usd_to_tk_covertion_rate").on("change",function(){
		 		expenses_tk=$('#expenses_tk').val();
		 		if(!expenses_tk){
		 			expenses_tk=0;
		 		}
		 		usd_to_tk_covertion_rate=$('#usd_to_tk_covertion_rate').val();
		 		if(!usd_to_tk_covertion_rate){
		 			usd_to_tk_covertion_rate=0;
		 		}
		 		expenses_usd=expenses_tk / usd_to_tk_covertion_rate;
		 		$("#expenses_usd").val(expenses_usd.toFixed(2));
		  })
		  
		   $("#revenue_euro,#euro_to_tk_covertion_rate,#revenue_tk,#usd_to_tk_covertion_rate").on("change",function(){
		 		revenue_tk=$('#revenue_tk').val();
		 		if(!revenue_tk){
		 			revenue_tk=0;
		 		}
		 		usd_to_tk_covertion_rate=$('#usd_to_tk_covertion_rate').val();
		 		if(!usd_to_tk_covertion_rate){
		 			usd_to_tk_covertion_rate=0;
		 		}
		 		revenue_usd=revenue_tk / usd_to_tk_covertion_rate;
		 		$("#revenue_usd").val(revenue_usd.toFixed(2));
		  })
		   $("#net_expense_euro,#euro_to_tk_covertion_rate,#net_expense_tk,#usd_to_tk_covertion_rate").on("change",function(){
		 		net_expense_tk=$('#net_expense_tk').val();
		 		if(!net_expense_tk){
		 			net_expense_tk=0;
		 		}
		 		usd_to_tk_covertion_rate=$('#usd_to_tk_covertion_rate').val();
		 		if(!usd_to_tk_covertion_rate){
		 			usd_to_tk_covertion_rate=0;
		 		}
		 		net_expense_usd=revenue_tk / usd_to_tk_covertion_rate;
		 		$("#net_expense_usd").val(net_expense_usd.toFixed(2));
		  })
		});
 </script>
</body>
</html>