<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
$report_name='Payable Invoice ICX Report';
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Journal for MTMMS</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #CCCCCC; }
			.brr1 { border-right:1px solid #CCCCCC; }
			.brb1 { border-bottom:1px solid #CCCCCC; }
			.brl1 { border-left:1px solid #CCCCCC; }
			.brt2 { border-top:2px solid #CCCCCC; }
			.brtl2 { border-top:2px solid #CCCCCC; border-left:2px solid #CCCCCC; }
			.brtr2 { border-top:2px solid #CCCCCC; border-right:2px solid #CCCCCC; }
			.brr2 { border-right:2px solid #CCCCCC; }
			.brrt2 { border-right:2px solid #CCCCCC; border-top:2px solid #CCCCCC; }
			.brrb2 { border-right:2px solid #CCCCCC; border-bottom:2px solid #CCCCCC; }
			.brb2 { border-bottom:2px solid #CCCCCC; }
			.brl2 { border-left:2px solid #CCCCCC; }
			.brlt2 { border-left:2px solid #CCCCCC; border-top:2px solid #CCCCCC; }
			.brlb2 { border-left:2px solid #CCCCCC; border-bottom:2px solid #CCCCCC; }
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
<body>
	<!--<a id="print_icon" href="#">Print</a>-->
	<div id="printArea">

		<div class="container">
			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td align="center" colspan="<?php echo $total_column; ?>">
							<div style="font-size:150%;"><?php echo $domain_name; ?></div>
						</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr style="border-top:1px solid #ccc;">
						<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
					</tr>
					<tr>
						<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp;<?php if(isset($filter_by)): ?>|&nbsp;<?php echo $filter_by; endif;?></td>
					</tr>
					<tr><td>&nbsp;</td></tr>
				</table>
			</div>
				
		<?php  $invoice_amount = $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE;?>

			
			<div class="row" style="margin-top:80px">
				 <table class="table table-borderless">
			 	     <tr>
			 	       <td>Inv. Date</td>
			 	       <td><?php echo date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
			 	     </tr>
				     <tr>
				       <td>Inv. Ref:</td>
				       <td><?php echo $record->OPERATOR ?>/ DOM /ICX/<?php echo $record->INVOICE_NUMBER ?></td>
				     </tr>
				     <tr>
				       <td>Inv. Amount: Tk.</td>
				       <td><?php echo number_format($invoice_amount,2); ?></td>
				     </tr>
				 </table>
			</div>
			<div class="row">
				<h5>Distribution Line:</h5>
				 <table class="table table-bordered">
				 
				 <tr>
							
							<td colspan="4" class="text-center">Actual Amount</td>
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">%age of Gross</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Bill Amount</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">VAT</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Tax @ <?php echo $record->TAX_RATE;?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
							<td style="mso-number-format:'\@';"><td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Postpaid</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Prepaid</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Adjustment</td>
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">100.00%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $invoice_amount = $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE ; echo number_format($invoice_amount,2) ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $vat = $record->VAT; echo number_format($vat,2);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">-<?php $tax = $record->TAX; echo number_format($tax,2);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $total_amount = $record->TOTAL_AMOUNT; echo number_format($total_amount,2);?></td>
							<td style="mso-number-format:'\@';"><td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"></td>
						</tr>
						
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">0.00%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">-</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">-</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">-</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">-</td>
							<td style="mso-number-format:'\@';"><td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $post_voice_bl = $record->POST_VOICE_BL; echo number_format($post_voice_bl,2); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $pre_voice_bl = $record->PRE_VOICE_BL;echo number_format($pre_voice_bl,2); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $total_amount_bl = $record->TOTAL_BL_AMOUNT; echo number_format($total_amount_bl,2);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adjustment_bl = $record->ADJUSTMENT; echo number_format($adjustment_bl,2);?></td>
						</tr>
						
		
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';"><td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';"><td>
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Ratio</td>
							
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';"><td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC" align="right"><?php $post_ratio=(($post_voice_bl/$total_amount_bl)*100); echo number_format($post_ratio,2);?>%</td>
							<td  style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC" align="right"><?php $pre_ratio=(($pre_voice_bl/$total_amount_bl)*100); echo number_format($pre_ratio,2);?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC"></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC" align="right"><?php echo number_format(($post_ratio+$pre_ratio),2);?>%</td>
						</tr>
						
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';"><td>
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Adjustment Taka</td>
							
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">&nbsp;</td>
							<td style="mso-number-format:'\@';"><td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC" align="right"><?php $post_adjustment=($adjustment_bl*$post_ratio)/100; if(0>$post_adjustment){echo'(';} echo number_format(abs($post_adjustment),2);if(0>$post_adjustment){echo')';}?></td>
							<td  style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC" align="right"><?php $pre_adjustment=($adjustment_bl*$pre_ratio)/100; if(0>$pre_adjustment){echo'(';} echo number_format(abs($pre_adjustment),2); if(0>$pre_adjustment){echo')';}?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC"></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC" align="right"><?php if(0>($post_adjustment+$pre_adjustment)){echo '('; } echo number_format(abs($post_adjustment+$pre_adjustment),2);if(0>($post_adjustment+$pre_adjustment)){echo ')'; }?></td>
						</tr>
						
						
							<?php $invoice_vat=$record->VAT; $invoice_tax = $record->TAX;if($record->ADJUSTMENT_BACKLOG > 0 ){?>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td align="right"><?php echo number_format($record->ADJUSTMENT_BACKLOG,2);?></td>
							<td align="right"><?php echo  number_format($record->ADJUSTMENT_BACKLOG,2);?></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<td style="border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-top:1px solid #CCCCCC;">Total Invoice</td>    
							<td align="right"><?php  $invoice_amount = $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE; echo number_format($invoice_amount,2); ?></td>
							<td align="right"><?php   echo number_format($invoice_vat,2); ?></td>
							<td align="right"><?php if((-$invoice_tax+$record->ADJUSTMENT_BACKLOG)<0){echo '(';}?> <?php $invoice_tax = $record->TAX; echo number_format(-$invoice_tax+$record->ADJUSTMENT_BACKLOG,2); ?><?php if((-$invoice_tax+$record->ADJUSTMENT_BACKLOG)<0){echo ')';}?></td>
							<td align="right"><?php $total_amount = $record->TOTAL_AMOUNT; echo number_format($total_amount+$record->ADJUSTMENT_BACKLOG,2);?></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<?php }else{?> 
						
						<tr>
							<td style="border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-top:1px solid #CCCCCC;">Total Invoice</td>
							<td align="right" style="border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-top:1px solid #CCCCCC;"><?php  $invoice_amount = $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE; echo number_format($invoice_amount,2); ?></td>
							<td align="right" style="border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-top:1px solid #CCCCCC;"><?php  echo number_format($invoice_vat,2); ?></td>
							<td align="right" style="border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-top:1px solid #CCCCCC;">(<?php  echo number_format($invoice_tax,2); ?>)</td>
							<td align="right" style="border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-top:1px solid #CCCCCC;"><?php $total_amount = $record->TOTAL_AMOUNT; echo number_format($total_amount,2);?></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<?php } ?>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
				 
				 
				 
				 
				 
				 
				 
				     <tr >
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; >A/C Code:</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; colspan="3">Project Code</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>Taka</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>Paste the below</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>Paste the below</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC ;border-right:1px solid #CCCCCC";>Paste the below</td>
				     </tr>
				     <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>2012651</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>Liability -</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>Accrued Expenses - Interconnection</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; align="right"><?php echo $invoice_amount-$adjustment_bl;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.2012651.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->TAX_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC ;border-right:1px solid #CCCCCC";><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>5012501</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";> Expenses - </td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";> Interconnection Expenses - Postpaid</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; align="right"><?php if(0>$post_adjustment){echo '(';} echo number_format(abs($post_adjustment),2); if(0>$post_adjustment){echo ')';}?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.5012501.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->TAX_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC ;border-right:1px solid #CCCCCC";><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>5011306</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>  Expenses - </td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";> Interconnection Expenses - Prepaid</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; align="right"><?php if(0>$pre_adjustment){echo '(';}?><?php echo number_format(abs($pre_adjustment),2);?><?php if(0>$pre_adjustment){echo ')';}?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.5011306.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->TAX_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC ;border-right:1px solid #CCCCCC";><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>1019602</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";> Assets -</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>VAT Current Account @ <?php echo $record->VAT_RATE;?>% (Auto Calculate)</td>			       
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; align="right"><?php if(0>$record->VAT){echo '(';}?><?php echo number_format(abs($record->VAT),2);?><?php if(0>$record->VAT){echo ')';}?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.1019602.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->TAX_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC ;border-right:1px solid #CCCCCC";><?php echo $record->VAT_CODE;?></td>
				     </tr>
				    <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>2018102</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";> Assets -</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>VAT Current Account @ <?php echo $record->VAT_RATE;?>% (Auto Calculate)</td>			       
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; align="right"><?php if(0>$record->TAX){echo '(';}?><?php echo number_format(abs($record->TAX),2);?><?php if(0>$record->TAX){echo ')';}?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.2018102.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->TAX_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-right:1px solid #CCCCCC";><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     	<?php if($record->ADJUSTMENT_BACKLOG > 0 ){?>
				     <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>AIT Adjustment (Previously Deducted 12% Instead of 7.5%)</td>			       
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; align="right">(<?php $negetive_backlog=(((-$record->ADJUSTMENT_BACKLOG)/$record->TAX_RATE)*100);echo number_format(abs($negetive_backlog));?>)</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.2018102.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->TAX_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";> AIT Adjustment (Previously Deducted 12% Instead of 7.5%)</td>			       
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC"; align="right"><?php $positive_backlog=((($record->ADJUSTMENT_BACKLOG)/$record->TAX_RATE)*100); echo number_format($positive_backlog,2);?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.2018102.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->TAX_CODE;?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td> 
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>AIT Adjustment @ 7.5% (Auto Calculate)</td>			       
				       <td align="right" style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";><?php $total_adjustment= (((($record->ADJUSTMENT_BACKLOG)/$record->TAX_RATE)*100)*$record->TAX_RATE)/100; echo number_format($total_adjustment,2);?></td>
				       <td style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC";>01.101.A000.2018102.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				     </tr>
				     <?php } ?>
				     	<?php if($record->ADJUSTMENT_BACKLOG > 0 ){?>
				     <tr>
				       <td colspan="4" style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC";>Total</td>
				       <td align="right" style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC; border-bottom:1px solid #CCCCCC";><?php echo number_format(( $total_adjustment + $positive_backlog + $negetive_backlog - $record->TAX + ( $invoice_amount-$adjustment_bl) + $post_adjustment + $pre_adjustment + $record->VAT), 2); ?></td>
				    	 <td colspan=3 style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC";></td>
				     </tr>
				     <?php }else{?>
				     <tr>
				       <td colspan="4" style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC; border-bottom:1px solid #CCCCCC";>Total</td>
				       <td align="right" style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC";><?php echo number_format(((( $invoice_amount-$adjustment_bl) + $post_adjustment + $pre_adjustment + $record->VAT )-( $record->TAX)), 2); ?></td>
				       <td colspan=3 style="border-left:1px solid #CCCCCC; border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-right:1px solid #CCCCCC";></td>
				     </tr>
				     <?php } ?>
				 </table>
			</div>
		</div>
		
	</div>
</body>
</html>























































