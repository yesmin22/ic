<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Payable Invoice Mobile</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper" >
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">
			<div class="page_caption">Create Invoice for Mobile</div>
			<div class="page_body" style="margin-left:20px;margin-right:20px">
				
					<fieldset class="divider"><legend>Please select an operator to create an invoice</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_payable_invoice_icx" method="post" action="" data-parsley-validate enctype="multipart/form-data" >
						<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<?php  $operator=$this->db->query("SELECT * FROM TBL_OPERATOR")->result();?>
						<table width="100%">
							<tr>
								<td colspan=2>
									<div class="form_label">Operator Name*</div>
									<div>
										<select id="operator" name="OPERATOR" class="input_full input_style" required>
											<option value="">Select One</option>
											<?php foreach( $operator as $a_operator){ ?>
											
											<option value="<?php echo $a_operator->OPERATOR_NAME.'|'.$a_operator->OPERATOR_TYPE;?>"><?php echo $a_operator->OPERATOR_NAME;?></option>
											
											
											<?php }?>
										</select>
										<span	class="fred"><?php //echo form_error('OPERATOR'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
										<input type="text" id="BILL_MONTH" name="BILL_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('REPORT_DATE',strtotime($edit['REPORT_DATE'])); ?>" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td>
									<div class="form_label">Domestic/International*</div>
									<div style="margin-left:10px">
										<select id="DOM_INT" name="DOM_INT" class="input_full input_style" required >
											<option value="Domestic"  selected >Domestic</option>
										</select>
										<span	class="fred"><?php echo form_error('DOM_INT'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<div class="form_label">Invoice Number*</div>
									<div>
										<input id="invoice_number_id" name="INVOICE_NUMBER" type="text" class="input_full input_style" value="<?php echo set_value('INVOICE_NUMBER',$edit['INVOICE_NUMBER']); ?>" required />
										<span	class="fred"><?php echo form_error('INVOICE_NUMBER'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Invoice Unique Code*</div>
									<div>
										<input id="invoice_unique_code" name="INVOICE_UNIQUE_CODE" type="text" class="input_full input_style" value="<?php echo set_value('INVOICE_UNIQUE_CODE',$edit['INVOICE_UNIQUE_CODE']); ?>" />
										<span	class="fred"><?php echo form_error('INVOICE_UNIQUE_CODE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Supplire Code*</div>
									<div>
										<input id="supplier_code" name="SUPPLIER_CODE" type="text" class="input_full input_style" value="<?php echo set_value('SUPPLIER_CODE',$edit['SUPPLIER_CODE']); ?>" />
										<span	class="fred"><?php echo form_error('SUPPLIER_CODE'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Vat Rate*</div>
									<div>
										<input id="VAT_RATE" name="VAT_RATE" type="text" class="input_full input_style" value="<?php echo set_value('VAT_RATE',$edit['VAT_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('VAT_RATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Tax Rate*</div>
									<div>
										<input id="TAX_RATE" name="TAX_RATE" type="text" class="input_full input_style" value="<?php echo set_value('TAX_RATE',$edit['TAX_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('TAX_RATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Vat Code*</div>
									<div>
										<input id="VAT_CODE" name="VAT_CODE" type="text" class="input_full input_style" value="<?php echo set_value('VAT_CODE',$edit['VAT_CODE']); ?>" required />
										<span	class="fred"><?php echo form_error('VAT_CODE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Tax Code*</div>
									<div>
										<input id="TAX_CODE" name="TAX_CODE" type="text" class="input_full input_style" value="<?php echo set_value('TAX_CODE',$edit['TAX_CODE']); ?>" required />
										<span	class="fred"><?php echo form_error('TAX_CODE'); ?></span>
									</div>
								</td>
							</tr>
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">Actual invoice amount for Voice*</div>
									<div>
										<input id="actual_invoice_amount_for_voice" name="ACTUAL_INVOICE_AMOUNT_FOR_VOICE" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_VOICE',$edit['ACTUAL_INVOICE_AMOUNT_FOR_VOICE']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Actual invoice amount for voice after VAT*</div>
									<div>
										<input id="amount_after_vat" name="ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT',$edit['ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Actual invoice amount for voice after TAX*</div>
									<div>
										<input id="amount_after_tax" name="ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX',$edit['ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Total invoice amount for voice after TAX*</div>
									<div>
										<input id="total_amount_after_tax" name="TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX" type="text" class="input_full input_style" value="<?php echo set_value('TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX',$edit['TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>							
							</tr>			
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">Actual invoice amount for SMS*</div>
									<div>
										<input id="actual_invoice_amount_for_SMS" name="ACTUAL_INVOICE_AMOUNT_FOR_SMS" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_SMS',$edit['ACTUAL_INVOICE_AMOUNT_FOR_SMS']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Actual invoice amount for SMS after VAT*</div>
									<div>
										<input id="amount_after_vat_for_sms" name="ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT',$edit['ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Actual invoice amount for SMS after TAX*</div>
									<div>
										<input id="amount_after_tax_for_sms" name="ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX',$edit['ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Total invoice amount for SMS after TAX*</div>
									<div>
										<input id="total_amount_after_tax_sms" name="TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX" type="text" class="input_full input_style" value="<?php echo set_value('TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX',$edit['TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>				
							</tr>				
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">Actual invoice amount for MMS*</div>
									<div>
										<input id="actual_invoice_amount_for_MMS" name="ACTUAL_INVOICE_AMOUNT_FOR_MMS" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_MMS',$edit['ACTUAL_INVOICE_AMOUNT_FOR_MMS']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Actual invoice amount for MMS after VAT*</div>
									<div>
										<input id="amount_after_vat_for_mms" name="ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT',$edit['ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Actual invoice amount for MMS after TAX*</div>
									<div>
										<input id="amount_after_tax_for_mms" name="ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX',$edit['ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Total invoice amount for MMS after TAX*</div>
									<div>
										<input id="total_amount_after_tax_mms" name="TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX" type="text" class="input_full input_style" value="<?php echo set_value('TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX',$edit['TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>								
							</tr>				
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">BL amount for postpaid Voice*</div>
									<div>
										<input id="post_moc_amount" name="POST_VOICE_BL" type="text" class="input_full input_style" value="<?php echo set_value('POST_VOICE_BL',$edit['POST_VOICE_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">BL amount for prepaid Voice*</div>
									<div>
										<input id="pre_moc_amount" name="PRE_VOICE_BL" type="text" class="input_full input_style" value="<?php echo set_value('PRE_VOICE_BL',$edit['PRE_VOICE_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Total pre & post amount for Voice*</div>
									<div>
										<input id="total_amount_bl" name="PRE_POST_VOICE_BL" type="text" class="input_full input_style" value="<?php echo set_value('PRE_POST_VOICE_BL',$edit['PRE_POST_VOICE_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label"> Adjustment amount for Voice*</div>
									<div>
										<input id="adjustment_amount_bl_voice" name="ADJUSTMENT_VOICE_BL" type="text" class="input_full input_style" value="<?php echo set_value('ADJUSTMENT_VOICE_BL',$edit['ADJUSTMENT_VOICE_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
							</tr>	
							<tr>	
								<td>
									<div class="form_label">BL amount for postpaid SMS*</div>
									<div>
										<input id="post_mosms_amount" name="POST_SMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('POST_SMS_BL',$edit['POST_SMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">BL amount for prepaid SMS*</div>
									<div>
										<input id="pre_mosms_amount" name="PRE_SMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('PRE_SMS_BL',$edit['PRE_SMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Total pre & post amount for SMS*</div>
									<div>
										<input id="total_mosms_amount" name="PRE_POST_SMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('PRE_POST_SMS_BL',$edit['PRE_POST_SMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label"> Adjustment amount for SMS*</div>
									<div>
										<input id="adjustment_amount_bl_sms" name="ADJUSTMENT_SMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('ADJUSTMENT_SMS_BL',$edit['ADJUSTMENT_SMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
							</tr> 
							<tr id="actual_amount_div">
								<td>
									<div class="form_label">BL amount for postpaid MMS*</div>
									<div>
										<input id="post_momms_amount" name="POST_MMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('POST_MMS_BL',$edit['POST_MMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">BL amount for prepaid MMS*</div>
									<div>
										<input id="pre_momms_amount" name="PRE_MMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('PRE_MMS_BL',$edit['PRE_MMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Total pre & post amount for MMS*</div>
									<div>
										<input id="total_momms_amount" name="PRE_POST_MMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('PRE_POST_MMS_BL',$edit['PRE_POST_MMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label"> Adjustment amount for MMS*</div>
									<div>
										<input id="adjustment_amount_bl_mms" name="ADJUSTMENT_MMS_BL" type="text" class="input_full input_style" value="<?php echo set_value('ADJUSTMENT_MMS_BL',$edit['ADJUSTMENT_MMS_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan=4>
									<div>
										<input type="submit" name="Submit" class="btn_gray" value="Submit" />
									</div>
								</td>
							</tr>
						</table>
					</form>
				<div class="float_clear_full">&nbsp;</div>
			</div>	
		</div><!--end #page_create_role -->
		<div id="footer_container" ><?php include(APPPATH."views/footer.php"); ?></div>	
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			var vat_rate_dom = 15;
			var vat_rate_int = 0;
			var tax_rate_dom = 12;
			var tax_rate_int = 7.5;
			$("#VAT_RATE").val(vat_rate_dom.toFixed(2));
			$("#TAX_RATE").val(tax_rate_dom.toFixed(2));
			
			$("#operator").on("change",function(){
		 		var op_name = $(this).val();
		 		var urlinfo=url_prefix + "get_supplier_code"
		 		if(op_name==""){
		 			return false;
		 		}
		 		
		 		var token = $('#token').val();
		 		var spinner = $(".spinner").show();
		 		spinner.show();
		
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { op_name: op_name, csrf_webspice_tkn: token }
		 		}).done(function(rslt){
					//if(rslt!=0){
						$("#supplier_code").val(rslt);
					//}
		 			
		 			
		 			spinner.hide();
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});
		
		 		return false;
		 		
		 	})
			
			
			
			
			
			
			
			
			
			
			
			$('.monthpick,.yearpick,#operator').on('change',function(){
				var op_name = $('#operator').val();
		 		var year = $(".yearpick").val();
		 		var month = $(".monthpick").val();
		 		var token = $('#token').val();
				actual_month=parseInt(month)+1;
				actual_year=year;
				actual_date=actual_month+'-'+actual_year;
				invoice_number='BL/'+op_name+'/'+actual_date;
		 		if(op_name && year && month){
		 		var urlinfo=url_prefix + "get_bl_amount";
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { op_name: op_name, year: year,month: month,csrf_webspice_tkn: token}
		 		}).done(function(rslt){
		 			obj = JSON.parse(rslt);
		 			console.log(obj);
		 			post_momms=obj[0].MOMMS_AMOUNT;
		 			post_mosms=obj[0].MOSMS_AMOUNT;
		 			post_moc_amount=obj[0].OP_MOC_AMOUNT;
		 			pre_momms_amount=obj[1].MOMMS_AMOUNT;
		 			pre_mosms_amount=obj[1].MOSMS_AMOUNT;
		 			pre_moc_amount=obj[1].OP_MOC_AMOUNT;
					
					console.log("PRE_MOC_AMOUNT" + pre_moc_amount);
				//	alert(post_momms);alert(post_mosms);alert(post_moc_amount);alert(pre_momms_amount);alert(pre_mosms_amount);alert("PRE_MOC_AMOUNT" + pre_moc_amount);
		  $("#post_momms_amount").val(post_momms);
          $("#post_mosms_amount").val(post_mosms);
          $("#post_moc_amount").val(post_moc_amount);
		 $("#pre_momms_amount").val(pre_momms_amount);
          $("#pre_mosms_amount").val(pre_mosms_amount);
          $("#pre_moc_amount").val(pre_moc_amount);
		  if(!pre_moc_amount){
			  pre_moc_amount=0;
		  }
		  total_voice=parseFloat(pre_moc_amount)+parseFloat(post_moc_amount);
		  total_sms=parseFloat(pre_mosms_amount)+parseFloat(post_mosms);
		  total_mms=parseFloat(pre_momms_amount)+parseFloat(post_momms);
		 
		  $("#total_amount_bl").val(parseFloat(total_voice));
          $("#total_mosms_amount").val(parseFloat(total_sms));
          $("#total_momms_amount").val(parseFloat(total_mms));
		  $("#invoice_number_id").val(invoice_number);
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});
		
		 		return false;
		 		
		 	}
			})	
			
			$('#actual_invoice_amount_for_voice,#VAT_RATE,#TAX_RATE,#DOM_INT').on( "change",function() {
       var actual_invoice_amount_for_voice=$('#actual_invoice_amount_for_voice').val();
       if(!actual_invoice_amount_for_voice){
       	actual_invoice_amount_for_voice=0;
       }
       var vat_rate=$('#VAT_RATE').val();
       if(!vat_rate){
       	vat_rate=0;
       }
       var tax_rate=$('#TAX_RATE').val();
       if(!tax_rate){
       	tax_rate=0;
       }
       var amount_after_vat=actual_invoice_amount_for_voice*(vat_rate/100);
       var amount_after_tax=actual_invoice_amount_for_voice*(tax_rate/100);
       var total_amount_after_tax=parseInt(actual_invoice_amount_for_voice)+parseInt(amount_after_vat)-parseInt(amount_after_tax);
       $("#amount_after_vat").val(amount_after_vat.toFixed(2));
			 $("#amount_after_tax").val(amount_after_tax.toFixed(2));
			 $("#total_amount_after_tax").val(total_amount_after_tax.toFixed(2));
      });
      
      $('#actual_invoice_amount_for_SMS,#VAT_RATE,#TAX_RATE,#DOM_INT').on( "change",function() {
       var actual_invoice_amount_for_SMS=$('#actual_invoice_amount_for_SMS').val();
       if(!actual_invoice_amount_for_SMS){
       	actual_invoice_amount_for_SMS=0;
       }
       var vat_rate=$('#VAT_RATE').val();
       if(!vat_rate){
       	vat_rate=0;
       }
       var tax_rate=$('#TAX_RATE').val();
        if(!tax_rate){
       	tax_rate=0;
       }
       var amount_after_vat_for_sms=actual_invoice_amount_for_SMS*(vat_rate/100);
       var amount_after_tax_for_sms=actual_invoice_amount_for_SMS*(tax_rate/100);
       var total_amount_after_tax_for_sms=parseInt(actual_invoice_amount_for_SMS)+parseInt(amount_after_vat_for_sms)-parseInt(amount_after_tax_for_sms);
       $("#amount_after_vat_for_sms").val(amount_after_vat_for_sms.toFixed(2));
			 $("#amount_after_tax_for_sms").val(amount_after_tax_for_sms.toFixed(2));
			 $("#total_amount_after_tax_sms").val(total_amount_after_tax_for_sms.toFixed(2));
       
      });
      $('#actual_invoice_amount_for_MMS,#VAT_RATE,#TAX_RATE').on( "change",function() {
       var actual_invoice_amount_for_MMS=$('#actual_invoice_amount_for_MMS').val();
       if(!actual_invoice_amount_for_MMS){
       	actual_invoice_amount_for_MMS=0;
       }
       var vat_rate=$('#VAT_RATE').val();
       if(!vat_rate){
       	vat_rate=0;
       }
       var tax_rate=$('#TAX_RATE').val();
       if(!tax_rate){
       	tax_rate=0;
       }
       var amount_after_vat_for_mms=actual_invoice_amount_for_MMS*(vat_rate/100);
       var amount_after_tax_for_mms=actual_invoice_amount_for_MMS*(tax_rate/100);
       var total_amount_after_tax_for_mms=parseInt(actual_invoice_amount_for_MMS)+parseInt(amount_after_vat_for_mms)-parseInt(amount_after_tax_for_mms);
       $("#amount_after_vat_for_mms").val(amount_after_vat_for_mms.toFixed(2));
			 $("#amount_after_tax_for_mms").val(amount_after_tax_for_mms.toFixed(2));
			 $("#total_amount_after_tax_mms").val(total_amount_after_tax_for_mms.toFixed(2));       
      });
      
      $('.monthpick,.yearpick,#operator,#pre_moc_amount,#post_moc_amount').on('change',function(){
       var pre_moc_amount=$('#pre_moc_amount').val();
       if(!pre_moc_amount){
       	pre_moc_amount=0;
       	}
       var post_moc_amount=$('#post_moc_amount').val();
       if(!post_moc_amount){
       	post_moc_amount=0;
       	}
       var total_moc_amount=parseInt(pre_moc_amount)+parseInt(post_moc_amount);
       $("#total_amount_bl").val(total_moc_amount.toFixed(2));
      })
      
      $('.monthpick,.yearpick,#operator,#pre_mosms_amount,#post_mosms_amount').on('change',function(){
       var pre_mosms_amount=$('#pre_mosms_amount').val();
       if(!pre_mosms_amount){
       	pre_mosms_amount=0;
       	}
       var post_mosms_amount=$('#post_mosms_amount').val();
       if(!post_mosms_amount){
       	post_mosms_amount=0;
       	}
       var total_mosms_amount=parseInt(pre_mosms_amount)+parseInt(post_mosms_amount);
       $("#total_mosms_amount").val(total_mosms_amount.toFixed(2));
      })
      
      
      $('.monthpick,.yearpick,#operator,#pre_momms_amount,#post_momms_amount').on('change',function(){
       var pre_momms_amount=$('#pre_momms_amount').val();
       if(!pre_momms_amount){
       	pre_momms_amount=0;
       	}
       var post_momms_amount=$('#post_momms_amount').val();
       if(!post_momms_amount){
       	post_momms_amount=0;
       	}
       var total_momms_amount=parseInt(pre_momms_amount)+parseInt(post_momms_amount);
       $("#total_momms_amount").val(total_momms_amount.toFixed(2));
      })
			
			$('.monthpick,.yearpick,#operator,#post_moc_amount,#pre_moc_amount,#actual_invoice_amount_for_voice,#DOM_INT').on( "change",function() {
    		var actual_invoice_amount_for_voice=$('#actual_invoice_amount_for_voice').val();
    		var pre_moc_amount=$('#pre_moc_amount').val();
       if(!pre_moc_amount){
       	pre_moc_amount=0;
       	}
       var post_moc_amount=$('#post_moc_amount').val();
       if(!post_moc_amount){
       	post_moc_amount=0;
       	}
       var total_voice_amount=parseInt(pre_moc_amount)+parseInt(post_moc_amount);
    		var adjustment_amount_bl_voice=actual_invoice_amount_for_voice-total_voice_amount;
    		$("#adjustment_amount_bl_voice").val(adjustment_amount_bl_voice.toFixed(2));
      });

      $('.monthpick,.yearpick,#operator,#post_mosms_amount,#pre_mosms_amount,#actual_invoice_amount_for_SMS,#DOM_INT').on( "change",function() {
    		var actual_invoice_amount_for_SMS=$('#actual_invoice_amount_for_SMS').val();
    		if(!actual_invoice_amount_for_SMS){
       	actual_invoice_amount_for_SMS=0;
       }
    		var pre_mosms_amount=$('#pre_mosms_amount').val();
       if(!pre_mosms_amount){
       	pre_mosms_amount=0;
       	}
       var post_mosms_amount=$('#post_mosms_amount').val();
       if(!post_mosms_amount){
       	post_mosms_amount=0;
       	}
       var total_mosms_amount=parseInt(pre_mosms_amount)+parseInt(post_mosms_amount);
    		var adjustment_amount_bl_sms=actual_invoice_amount_for_SMS-total_mosms_amount;
    		$("#adjustment_amount_bl_sms").val(adjustment_amount_bl_sms.toFixed(2));
      });
      
       $('.monthpick,.yearpick,#operator,#post_momms_amount,#pre_momms_amount,#actual_invoice_amount_for_MMS').on( "change",function() {
    		var actual_invoice_amount_for_MMS=$('#actual_invoice_amount_for_MMS').val();
    		if(!actual_invoice_amount_for_MMS){
    			actual_invoice_amount_for_MMS=0;
    		}
    		var pre_momms_amount=$('#pre_momms_amount').val();
       if(!pre_momms_amount){
       	pre_momms_amount=0;
       	}
       var post_momms_amount=$('#post_momms_amount').val();
       if(!post_momms_amount){
       	post_momms_amount=0;
       	}
       var total_momms_amount=parseInt(pre_momms_amount)+parseInt(post_momms_amount);
    		var adjustment_amount_bl_mms=actual_invoice_amount_for_MMS-total_momms_amount;
    		$("#adjustment_amount_bl_mms").val(adjustment_amount_bl_mms.toFixed(2));
      });
      	$('.monthpick,.yearpick,#operator').on('change',function(){
				var op_name = $('#operator').val();
		 		var year = $(".yearpick").val();
		 		var month = $(".monthpick").val();
		 		var token = $('#token').val();
		 		if(op_name && year && month){
		 		var urlinfo=url_prefix + "get_short_name";
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { op_name: op_name,type:'ICX', year: year,month: month,csrf_webspice_tkn: token}
		 		}).done(function(rslt){
		 			obj = JSON.parse(rslt);
		 			console.log(obj);
		 			invoice_number= obj[0] ? obj[0].OPERATOR_SHORT_CODE+'-Banglalink Interconnection'+year+'/'+ (parseInt(month)+1) +'/IC/' : '';
          $("#invoice_number").val(invoice_number);
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});
		
		 		return false;
		 		
		 	}
			})	
		});
 </script>
</body>
</html>