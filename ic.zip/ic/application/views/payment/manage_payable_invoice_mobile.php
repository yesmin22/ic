<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Manage Payable Invoice MOBILE</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
		           <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_payable_invoice_mobile">Refresh</a>
								<!--<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_payable_invoice_icx/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_payable_invoice_icx/csv" target="_blank">Export</a>-->
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table class="table table-bordered table-striped new_table_sm" style="overflow:scroll; display:block">
					<tr>
						<th>ID</th>
						<th>Operator</th>
						<th>Supplier Code</th>
						<th>Invoice Number</th>
						<th>Dom/Int</th>
						<th>Vat Rate</th>
						<th>Tax Rate</th>
						<th>Vat Code</th>
						<th>Tax Code</th>						
						<th>Actual Invoice Amount for Voice</th>
						<th>Actual Invoice Amount for Voice after Vat</th>
						<th>Actual Invoice Amount for Voice after Tax</th>
						<th>Total Invoice Amount for Voice after Tax</th>
						<th>Actual Invoice Amount for Sms</th>
						<th>Actual Invoice Amount for Sms after Vat</th>
						<th>Actual Invoice Amount for Sms after Tax</th>
						<th>Total Invoice Amount for Sms after Tax</th>
						<th>Actual Invoice Amount for Mms</th>
						<th>Actual Invoice Amount for Mms after Vat</th>
						<th>Actual Invoice_Amount for Mms after Tax</th>
						<th>Total Invoice Amount for Mms after Tax</th>
						<th>Pre Voice BL</th>
						<th>Post Voice BL</th>
						<th>Pre Post Voice BL</th>
						<th>Adjustment Voice BL</th>
						<th>Pre Sms BL</th>		
						<th>Post Sms BL</th>
						<th>Pre Post Sms BL</th>
						<th>Adjustment Sms BL</th>
						<th>Pre Mms BL</th>
						<th>Post Mms BL</th>
						<th>Pre Post Mms BL</th>
						<th>Adjustment Mms BL</th>
						<th>Report Date</th>
						<!--<th>Action</th>-->
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $page_index+$i; ?></td>
						<td><?php echo $v->OPERATOR; ?></td>
						<td><?php echo $v->SUPPLIER_CODE; ?></td>
						<td><?php echo $v->INVOICE_NUMBER; ?></td>
						<td><?php echo $v->DOM_INT; ?></td>
						<td><?php echo $v->VAT_RATE; ?></td>
						<td><?php echo $v->TAX_RATE; ?></td>
						<td><?php echo $v->VAT_CODE; ?></td>
						<td><?php echo $v->TAX_CODE; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_VOICE; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX; ?></td>
						<td><?php echo $v->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_SMS; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT; ?></td>
						
						
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX; ?></td>
						<td><?php echo $v->TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_MMS; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT; ?></td>
						<td><?php echo $v->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX; ?></td>
						<td><?php echo $v->TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX; ?></td>
						<td><?php echo $v->PRE_VOICE_BL; ?></td>
						<td><?php echo $v->POST_VOICE_BL; ?></td>
						<td><?php echo $v->PRE_POST_VOICE_BL; ?></td>
						<td><?php echo $v->ADJUSTMENT_VOICE_BL; ?></td>
						<td><?php echo $v->PRE_SMS_BL; ?></td>
						
						
						
						<td><?php echo $v->POST_SMS_BL; ?></td>
						<td><?php echo $v->PRE_POST_SMS_BL; ?></td>
						<td><?php echo $v->ADJUSTMENT_SMS_BL; ?></td>
						<td><?php echo $v->PRE_MMS_BL; ?></td>
						<td><?php echo $v->POST_MMS_BL; ?></td>
						<td><?php echo $v->PRE_POST_MMS_BL; ?></td>
						<td><?php echo $v->ADJUSTMENT_MMS_BL; ?></td>
						<td><?php echo $v->REPORT_DATE; ?></td>
						<!--
						<td class="field_button">
							<?php// if( $this->webspice->permission_verify('manage_payable_invoice_mobile',true) && $v->STATUS!=9 ): ?>
							<a href="<?php //echo $url_prefix; ?>manage_payable_invoice_mobile/edit/<?php// echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Edit</a>
							<?php// endif; ?>
						</td>-->
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
				
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>