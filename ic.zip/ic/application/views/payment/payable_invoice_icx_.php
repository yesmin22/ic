<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Payable Invoice ICX</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">
			<div class="page_caption">Create Invoice for ICX</div>
			<div class="page_body">
				<div class="left_section">
					<fieldset class="divider"><legend>Please select an operator to create an invoice</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_payable_invoice_icx" method="post" action="" data-parsley-validate enctype="multipart/form-data" >
						<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<table width="100%">
							<tr>
								<td colspan=2 >
									<div class="form_label">Operator Name*</div>
									<div>
										<select id="operator" name="OPERATOR" class="input_full input_style" required>
											<option value="">Select One</option>
											<?php if( set_value('OPERATOR', $edit['OPERATOR']) ): ?>
												<?php echo str_replace('value="'.set_value('OPERATOR', $edit['OPERATOR']).'"','value="'.set_value('OPERATOR', $edit['OPERATOR']).'" selected="selected"', $this->customcache->get_operator('option_name')); ?>
											<?php else: ?>
												<?php echo $this->customcache->get_operator('option_name'); ?>
											<?php endif; ?>
										</select>
										<span	class="fred"><?php echo form_error('OPERATOR'); ?></span>
									</div>
								</td>
								<td colspan=2 >
									<div class="form_label">Supplire Code*</div>
									<div>
										<input id="supplier_code" name="SUPPLIER_CODE" type="text" class="input_full input_style" value="<?php echo set_value('SUPPLIER_CODE',$edit['SUPPLIER_CODE']); ?>" />
										<span	class="fred"><?php echo form_error('SUPPLIER_CODE'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td colspan=2 >
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
										<input type="text" id="BILL_MONTH" name="BILL_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td>
									<div class="form_label">Domestic/International*</div>
									<div style="margin-right: 20px">
										<select id="DOM_INT" name="DOM_INT" class="input_full input_style" required >
											<option value="">Select One</option>
											<option value="Domestic" <?php if($edit["DOM_INT"]=="Domestic"){echo "selected"; } ?>>Domestic</option>
											<option value="International" <?php if($edit["DOM_INT"]=="International"){echo "selected"; } ?>>International</option>
										</select>
										<span	class="fred"><?php echo form_error('DOM_INT'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label" style="margin-left: 7px;">Paticulars*</div>
									<div>
										<select id="PARTICULARS" name="PARTICULARS" class="input_full input_style" required >
											<option value="">Select One</option>
											<option value="Voice" <?php if($edit["PARTICULARS"]=="Voice"){echo "selected"; } ?>>Voice</option>
											<option value="SMS" <?php if($edit["PARTICULARS"]=="SMS"){echo "selected"; } ?>>SMS</option>
											<option value="MMS" <?php if($edit["PARTICULARS"]=="MMS"){echo "selected"; } ?>>MMS</option>
										</select>
										<span	class="fred"><?php echo form_error('PARTICULARS'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td  colspan=2 >
									<div class="form_label">Invoice Number*</div>
									<div>
										<input name="INVOICE_NUMBER" type="text" class="input_full input_style" value="<?php echo set_value('INVOICE_NUMBER',$edit['INVOICE_NUMBER']); ?>" required />
										<span	class="fred"><?php echo form_error('INVOICE_NUMBER'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Invoice Amount*</div>
									<div>
										<input name="INVOICE_AMOUNT" type="text" class="input_full input_style" value="<?php echo set_value('INVOICE_AMOUNT',$edit['INVOICE_AMOUNT']); ?>" required />
										<span	class="fred"><?php echo form_error('INVOICE_AMOUNT'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Invoice Date*</div>
									<div>
										<input name="INVOICE_DATE" type="text" class="date_picker input_full input_style" value="<?php echo set_value('INVOICE_DATE',$edit['INVOICE_DATE']); ?>" required />
										<span	class="fred"><?php echo form_error('INVOICE_DATE'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td>
									<div class="form_label">Vat Rate*</div>
									<div>
										<input id="VAT_RATE" name="VAT_RATE" type="text" class="input_full input_style" value="<?php echo set_value('VAT_RATE',$edit['VAT_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('VAT_RATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Tax Rate*</div>
									<div>
										<input id="TAX_RATE" name="TAX_RATE" type="text" class="input_full input_style" value="<?php echo set_value('TAX_RATE',$edit['TAX_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('TAX_RATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Vat Code*</div>
									<div>
										<input id="VAT_CODE" name="VAT_CODE" type="text" class="input_full input_style" value="<?php echo set_value('VAT_CODE',$edit['VAT_CODE']); ?>" required />
										<span	class="fred"><?php echo form_error('VAT_CODE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Tax Code*</div>
									<div>
										<input id="TAX_CODE" name="TAX_CODE" type="text" class="input_full input_style" value="<?php echo set_value('TAX_CODE',$edit['TAX_CODE']); ?>" required />
										<span	class="fred"><?php echo form_error('TAX_CODE'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td>
									<div class="form_label">Tax*</div>
									<div>
										<input type="radio" id="included" name="INCLUDED_EXCLUDED" value="included" required /> <label for="included">Inclu</label>
										<input type="radio" id="excluded" name="INCLUDED_EXCLUDED" value="excluded" required /> <label for="excluded">Exclu</label>
										<span	class="fred"><?php echo form_error('INCLUDED_EXCLUDED'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Adjustment*</div>
									<div>
										<input id="ADJUSTMENT_VALUE" name="ADJUSTMENT_VALUE" type="text" class="input_full input_style" value="<?php echo set_value('ADJUSTMENT_VALUE',$edit['ADJUSTMENT_VALUE']); ?>" required />
										<span	class="fred"><?php echo form_error('ADJUSTMENT_VALUE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Temp Value*</div>
									<div>
										<input id="TEMP_VALUE" name="TEMP_VALUE" type="text" class="input_full input_style" value="<?php echo set_value('TEMP_VALUE',$edit['TEMP_VALUE']); ?>" required />
										<span	class="fred"><?php echo form_error('TEMP_VALUE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Collection Date*</div>
									<div>
										<input name="COLLECTION_DATE" type="text" class="date_picker input_full input_style" value="<?php echo set_value('COLLECTION_DATE',$edit['COLLECTION_DATE']); ?>" required />
										<span	class="fred"><?php echo form_error('COLLECTION_DATE'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td colspan=4 >
									<div class="form_label">Adjustment Note:</div>
									<div>
										<input name="ADJUSTMENT_NOTE" type="text" class="input_full input_style" value="<?php echo set_value('ADJUSTMENT_NOTE',$edit['ADJUSTMENT_NOTE']); ?>" />
										<span	class="fred"><?php echo form_error('ADJUSTMENT_NOTE'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td colspan=4 >
									<div class="form_label">Attachment*</div>
									<div>
										<input type="file" class="" id="attachment" name="ATTACHMENT" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" required />
									</div>
								</td>
							</tr>
							
							<tr>
								<td colspan=4 >
									<div>
										<input type="submit" name="Submit" class="btn_gray" value="Submit" />
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
			
		</div><!--end #page_create_role -->

		<div id="footer_container" ><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			var vat_rate_dom = 15;
			var vat_rate_int = 0;
			var tax_rate_dom = 12;
			var tax_rate_int = 7.5;

			$("#DOM_INT").change(function(){
				if($(this).val()=="Domestic"){
					$("#VAT_RATE").val(vat_rate_dom);
					$("#TAX_RATE").val(tax_rate_dom);
				}

				if($(this).val()=="International"){
					$("#VAT_RATE").val(vat_rate_int);
					$("#TAX_RATE").val(tax_rate_int);
				}
			});

			$("#ADJUSTMENT_VALUE").keyup(function(){
				$(this).val($(this).val().replace(/ /g,'').replace(',','').replace(' ',''));
				var adjustment_value = $(this).val().replace(/ /g,'').replace(',','').replace(' ','')
				var tax_rate = $("#TAX_RATE").val();
				var temp_value = adjustment_value / (tax_rate/100);
				temp_value = Math.round(temp_value * 100) / 100; // *100 &/100 for two decimal
				$("#TEMP_VALUE").val(temp_value);
			});
			
		 	$("#operator").on("change",function(){
		 		var op_name = $(this).val();
		 		var urlinfo=url_prefix + "get_supplier_code"
		 		if(op_name==""){
		 			return false;
		 		}
		 		
		 		var token = $('#token').val();
		 		var spinner = $(".spinner").show();
		 		spinner.show();
		
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { op_name: op_name, csrf_webspice_tkn: token }
		 		}).done(function(rslt){
		 			obj = JSON.parse(rslt);
		 			$("#supplier_code").val(obj.SUPPLIER_CODE);
		 			
		 			spinner.hide();
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});
		
		 		return false;
		 		
		 	})
			
		});
 </script>
</body>
</html>