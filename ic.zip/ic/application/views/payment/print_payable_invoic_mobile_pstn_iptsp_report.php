<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 8 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Payable Invoice Mobile PSTN IPTSP Report";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $report_name; ?></title>

	<style type="text/css">
	#printArea { width:1024px; margin:auto; }
	/*body, table {font-family:tahoma; font-size:13px; border-collapse: collapse;}*/
	table td { padding:8px;}

	 table.table-borderless td,table.table-borderless th{
	     border: none !important;
	}

</style>

<?php if( $action_type == 'print'): ?>
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
	<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

	<!-- print plugin -->
	<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#printArea').jqprint();
			$('#print_icon').click(function(){
				$('#printArea').jqprint();
			});
		});
	</script>
<?php endif; ?>

<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

</head>

<body>
	<!--<a id="print_icon" href="#">Print</a>-->
	<div id="printArea">
		<div class="container">
			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td align="center" colspan="<?php echo $total_column; ?>">
							<div style="font-size:150%;"><?php echo $domain_name; ?></div>
						</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr style="border-top:1px solid #ccc;">
						<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
					</tr>
					<tr>
						<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp;<?php if(isset($filter_by)): ?>|&nbsp;<?php echo $filter_by; endif;?></td>
					</tr>
					<tr><td>&nbsp;</td></tr>
				</table>
			</div>
				
			<div class="row">
				<table class="table table-borderless">
					<tr>
						<td>OP Name</td>
						<td colspan="3"><?php echo $records[0]->OPERATOR; ?></td>
					</tr>
					<!--<tr>
						<td>Operator Type</td>
						<td><?php echo $operator_type = $records[0]->OPERATOR_TYPE; ?></td>
					</tr>-->
					<tr>
						<td>Bill Month</td>
						<?php 
							$date = new DateTime($records[0]->REPORT_DATE);
							$date->modify('-1 month');
						?>
						<td><?php echo $date->format('d-M-y'); ?></td>
					</tr>
					<tr>
						<td>Description</td>
						<td><?php echo $records[0]->OPERATOR.','.$date->format('M-y').',INVOICE, Inter connect call carrying charges payable Inv#'.$records[0]->INVOICE_NUMBER." dated ".date('d-M-y', strtotime($record->BILL_MONTH)); ?></td>
					</tr>
					
					<tr>
						<td>Vendor Code</td>
						<td><?php echo $records[0]->SUPPLIER_CODE; ?></td>
					</tr>
				</table>
			</div>
			<div class="row">
				<h5><?php dd($records);echo $record->OPERATOR.'('.$record->OPERATOR_TYPE.')' ?> - Domestic Call Carrying Charge - <?php echo $date->format('F-Y'); ?></h5>
				<div class="col-md-6">
					<table border="1" class="table-bordered" style="text-align: center;">
						<tr>
							<td colspan="5" class="text-center">Actual Invoice Amount</td>
						</tr>
						<?php dd($record);?>
						<tr>
						
							<td>Particulars</td>
							<td>Bill Amount</td>
							<td>VAT-<?php echo (isset($record->VAT_RATE)) ? $record->VAT_RATE : 0 ?>%</td>
							<td>WH VAT-<?php echo (isset($WITHOUT_VAT)) ? $WITHOUT_VAT : 0 ?>%</td>
							<td>Total</td>
						</tr>
						<?php $total_inv_amt = 0; $total_vat_amt = 0; $total_without_vat_amt = 0; $total = 0; $grand_total = 0; $voice_bill_amt = 0; $sms_bill_amt = 0; $mms_bill_amt = 0;?>
						<?php foreach ($records as $record) { ?>	
						<?php //dd($records); ?>
						<?php if($record->PARTICULARS == 'Voice') $voice_bill_amt = $record->INVOICE_AMOUNT; ?>					
						<?php if($record->PARTICULARS == 'SMS')   $sms_bill_amt = $record->INVOICE_AMOUNT; ?>					
						<?php if($record->PARTICULARS == 'MMS')   $mms_bill_amt = $record->INVOICE_AMOUNT; ?>					
							<tr>
								<td><?php echo $record->PARTICULARS; ?></td>
								<td><?php echo $invoice_amount = $record->INVOICE_AMOUNT; ?></td>
								<?php $total_inv_amt += $invoice_amount; ?>
								<?php $vat = @round($record->INVOICE_AMOUNT * $record->VAT_RATE / 100, 2); ?>
								<td><?php echo $vat; ?></td>
								<?php $total_vat_amt += $vat; ?>
								<?php $without_vat = -@round($record->INVOICE_AMOUNT * $WITHOUT_VAT / 100, 2); ?>
								<td><?php echo $without_vat; ?></td>
								<?php $total_without_vat_amt += $without_vat; ?>
								<?php $total = $invoice_amount + $vat + $without_vat; ?>
								<?php $grand_total += $total; ?>
								<td><?php echo $total; ?></td>
							</tr>
						<?php } ?>
						<tr>
							<td>Total</td>
							<td><?php echo $total_inv_amt; ?></td>
							<td><?php echo $total_vat_amt; ?></td>
							<td><?php echo $total_without_vat_amt; ?></td>
							<td><?php echo $grand_total; ?></td>
						</tr>
					</table>

					 <table border="0" class="table table-borderless" style="margin-top: 70px;">
				 	     <tr>
				 	       <td>Inv. Date</td>
				 	       <td><?php echo date('d-M-y', strtotime($record->BILL_MONTH)); ?></td>
				 	     </tr>
					     <tr>
					       <td>Inv. Ref:</td>
					       <td><?php echo $record->OPERATOR; ?>/ DOM /<?php echo $operator_type; ?>/<?php echo $record->INVOICE_NUMBER ?></td>
					     </tr>
					     <tr>
					       <td>Inv. Amount: Tk.</td>
					       <td><?php echo round($total_inv_amt + $total_vat_amt, 2); ?></td>
					     </tr>
					 </table>
				</div>
				<div class="col-md-6">
					<table border="1" class="table-bordered" style="width: 530px; text-align: center;">
						<tr>
							<td colspan="4" class="text-center">Provision Made as per IT Report</td>
						</tr>
						<tr>
							<td>Postpaid</td>
							<td>Prepaid</td>
							<td>Total</td>
							<td>Adjustment</td>
						</tr>
						<?php $total_postpaid = 0; $total_prepaid = 0; $total = 0; $total_adjust = 0; $grand_total = 0; ?>
						<tr>
							<td><?php echo $voice_postpaid; ?></td>
							<td><?php echo $voice_prepaid; ?></td>
							<td><?php echo $voice_total = $voice_postpaid + $voice_prepaid; ?></td>
							<td><?php echo $voice_adjustment = round($voice_bill_amt - $voice_total, 2); ?></td>
						</tr>
						<tr>
							<td><?php echo $sms_postpaid; ?></td>
							<td><?php echo $sms_prepaid; ?></td>
							<td><?php echo $sms_total = $sms_postpaid + $sms_prepaid; ?></td>
							<td><?php echo $sms_adjustment = round($sms_bill_amt - $sms_total, 2); ?></td>
						</tr>
						<tr>
							<td><?php echo $mms_postpaid; ?></td>
							<td><?php echo $mms_prepaid; ?></td>
							<td><?php echo $mms_total = $mms_postpaid + $mms_prepaid; ?></td>
							<td><?php echo $mms_adjustment = round($mms_bill_amt - $mms_total, 2); ?></td>
						</tr>
						<tr>
							<td><?php echo $total_postpaid = $voice_postpaid + $sms_postpaid + $mms_postpaid; ?></td>
							<td><?php echo $total_prepaid = $voice_prepaid + $sms_prepaid + $mms_prepaid; ?></td>
							<td><?php echo $grand_total = $total_postpaid + $total_prepaid; ?></td>
							<td><?php echo $total_adjust = $voice_adjustment + $sms_adjustment + $mms_adjustment; ?></td>
						</tr>
						<tr>
							<td colspan="4" class="text-center">Ratio</td>
						</tr>
						<tr>
							<?php $voice_postpaid_percent = @round($voice_postpaid / $voice_total, 4) * 100; ?>
							<td><?php echo $voice_postpaid_percent ?>%</td>
							<?php $voice_prepaid_percent = @round($voice_prepaid / $voice_total, 4) * 100; ?>
							<td><?php echo $voice_prepaid_percent ?>%</td>
							<td><?php echo round($voice_postpaid_percent + $voice_prepaid_percent, 2); ?>%</td>
							<td>Voice</td>
						</tr>
						<tr>
							<?php $sms_postpaid_percent = @round($sms_postpaid / $sms_total, 4) * 100; ?>
							<td><?php echo $sms_postpaid_percent ?>%</td>
							<?php $sms_prepaid_percent = @round($sms_prepaid / $sms_total, 4) * 100; ?>
							<td><?php echo $sms_prepaid_percent ?>%</td>
							<td><?php echo round($sms_postpaid_percent + $sms_prepaid_percent, 2); ?>%</td>
							<td>SMS</td>
						</tr>
						<tr>
							<?php $mms_postpaid_percent = @round($mms_postpaid / $mms_total, 4) * 100; ?>
							<td><?php echo $mms_postpaid_percent ?>%</td>
							<?php $mms_prepaid_percent = @round($mms_prepaid / $mms_total, 4) * 100; ?>
							<td><?php echo $mms_prepaid_percent ?>%</td>
							<td><?php echo round($mms_postpaid_percent + $mms_prepaid_percent, 2); ?>%</td>
							<td>MMS</td>
						</tr>
						<tr>
							<td colspan="4" class="text-center">Adjustment - Taka</td>
						</tr>
						<tr>
							<?php $voice_postpaid_adjust = @round($voice_postpaid_percent * $voice_adjustment / 100, 2); ?>
							<td><?php echo $voice_postpaid_adjust; ?></td>
							<?php $voice_prepaid_adjust = @round($voice_prepaid_percent * $voice_adjustment / 100, 2); ?>
							<td><?php echo $voice_prepaid_adjust ?></td>
							<td><?php echo $total_voice_adjust = round($voice_postpaid_adjust + $voice_prepaid_adjust, 2); ?></td>
							<td>Voice</td>
						</tr>
						<tr>
							<?php $sms_postpaid_adjust = @round($sms_postpaid_percent * $sms_adjustment / 100, 2); ?>
							<td><?php echo $sms_postpaid_adjust; ?></td>
							<?php $sms_prepaid_adjust = @round($sms_prepaid_percent * $sms_adjustment / 100, 2); ?>
							<td><?php echo $sms_prepaid_adjust ?></td>
							<td><?php echo $total_sms_adjust = round($sms_postpaid_adjust + $sms_prepaid_adjust, 2); ?></td>
							<td>SMS</td>
						</tr>
						<tr>
							<?php $mms_postpaid_adjust = @round($mms_postpaid_percent * $mms_adjustment / 100, 2); ?>
							<td><?php echo $mms_postpaid_adjust; ?></td>
							<?php $mms_prepaid_adjust = @round($mms_prepaid_percent * $mms_adjustment / 100, 2); ?>
							<td><?php echo $mms_prepaid_adjust ?></td>
							<td><?php echo $total_mms_adjust = round($mms_postpaid_adjust + $mms_prepaid_adjust, 2); ?></td>
							<td>MMS</td>
						</tr>
						<tr>
							<td><?php echo $postpaid_adjust_total = $voice_postpaid_adjust + $sms_postpaid_adjust + $mms_postpaid_adjust; ?></td>
							<td><?php echo $prepaid_adjust_total = $voice_prepaid_adjust + $sms_prepaid_adjust + $mms_prepaid_adjust; ?></td>
							<td><?php echo $postpaid_adjust_total + $prepaid_adjust_total; ?></td>
							<td>Total</td>
						</tr>
					</table>
				</div>
			</div>

			<div class="row" style="margin-top: 15px;">
				<h5>Distribution Line:</h5>
				 <table border="0" class="table table-borderless">
				     <tr>
				       <td></td>
				       <td>A/C Code:</td>
				       <td colspan = "3">Project Code</td>
				       <td>Taka</td>
				       <td>Account Code</td>
				       <td>Tax Code</td>
				       <td>AIT Code</td>
				     </tr>

				     <tr>
				       <td>Voice</td>
				       <td>2012651</td>
				       <td>0000</td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td><?php echo $voice_total; ?></td>
				       <td>01.101.A000.2012752.0000.0000.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>

				     <tr>
				       <td>SMS</td>
				       <td>2012651</td>
				       <td>0000</td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td><?php echo $sms_total; ?></td>
				       <td>01.101.A000.2012752.0000.0000.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>
				    
				    <tr>
				      <td>SMS</td>
				      <td>2012651</td>
				      <td>0000</td>
				      <td>Liability -</td>
				      <td>Accrued Expenses - Interconnection</td>
				      <td><?php echo $mms_total; ?></td>
				      <td>01.101.A000.2012752.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>Voice</td>
				      <td>5012251</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection Expenses - GP (Postpaid)</td>
				      <td><?php echo $voice_postpaid = -$voice_postpaid; ?></td>
				      <td>01.101.A000.5012251.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>SMS</td>
				      <td>5012251</td>
				      <td>0000</td>
				      <td>Liability -</td>
				      <td>Accrued Expenses - Interconnection</td>
				      <td><?php echo $voice_prepaid = -$voice_prepaid; ?></td>
				      <td>01.101.A000.5011301.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>SMS</td>
				      <td>5012251</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection Expenses - GP (Postpaid)</td>
				      <td><?php echo $sms_postpaid = -$sms_postpaid; ?></td>
				      <td>01.101.A000.5011301.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>Voice</td>
				      <td>5012251</td>
				      <td>0000</td>
				      <td>Liability -</td>
				      <td>Accrued Expenses - Interconnection</td>
				      <td><?php echo $sms_prepaid = -$sms_prepaid; ?></td>
				      <td>01.101.A000.5012911.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>


				    <tr>
				      <td>SMS</td>
				      <td>5012251</td>
				      <td>0000</td>
				      <td>Liability -</td>
				      <td>Accrued Expenses - Interconnection</td>
				      <td><?php echo $mms_postpaid = -$mms_postpaid; ?></td>
				      <td>01.101.A000.5012911.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>SMS</td>
				      <td>5011911</td>
				      <td>0000</td>
				      <td>Liability -</td>
				      <td>Accrued Expenses - Interconnection</td>
				      <td><?php echo $mms_prepaid = -$mms_prepaid; ?></td>
				      <td>01.101.A000.5012911.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>Voice</td>
				      <td>5012251</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection Expenses - GP (Postpaid)</td>
				      <td><?php echo $voice_postp_expense = @$voice_bill_amt * $voice_postpaid_percent / 100; ?></td>
				      <td>01.101.A000.5012251.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>Voice</td>
				      <td>5011301</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection Expenses - GP (Postpaid)</td>
				      <td><?php echo $voice_prep_expense = @$voice_bill_amt * $voice_prepaid_percent / 100; ?></td>
				      <td>01.101.A000.5011301.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>SMS</td>
				      <td>5012911</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection SMS Expenses - Postpaid</td>
				      <td><?php echo $sms_postp_expense = @$sms_bill_amt * $sms_postpaid_percent / 100; ?></td>
				      <td>01.101.A000.5012911.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>SMS</td>
				      <td>5011911</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection Expenses - GP (Postpaid)</td>
				      <td><?php echo $sms_prep_expense = @$sms_bill_amt * $sms_prepaid_percent / 100; ?></td>
				      <td>01.101.A000.5011911.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>MMS</td>
				      <td>5012911</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection MMS Expenses - Postpaid</td>
				      <td><?php echo $mms_postp_expense = @$mms_bill_amt * $mms_postpaid_percent / 100; ?></td>
				      <td>01.101.A000.5012911.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>MMS</td>
				      <td>5011911</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Interconnection MMS Expenses - Prepaid</td>
				      <td><?php echo $mms_prep_expense = @$mms_bill_amt * $mms_prepaid_percent / 100; ?></td>
				      <td>01.101.A000.5011911.0000.0000.0000</td>
				      <td>BL/S012/02</td>
				      <td>WH/S-52AA/32</td>
				    </tr>

				    <tr>
				      <td>AIT</td>
				      <td>2018102</td>
				      <td>0000</td>
				      <td>Expenses -</td>
				      <td>Advance Income Tax 12% (Auto Calculate)</td>
				      <td colspan="4"><?php echo $total_without_vat_amt; ?></td>
				    </tr>

				    <tr>
				      <td>VAT</td>
				      <td>1019602</td>
				      <td>0000</td>
				      <td>Assets -</td>
				      <td>VAT Current Account @ 15% (Auto Calculate)</td>
				      <td colspan="4"><?php echo $total_vat_amt; ?></td>
				    </tr>

				     <tr>
				       <td colspan="5">Total</td>
				       <?php $final_amt = $voice_total + $sms_total + $mms_total + $voice_postpaid + $voice_prepaid + $sms_postpaid + $sms_prepaid + $mms_postpaid + $mms_prepaid + $voice_postp_expense + $voice_prep_expense + $sms_postp_expense + $sms_prep_expense + $mms_postp_expense + $mms_prep_expense + $total_without_vat_amt + $total_vat_amt;  ?>
				       <td><?php echo $final_amt; ?></td>
				     </tr>
				 </table>
			</div>

			<div class="row">
				<table border="0" class="table table-borderless">
					<tr>
						<td>Total - VAT @ 15%</td>
						<td><?php echo $total_vat_amt; ?></td>
					</tr>
					<tr>
						<td>AIT</td>
						<td><?php echo $total_without_vat_amt; ?></td>
					</tr>
					<tr>
						<td>Total Invoice Figure</td>
						<td><?php echo round($total_inv_amt + $total_vat_amt, 2); ?></td>
					</tr>
				</table>
			</div>
		</div>
		
	</div>
</body>
</html>