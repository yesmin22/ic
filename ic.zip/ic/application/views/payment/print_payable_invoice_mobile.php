<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 8 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Payable Invoice Mobile Report";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $report_name; ?></title>

	<style type="text/css">
	#printArea { width:1024px; margin:auto; }
	/*body, table {font-family:tahoma; font-size:13px; border-collapse: collapse;}*/
	table td { padding:8px;}

	 table.table-borderless td,table.table-borderless th{
	     border: none !important;
	}

</style>

<?php if( $action_type == 'print'): ?>
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
	<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

	<!-- print plugin -->
	<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#printArea').jqprint();
			$('#print_icon').click(function(){
				$('#printArea').jqprint();
			});
		});
	</script>
<?php endif; ?>

<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

</head>

<body>
	<!--<a id="print_icon" href="#">Print</a>-->

	<div id="printArea">
		<div class="container">
			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td align="center" colspan="<?php echo $total_column; ?>">
							<div style="font-size:150%;"><?php echo $domain_name; ?></div>
						</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr style="border-top:1px solid #ccc;">
						<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
					</tr>
					<tr>
						<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp;<?php if(isset($filter_by)): ?>|&nbsp;<?php echo $filter_by; endif;?></td>
					</tr>
					<tr><td>&nbsp;</td></tr>
				</table>
			</div>
				
			<div class="row">
				<table class="table table-borderless">
					<tr>
						<td>OP Name</td>
						<td colspan="3"><?php echo $record->OPERATOR; ?></td>
					</tr>
					<tr>
						<td>Operator Type</td>
						<td>?????????></td>
					</tr>
					<tr>
						<td>Bill Month</td>
						<?php 
							$date = new DateTime($record->REPORT_DATE);
							$date->modify('-1 month');
						?>
						<td><?php echo $date->format('d-M-y'); ?></td>
					</tr>
					<tr>
						<td>Description</td>
						<td><?php echo $record->OPERATOR.','.'?????'.','.$date->format('M-y').',INVOICE, Inter connect call carrying charges payable Inv#'.$record->INVOICE_NUMBER." dated ".date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
					</tr>
					<tr>
						<td>OPTYPE</td>
						<td>????????????</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<h5><?php echo $record->OPERATOR.'('.'?????'.')' ?> - Call Carrying Charge - <?php echo $date->format('F-Y'); ?></h5>
				<div class="col-md-6">
					<table class="table-bordered" style="width: 500px">
						<tr>
							<td colspan="5" class="text-center">Actual Invoice Amount</td>
						</tr>
						<tr>
							<td>Particulars</td>
							<td>Bill Amount</td>
							<td>VAT-<?php echo $record->VAT_RATE;?></td>
							<td>Tax -<?php echo $record->TAX_RATE;?></td>
							<td>Total</td>
							<td></td>
							<td>Postpaid</td>
							<td>Prepaid</td>
							<td>Total</td>
							<td>Adjustment</td>
						</tr>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<td>Voice</td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX; ?></td>
							<td><?php echo $record->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX; ?></td>
							<td></td>
							<td><?php echo $record->POST_VOICE_BL; ?></td>
							<td><?php echo $record->PRE_VOICE_BL; ?></td>
							<td><?php echo $record->PRE_POST_VOICE_BL; ?></td>
							<td><?php echo $record->ADJUSTMENT_VOICE_BL; ?></td>
						</tr>
						<tr>
							<td>SMS</td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_SMS; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX; ?></td>
							<td><?php echo $record->TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX; ?></td>
							<td></td>
							<td><?php echo $record->POST_SMS_BL; ?></td>
							<td><?php echo $record->PRE_SMS_BL; ?></td>
							<td><?php echo $record->PRE_POST_SMS_BL; ?></td>
							<td><?php echo $record->ADJUSTMENT_SMS_BL; ?></td>
						</tr>
						<tr>
							<td>MMS</td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_MMS; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX; ?></td>
							<td><?php echo $record->TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX; ?></td>
							<td></td>
							<td><?php echo $record->POST_MMS_BL; ?></td>
							<td><?php echo $record->PRE_MMS_BL; ?></td>
							<td><?php echo $record->PRE_POST_MMS_BL; ?></td>
							<td><?php echo $record->ADJUSTMENT_MMS_BL; ?></td>
						</tr>
						<tr>
							<td>Total</td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT; ?></td>
							<td><?php echo $record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX; ?></td>
							<td><?php echo $record->TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX+$record->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX+$record->TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX; ?></td>
							<td></td>
							<td><?php echo $record->POST_MMS_BL+$record->POST_VOICE_BL+$record->POST_SMS_BL; ?></td>
							<td><?php echo $record->PRE_MMS_BL+$record->PRE_VOICE_BL+$record->PRE_SMS_BL; ?></td>
							<td><?php echo $record->PRE_POST_MMS_BL+$record->PRE_POST_VOICE_BL+$record->PRE_POST_SMS_BL; ?></td>
							<td><?php echo $record->ADJUSTMENT_MMS_BL+$record->ADJUSTMENT_VOICE_BL+$record->ADJUSTMENT_SMS_BL; ?></td>
						</tr>
					</table>
				</div>
				<div class="col-md-6">
					<table class="table-bordered" style="width: 500px">
						<tr>
							<td colspan="4" class="text-center">Provision Made as per IT Report</td>
						</tr>
						<tr>
							<td>Postpaid</td>
							<td>Prepaid</td>
							<td>Total</td>
							<td>Adjustment</td>
						</tr>
						<tr>
							<td><?php echo $postpaid; ?></td>
							<td><?php echo $prepaid; ?></td>
							<td><?php echo $post_pre_total = $postpaid + $prepaid; ?></td>
							<td><?php echo $total_adjustment = round($total_invoice - $post_pre_total, 2); ?></td>
						</tr>
						<tr>
							<td colspan="4" class="text-center">Ratio</td>
						</tr>
						<tr>
							<?php $postpaid_percent = round($postpaid / $post_pre_total, 2); ?>
							<td><?php echo $postpaid_percent ?>%</td>
							<?php $prepaid_percent = round($prepaid / $post_pre_total, 2); ?>
							<td colspan="2"><?php echo $prepaid_percent ?>%</td>
							<td><?php echo round($postpaid_percent + $prepaid_percent, 2) * 100; ?>%</td>
						</tr>
						<tr>
							<td colspan="4" class="text-center">Adjustment - Taka</td>
						</tr>
						<tr>
							<?php $postpaid_adjust = round($postpaid_percent * $total_adjustment, 2); ?>
							<td><?php echo $postpaid_adjust; ?></td>
							<?php $prepaid_adjust = round($prepaid_percent * $total_adjustment, 2); ?>
							<td colspan="2"><?php echo $prepaid_adjust ?></td>
							<td><?php echo round($postpaid_adjust + $prepaid_adjust, 2); ?></td>
						</tr>
					</table>
				</div>
			</div>

			<div class="row">
				 <table class="table table-borderless">
			 	     <tr>
			 	       <td>Inv. Date</td>
			 	       <td><?php echo date('d-M-y', strtotime($record->BILL_MONTH)); ?></td>
			 	     </tr>
				     <tr>
				       <td>Inv. Ref:</td>
				       <td><?php echo $record->OPERATOR ?>/ DOM /<?php echo $record->OPERATOR_TYPE ?>/<?php echo $record->INVOICE_NUMBER ?></td>
				     </tr>
				     <tr>
				       <td>Inv. Amount: Tk.</td>
				       <td><?php echo round($record->INVOICE_AMOUNT + $vat, 2); ?></td>
				     </tr>
				 </table>
			</div>

			<div class="row">
				<h5>Distribution Line:</h5>
				 <table class="table table-borderless">
				     <tr>
				       <td>A/C Code:</td>
				       <td colspan="3">Project Code</td>
				       <td>Taka</td>
				       <td>Paste the below</td>
				       <td>Paste the below</td>
				       <td>Paste the below</td>
				     </tr>
				     <tr>
				       <td>2012651</td>
				       <td>ICA3</td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td><?php echo round($record->INVOICE_AMOUNT + $total_adjustment, 2); ?></td>
				       <td>01.101.A000.2012751.0000.ICA3.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>
				     <tr>
				       <td>5012501</td>
				       <td>0000</td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - Postpaid</td>
				       <td><?php echo $postpaid_adjust; ?></td>
				       <td>01.101.A000.2012751.0000.ICA3.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>
				     <tr>
				       <td>5011306</td>
				       <td>0000</td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - Prepaid</td>
				       <td><?php echo $prepaid_adjust; ?></td>
				       <td>01.101.A000.2012751.0000.ICA3.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>
				     <tr>
				       <td>1019602</td>
				       <td>0000</td>
				       <td>Assets -</td>
				       <td>VAT Current Account @ 15% (Auto Calculate)</td>
				       <td><?php echo $vat; ?></td>
				       <td>01.101.A000.2012751.0000.ICA3.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>
				     <tr>
				       <td>2018102</td>
				       <td>0000</td>
				       <td>Assets -</td>
				       <td>Advance Income Tax 12% on 100%</td>
				       <td><?php echo $tax; ?></td>
				       <td>01.101.A000.2012751.0000.ICA3.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>
				     <tr>
				       <td colspan="4">Total</td>
				       <td><?php echo round( $record->INVOICE_AMOUNT + $postpaid_adjust + $prepaid_adjust + $vat + $tax, 2); ?></td>
				     </tr>
				 </table>
			</div>
		</div>
		
	</div>
</body>
</html>