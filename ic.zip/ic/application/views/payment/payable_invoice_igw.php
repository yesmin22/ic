<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Payable Invoice IGW</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper" >
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">
			<div class="page_caption">Create Invoice for IGW</div>
			<div class="page_body" style="margin-left:20px;margin-right:20px">
				
					<fieldset class="divider"><legend>Please select an operator to create an invoice</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_payable_invoice_icx" method="post" action="" data-parsley-validate enctype="multipart/form-data" >
						<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<?php  $operator=$this->db->query("SELECT * FROM TBL_OPERATOR WHERE OPERATOR_TYPE='IGW'")->result();?>
						<table width="100%">
							<tr>
								<td>
									<div class="form_label">Operator Name*</div>
									<div>
										<select id="operator" name="OPERATOR" class="input_full input_style" required>
											<option value="">Select One</option>
											<?php foreach( $operator as $a_operator){ ?>
											<option value="<?php echo $a_operator->OPERATOR_NAME.'|'.$a_operator->OPERATOR_TYPE;?>"><?php echo $a_operator->OPERATOR_NAME;?></option>
											<?php }?>
										</select>
										<span	class="fred"><?php //echo form_error('OPERATOR'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
										<input type="text" id="BILL_MONTH" name="BILL_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('REPORT_DATE',strtotime($edit['REPORT_DATE'])); ?>" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td>
									<div class="form_label">Supplire Code*</div>
									<div>
										<input id="supplier_code" name="SUPPLIER_CODE" type="text" class="input_full input_style" value="<?php echo set_value('SUPPLIER_CODE',$edit['SUPPLIER_CODE']); ?>" />
										<span	class="fred"><?php echo form_error('SUPPLIER_CODE'); ?></span>
									</div>
								</td>
								<td colspan='2'>
									<div class="form_label">Invoice Number*</div>
									<div>
										<input id="invoice_number" name="INVOICE_NUMBER" type="text" class="input_full input_style" value="<?php echo set_value('INVOICE_NUMBER',$edit['INVOICE_NUMBER']); ?>" required />
										<span	class="fred"><?php echo form_error('INVOICE_NUMBER'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
							<td>
									<div class="form_label">Invoice Unique Code*</div>
									<div>
										<input id="invoice_unique_code" name="INVOICE_UNIQUE_CODE" type="text" class="input_full input_style" value="<?php echo set_value('INVOICE_UNIQUE_CODE',$edit['INVOICE_UNIQUE_CODE']); ?>" />
										<span	class="fred"><?php echo form_error('INVOICE_UNIQUE_CODE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Vat Rate*</div>
									<div>
										<input id="VAT_RATE" name="VAT_RATE" type="text" class="input_full input_style" value="<?php echo set_value('VAT_RATE',$edit['VAT_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('VAT_RATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Tax Rate*</div>
									<div>
										<input id="TAX_RATE" name="TAX_RATE" type="text" class="input_full input_style" value="<?php echo set_value('TAX_RATE',$edit['TAX_RATE']); ?>" required />
										<span	class="fred"><?php echo form_error('TAX_RATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Vat Code*</div>
									<div>
										<input id="VAT_CODE" name="VAT_CODE" type="text" class="input_full input_style" value="<?php echo set_value('VAT_CODE',$edit['VAT_CODE']); ?>" required />
										<span	class="fred"><?php echo form_error('VAT_CODE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Tax Code*</div>
									<div>
										<input id="TAX_CODE" name="TAX_CODE" type="text" class="input_full input_style" value="<?php echo set_value('TAX_CODE',$edit['TAX_CODE']); ?>" required />
										<span	class="fred"><?php echo form_error('TAX_CODE'); ?></span>
									</div>
								</td>
							</tr>
							<tr id="bl_amount_div">
								<td>
									<div class="form_label">Actual invoice amount*</div>
									<div>
										<input id="actual_invoice_amount_for_voice" name="ACTUAL_INVOICE_AMOUNT_FOR_VOICE" type="text" class="input_full input_style" value="<?php echo set_value('ACTUAL_INVOICE_AMOUNT_FOR_VOICE',$edit['ACTUAL_INVOICE_AMOUNT_FOR_VOICE']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">VAT*</div>
									<div>
										<input id="vat" name="VAT" type="text" class="input_full input_style" value="<?php echo set_value('VAT',$edit['VAT']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>	
								<td>
									<div class="form_label">TAX*</div>
									<div>
										<input id="tax" name="TAX" type="text" class="input_full input_style" value="<?php echo set_value('TAX',$edit['TAX']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>	
								<td colspan='2'>
									<div class="form_label ">Total Amount*</div>
									<div>
										<input id="total_amount" name="TOTAL_AMOUNT" type="text" class="input_full input_style" value="<?php echo set_value('TOTAL_AMOUNT',$edit['TOTAL_AMOUNT']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>						
							</tr>				
							<!--<tr id="bl_amount_div">
								<td>
									<div class="form_label">BL amount for postpaid*</div>
									<div>
										<input id="post_moc_amount" name="POST_VOICE_BL" type="text" class="input_full input_style" value="<?php echo set_value('POST_VOICE_BL',$edit['POST_VOICE_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">BL amount for prepaid *</div>
									<div>
										<input id="pre_moc_amount" name="PRE_VOICE_BL" type="text" class="input_full input_style" value="<?php echo set_value('PRE_VOICE_BL',$edit['PRE_VOICE_BL']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Total BL Amount*</div>
									<div>
										<input id="total_bl_amount" name="TOTAL_BL_AMOUNT" type="text" class="input_full input_style" value="<?php echo set_value('TOTAL_BL_AMOUNT',$edit['TOTAL_BL_AMOUNT']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Difference Between Invoice Amount & BL Amount*</div>
									<div>
										<input id="adjustment" name="ADJUSTMENT" type="text" class="input_full input_style" value="<?php echo set_value('ADJUSTMENT',$edit['ADJUSTMENT']); ?>" required />
										<span	class="fred"></span>
									</div>
								</td>
							</tr>	
							<tr>
								<td colspan=4>
									<div>
										<input type="submit" name="Submit" class="btn_gray" value="Submit" />
									</div>
								</td>
							</tr>-->
							<td colspan=5>
									<div>
										<input type="submit" name="Submit" class="btn_gray" value="Submit" />
									</div>
								</td>
						</table>
					</form>
				<div class="float_clear_full">&nbsp;</div>
			</div>	
		</div><!--end #page_create_role -->
		<div id="footer_container" ><?php include(APPPATH."views/footer.php"); ?></div>	
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			var vat_rate_dom = 15;
			var vat_rate_int = 0;
			var tax_rate_dom = 12;
			var tax_rate_int = 7.5;
		$("#operator").on("change",function(){
		 		var op_name = $(this).val();
		 		var urlinfo=url_prefix + "get_supplier_code"
		 		if(op_name==""){
		 			return false;
		 		}
		 		
		 		var token = $('#token').val();
		 		var spinner = $(".spinner").show();
		 		spinner.show();
		
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { op_name: op_name, csrf_webspice_tkn: token }
		 		}).done(function(rslt){
					//if(rslt!=0){
						$("#supplier_code").val(rslt);
					//}
		 			
		 			
		 			spinner.hide();
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});
		
		 		return false;
		 		
		 	})
			$('#DOM_INT,#actual_invoice_amount_for_voice,#VAT_RATE,#TAX_RATE').on( "change",function() {
    		var actual_invoice_amount_for_voice=$('#actual_invoice_amount_for_voice').val();
    		var vat_rate=$('#VAT_RATE').val();
    		var tax_rate=$('#TAX_RATE').val();
        if(!actual_invoice_amount_for_voice){
       	actual_invoice_amount_for_voice=0;
       	}
       	if(!vat_rate){
       	vat_rate=0;
       	}
       	if(!tax_rate){
       	tax_rate=0;
       	} 	
      	vat=actual_invoice_amount_for_voice*(vat_rate/100);
      	tax=actual_invoice_amount_for_voice*(tax_rate/100);
      	total_amount=(parseInt(actual_invoice_amount_for_voice)+parseInt(vat)-parseInt(tax));
    		$("#vat").val(vat.toFixed(2));
    		$("#tax").val(tax.toFixed(2));
    		$("#total_amount").val(total_amount.toFixed(2));
      });			
			
      $('#actual_invoice_amount_for_voice').on( "change",function() {
    		var actual_invoice_amount_for_voice=$('#actual_invoice_amount_for_voice').val();
        if(!actual_invoice_amount_for_voice){
       	actual_invoice_amount_for_voice=0;
       	}
    		$("#total_bl_amount").val(actual_invoice_amount_for_voice);
      });
      $('.monthpick,.yearpick,#operator').on('change',function(){
				var op_name = $('#operator').val();
		 		var year = $(".yearpick").val();
		 		var month = $(".monthpick").val();
		 		var token = $('#token').val();
		 		if(op_name && year && month){
		 		var urlinfo=url_prefix + "get_bl_amount_for_icx";
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { op_name: op_name, year: year,month: month,csrf_webspice_tkn: token}
		 		}).done(function(rslt){
		 			
		 			obj = JSON.parse(rslt);
		 			console.log(obj);
		 		  if(rslt=='[]'){
		 		  	post_moc_amount=0;
		 		  	pre_moc_amount=0;
		 		  }else{
		 		  	post_moc_amount=obj[0].OP_MOC_AMOUNT;
		 		  	pre_moc_amount=obj[1].OP_MOC_AMOUNT;
		 		  }
		 			$("#post_moc_amount").val(post_moc_amount);
		 			$("#pre_moc_amount").val(pre_moc_amount);
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});
		
		 		return false;
		 		
		 	}
			})	      

			 $('#post_moc_amount,#pre_moc_amount,.monthpick,.yearpick,#operator,#DOM_INT,#actual_invoice_amount_for_voice,#VAT_RATE,#TAX_RATE,#total_bl_amount').on('change',function(){
			 	var actual_invoice_amount_for_voice = $("#actual_invoice_amount_for_voice").val();
			 	var total_bl_amount = $("#total_bl_amount").val();
			 	var adjusment=(actual_invoice_amount_for_voice-total_bl_amount);
			 	$("#adjustment").val(adjusment.toFixed(2));
			 })		




			$('.monthpick,.yearpick,#operator').on('change',function(){
				var op_name = $('#operator').val();
		 		var year = $(".yearpick").val();
		 		var month = $(".monthpick").val();
		 		var token = $('#token').val();
				var dom_int = 'INT';
				actual_month=parseInt(month)+1;
				actual_year=year;
				actual_date=actual_month+'-'+actual_year;
				//alert(dom_int);
		 		if(op_name && year && month){
				invoice_number='BL/'+op_name+'/'+dom_int+'/'+actual_date;
		        $("#invoice_number").val(invoice_number);
		 	}
			})	













			 
		});
 </script>
</body>
</html>