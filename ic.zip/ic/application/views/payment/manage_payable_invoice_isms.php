<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Manage Payable Invoice ISMS</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
		           <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_payable_invoice_isms">Refresh</a>
								<!--<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_payable_invoice_icx/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_payable_invoice_icx/csv" target="_blank">Export</a>-->
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table class="table table-bordered table-striped new_table_sm" style="overflow:scroll; display:block">
					<tr>
						<th>ID</th>
						<th>Operator</th>
						<th>Supplier Code</th>
						<th>Invoice Number</th>
						<th>Expenses Euro</th>
						<th>Revenue Euro</th>
						<th>Net Expense Euro</th>
						<th>Conv. Rate Euro to Tk</th>
						<th>Expenses Tk</th>
						<th>Revenue Tk</th>
						<th>Net Expense Tk</th>
						<th>Conv. Rate USD to Tk</th>
						<th>Expenses USD</th>
						<th>Revenue USD</th>
						<th>Net Expense USD</th>
						<th>B2B Cost Ratio</th>
						<th>B2B Revenue Ratio</th>
						<th>B2C Cost Ratio</th>
						<th>B2C Revenue Ratio</th>
						<th>Report Date</th>
						<!--<th>Action</th>-->
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $page_index+$i; ?></td>
						<td><?php echo $v->OPERATOR; ?></td>
						<td><?php echo $v->SUPPLIER_CODE; ?></td>
						<td><?php echo $v->INVOICE_NUMBER; ?></td>
						<td><?php echo $v->EXPENSES_EURO; ?></td>
						<td><?php echo $v->REVENUE_EURO; ?></td>
						<td><?php echo $v->NET_EXPENSE_EURO; ?></td>
						<td><?php echo $v->EURO_TO_TK_COVERTION_RATE; ?></td>
						<td><?php echo $v->EXPENSES_TK; ?></td>
						<td><?php echo $v->REVENUE_TK; ?></td>
						<td><?php echo $v->NET_EXPENSE_TK; ?></td>
						<td><?php echo $v->USD_TO_TK_COVERTION_RATE; ?></td>
						<td><?php echo $v->EXPENSES_USD; ?></td>
						<td><?php echo $v->REVENUE_USD; ?></td>
						<td><?php echo $v->NET_EXPENSE_USD; ?></td>
						<td><?php echo $v->B2B_COST_RATIO; ?></td>
						<td><?php echo $v->B2B_REVENUE_RATIO; ?></td>
						<td><?php echo $v->B2C_COST_RATIO; ?></td>
						<td><?php echo $v->B2C_REVENUE_RATIO; ?></td>
						<td><?php echo $v->REPORT_DATE; ?></td>
						<!--<td class="field_button">
							<?php// if( $this->webspice->permission_verify('manage_payable_invoice_isms',true) && $v->STATUS!=9 ): ?>
							<a href="<?php //echo $url_prefix; ?>manage_payable_invoice_isms/edit/<?php //echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Edit</a>
							<?php //endif; ?>
						</td>-->
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
				
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>