<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
# don't edit the below area (csv)
$report_name='Payable Invoice ICX Report';
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Journal for MTMMS</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.brt1 { border-top:1px solid #CCCCCC; }
			.brr1 { border-right:1px solid #CCCCCC; }
			.brb1 { border-bottom:1px solid #CCCCCC; }
			.brl1 { border-left:1px solid #CCCCCC; }
			.brt2 { border-top:2px solid #CCCCCC; }
			.brtl2 { border-top:2px solid #CCCCCC; border-left:2px solid #CCCCCC; }
			.brtr2 { border-top:2px solid #CCCCCC; border-right:2px solid #CCCCCC; }
			.brr2 { border-right:2px solid #CCCCCC; }
			.brrt2 { border-right:2px solid #CCCCCC; border-top:2px solid #CCCCCC; }
			.brrb2 { border-right:2px solid #CCCCCC; border-bottom:2px solid #CCCCCC; }
			.brb2 { border-bottom:2px solid #CCCCCC; }
			.brl2 { border-left:2px solid #CCCCCC; }
			.brlt2 { border-left:2px solid #CCCCCC; border-top:2px solid #CCCCCC; }
			.brlb2 { border-left:2px solid #CCCCCC; border-bottom:2px solid #CCCCCC; }
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>

<body>
	<!--<a id="print_icon" href="#">Print</a>-->

	<div id="printArea">
		<div class="container">
			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td align="center" colspan="<?php echo $total_column; $post_ratio_sms=0; ?>">
							<div style="font-size:150%;"><?php echo $domain_name; ?></div>
						</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr style="border-top:1px solid #ccc;">
						<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
					</tr>
					<tr>
						<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp;<?php if(isset($filter_by)): ?>|&nbsp;<?php echo $filter_by; endif;?></td>
					</tr>
					<tr><td>&nbsp;</td></tr>
				</table>
			</div>
				
			<div class="row">
				<table>
					<tr>
						<td>OP Name</td>
						<td colspan="3"><?php echo $record->OPERATOR; ?></td>
					</tr>
					<tr>
						<td>Operator Type</td>
						<td><?php echo $operator_info->OPERATOR_TYPE;?></td>
					</tr>
					<tr>
						<td>Bill Month</td>
						<?php 
						$post_ratio_mms=0;
						$pre_ratio_mms=0;
						$adj_post_sms=0;
						$adj_pre_sms=0;
						//$post_ratio_mms=0;
						$adj_pre_mms=0;
						$adj_pre_voice=0;
						$adj_post_mms=0;
						$adj_post_mms=0;
						$pre_ratio_sms=0;
						
						
						
						
							$date = new DateTime($record->REPORT_DATE);
							//$date->modify('-1 month');
						?>
						<td><?php echo $date->format('d-M-y'); ?></td>
					</tr>
					<tr>
						<td>Description</td>
						<td><?php echo $record->OPERATOR.','.$operator_info->OPERATOR_TYPE.','.$date->format('M-y').',INVOICE, Inter connect call carrying charges payable Inv#'.$record->INVOICE_NUMBER." dated ".date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
					</tr>
					<tr>
						<td>OPTYPE</td>
						<td><?php echo $operator_info->OPERATOR_TYPE?></td>
					</tr>
				</table>
			</div>
<?php if($record->OPERATOR_TYPE=='MOBILE'){?>
			<div class="row">
				<h5><?php echo $record->OPERATOR.'('.$operator_info->OPERATOR_TYPE.')' ?> - Call Carrying Charge - <?php echo $date->format('F-Y'); ?></h5>
				<div class="">
					<table style="width: 900px">
						
				 </table>
			</div>

			<div class="row">
			
				 <table class="table table-borderless">
				 
				 
				 <tr>
							<td></td>
							<td colspan="4" style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Actual Invoice Amount</td>
							<td colspan="5" style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"> Provision Made as per IT Report</td>
							<td></td>
						</tr>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Particulars</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Bill Amount</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">VAT-<?php echo $record->VAT_RATE;?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Tax -<?php echo $record->TAX_RATE;?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
							<td >&nbsp;</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Postpaid</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Prepaid</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Adjustment</td>
						</tr>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="border-right:1px solid #cccccc"></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr >
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Voice</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">(<?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX); ?>)</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX); ?></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->POST_VOICE_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_VOICE_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_POST_VOICE_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ADJUSTMENT_VOICE_BL); ?></td>
						</tr>
						<?php if($record->PRE_SMS_BL!=0 && $record->POST_SMS_BL!=0){?>
						<tr>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">SMS</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_SMS); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">(<?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX); ?>)</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX); ?></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"> <?php echo number_format($record->POST_SMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_SMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_POST_SMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ADJUSTMENT_SMS_BL); ?></td>
						</tr>
						<?php }?>
						<?php if($record->PRE_MMS_BL!=0 && $record->POST_MMS_BL!=0){?>
						<tr >
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">MMS</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">(<?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX); ?>)</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX); ?></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->POST_MMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_MMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"> <?php echo number_format($record->PRE_POST_MMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ADJUSTMENT_MMS_BL); ?></td>
						</tr>
						<?php }?>
						<tr >
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">(<?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX); ?>)</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->TOTAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX+$record->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX+$record->TOTAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX); ?></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->POST_MMS_BL+$record->POST_VOICE_BL+$record->POST_SMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_MMS_BL+$record->PRE_VOICE_BL+$record->PRE_SMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_POST_MMS_BL+$record->PRE_POST_VOICE_BL+$record->PRE_POST_SMS_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ADJUSTMENT_MMS_BL+$record->ADJUSTMENT_VOICE_BL+$record->ADJUSTMENT_SMS_BL); ?></td>
						</tr>
						<tr >
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;" colspan=4>Ratio</td>
						</tr>
						<tr >
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $total_voice=$record->POST_VOICE_BL+$record->PRE_VOICE_BL;$post_ratio_voice=(($record->POST_VOICE_BL/$total_voice)*100); echo number_format($post_ratio_voice); ?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $pre_ratio_voice=(($record->PRE_VOICE_BL/$total_voice)*100); echo number_format($pre_ratio_voice);?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($post_ratio_voice+$pre_ratio_voice); ?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Voice</td>
						</tr>
						<?php $total_sms=$record->POST_SMS_BL+$record->PRE_SMS_BL;  if($total_sms!=0){?>
						<tr >
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $post_ratio_sms=(($record->POST_SMS_BL/$total_sms)*100); echo number_format($post_ratio_sms);?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $pre_ratio_sms=(($record->PRE_SMS_BL/$total_sms)*100); echo number_format($pre_ratio_sms); ?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($post_ratio_sms+$pre_ratio_sms); ?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">SMS</td>
						</tr>
						<?php }?>
						<?php $total_mms=$record->POST_MMS_BL+$record->PRE_MMS_BL; if($total_mms!=0){?>
						<tr >
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $total_mms=$record->POST_MMS_BL+$record->PRE_MMS_BL; $post_ratio_mms=(($record->POST_MMS_BL/$total_mms)*100); echo number_format($post_ratio_mms,2);?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $pre_ratio_mms= (($record->PRE_MMS_BL/$total_mms)*100); echo number_format($pre_ratio_mms,2);?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format(($post_ratio_mms+$pre_ratio_mms),2); ?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">MMS</td>
						</tr>
						<?php }?>  
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Adjustment - Taka</td>
						</tr>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adj_post_voice=(($post_ratio_voice * ($record->ADJUSTMENT_VOICE_BL))/100); echo number_format($adj_post_voice);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adj_pre_voice= (($pre_ratio_voice * ($record->ADJUSTMENT_VOICE_BL))/100); echo number_format($adj_pre_voice);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($adj_post_voice+$adj_pre_voice);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Voice</td>
						</tr>
						<?php if(isset($post_ratio_sms) && $post_ratio_sms!=0){ ?>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adj_post_sms=($post_ratio_sms * ($record->ADJUSTMENT_SMS_BL)); echo number_format($adj_post_sms);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"> <?php $adj_pre_sms= ($pre_ratio_sms * ($record->ADJUSTMENT_SMS_BL)); echo number_format($adj_pre_sms);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($adj_post_sms+$adj_pre_sms);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">SMS</td>
						</tr>
						<?php } ?>
						<?php   if($post_ratio_mms!=0 && $pre_ratio_mms!=0){?>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adj_post_mms=($post_ratio_mms * ($record->ADJUSTMENT_MMS_BL)); echo number_format($adj_post_mms);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adj_pre_mms= ($pre_ratio_mms * ($record->ADJUSTMENT_MMS_BL)); echo number_format($adj_pre_mms);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($adj_post_mms+$adj_pre_mms);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">MMS</td>
						</tr>
						<?php } ?>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($adj_post_mms+$adj_post_sms+$adj_post_voice);?></td>
							
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo  number_format($adj_pre_mms+$adj_pre_sms+$adj_pre_voice);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($adj_post_mms+$adj_pre_mms+$adj_post_sms+$adj_pre_sms+$adj_post_voice+$adj_pre_voice);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
						</tr>
						
						<tr style="height:10px">
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr style="height:10px">
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr style="height:10px">
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<tr style="height:10px">
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
					</table>
			
				</div>
			</div>

			
			
			
			<div class="row">
				 <table class="table table-borderless">
				  <tr>
			 	       <td colspan=2><h5>Distribution Line:</h5></td>
			 	       
			 	     </tr>
			 	     <tr>
			 	       <td>Inv. Date</td>
			 	       <td><?php echo date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
			 	     </tr>
				     <tr>
				       <td>Inv. Ref:</td>
				       <td><?php echo $record->OPERATOR; ?>/<?php echo $record->INVOICE_NUMBER ?></td>
				     </tr>
				     <tr>
				       <td>Inv. Amount: Tk.</td>
				       <td><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				     </tr>
				 
				  <tr>
				       <td>Inv. Amount: Tk.</td>
				       <td><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				     </tr>
				 
				 
				 
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td></td>
				       <td>A/C Code:</td>
				       <td>Project Code</td>
				       <td></td>
				       <td></td>
				       <td>Taka</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>ACCOUNT CODE</td>
				       <td>TAX CODE</td>
				       <td>AIT CODE</td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>Voice</td>
				       <td><?php echo $gl_info->ACCURED;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right"><?php echo number_format($record->PRE_POST_VOICE_BL); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->ACCURED;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->ACCURED;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right"><?php echo number_format($record->PRE_POST_SMS_BL); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->ACCURED;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->ACCURED;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right"><?php echo number_format($record->PRE_POST_MMS_BL); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->ACCURED;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>Voice</td>
				       <td><?php echo $gl_info->POST_VOICE;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right">(<?php echo number_format($record->POST_VOICE_BL); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->POST_VOICE;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td>BL/S012/02</td>
				       <td>WH/S-52AA/32</td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->PRE_VOICE;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right">(<?php echo number_format($record->PRE_VOICE_BL); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->PRE_VOICE;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->POST_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right">(<?php echo number_format($record->POST_SMS_BL); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->POST_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>Voice</td>
				       <td><?php echo $gl_info->PRE_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right">(<?php echo number_format($record->PRE_SMS_BL); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->PRE_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->POST_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right">(<?php echo number_format($record->POST_MMS_BL); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->POST_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->PRE_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right">(<?php echo number_format($record->PRE_MMS_BL); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->PRE_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr> 
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>Voice</td>
				       <td><?php echo $gl_info->POST_VOICE;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right"><?php echo number_format((($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE * $post_ratio_voice)/100)); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->POST_VOICE;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>Voice</td>
				       <td><?php echo $gl_info->PRE_VOICE;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right"><?php echo number_format((($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE * $pre_ratio_voice)/100)); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->PRE_VOICE;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->POST_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right"><?php echo number_format((($record->ACTUAL_INVOICE_AMOUNT_FOR_SMS * $post_ratio_sms)/100)); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->POST_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>SMS</td>
				       <td><?php echo $gl_info->PRE_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right"><?php echo number_format((($record->ACTUAL_INVOICE_AMOUNT_FOR_SMS * $pre_ratio_sms)/100)) ; ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->PRE_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>MMS</td>
				       <td><?php echo $gl_info->POST_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right"><?php echo number_format((($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS * $post_ratio_mms)/100)); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->POST_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>MMS</td>
				       <td><?php echo $gl_info->PRE_SMS;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Interconnection Expenses - <?php echo $record->OPERATOR;?> (Postpaid)</td>
				       <td align="right"><?php echo number_format((($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS * $pre_ratio_mms)/100)); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->PRE_SMS;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>AIT</td>
				       <td>2018102</td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses -</td>
				       <td>Advance Income Tax <?php echo $record->TAX_RATE;?>% (Auto Calculate)</td>
				       <td align="right">(<?php echo number_format(($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX)); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.2018102.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>VAT</td>
				       <td>1019602</td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Assets - </td>
				       <td>VAT Current Account @ <?php echo $record->VAT_RATE;?>% (Auto Calculate)</td>
				       <td align="right"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.1019602.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				    
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				       <td colspan="5">Total</td>
				       <td align="right"><?php echo number_format(($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT+(-($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX))   +   (($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS * $pre_ratio_mms)/100)+(($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS * $post_ratio_mms)/100)+(($record->ACTUAL_INVOICE_AMOUNT_FOR_SMS * $pre_ratio_sms)/100)+(($record->ACTUAL_INVOICE_AMOUNT_FOR_SMS * $post_ratio_sms)/100)+(($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE * $pre_ratio_voice)/100)+(($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE * $post_ratio_voice)/100)+(-($record->PRE_MMS_BL))+(-($record->POST_MMS_BL))+(-($record->PRE_SMS_BL))+(-($record->POST_SMS_BL))+(-($record->PRE_VOICE_BL))+(-($record->POST_VOICE_BL))+$record->PRE_POST_MMS_BL+$record->PRE_POST_SMS_BL+$record->PRE_POST_VOICE_BL));?></td>
				       <td colspan=4></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>&nbsp;</td>
				     	 <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				     </tr>
				     
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td colspan=4></td>
				       <td>Total - VAT @ <?php echo $record->VAT_RATE;?>%</td>
				       <td align="right"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td colspan=4></td>
				       <td>AIT</td>
				       <td align="right">(<?php echo number_format(($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_TAX)); ?>)</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td colspan=4></td>
				       <td>Total Invoice Figure</td>
				       <td align="right"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				     </tr>
				 </table>
			</div>
<?php }else{ ?>































		<div class="row">
				<h5><?php echo $record->OPERATOR.'('.$operator_info->OPERATOR_TYPE.')' ?> - Call Carrying Charge - <?php echo $date->format('F-Y'); ?></h5>
				<div class="">
					<table style="width: 900px">
						
				 </table>
			</div>

			

			<div class="row">
			 <table class="table table-borderless" style="margin-left:300px">
				   <tr>
							<td></td>
							
							<td colspan="4" style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Actual Invoice Amount</td>
							<td colspan="4" style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"> Provision Made as per IT Report</td>
						
						</tr>
						<tr>
							<td></td>
							
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Bill Amount</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">VAT-<?php echo $record->VAT_RATE;?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Tax -<?php echo $record->TAX_RATE;?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
							
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Postpaid</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Prepaid</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Total</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Adjustment</td>
						</tr>
					
						<tr >
							<td></td>
							
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">(<?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX); ?>)</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->TOTAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_TAX); ?></td>
						
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->POST_VOICE_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_VOICE_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->PRE_POST_VOICE_BL); ?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($record->ADJUSTMENT_VOICE_BL); ?></td>
						</tr>
						
						<tr >
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
					
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;" colspan=4>Ratio</td>
						</tr>
						<tr >
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
				
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $total_voice=$record->POST_VOICE_BL+$record->PRE_VOICE_BL;$post_ratio_voice=(($record->POST_VOICE_BL/$total_voice)*100); echo number_format($post_ratio_voice); ?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $pre_ratio_voice=(($record->PRE_VOICE_BL/$total_voice)*100); echo number_format($pre_ratio_voice);?>%</td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($post_ratio_voice+$pre_ratio_voice); ?>%</td>
						</tr>
				
				 <tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							
							<td colspan=4 style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;">Adjustment - Taka</td>
						</tr>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adj_post_voice=(($post_ratio_voice * ($record->ADJUSTMENT_VOICE_BL))/100); echo number_format($adj_post_voice);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php $adj_pre_voice= (($pre_ratio_voice * ($record->ADJUSTMENT_VOICE_BL))/100); echo number_format($adj_pre_voice);?></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"></td>
							<td style="mso-number-format:'\@';border-top:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;"><?php echo number_format($adj_post_voice+$adj_pre_voice);?></td>
						</tr>
				 
				
				    
				 </table>
				 <table class="table table-borderless">
				  
				
				  <tr>
			 	       <td colspan=2><h5>Distribution Line:</h5></td>
			 	       
			 	     </tr>
			 	     <tr>
			 	       <td>Inv. Date</td>
			 	       <td><?php echo date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
			 	     </tr>
				     <tr>
				       <td>Inv. Ref:</td>
				       <td><?php echo $record->OPERATOR; ?>/<?php echo $record->INVOICE_NUMBER ?></td>
				     </tr>
				     <tr>
				       <td>Inv. Amount: Tk.</td>
				       <td><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				     </tr>
				 
				  <tr>
				       <td>Inv. Amount: Tk.</td>
				       <td><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS+$record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td></td>
				       <td>A/C Code:</td>
				       <td>Project Code</td>
				       <td></td>
				       <td></td>
				       <td>Taka</td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>ACCOUNT CODE</td>
				       <td>TAX CODE</td>
				       <td>AIT CODE</td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td></td>
				       <td><?php echo $gl_info->ACCURED;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right"><?php echo number_format($record->PRE_POST_VOICE_BL); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->ACCURED;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td></td>
				       <td><?php echo $gl_info->ACCURED;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right"><?php echo number_format($adj_post_voice); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->ACCURED;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td></td>
				       <td><?php echo $gl_info->ACCURED;?></td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td>Accrued Expenses - Interconnection</td>
				       <td align="right"><?php echo number_format($adj_pre_voice); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.<?php echo $gl_info->ACCURED;?>.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     
		
		
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>VAT</td>
				       <td>1019602</td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Assets - </td>
				       <td>VAT Current Account @ <?php echo $record->VAT_RATE;?>% (Auto Calculate)</td>
				       <td align="right"><?php echo number_format($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT); ?></td>
				       <td class="" style="width:15px;">&nbsp;</td>
				       <td>01.101.A000.1019602.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				    
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				       <td colspan="5">Total</td>
				       <td align="right"> <?php echo number_format(($adj_pre_voice+$adj_post_voice+$record->PRE_POST_VOICE_BL)+($record->ACTUAL_INVOICE_AMOUNT_FOR_MMS_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE_AFTER_VAT+$record->ACTUAL_INVOICE_AMOUNT_FOR_SMS_AFTER_VAT),2);?></td>
					  <td colspan=4></td>
				     </tr>
				     <tr style="border-color: #cccccc #cccccc #cccccc #cccccc;border-style: solid solid solid solid;border-width: 1px 1px 1px 1px;">
				     	 <td>&nbsp;</td>
				     	 <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				       <td>&nbsp;</td>
				     </tr>
				     
				    
				 </table>
			</div>


<?php } ?>
		</div>
		
	</div>
</body>
</html>






























