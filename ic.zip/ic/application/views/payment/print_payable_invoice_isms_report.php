<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 8 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Payable Invoice IGW Report";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $report_name; ?></title>

	<style type="text/css">
	#printArea { width:1024px; margin:auto; }
	/*body, table {font-family:tahoma; font-size:13px; border-collapse: collapse;}*/
	table td { padding:8px;}

	 table.table-borderless td,table.table-borderless th{
	     border: none !important;
	}

</style>

<?php if( $action_type == 'print'): ?>
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
	<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

	<!-- print plugin -->
	<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#printArea').jqprint();
			$('#print_icon').click(function(){
				$('#printArea').jqprint();
			});
		});
	</script>
<?php endif; ?>

<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

</head>

<body>
	<!--<a id="print_icon" href="#">Print</a>-->
	<div id="printArea">

		<div class="container">
			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td align="center" colspan="<?php echo $total_column; ?>">
							<div style="font-size:150%;"><?php echo $domain_name; ?></div>
						</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr style="border-top:1px solid #ccc;">
						<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
					</tr>
					<tr>
						<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp;<?php if(isset($filter_by)): ?>|&nbsp;<?php echo $filter_by; endif;?></td>
					</tr>
					<tr><td>&nbsp;</td></tr>
				</table>
			</div>
				
			<div class="row">
				<table class="table table-borderless">
					<tr>
						<td>OP Name</td>
						<td colspan="3"><?php echo $record->OPERATOR; ?></td>
					</tr>
					<tr>
						<td>Operator Type</td>
						<td>ISMS</td>
					</tr>
					<tr>
						<td>Bill Month</td>
						<?php 
							$date = new DateTime($record->REPORT_DATE);
							//$date->modify('-1 month');
						?>
						<td><?php echo $date->format('d-M-y'); ?></td>
					</tr>
					<tr>
						<td>Description</td>
						<td><?php echo $record->OPERATOR.', ISMS'.','.$date->format('M-y').',INVOICE, Inter connect call carrying charges payable Inv#'.$record->INVOICE_NUMBER." dated ".date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
					</tr>
					<tr>
						<td>Vendor Code</td>
						<td><?php echo $record->SUPPLIER_CODE; ?></td>
					</tr>
				</table>
			</div>

			<div class="row">
				<h5><?php echo $record->OPERATOR.'(ISMS)' ?> <?php echo $date->format('F-Y'); ?></h5>
				<div class="col-md-12">
					<table class="table-bordered" style="width: 500px">
						<tr>
							<td>Month</td>
							<td>Expenses Euro</td>
							<td>Revenue Euro</td>
							<td>Net Expense Euro</td>
							<td>Conv. Rate Euro to Tk</td>
							<td>Expenses Tk</td>
							<td>Revenue Tk</td>
							<td>Net Expense Tk</td>
							<td>Conv. Rate USD to Tk</td>
							<td>Expenses USD</td>
							<td>Revenue USD</td>
							<td>Net Expense USD</td>
						</tr>
						<tr>
							<td><?php echo $date->format('d-M-y'); ?></td>
							<td align="right"><?php $expenses_euro=$record->EXPENSES_EURO; echo number_format($expenses_euro,2);?></td>
							<td align="right"><?php $revenue_euro=$record->REVENUE_EURO; echo number_format($revenue_euro,2);?></td>
							<td align="right"><?php $net_expense_euro=$record->NET_EXPENSE_EURO; echo number_format($net_expense_euro,2);?></td>
							<td align="right"><?php $euro_to_tk_covertion_rate=$record->EURO_TO_TK_COVERTION_RATE; echo number_format($euro_to_tk_covertion_rate,2);?></td>
							<td align="right"><?php $expenses_tk=$record->EXPENSES_TK; echo number_format($expenses_tk,2);?></td>
							<td align="right"><?php $revenue_tk=$record->REVENUE_TK; echo number_format($revenue_tk,2);?></td>
							<td align="right"><?php $net_expense_tk=$record->NET_EXPENSE_TK; echo number_format($net_expense_tk,2);?></td>
							<td align="right"><?php $usd_to_tk_covertion_rate=$record->USD_TO_TK_COVERTION_RATE; echo number_format($usd_to_tk_covertion_rate,2);?></td>
							<td align="right"><?php $expenses_usd=$record->EXPENSES_USD; echo number_format($expenses_usd,2);?></td>
							<td align="right"><?php $revenue_usd=$record->REVENUE_USD; echo number_format($revenue_usd,2);?></td>
							<td align="right"><?php $net_expense_usd=$record->NET_EXPENSE_USD; echo number_format($net_expense_usd,2);?></td>
						</tr>
						<tr>
							<td>Total</td>
							<td align="right"><?php $expenses_euro=$record->EXPENSES_EURO; echo number_format($expenses_euro,2);?></td>
							<td align="right"><?php $revenue_euro=$record->REVENUE_EURO; echo number_format($revenue_euro,2);?></td>
							<td align="right"><?php $net_expense_euro=$record->NET_EXPENSE_EURO; echo number_format($net_expense_euro,2);?></td>
							<td align="right"></td>
							<td align="right"><?php $expenses_tk=$record->EXPENSES_TK; echo number_format($expenses_tk,2);?></td>
							<td align="right"><?php $revenue_tk=$record->REVENUE_TK; echo number_format($revenue_tk,2);?></td>
							<td align="right"><?php $net_expense_tk=$record->NET_EXPENSE_TK; echo number_format($net_expense_tk,2);?></td>
							<td align="right"></td>
							<td align="right"><?php $expenses_usd=$record->EXPENSES_USD; echo number_format($expenses_usd,2);?></td>
							<td align="right"><?php $revenue_usd=$record->REVENUE_USD; echo number_format($revenue_usd,2);?></td>
							<td align="right"><?php $net_expense_usd=$record->NET_EXPENSE_USD; echo number_format($net_expense_usd,2);?></td>
						</tr>
					</table>
				</div>
			</div>

			<div class="row">
				 <table class="table table-borderless">
			 	     <tr>
			 	       <td>Inv. Date</td>
			 	       <td><?php echo date('d-M-y', strtotime($record->REPORT_MONTH)); ?></td>
			 	     </tr>
				     <tr>
				       <td>Inv. Ref:</td>
				       <td><?php echo $record->INVOICE_NUMBER; ?></td>
				     </tr>
				     <tr>
				       <td>Inv. Amount: (USD)</td>
				       <td><?php echo number_format($net_expense_usd,2); ?></td>
				     </tr>
				 </table>
			</div>
			<div class="row">
				<h5>Distribution Line:</h5>
				<?php 
					$exclude_ait_usd_1=(($expenses_usd * $record->B2B_COST_RATIO)/100);
					$exclude_ait_usd_2=(($expenses_usd * $record->B2C_COST_RATIO)/100);
					$exclude_ait_usd_3=(($revenue_usd * $record->B2B_REVENUE_RATIO)/100);
					$exclude_ait_usd_4=(($revenue_usd * $record->B2C_REVENUE_RATIO)/100);
					
					$total_exclude_ait_usd=$exclude_ait_usd_1+$exclude_ait_usd_2-$exclude_ait_usd_3-$exclude_ait_usd_4;
					$total_ait_usd=$exclude_ait_usd_1+$exclude_ait_usd_2+$exclude_ait_usd_3+$exclude_ait_usd_4;

					$uit_ait_1=$exclude_ait_usd_1+($total_exclude_ait_usd/(1-($record->AIT_RATIO/100))* ($record->AIT_RATIO/100) * ($record->B2B_COST_RATIO/100));
					$uit_ait_2=$exclude_ait_usd_2+($total_exclude_ait_usd/(1-($record->AIT_RATIO/100))* ($record->AIT_RATIO/100) * ($record->B2C_COST_RATIO/100));
					$uit_ait_3=$exclude_ait_usd_3;
					$uit_ait_4=$exclude_ait_usd_4;
					$total_uit_ait=($uit_ait_1+$uit_ait_2)-($uit_ait_3+$uit_ait_4);
					$ait1=$uit_ait_1*($record->AIT_RATIO/100);
					$ait2=$uit_ait_2*($record->AIT_RATIO/100);
					$ait3=$uit_ait_3*($record->AIT_RATIO/100);
					$ait4=$uit_ait_4*($record->AIT_RATIO/100);
					$total_ait=-$ait1-$ait2+$ait3+$ait4;
					$bdt1=$exclude_ait_usd_1*$usd_to_tk_covertion_rate;
					$bdt2=$exclude_ait_usd_2*$usd_to_tk_covertion_rate;
					$bdt3=$exclude_ait_usd_3*$usd_to_tk_covertion_rate;
					$bdt4=$exclude_ait_usd_4*$usd_to_tk_covertion_rate;
					$total_bdt=$bdt1+$bdt2-$bdt3-$bdt4;
				?>
				 <table class="table table-borderless">
				     <tr>
				       <td colspan="3">A/C Code:</td>
				       <td >Withholding TAX</td>
				       <td>Taka</td>
				       <td>Paste the below</td>
				       <td>Paste the below</td>
				       <td>Paste the below</td>
				     </tr>
				     <tr>
				     	 <td>01.101.A000.5012928.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				     	 <td><?php echo $record->TAX_CODE;?></td>
				       <td>Interconnection Expenses - Others (Postpaid)</td>
				       <td><?php echo number_format($uit_ait_1,2);?></td>
				       <td>(<?php echo number_format($ait1,2);?>)</td>
				       <td> <?php echo number_format($exclude_ait_usd_1,2);?> </td>
				       <td> <?php echo number_format($bdt1,2);?> </td>
				     </tr>
				     <tr>
				     	 <td>01.101.A000.5017423.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				     	 <td><?php echo $record->TAX_CODE;?></td>
				       <td>Interconnection Expenses - Others (Postpaid)</td>
				       <td><?php echo number_format($uit_ait_2,2);?></td>
				       <td>(<?php echo number_format($ait2,2);?>)</td>
				       <td> <?php echo number_format($exclude_ait_usd_2,2);?> </td>
				       <td> <?php echo number_format($bdt2,2);?> </td>
				     </tr>
				     <tr>
				     	 <td>01.101.A000.4012755.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				     	 <td><?php echo $record->TAX_CODE;?></td>
				       <td>Interconnection Revenue - Others (Postpaid)</td>
				       <td>(<?php echo number_format($uit_ait_3,2);?>)</td>
				       <td><?php echo number_format($ait3,2);?></td>
				       <td>( <?php echo number_format($exclude_ait_usd_3,2);?>) </td>
				       <td> (<?php echo number_format($bdt3,2);?>) </td>
				     </tr>
				     <tr>
				     	 <td>01.101.A000.4017455.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				     	 <td><?php echo $record->TAX_CODE;?></td>
				       <td>Interconnection Revenue - Others (Postpaid)</td>
				       <td>(<?php echo number_format($uit_ait_4,2);?>)</td>
				       <td><?php echo number_format($ait4,2);?></td>
				       <td> (<?php echo number_format($exclude_ait_usd_4,2);?>) </td>
				       <td> (<?php echo number_format($bdt4,2);?>) </td>
				     </tr>
				    
				     <tr>
				     	 <td colspan=3>Total</td>
				       <td><?php if(0>$total_uit_ait){echo '(';}?><?php echo number_format(abs($total_uit_ait),2);?><?php if(0>$total_uit_ait){echo ')';}?></td>
				       <td><?php if(0>$total_ait){echo '(';}?><?php echo number_format(abs($total_ait),2);?><?php if(0>$total_ait){echo ')';}?></td>
				       <td><?php if(0>$total_exclude_ait_usd){echo '(';}?> <?php echo number_format(abs($total_exclude_ait_usd),2);?> <?php if(0>$total_exclude_ait_usd){echo ')';}?></td>
				       <td><?php if(0>$total_bdt){echo '(';}?> <?php echo number_format(abs($total_bdt),2);?><?php if(0>$total_bdt){echo ')';}?> </td>
				     </tr>
				     
				 </table>
			</div>
		</div>
		
	</div>
</body>
</html>