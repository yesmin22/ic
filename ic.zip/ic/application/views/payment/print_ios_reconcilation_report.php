<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/floatThead/dist/jquery.floatThead.min.js"></script>
	<style>
		.newmenufilter{
			font-size: 0.5em;
		 	width: 1300px;
		 	overflow-x: auto;
		  white-space: nowrap; 
		}
		.newdesign{
			font-size: 10px;
		}
	</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/iims/iims_header.php"); ?></div>
		<div id="page_manage_public_nat" class="main_container page_identifier">
			<div class="page_caption">&nbsp;Manage Public NAT </div>
			<div class="page_body table-responsive" style="min-height:420px">
				<div>
				<ul class="nav nav-tabs">
							<?php
								$active_class = $this->uri->segment(2);
								$active_class = $this->webspice->encrypt_decrypt($active_class,'decrypt');
							?>
							<li class="<?php if($active_class==false || $active_class=='all'){echo 'active';}else{echo '';}?>">
								<a href="<?php echo $url_prefix; ?>manage_public_nat/<?php echo $this->webspice->encrypt_decrypt('all','encrypt'); ?>">
									<b>All</b>
								</a>
							</li>
							<?php
							foreach($site_tab as $key=>$value):
							?>
							<li class="<?php echo ($active_class==$value->OPTION_ID) ? 'active' : '' ;?>">
								<a href="<?php echo $url_prefix; ?>manage_public_nat/<?php echo $this->webspice->encrypt_decrypt($value->OPTION_ID,'encrypt'); ?>">
									<b><?php echo $value->OPTION_VALUE; ?></b>
								</a>
							</li>
							<?php endforeach; ?>
						</ul>
				</div>
						
					<br />
				<!--filter section-->
				<form id="frm_filter" method="post" action="<?php echo $url_prefix; ?>manage_public_nat/<?php echo $route_name; ?>/filter" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					<input type="hidden" name="table_name" value="TBL_LB_PUBLIC_NAT" id="table_name">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td><input type="text" name="SearchKeyword" class="form-control" /></td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix.$this->uri->segment(1); ?>/<?php echo $route_name;?>/refresh">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix.$this->uri->segment(1); ?>/<?php echo $route_name;?>/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix.$this->uri->segment(1); ?>/<?php echo $route_name;?>/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
				</form>
				
				<br />
				<?php if(isset($active_class)){?>
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<div style="overflow:auto; height:350px" id="draggable_scroll">
					<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
				<table class="table pims_data_table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th>SL No</th>
						<th>Site Name</th>
						<th>Sourch</th>
						<th>Local Destination</th>
						<th>Public Destination</th>
						<th>Ports</th>
						<th>Status</th>
						<th>Edit</th>
					</tr>
					</thead>
					<tbody>
					<?php $i=$page_index; foreach($get_record as $k=>$v): ?>
					<tr id="<?php echo $v->ID;?>" class="data-in-table">
						<td><?php echo $i; ?></td>
						<td class="SITE_NAME" ><?php echo $this->customcache->option_maker($v->SITE_NAME,'OPTION_VALUE'); ?></td>
						<td class="SOURCE" ><?php echo $v->SOURCE; ?></td>
						<td class="LOCAL_DESTINATION" ><?php echo $v->LOCAL_DESTINATION; ?></td>
						<td class="PUBLIC_DESTINATION" ><?php echo $v->PUBLIC_DESTINATION; ?></td>
						<td class="PORTS" ><?php echo $v->PORTS; ?></td>
						<td><?php echo $this->webspice->static_status($v->STATUS); ?></td>
						<td>
							<?php if( $this->webspice->permission_verify('manage_public_nat',true)): ?>
								<a href="<?php echo $url_prefix; ?>manage_public_nat/<?php echo $route_name; ?>/edit/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn btn-warning btn-xs" title="Edit">Edit</a>
							<?php endif; ?>
						</td>
					</tr>
					<?php 
						$i++;
						endforeach;
					?>
				</tbody>
				</table>
				</div>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
				<?php } ?>
			</div><!--end .page_body-->
		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/other_footer.php"); ?></div>
	</div>
	<script>
		var $table = $('table.new_table');
		$table.floatThead({
		    scrollContainer: function($table){
		        return $table.closest('#draggable_scroll');
		    }
		});
	</script>
</body>
</html>