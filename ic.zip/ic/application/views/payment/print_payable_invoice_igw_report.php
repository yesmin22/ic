<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 8 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Payable Invoice IGW Report";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $report_name; ?></title>

	<style type="text/css">
	#printArea { width:1024px; margin:auto; }
	/*body, table {font-family:tahoma; font-size:13px; border-collapse: collapse;}*/
	table td { padding:8px;}

	 table.table-borderless td,table.table-borderless th{
	     border: none !important;
	}

</style>

<?php if( $action_type == 'print'): ?>
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
	<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

	<!-- print plugin -->
	<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#printArea').jqprint();
			$('#print_icon').click(function(){
				$('#printArea').jqprint();
			});
		});
	</script>
<?php endif; ?>

<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>

</head>

<body>
	<!--<a id="print_icon" href="#">Print</a>-->
	<div id="printArea">

		<div class="container">
			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td align="center" colspan="<?php echo $total_column; ?>">
							<div style="font-size:150%;"><?php echo $domain_name; ?></div>
						</td>
					</tr>
				</table>
			</div>

			<div class="row">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
					<tr style="border-top:1px solid #ccc;">
						<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
					</tr>
					<tr>
						<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp;<?php if(isset($filter_by)): ?>|&nbsp;<?php echo $filter_by; endif;?></td>
					</tr>
					<tr><td>&nbsp;</td></tr>
				</table>
			</div>
				
			<div class="row">
				<table class="table table-borderless">
					<tr>
						<td>OP Name</td>
						<td colspan="3"><?php echo $record->OPERATOR; ?></td>
					</tr>
					<tr>
						<td>Operator Type</td>
						<td>ICX</td>
					</tr>
					<tr>
						<td>Bill Month</td>
						<?php 
							$date = new DateTime($record->REPORT_DATE);
							//$date->modify('-1 month');
						?>
						<td><?php echo $date->format('d-M-y'); ?></td>
					</tr>
					<tr>
						<td>Description</td>
						<td><?php echo $record->OPERATOR.', ICX'.','.$date->format('M-y').',INVOICE, Inter connect call carrying charges payable Inv#'.$record->INVOICE_NUMBER." dated ".date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
					</tr>
					<tr>
						<td>OPTYPE</td>
						<td>IGW</td>
					</tr>
					<tr>
						<td>Vendor Code</td>
						<td><?php echo $record->SUPPLIER_CODE; ?></td>
					</tr>
				</table>
			</div>

			<div class="row">
				<h5><?php echo $record->OPERATOR.'(ICX)' ?> - ISD Revenue Sharing Charge - <?php echo $date->format('F-Y'); ?></h5>
				<div class="col-md-6">
					<table class="table-bordered" style="width: 500px">
						<tr>
							<td></td>
							<td colspan="4" class="text-center">Actual Amount</td>
						</tr>
						<tr>
							<td>Bill Amount</td>
							<td>VAT</td>
							<td>Tax @ <?php echo $record->TAX_RATE;?>%</td>
							<td>Total</td>
						</tr>
						<tr>
							<td align="right"><?php $invoice_amount = $record->ACTUAL_INVOICE_AMOUNT_FOR_VOICE ; echo number_format($invoice_amount,2) ?></td>
							<td align="right"><?php $vat = $record->VAT; echo number_format($vat,2);?></td>
							<td align="right">(<?php $tax = $record->TAX; echo number_format($tax,2);?>)</td>
							<td align="right"><?php $total_amount = $record->TOTAL_AMOUNT; echo number_format($total_amount,2);?></td>
						</tr>
					</table>
				</div>
				<div class="col-md-6">
					<table class="table-bordered" style="width: 500px">
						<tr>
							<td colspan="3" class="text-center">Provision Made as per IT Report</td>
							<td></td>
						</tr>
						<tr>
							<td>Postpaid</td>
							<td>Prepaid</td>
							<td>Total</td>
							<td>Adjustment</td>
						</tr>
						<tr>
							<td align="right">-</td>
							<td align="right">-</td>
							<td align="right"><?php echo number_format($invoice_amount,2);?></td>
							<td align="right">-</td>
						</tr>
						<tr>
							<td colspan="4" class="text-center">Ratio</td>
						</tr>
						<tr>
							<td align="right">0%</td>
							<td align="right">0%</td>
							<td></td>
							<td align="right">-</td>
						</tr>
						<tr>
							<td colspan="4" class="text-center">Adjustment - Taka</td>
						</tr>
						<tr>
							<td align="right">-</td>
							<td align="right">-</td>
							<td align="right"></td>
							<td align="right">-</td>
						</tr>
					</table>
				</div>
			</div>

			<div class="row">
				 <table class="table table-borderless">
			 	     <tr>
			 	       <td>Inv. Date</td>
					   
			 	       <td><?php echo date('d-M-y', strtotime($record->REPORT_DATE)); ?></td>
			 	     </tr>
				     <tr>
				       <td>Inv. Ref:</td>
				       <td><?php echo $record->OPERATOR ?>/ DOM /ICX/<?php echo $record->INVOICE_NUMBER ?></td>
				     </tr>
				     <tr>
				       <td>Inv. Amount: Tk.</td>
				       <td><?php echo number_format($invoice_amount,2); ?></td>
				     </tr>
				 </table>
			</div>
			<div class="row">
				<h5>Distribution Line:</h5>
				 <table class="table table-borderless">
				     <tr>
				       <td>A/C Code:</td>
				       <td colspan="3">Project Code</td>
				       <td>Taka</td>
				       <td>Paste the below</td>
				       <td>Paste the below</td>
				       <td>Paste the below</td>
				     </tr>
				     <tr>
				       <td>2012751</td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Liability -</td>
				       <td> Accrued Expenses - Interconnection</td>
				       <td align="right"><?php echo number_format($invoice_amount,2);?></td>
				       <td>01.101.A000.2012751.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td>5012201</td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td> Expenses - </td>
				       <td>Interconnection Expenses - Postpaid</td>
				       <td align="right">-</td>
				       <td>01.101.A000.5012201.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td>5011201</td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td>Expenses - </td>
				       <td>Interconnection Expenses - Prepaid </td>
				       <td align="right">-</td>
				       <td>01.101.A000.5011201.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				     <tr>
				       <td>2018102</td>
				       <td><?php echo $operator_info->PROJECT_CODE;?></td>
				       <td> Assets -</td>
				       <td> Advance Income Tax</td>			       
				       <td align="right"><?php echo number_format($tax,2);?></td>
				       <td>01.101.A000.2018102.0000.<?php echo $operator_info->PROJECT_CODE;?>.0000</td>
				       <td><?php echo $record->TAX_CODE;?></td>
				       <td><?php echo $record->VAT_CODE;?></td>
				     </tr>
				    
				     <tr>				       
				     	 <td colspan="4">Total</td>
				       <td align="right"><?php echo number_format( $invoice_amount - $tax, 2); ?></td>
				     </tr>
				     
				 </table>
			</div>
		</div>
		
	</div>
</body>
</html>