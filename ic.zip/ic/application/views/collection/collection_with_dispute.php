<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Payment Allocation WO PNR</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
	<style>
		.table-condensed>thead>tr>th, .table-condensed>tbody>tr>th, .table-condensed>tfoot>tr>th, .table-condensed>thead>tr>td, .table-condensed>tbody>tr>td, .table-condensed>tfoot>tr>td{
		    padding: 5px;
		}
		.type_checkbox{cursor:pointer;}
		input{text-align:right;}
		
		[data-tip] {
			position:relative;
		
		}
		[data-tip]:before {
			content:'';
			/* hides the tooltip when not hovered */
			display:none;
			content:'';
			border-left: 5px solid transparent;
			border-right: 5px solid transparent;
			border-bottom: 5px solid #1a1a1a;	
			position:absolute;
			top:30px;
			left:35px;
			z-index:8;
			font-size:0;
			line-height:0;
			width:0;
			height:0;
		}
		[data-tip]:after {
			display:none;
			content:attr(data-tip);
			position:absolute;
			top:35px;
			left:0px;
			padding:5px 8px;
			background:#1a1a1a;
			color:#fff;
			z-index:9;
			font-size: 0.75em;
			height:28px;
			line-height:18px;
			-webkit-border-radius: 3px;
			-moz-border-radius: 3px;
			border-radius: 3px;
			white-space:nowrap;
			word-wrap:normal;
		}
		[data-tip]:hover:before,
		[data-tip]:hover:after {
			display:block;
		}
		
	</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_payment_allocation" class="main_container page_identifier">
			<div class="page_caption">Collection Info</div>
			<div class="page_body">
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="ID"name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />
					<div id="inv_search">
						<table style="width:auto;">
						<tr>
							<td style="width:550px">
								<div class="form_label">Operator Name *</div>
								 <div>
									<select name="OPERATOR_NAME" id="OPERATOR_NAME" class="input_m input_style" required>
									<option value="">Select One</option>
									<?php //echo $this->customcache->get_operator_invoice('option_for_type'); 
									foreach($operator_name as $k=>$v){?>
										<option value="<?php echo $v->OPERATOR_TYPE.'|'.$v->OPERATOR_NAME;?>"><?php echo $v->OPERATOR_NAME.'('.$v->OPERATOR_TYPE.')';?></option>
									<?php	}
									
									
									?>
									</select>
								 	<span	class="fred"><?php //echo form_error('ICX'); ?></span>
								 </div>
							</td>
							<td style="width:270px">
									<div class="form_label">Bill Period From Date *</div>
									<div class="month_picker_container">
		              	<input type="text" class="date_picker input_style" id="from_date" name="from_date" required/>
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td style="width:270px">
									<div class="form_label">Bill Period To Date *</div>
									<div class="month_picker_container">
		              	<input type="text" class="date_picker input_style" id="to_date" name="to_date" required/>
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td>
										<div class="form_label">TDS Rate </div>
										<div>
			               <select name="TDS_RATE" id="tds_rate" class="input_full input_style">
			               	<option value=''>SELECT ONE</option>
					            <option value='12'>12 %</option>
					            <option value='10'>10 %</option>
					            <option value='7.50'>7.50 %</option>
		             			</select>
											<span	class="fred"><?php //echo form_error('tds_rate'); 
												?></span>
										</div>
									</td>
							<td>
								<div class="form_label">&nbsp;</div>
								<div>
									<input id="btn_search" type="button" class="btn btn-success" value="Search" />
								</div>
							</td>
						</tr>
						<tr><td colspan=3><div class="spinner"></div></td></tr>
						</table>
					</div>
				</form>
				
				<form id="frm_payment_allocation_wo_pnr" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					<div id="inv_list"></div>
					<div >
					<fieldset>
					<table>
						<tr id="invoices"></tr>
						<tr>
							<input type="hidden" name='OPERATOR_NAME' value='' id='operator_name_new' />
							<input type="hidden" name='from_date' value='' id='from_date_new' />
							<input type="hidden" name='to_date' value='' id='to_date_new' />
							<input type="hidden" name='TDS_RATE' value='' id='tds_rate_new' />
								<td>
									<div class="form_label">Total Settlement*</div>
									<div>
		               <input type="text" id="cheque_amount_settlement" name="CHEQUE_AMOUNT_SETTLEMENT" class="input_full input_style" value="<?php //echo set_value('CHEQUE_AMOUNT_SETTLEMENT',$edit['CHEQUE_AMOUNT_SETTLEMENT']); 
		               ?>" required readonly/>
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT_SETTLEMENT'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Cheque Amount Remaining*</div>
									<div>
		               <input type="text" id="cheque_amount_remaining" name="CHEQUE_AMOUNT_REMAINING" class="input_full input_style" value="" required readonly/>
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT_REMAINING'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">TDS Settlement*</div>
									<div>
		               <input type="text" id="tds_settlement" name="TDS_SETTLEMENT" class="input_full input_style" value="" required readonly/>
										<span	class="fred"><?php echo form_error('TDS_SETTLEMENT'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Total Settlement*</div>
									<div>
		               <input type="text" id="total_settlement" name="TOTAL_SETTLEMENT" class="input_full input_style" value="" required readonly/>
										<span	class="fred"><?php echo form_error('TOTAL_SETTLEMENT'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td >
									<div class="form_label">Bank Name</div>
									<div>
		               <input type="text" id="bank_name" name="BANK_NAME" class="input_full input_style" value="" />
										<span	class="fred"><?php echo form_error('BANK_NAME'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Bank Account</div>
									<div>
		               <input type="text" id="bank_account" name="BANK_ACCOUNT" class="input_full input_style" value="" />
										<span	class="fred"><?php echo form_error('BANK_ACCOUNT'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Cheque Number</div>
									<div>
		               <input type="text" id="CHEQUE_NUMBER" name="CHEQUE_NUMBER" class="input_full input_style" value="" required />
										<span	class="fred"><?php echo form_error('CHEQUE_NUMBER'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Cheque Amount*</div>
									<div>
		               <input type="text" id="CHEQUE_AMOUNT" name="CHEQUE_AMOUNT" class="input_full input_style" value="" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
								<td>
									<div class="form_label">Cheque Date*</div>
									<div class="month_picker_container">
										<input type="text" id="CHEQUE_DATE" name="CHEQUE_DATE" class="date_picker input_style" value="" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Entry Date*</div>
									<div class="month_picker_container">
										<input type="text" id="ENTRY_DATE" name="ENTRY_DATE" class="date_picker input_style" value="<?php echo date("Y/m/d");?>" required />
										<span	class="fred"></span>
									</div>
								</td>
						</tr>
					</table>
					</fieldset>
				</div>
					<div><input id="btn_submit" type="submit" class="btn_gray confirmation" value="Allocate" /></div>
				</form>
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
	<script type="text/javascript">
		$(document).ready(function(){
			var token = $('#token').val();
			var spinner = $('.spinner');
			$("#btn_search").click(function(){
				var operator_name = $("#OPERATOR_NAME").val();
				var from_date = $("#from_date").val();
				var to_date = $("#to_date").val();
				var token = $('#token').val();
				var tds_rate= $('#tds_rate').val();
				//if(!tds_rate){
				//	alert("You want to collect amount without TDS or you should select TDS!");
				//}
        $("#operator_name_new").val(operator_name);
        $("#to_date_new").val(to_date);
        $("#from_date_new").val(from_date);
        $("#tds_rate_new").val(tds_rate);
				
			
				if(!operator_name){
					alert("Please select Operator Name!");
					return false;
				}
				if(!from_date){
					alert("Please select From Date!");
					return false;
				}
				if(!to_date){
					alert("Please select To Date!");
					return false;
				}
				$(spinner).show();
	
				var ajaxCall = $.ajax({
				 type: "POST",
				 url: url_prefix + "get_invoice_amount_for_collection_with_dispute",
				 data: { ajax_call: "get_invoice", csrf_webspice_tkn:token, tds_rate:tds_rate, operator_name:operator_name, from_date: from_date,to_date: to_date}
				}).done(function(msg){
					$("#inv_list").html(msg);
					$(spinner).hide();
				}).fail(function() {
					alert( "Failed: We could not execute your request. Please try again later or report to authority." );
					$(spinner).hide();
				});
			});
			
		  $("input").focus(function(){
		  	$(this).css("text-align","left");
		  	var temp = $(this).val();
		  	$(this).val("").val(temp);
		  }).focusout(function(){
		  	$(this).css("text-align","right");
		  });
	  
			var $chkboxes = $('.type_checkbox');
			var lastChecked = null;
			$(document.body).on('change',".type_checkbox",function() {
				var selected_chkbox = $(this).val();
				if ( $(this).is(":checked")){
					//6/24/18 3:37
					  var tds=0;
						settlement=$("#remaining_amount_new_for_calculation"+selected_chkbox).val();
						$("#sattled"+selected_chkbox).val(settlement);
						$("#tds"+selected_chkbox).val(tds);
						$("#remaining"+selected_chkbox).val(0);
						$("#total_sattled"+selected_chkbox).val(settlement);
						$("#sattled"+selected_chkbox).removeAttr('disabled');	
		      	$("#tds"+selected_chkbox).removeAttr('disabled');
			      //$("#tds_remaining"+id_for_val).removeAttr('disabled');
			      $("#dispute"+selected_chkbox).removeAttr('disabled');
			      $("#total_sattled"+selected_chkbox).removeAttr('disabled');
					
					
					
		
					
					 $("#full_partial"+selected_chkbox).removeAttr('disabled');
					 $("#include_tax"+selected_chkbox).removeAttr('disabled');
					 var cheque_amount = $("#CHEQUE_AMOUNT").val();
			  	total_payable_amount = calculate_total_payable_amt_again();
					total_payable_amount_tds = calculate_total_payable_tds_again();
					$("#cheque_amount_settlement").val(total_payable_amount.toFixed(2));
					cheque_rem=cheque_amount-total_payable_amount;
				  $("#cheque_amount_remaining").val(cheque_rem.toFixed(2));
				  $("#tds_settlement").val(total_payable_amount_tds.toFixed(2));
				  total_stl=parseFloat(total_payable_amount)+parseFloat(total_payable_amount_tds);
				  $("#total_settlement").val(total_stl.toFixed(2));	
			  }else{	
			  	
			  	//6/24/2018 6:25
			  	settlement=$("#remaining_amount_new_for_calculation"+selected_chkbox).val();
					$("#remaining"+selected_chkbox).val(settlement);
					$("#include_tax"+selected_chkbox).prop('checked', false); 
					$("#full_partial"+selected_chkbox).val("YES");
					$("#tds"+selected_chkbox).val('');
			  	$("#tds"+selected_chkbox).attr("disabled", true);
			  	$("#total_sattled"+selected_chkbox).val('');
			  	$("#total_sattled"+selected_chkbox).attr("disabled", true);
			  	$("#dispute"+selected_chkbox).val('');
			  	$("#sattled"+selected_chkbox).val('');
			  	$("#sattled"+selected_chkbox).attr("disabled", true);
			  	$("#dispute"+selected_chkbox).attr("disabled", true);
			  	
			  	
			  	
			  	
			  	
			  	
			  	
			  	
			  	
			  	
			  	
			  	var cheque_amount = $("#CHEQUE_AMOUNT").val();
			  	total_payable_amount = calculate_total_payable_amt_again();
					total_payable_amount_tds = calculate_total_payable_tds_again();
					$("#cheque_amount_settlement").val(total_payable_amount.toFixed(2));
					cheque_rem=cheque_amount-total_payable_amount;
				  $("#cheque_amount_remaining").val(cheque_rem.toFixed(2));
				  $("#tds_settlement").val(total_payable_amount_tds.toFixed(2));
				   total_stl=parseFloat(total_payable_amount)+parseFloat(total_payable_amount_tds);
				  $("#total_settlement").val(total_stl.toFixed(2));	
				
			  }
			});	
			
			

			$(document.body).on('click',".selectall",function(){
				if ( $(this).is(":checked")){
				$('.individual').not("[disabled]").each(function() { //loop through each checkbox
					this.checked = true; //select all checkboxes with class "checkbox1"
					 $(".cheack_all_class").removeAttr('disabled');
					 
					 
					//it's for full partial......not so much necessary

			var id_for_val = $(this).val();
		 	$("#sattled"+id_for_val).removeAttr('disabled');	
			$("#tds"+id_for_val).removeAttr('disabled');
			$("#tds_remaining"+id_for_val).removeAttr('disabled');
			$("#dispute"+id_for_val).removeAttr('disabled');
			$("#total_sattled"+id_for_val).removeAttr('disabled');
			full_partial=$("#full_partial"+id_for_val).val();
			var remaining_temp = $("#remaining"+id_for_val).val();
		 	remaining = $("#remaining_amount_new_for_calculation"+id_for_val).val();
		 	if(remaining_temp==0){
					$("#remaining"+id_for_val).val(remaining);
				}
			var tds = $("#tds_rate_hidden").val();
			var dispute = $("#dispute"+id_for_val).val();		
			if(dispute==''){
				dispute=0;
			}	
			if(full_partial!=''){
			if(full_partial=='YES' ){
				if ( $("#include_tax"+id_for_val).is(":checked")){
					var remaining_tds=(remaining * tds)/100;
					var sattled = (remaining - remaining_tds) - dispute; 
					var total_sattlement=parseFloat(remaining)- parseFloat(dispute);
					remaining_amount=remaining-(parseFloat(sattled)+parseFloat(remaining_tds));
					$("#remaining"+id_for_val).val(0);
					$("#sattled"+id_for_val).val(sattled.toFixed(2));
					$("#tds"+id_for_val).val(remaining_tds.toFixed(2));
					$("#dispute"+id_for_val).val(dispute);
					$("#total_sattled"+id_for_val).val(total_sattlement.toFixed(2));
				}else{
					var sattled = remaining - dispute; 
					remaining_amount=remaining-sattled;
					$("#remaining"+id_for_val).val(remaining_amount);
					$("#sattled"+id_for_val).val(sattled.toFixed(2));
					$("#tds"+id_for_val).val(0);
					$("#dispute"+id_for_val).val(dispute);
					$("#total_sattled"+id_for_val).val(sattled.toFixed(2));	
				}
				
			}else{
					if ( $("#include_tax"+id_for_val).is(":checked")){
						var remaining_tds=(remaining * tds)/100;
						var sattled = (remaining - remaining_tds) - dispute; 
						var total_sattlement=parseFloat(remaining)-parseFloat(dispute);
						$("#sattled"+id_for_val).val(sattled.toFixed(2));
						$("#tds"+id_for_val).val(remaining_tds.toFixed(2));
						$("#dispute"+id_for_val).val(dispute);
						$("#total_sattled"+id_for_val).val(total_sattlement.toFixed(2));	
					}else{
						var sattled = remaining - dispute; 
						$("#sattled"+id_for_val).val(sattled.toFixed(2));
						$("#tds"+id_for_val).val(0);
						$("#dispute"+id_for_val).val(dispute);
						$("#total_sattled"+id_for_val).val(sattled.toFixed(2));	
					}
				}
			
			var cheque_amount = $("#CHEQUE_AMOUNT").val();
			if(cheque_amount==''){
				cheque_amount=0;
				
			}
			total_payable_amount=calculate_total_payable_amt_again();
			total_payable_amount_tds = calculate_total_payable_tds_again();
			cheque_remaining=cheque_amount-total_payable_amount;
			$("#cheque_amount_remaining").val(cheque_remaining.toFixed(2));
			$("#cheque_amount_settlement").val(total_payable_amount.toFixed(2));
			$("#tds_settlement").val(total_payable_amount_tds.toFixed(2));	
			total_tds_amount=parseFloat(total_payable_amount)+parseFloat(total_payable_amount_tds);
			$("#total_settlement").val(total_tds_amount.toFixed(2));
			}else{
				$("#sattled"+id_for_val).val(0);
				$("#tds"+id_for_val).val(0);
				$("#dispute"+id_for_val).val(0);
				$("#total_sattled"+id_for_val).val(0);
				
				}	
					 
				
				});
			}else{
				$('.individual').not("[disabled]").each(function() { //loop through each checkbox
				$('.cheack_all_class').prop('checked', false); 
				var cur_tr = $(this).parent().parent();
        var remaining = cur_tr.find('.remaining_amount_new_for_calculation').val();	
				cur_tr.find('.remaining_amount').val(remaining);	
					
				cur_tr.find('.settlement').val('');	
				cur_tr.find('.settlement').attr("disabled", true);	
				cur_tr.find('.tds').val('');	
				cur_tr.find('.tds').attr("disabled", true);	
				cur_tr.find('.dispute').val('');	
				cur_tr.find('.dispute').attr("disabled", true);	
				cur_tr.find('.total_satelment').val('');	
				cur_tr.find('.total_satelment').attr("disabled", true);		
				
					$("#cheque_amount_settlement").val(0);
					$("#cheque_amount_remaining").val(0);
					$("#tds_settlement").val(0);
					$("#total_settlement").val(0);
					this.checked = false; //select all checkboxes with class "checkbox1"
				});
				
				}
			});
			
			function calculate_total_payable_amt_again(){
                var total_settlement=0;
                $(".type_checkbox").each(function(){
                        if($(this).is(':checked')){
                            var cur_tr = $(this).parent().parent();
                            var settlement = cur_tr.find('.settlement').val();
                            if(settlement==''){
                            	settlement=0;
                            	}
														total_settlement=parseFloat(total_settlement) + parseFloat(settlement);
														//alert(total_settlement);
                        }
                    });
				return total_settlement;
                    
        } 
		function calculate_total_payable_tds_again(){
                var total_tds=0;
                $(".type_checkbox").each(function(){
                        if($(this).is(':checked')){
                            var cur_tr = $(this).parent().parent();
                            var tds = cur_tr.find('.tds').val();
                            if(tds==''){
                            	tds=0;
                            	}
							total_tds=parseFloat(total_tds) + parseFloat(tds);
							//alert(total_settlement);
                        }
                    });
				return total_tds;
                    
       } 
			$('#CHEQUE_AMOUNT').on('keyup',function(){
				var check_amount=$("#CHEQUE_AMOUNT").val();
				cheque_amount_settlement=$("#cheque_amount_settlement").val();
				if(cheque_amount_settlement==''){cheque_amount_settlement=0;}
				remaining_amount=check_amount-cheque_amount_settlement;
				$("#cheque_amount_remaining").val(remaining_amount.toFixed(2));
			})
			
			function calculate_total_tds(){
                var total_tds=0;
                $(".type_checkbox").each(function(){
                        if($(this).is(':checked')){
                            var cur_tr = $(this).parent().parent();
                            var tds = cur_tr.find('.tds').val();
							total_tds=parseFloat(total_tds) + parseFloat(tds);
                        }
                    });
				return total_tds;
                    
       }
       
		$("#btn_submit").click(function(){
			var check_amount=$("#CHEQUE_AMOUNT").val();
			check_amount=parseFloat(check_amount);
			cheque_amount_settlement=$("#cheque_amount_settlement").val();
			cheque_amount_remaining=$("#cheque_amount_remaining").val();
			if(cheque_amount_remaining > 1){
				alert('Remaining amount should be 0');
				return false;
			}
			if(check_amount < cheque_amount_settlement){
				alert('Settlement amount should not more than cheque amount');
				return false;
			}
			$('.type_checkbox').each(function(){
				var cur_tr = $(this).parent().parent();	
				if($(this).is(':checked')){
					if(cur_tr.find('.full_partial').val()=='YES'){
						if(!cur_tr.find('.include_tax').is(':checked')){
							if( cur_tr.find('.remaining_amount_new_for_calculation').val() > cur_tr.find('.settlement').val() ){
								alert("Sum of settlement amount can not be less than remaining amount! Please check invoice number-"+cur_tr.find('.invoice_number').val());
								return false;
							}
						}
						
						/*if(cur_tr.find('.include_tax').is(':checked')){
							if( cur_tr.find('.remaining_amount_new_for_calculation').val() > (cur_tr.find('.settlement').val() + cur_tr.find('.tds').val())){
								alert("Sum of settlement amount and tds can not be less than remaining amount! Please check invoice number-"+cur_tr.find('.invoice_number').val());
								return false;
							}
						}else{
							if( cur_tr.find('.remaining_amount_new_for_calculation').val() > cur_tr.find('.settlement').val() ){
								alert("Sum of settlement amount can not be less than remaining amount! Please check invoice number-"+cur_tr.find('.invoice_number').val());
								return false;
							}
						}*/
					}
					
				}
				return false;
				
			});
			//alert('Settlement amount should not more than cheque amount');
		//	return false;
		
		
		})
			

		});
	</script>
</body>
</html>