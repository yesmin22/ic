<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Payment Allocation WO PNR</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
	<style>
		.table-condensed>thead>tr>th, .table-condensed>tbody>tr>th, .table-condensed>tfoot>tr>th, .table-condensed>thead>tr>td, .table-condensed>tbody>tr>td, .table-condensed>tfoot>tr>td{
		    padding: 5px;
		}
		.type_checkbox{cursor:pointer;}
		input{text-align:right;}
		
		[data-tip] {
			position:relative;
		
		}
		[data-tip]:before {
			content:'';
			/* hides the tooltip when not hovered */
			display:none;
			content:''; 
			border-left: 5px solid transparent;
			border-right: 5px solid transparent;
			border-bottom: 5px solid #1a1a1a;	
			position:absolute;
			top:30px;
			left:35px;
			z-index:8;
			font-size:0;
			line-height:0;
			width:0;
			height:0;
		}
		[data-tip]:after {
			display:none;
			content:attr(data-tip);
			position:absolute;
			top:35px;
			left:0px;
			padding:5px 8px;
			background:#1a1a1a;
			color:#fff;
			z-index:9;
			font-size: 0.75em;
			height:28px;
			line-height:18px;
			-webkit-border-radius: 3px;
			-moz-border-radius: 3px;
			border-radius: 3px;
			white-space:nowrap;
			word-wrap:normal;
		}
		[data-tip]:hover:before,
		[data-tip]:hover:after {
			display:block;
		}
		
	</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_payment_allocation" class="main_container page_identifier">
			<div class="page_caption">Payment Allocation</div>
			<div class="page_body">
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="ID"name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />
					<div id="inv_search">
						<table style="width:auto;">
						<tr>
							<td style="width:550px">
								<div class="form_label">Operator Name *</div>
								 <div>
									<select name="OPERATOR_NAME" id="OPERATOR_NAME" class="input_m input_style" required>
									<option value="">Select One</option>
									<?php echo $this->customcache->get_operator_invoice('option_for_type'); ?>
									</select>
								 	<span	class="fred"><?php //echo form_error('ICX'); ?></span>
								 </div>
							</td>
							<td style="width:270px">
									<div class="form_label">Bill Period From Date *</div>
									<div class="month_picker_container">
		              	<input type="text" class="date_picker input_style" id="from_date" name="from_date" required/>
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td style="width:270px">
									<div class="form_label">Bill Period To Date *</div>
									<div class="month_picker_container">
		              	<input type="text" class="date_picker input_style" id="to_date" name="to_date" required/>
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td>
										<div class="form_label">TDS Rate *</div>
										<div>
			               <select name="TDS_RATE" id="tds_rate" class="input_full input_style">
			               	<option value=''>SELECT ONE</option>
					            <option value='12'>12 %</option>
					            <option value='10'>10 %</option>
					            <option value='7.50'>7.50 %</option>
		             			</select>
											<span	class="fred"><?php //echo form_error('tds_rate'); 
												?></span>
										</div>
									</td>
							<td>
								<div class="form_label">&nbsp;</div>
								<div>
									<input id="btn_search" type="button" class="btn btn-success" value="Search" />
								</div>
							</td>
						</tr>
						<tr><td colspan=3><div class="spinner"></div></td></tr>
						</table>
					</div>
				</form>
				
				<form id="frm_payment_allocation_wo_pnr" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					<div id="inv_list"></div>
					<div >
					<fieldset>
					<table>
						<tr id="invoices"></tr>
						<tr>
							<input type="hidden" name='OPERATOR_NAME' value='' id='operator_name_new' />
							<input type="hidden" name='from_date' value='' id='from_date_new' />
							<input type="hidden" name='to_date' value='' id='to_date_new' />
							<input type="hidden" name='TDS_RATE' value='' id='tds_rate_new' />
								<td>
									<div class="form_label">Cheque Amount Settlement*</div>
									<div>
		               <input type="text" id="cheque_amount_settlement" name="CHEQUE_AMOUNT_SETTLEMENT" class="input_full input_style" value="<?php //echo set_value('CHEQUE_AMOUNT_SETTLEMENT',$edit['CHEQUE_AMOUNT_SETTLEMENT']); 
		               ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT_SETTLEMENT'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Cheque Amount Remaining*</div>
									<div>
		               <input type="text" id="cheque_amount_remaining" name="CHEQUE_AMOUNT_REMAINING" class="input_full input_style" value="" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT_REMAINING'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">TDS Settlement*</div>
									<div>
		               <input type="text" id="tds_settlement" name="TDS_SETTLEMENT" class="input_full input_style" value="" required />
										<span	class="fred"><?php echo form_error('TDS_SETTLEMENT'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Total Settlement*</div>
									<div>
		               <input type="text" id="total_settlement" name="TOTAL_SETTLEMENT" class="input_full input_style" value="" required />
										<span	class="fred"><?php echo form_error('TOTAL_SETTLEMENT'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td >
									<div class="form_label">Bank Name*</div>
									<div>
		               <input type="text" id="bank_name" name="BANK_NAME" class="input_full input_style" value="" />
										<span	class="fred"><?php echo form_error('BANK_NAME'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Bank Account*</div>
									<div>
		               <input type="text" id="bank_account" name="BANK_ACCOUNT" class="input_full input_style" value="" />
										<span	class="fred"><?php echo form_error('BANK_ACCOUNT'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Cheque Number*</div>
									<div>
		               <input type="text" id="CHEQUE_NUMBER" name="CHEQUE_NUMBER" class="input_full input_style" value="" required />
										<span	class="fred"><?php echo form_error('CHEQUE_NUMBER'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Cheque Amount*</div>
									<div>
		               <input type="text" id="CHEQUE_AMOUNT" name="CHEQUE_AMOUNT" class="input_full input_style" value="" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
								<td>
									<div class="form_label">Cheque Date*</div>
									<div class="month_picker_container">
										<input type="text" id="CHEQUE_DATE" name="CHEQUE_DATE" class="date_picker input_style" value="" required />
										<span	class="fred"></span>
									</div>
								</td>
								<td>
									<div class="form_label">Entry Date*</div>
									<div class="month_picker_container">
										<input type="text" id="ENTRY_DATE" name="ENTRY_DATE" class="date_picker input_style" value="" required />
										<span	class="fred"></span>
									</div>
								</td>
						</tr>
					</table>
					</fieldset>
				</div>
					<div><input id="btn_submit" type="submit" class="btn_gray confirmation" value="Allocate" /></div>
				</form>
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
	

	<script type="text/javascript">
		$(document).ready(function(){
			var token = $('#token').val();
			var spinner = $('.spinner');
			$("#btn_search").click(function(){
				var operator_name = $("#OPERATOR_NAME").val();
				var from_date = $("#from_date").val();
				var to_date = $("#to_date").val();
				var token = $('#token').val();
				var tds_rate= $('#tds_rate').val();
				//if(!tds_rate){
				//	alert("You want to collect amount without TDS or you should select TDS!");
				//}
				
				if(!operator_name){
					alert("Please select Operator Name!");
					return false;
				}
				if(!from_date){
					alert("Please select From Date!");
					return false;
				}
				if(!to_date){
					alert("Please select To Date!");
					return false;
				}
				$(spinner).show();
	
				var ajaxCall = $.ajax({
				 type: "POST",
				 url: url_prefix + "get_invoice_amount_for_collection_with_dispute",
				 data: { ajax_call: "get_invoice", csrf_webspice_tkn:token, tds_rate:tds_rate, operator_name:operator_name, from_date: from_date,to_date: to_date}
				}).done(function(msg){
					$("#inv_list").html(msg);
					$(spinner).hide();
				}).fail(function() {
					alert( "Failed: We could not execute your request. Please try again later or report to authority." );
					$(spinner).hide();
				});
			});
			
			
			
			
			/*$("#vendor_name").change(function(){
				var vendor_name = $(this).val();
				$(spinner).show();
				$("#inv_list").html('');
				var ajaxCall = $.ajax({
				 type: "POST",
				 url: url_prefix + "get_invoice_info",
				 data: { ajax_call: "get_period", csrf_webspice_tkn:token, vendor_name:vendor_name}
				}).done(function(msg){
					$("#period").html(msg);
					$("#period").trigger("chosen:updated");
					$(spinner).hide();
				}).fail(function() {
					alert( "Failed: We could not execute your request. Please try again later or report to authority." );
					$(spinner).hide();
				});
			});*/
			
			
			
		  $("input").focus(function(){
		  	$(this).css("text-align","left");
		  	var temp = $(this).val();
		  	$(this).val("").val(temp);
		  }).focusout(function(){
		  	$(this).css("text-align","right");
		  });
	  
			var $chkboxes = $('.type_checkbox');
			var lastChecked = null;
			$(document.body).on('change',".type_checkbox",function() {
				total_payable_amount=0;
				total_payable_amount_tds=0;
				var cheque_amount = $("#CHEQUE_AMOUNT").val();
				total_payable_amount = calculate_total_payable_amt();
				total_payable_amount_tds = calculate_total_payable_tds();
				$("#cheque_amount_settlement").val(total_payable_amount);
				$("#cheque_amount_remaining").val(cheque_amount-total_payable_amount);
				$("#tds_settlement").val(total_payable_amount_tds);
				$("#total_settlement").val(parseFloat(total_payable_amount)+parseFloat(total_payable_amount_tds));
			});
			
			function calculate_total_payable_amt(){
				total_payable_amount=0;
				$(".type_checkbox").each(function(){
						if($(this).is(':checked')){
							var cur_tr = $(this).parent().parent();
							var settlement = cur_tr.find('.settlement').val();
							var is_full = cur_tr.find('.is_full').val();
							if(is_full=''){
								alert('You should select first amount settlement is full sattled or partial!');
								return false;
							}
							total_payable_amount = parseFloat(total_payable_amount) + parseFloat(settlement);
						}
					});
					return total_payable_amount;
			}
			
			
			function calculate_total_payable_tds(){
				total_payable_amount_tds=0;
				$(".type_checkbox").each(function(){
						if($(this).is(':checked')){
							var cur_tr = $(this).parent().parent();
							var tds = cur_tr.find('.tds').val();
							total_payable_amount_tds = parseFloat(total_payable_amount_tds) + parseFloat(tds);
						}
					});
					return total_payable_amount_tds;
			}
			
			
			
				/*$('.type_checkbox').click(function(e){
				alert(1111111);
				if(!lastChecked) {
					lastChecked = this;
					return;
				}
				
				if(e.shiftKey) {
					var start = $chkboxes.index(this);
					var end = $chkboxes.index(lastChecked);
					$chkboxes.slice(Math.min(start,end), Math.max(start,end)+ 1).prop('checked', lastChecked.checked);
				}
				
				lastChecked = this;
				alert(lastChecked);
			});
			
			$("#CHEQUE_AMOUNT").keyup(function(){
				
			});*/

			$('#CHEQUE_AMOUNT').on('keyup',function(){
				var chk_amount = $(this).val();
				var cheque_amount_settlement = $('#cheque_amount_settlement').val();
				var cheque_amount_remaining = $('cheque_amount_remaining').val();
				var tds_settlement = $('tds_settlement').val();
				var total_settlement = $('total_settlement').val();
				$("#cheque_amount_remaining").val(chk_amount-cheque_amount_settlement);
			});
			
			$("#btn_submit").click(function(){
				var operator_name = $( "#OPERATOR_NAME" ).val();
				var to_date =$( "#to_date" ).val();
				var from_date =$( "#from_date" ).val();
				var tds_rate =$( "#tds_rate" ).val();
        $("#operator_name_new").val(operator_name);
        $("#to_date_new").val(to_date);
        $("#from_date_new").val(from_date);
        $("#tds_rate_new").val(tds_rate);
    	});
		});
	</script>
</body>
</html>