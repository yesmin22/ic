<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Collection Module</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>collection_module">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>collection_module/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>collection_module/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				
				<table class="table table-bordered table-striped new_table">
					<tr>
						<th>SL</th>
						<th>Operator Name</th>
						<th>Month</th>
						<th>Receivable</th>
						<th>Collection</th>
						<th>Outstanding</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->OPERATOR_NAME; ?></td>
						<td><?php echo $v->BILL_MONTH; ?></td>
						<td style="text-align:right"><?php echo $v->RECEIVABLE; ?></td>
						<td style="text-align:right"><?php echo $v->COLLECTION; ?></td>
						<td style="text-align:right">
							<?php 
							$outstanding = ($v->RECEIVABLE - $v->COLLECTION); 
							echo $outstanding;
							?>
						</td>
						<td>
							<?php if($v->RECEIVABLE == $v->COLLECTION): ?>
								<span class="label label-success">Paid</span>
							<?php endif; ?>
							<?php if($v->RECEIVABLE > $v->COLLECTION): ?>
								<span class="label label-info">Pending</span>
							<?php endif; ?>
						</td>
						<td class="field_button">
							<a href="<?php echo $url_prefix; ?>create_collection/<?php echo $this->webspice->encrypt_decrypt($v->OPERATOR_NAME,'encrypt'); ?>/<?php echo $this->webspice->encrypt_decrypt($v->TEMP_BILL_MONTH,'encrypt'); ?>/<?php echo $this->webspice->encrypt_decrypt($v->RECEIVABLE,'encrypt'); ?>" class="btn_orange">Collection</a>
						</td>
					</tr>
					<?php endforeach; ?>
				</table>
				
				<div id="pagination">
					<?php echo $pager; ?>
					<div class="float_clear_full">&nbsp;</div>
				</div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>