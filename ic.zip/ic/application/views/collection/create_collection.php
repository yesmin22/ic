<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<style>
		.page_body.stamp {
    background: none;
     }
	</style>
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_collection_module" class="main_container page_identifier">
			<?php if( isset($edit['ID']) && $edit['ID'] ):?>
				<div class="page_caption">Edit Collection</div>
			<?php else:?>
				<div class="page_caption">Collection</div>
			<?php endif;?>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset>
					<fieldset class="divider"><legend>Please Enter Collection Information</legend></fieldset>
          
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_user" method="post" action="" data-parsley-validate>
						<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="ID"name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />

						<table width="100%">
							<tr>
								<td>
									<div class="form_label">Bill Month*</div>
									<div class="month_picker_container">
										<input type="text" id="BILL_MONTH" name="BILL_MONTH" class="input_full input_style" value="<?php echo set_value('BILL_MONTH',$edit['BILL_MONTH']); ?>" readonly required />
										<span	class="fred"><?php echo form_error('BILL_MONTH'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Operator*</div>
									<div>
		               <input type="text" id="OPERATOR" name="OPERATOR" class="input_full input_style" value="<?php echo set_value('OPERATOR',$edit['OPERATOR']); ?>" readonly required />
										<span	class="fred"><?php echo form_error('OPERATOR'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td>
									<div class="form_label">Receivable*</div>
									<div>
										<input type="number" step="0.01" class="input_full input_style" id="CURRENT_AMOUNT" name="CURRENT_AMOUNT" value="<?php echo set_value('CURRENT_AMOUNT',$edit['CURRENT_AMOUNT']); ?>" readonly />
										<span class="fred"><?php echo form_error('CURRENT_AMOUNT'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td>
									<div class="form_label">Checque No*</div>
									<div>
										<input type="text" class="input_full input_style" id="CHECQUE_NO" name="CHECQUE_NO" value="<?php echo set_value('CHECQUE_NO',$edit['CHECQUE_NO']); ?>" required />
										<span class="fred"><?php echo form_error('CHECQUE_NO'); ?></span>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<div class="form_label">Bank Name*</div>
									<div>
										<input type="text" class="input_full input_style" id="BANK_NAME" name="BANK_NAME" value="<?php echo set_value('BANK_NAME',$edit['BANK_NAME']); ?>" required />
										<span class="fred"><?php echo form_error('BANK_NAME'); ?></span>
									</div>
								</td>
							</tr>
							
							<tr>
								<td>
									<div class="form_label">Amount*</div>
									<div>
										<input type="number" class="input_full input_style" step="0.01" id="AMOUNT" name="AMOUNT" value="<?php echo set_value('AMOUNT',$edit['AMOUNT']); ?>" required />
										<span class="fred"><?php echo form_error('AMOUNT'); ?></span>
									</div>
								</td>
							</tr>
						</table>
					</fieldset>
				</div>
				
				<div class="right_section">
					<fieldset>
					<table>
						<tr>
								<td colspan=3>
									<div class="form_label">Bank Name*</div>
									<div>
		               <input type="text" id="bank_name" name="BANK_NAME" class="input_full input_style" value="<?php echo set_value('BANK_NAME',$edit['BANK_NAME']); ?>" required />
										<span	class="fred"><?php echo form_error('BANK_NAME'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
								<td colspan=3>
									<div class="form_label">Bank Account*</div>
									<div>
		               <input type="text" id="bank_account" name="BANK_ACCOUNT" class="input_full input_style" value="<?php echo set_value('BANK_ACCOUNT',$edit['BANK_ACCOUNT']); ?>" required />
										<span	class="fred"><?php echo form_error('BANK_ACCOUNT'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
								<td colspan=3>
									<div class="form_label">Cheque Number*</div>
									<div>
		               <input type="text" id="CHEQUE_NUMBER" name="CHEQUE_NUMBER" class="input_full input_style" value="<?php echo set_value('CHEQUE_NUMBER',$edit['CHEQUE_NUMBER']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_NUMBER'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
							<td>
									<div class="form_label">Cheque Amount*</div>
									<div>
		               <input type="text" id="CHEQUE_AMOUNT" name="CHEQUE_AMOUNT" class="input_full input_style" value="<?php echo set_value('CHEQUE_AMOUNT',$edit['CHEQUE_AMOUNT']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Cheque Date*</div>
									<div class="month_picker_container">
										<input type="text" id="CHEQUE_DATE" name="CHEQUE_DATE" class="input_full input_style" value="<?php echo set_value('CHEQUE_DATE',$edit['CHEQUE_DATE']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_DATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Entry Date*</div>
									<div class="month_picker_container">
										<input type="text" id="ENTRY_DATE" name="ENTRY_DATE" class="input_full input_style" value="<?php echo set_value('ENTRY_DATE',$edit['ENTRY_DATE']); ?>" required />
										<span	class="fred"><?php echo form_error('ENTRY_DATE'); ?></span>
									</div>
								</td>
						</tr>
            <tr>
								<td>
									<div class="form_label">AIT Rate for IOS*</div>
									<div>
		               <input type="text" id="AIT_RATE_FOR_IOS" name="AIT_RATE_FOR_IOS" class="input_full input_style" value="<?php echo set_value('AIT_RATE_FOR_IOS',$edit['AIT_RATE_FOR_IOS']); ?>" required />
										<span	class="fred"><?php echo form_error('AIT_RATE_FOR_IOS'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">AIT Rate for PSTN/PTSP*</div>
									<div>
		               <input type="text" id="AIT_RATE_FOR_PSTN_PTSP" name="AIT_RATE_FOR_PSTN_PTSP" class="input_full input_style" value="<?php echo set_value('AIT_RATE_FOR_PSTN_PTSP',$edit['AIT_RATE_FOR_PSTN_PTSP']); ?>" required />
										<span	class="fred"><?php echo form_error('AIT_RATE_FOR_PSTN_PTSP'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">AIT Rate for Mobile*</div>
									<div>
		               <input type="text" id="AIT_RATE_FOR_MOBILE" name="AIT_RATE_FOR_MOBILE" class="input_full input_style" value="<?php echo set_value('AIT_RATE_FOR_MOBILE',$edit['AIT_RATE_FOR_MOBILE']); ?>" required />
										<span	class="fred"><?php echo form_error('AIT_RATE_FOR_MOBILE'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
								<td colspan=2>
									<div class="form_label">Settlement Including Cheque Amount*</div>
									<div>
		               <input type="text" id="SETTLEMENT_INCLUDING_CHEQUE_AMOUNT" name="SETTLEMENT_INCLUDING_CHEQUE_AMOUNT" class="input_full input_style" value="<?php echo set_value('SETTLEMENT_INCLUDING_CHEQUE_AMOUNT',$edit['SETTLEMENT_INCLUDING_CHEQUE_AMOUNT']); ?>" required />
										<span	class="fred"><?php echo form_error('SETTLEMENT_INCLUDING_CHEQUE_AMOUNT'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Main Amount with vat*</div>
									<div>
		               <input type="text" id="MAIN_AMOUNT_WITH_VAT" name="MAIN_AMOUNT_WITH_VAT" class="input_full input_style" value="<?php echo set_value('MAIN_AMOUNT_WITH_VAT',$edit['MAIN_AMOUNT_WITH_VAT']); ?>" required />
										<span	class="fred"><?php echo form_error('MAIN_AMOUNT_WITH_VAT'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
							  <td>
									<div class="form_label">Main Amount without vat*</div>
									<div>
		               <input type="text" id="MAIN_AMOUNT_WITHOUT_VAT" name="MAIN_AMOUNT_WITHOUT_VAT" class="input_full input_style" value="<?php echo set_value('MAIN_AMOUNT_WITHOUT_VAT',$edit['MAIN_AMOUNT_WITHOUT_VAT']); ?>" required />
										<span	class="fred"><?php echo form_error('MAIN_AMOUNT_WITHOUT_VAT'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">AIT on Sourch*</div>
									<div>
		               <input type="text" id="AIT_ON_SOURCH" name="AIT_ON_SOURCH" class="input_full input_style" value="<?php echo set_value('AIT_ON_SOURCH',$edit['AIT_ON_SOURCH']); ?>" required />
										<span	class="fred"><?php echo form_error('AIT_ON_SOURCH'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Invoice Cheque Amount*</div>
									<div>
		               <input type="text" id="INVOICE_CHEQUE_AMOUNT" name="INVOICE_CHEQUE_AMOUNT" class="input_full input_style" value="<?php echo set_value('INVOICE_CHEQUE_AMOUNT',$edit['INVOICE_CHEQUE_AMOUNT']); ?>" required />
										<span	class="fred"><?php echo form_error('INVOICE_CHEQUE_AMOUNT'); ?></span>
									</div>
								</td>
						</tr>
					</table>
					</fieldset>
				</div>
				<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
			 </form>
				<div class="float_clear_full">&nbsp;</div>
				
				
			</div>

		</div>
		
	</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#OPERATOR').on("change", function(){
			var bill_month = $('#BILL_MONTH').val();
			if(!bill_month){
				alert("Please select a bill month!");
				return false;
			}
			var operator = $('#OPERATOR').val();
			var token = $('#token').val();
			var spinner = $(this).parent().parent().find('.spinner');
			$(spinner).show();
			var ajaxCall = $.ajax({
			 type: "POST",
			 url: url_prefix + "get_receiveable",
			 data: { ajax_call:'yes', bill_month:bill_month, operator:operator, csrf_webspice_tkn:token}
			}).done(function(msg){
			 switch(msg.trim()){
			  case 'no-data':
					alert('No Data Found!');
					$(spinner).hide();
			   	break;
			   
			  default:
			  	$("#CURRENT_AMOUNT").val(msg.trim());
			   	$(spinner).hide();
			    break;
			 }
			}).fail(function() {
				alert( "Failed: We could not execute your request. Please try again later or report to authority." );
				$(spinner).hide();
			});	
		});
		
		$('#OPERATOR').on("change", function(){
			
		})

	});
	</script>	
</body>
</html>