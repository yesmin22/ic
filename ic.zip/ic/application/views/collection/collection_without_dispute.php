<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<style>
		.page_body.stamp {
    background: none;
     }
	</style>
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_collection_module" class="main_container page_identifier">
			<?php if( isset($edit['ID']) && $edit['ID'] ):?>
				<div class="page_caption">Edit Collection</div>
			<?php else:?>
				<div class="page_caption">Collection without Dispute</div>
			<?php endif;?>
			<div class="page_body">
				<div>
					<fieldset>
					<fieldset class="divider"><legend>Please Enter Collection Information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_user" method="post" action="" data-parsley-validate>
						<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="ID"name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />
						<table width="100%">
						  <tr>
								 <td>
								 <div class="form_label">Operator Name *</div>
								 <div>
									<select name="OPERATOR_NAME" id="OPERATOR_NAME" class="input_m input_style" required>
									<option value="">Select One</option>
									<?php echo $this->customcache->get_operator_invoice('option_name'); ?>
									</select>
								 	<span	class="fred"><?php //echo form_error('ICX'); ?></span>
								 </div>
								 </td>
								 <td>
										<div class="form_label">Operator Type*</div>
										<div>
			               <select name="OPERATOR_TYPE" id="operator_type" class="input_m input_style" required>
			               	<option value=''>SELECT ONE</option>
					            <option value='BTRC' >BTRC</option>
					            <option value='ICX' >ICX</option>
					            <option value='IGW' >IGW</option>
					            <option value='IPTSP' >IPTSP</option>
					            <option value='ISMS' >ISMS</option>
					            <option value='MOBILE' >MOBILE</option>
					            <option value='PSTN' >PSTN</option>
		             			</select>
											<span	class="fred"><?php echo form_error('operator_type'); ?></span>
										</div>
								 </td>
								 <td>
									<div class="form_label">&nbsp</div>
									<div class="form-check">
  								<label class="form-check-label">
    							<input class="form-check-input" id="isSelected" type="checkbox" name="tds" value="tds" checked>
    							TDS
  								</label>
									</div>
								</td>
								<td>
										<div class="form_label">TDS Rate *</div>
										<div>
			               <select name="TDS_RATE" id="tds_rate" class="input_full input_style" required>
			               	<option value=''>SELECT ONE</option>
					            <option value='12'>12 %</option>
					            <option value='10'>10 %</option>
					            <option value='7.50'>7.50 %</option>
		             			</select>
											<span	class="fred"><?php echo form_error('tds_rate'); ?></span>
										</div>
									</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Bill Period From Date *</div>
									<div class="month_picker_container">
		              	<input type="text" class="date_picker input_style" id="from_date" name="from_date" required/>
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
								<td>
									<div class="form_label">Bill Period To Date *</div>
									<div class="month_picker_container">
		              	<input type="text" class="date_picker input_style" id="to_date" name="to_date" required/>
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>	
					</table>
					</fieldset>
				</div>
				<div >
					<fieldset>
					<table>
						<tr id="invoices"></tr>
						<tr>
								<td colspan=2>
									<div class="form_label">Cheque Amount Settlement*</div>
									<div>
		               <input type="text" id="cheque_amount_settlement" name="CHEQUE_AMOUNT_SETTLEMENT" class="input_full input_style" value="<?php echo set_value('CHEQUE_AMOUNT_SETTLEMENT',$edit['CHEQUE_AMOUNT_SETTLEMENT']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT_SETTLEMENT'); ?></span>
									</div>
								</td>
								<td colspan=3>
									<div class="form_label">Cheque Amount Remaining*</div>
									<div>
		               <input type="text" id="cheque_amount_remaining" name="CHEQUE_AMOUNT_REMAINING" class="input_full input_style" value="<?php echo set_value('CHEQUE_AMOUNT_REMAINING',$edit['CHEQUE_AMOUNT_REMAINING']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT_REMAINING'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">TDS Settlement*</div>
									<div>
		               <input type="text" id="tds_settlement" name="TDS_SETTLEMENT" class="input_full input_style" value="<?php echo set_value('TDS_SETTLEMENT',$edit['TDS_SETTLEMENT']); ?>" required />
										<span	class="fred"><?php echo form_error('TDS_SETTLEMENT'); ?></span>
									</div>
								</td>
								<!--<td >
									<div class="form_label">TDS Remaining*</div>
									<div>
		               <input type="text" id="tds_remaining" name="TDS_REMAINING" class="input_full input_style" value="<?php 
		               //echo set_value('TDS_REMAINING',$edit['TDS_REMAINING']); ?>" required />
										<span	class="fred"><?php echo form_error('TDS_REMAINING'); ?></span>
									</div>
								</td>-->
								<td >
									<div class="form_label">Total Settlement*</div>
									<div>
		               <input type="text" id="total_settlement" name="TOTAL_SETTLEMENT" class="input_full input_style" value="<?php echo set_value('TOTAL_SETTLEMENT',$edit['TOTAL_SETTLEMENT']); ?>" required />
										<span	class="fred"><?php echo form_error('TOTAL_SETTLEMENT'); ?></span>
									</div>
								</td>
								<!--<td >
									<div class="form_label">Total Remaining*</div>
									<div>
		               <input type="text" id="total_remaining" name="TOTAL_REMAINING" class="input_full input_style" value="<?php echo set_value('TOTAL_REMAINING',$edit['TOTAL_REMAINING']); ?>" required />
										<span	class="fred"><?php echo form_error('TOTAL_REMAINING'); ?></span>
									</div>
								</td>-->
							</tr>
					</table>
					</fieldset>
				</div>
				
				<div >
					<fieldset>
					<table>
						<tr>
								<td >
									<div class="form_label">Bank Name*</div>
									<div>
		               <input type="text" id="bank_name" name="BANK_NAME" class="input_full input_style" value="<?php echo set_value('BANK_NAME',$edit['BANK_NAME']); ?>" />
										<span	class="fred"><?php echo form_error('BANK_NAME'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Bank Account*</div>
									<div>
		               <input type="text" id="bank_account" name="BANK_ACCOUNT" class="input_full input_style" value="<?php echo set_value('BANK_ACCOUNT',$edit['BANK_ACCOUNT']); ?>" />
										<span	class="fred"><?php echo form_error('BANK_ACCOUNT'); ?></span>
									</div>
								</td>
								<td >
									<div class="form_label">Cheque Number*</div>
									<div>
		               <input type="text" id="CHEQUE_NUMBER" name="CHEQUE_NUMBER" class="input_full input_style" value="<?php echo set_value('CHEQUE_NUMBER',$edit['CHEQUE_NUMBER']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_NUMBER'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Cheque Amount*</div>
									<div>
		               <input type="text" id="CHEQUE_AMOUNT" name="CHEQUE_AMOUNT" class="input_full input_style" value="<?php echo set_value('CHEQUE_AMOUNT',$edit['CHEQUE_AMOUNT']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_AMOUNT'); ?></span>
									</div>
								</td>
						</tr>
						<tr>
								<td>
									<div class="form_label">Cheque Date*</div>
									<div class="month_picker_container">
										<input type="text" id="CHEQUE_DATE" name="CHEQUE_DATE" class="date_picker input_style" value="<?php echo set_value('CHEQUE_DATE',$edit['CHEQUE_DATE']); ?>" required />
										<span	class="fred"><?php echo form_error('CHEQUE_DATE'); ?></span>
									</div>
								</td>
								<td>
									<div class="form_label">Entry Date*</div>
									<div class="month_picker_container">
										<input type="text" id="ENTRY_DATE" name="ENTRY_DATE" class="date_picker input_style" value="<?php echo set_value('ENTRY_DATE',$edit['ENTRY_DATE']); ?>" required />
										<span	class="fred"><?php echo form_error('ENTRY_DATE'); ?></span>
									</div>
								</td>
						</tr>
					</table>
					</fieldset>
				</div>
				<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
			 </form>
				<div class="float_clear_full">&nbsp;</div>
			</div>

		</div>
		
	</div>
<script type="text/javascript">  
	$(document).ready(function(){
		$('#invoices').html('');
		$('#OPERATOR_NAME, #from_date , #to_date ,#operator_type').on('change',function(){ 
				var op_name = $('#OPERATOR_NAME').val();
				var op_type = $('#operator_type').val();
		 		var from_date = $("#from_date").val();
		 		var to_date = $("#to_date").val();
		 		var token = $('#token').val();
		 		var without_dispute = 'without_dispute';
				if(op_name && from_date && to_date){
		 		var urlinfo=url_prefix + "get_invoice_amount_for_collection_with_dispute";
		 		var jqxhr = $.ajax({
		 			type: "POST",
		 			url: urlinfo,
		 			data: { collection_type: without_dispute, op_type: op_type, op_name: op_name, from_date: from_date,to_date: to_date,csrf_webspice_tkn: token}
		 		}).done(function(rslt){
		 			console.log(rslt);
		 			$('#invoices').html(rslt);
		 		}).fail(function() {
		 			alert( "We could not execute your request. Please try again later or report to authority." );
		 			spinner.hide();
		 		});
		
		 		return false;
				}
		})	

		$('#isSelected').click(function() {
				if($("#isSelected").is(':checked')){
     			 var tds_rate = $('#tds_rate').val();
     			 $('.remaining_amount').each(function(i){
						var remaining_amount = $(this).data('invc_'+i);
						 tds_val = ((remaining_amount / 1.15) * tds_rate ) / 100 ;
						 total_settlement_amount = remaining_amount - tds_val;	 
						 total_amount = total_settlement_amount + tds_val + dispute;
						 $('.tds_'+i).val(tds_val.toFixed(2));
						 $('.stl_'+i).val(total_settlement_amount.toFixed(2));
						 $('.ttl_stl_'+i).val(total_amount.toFixed(2));
					
					});
     		}	 
    		else{
    			var tds_rate = $('#tds_rate').val();
					$('.remaining_amount').each(function(i){
						var remaining_amount = $(this).data('invc_'+i);
						 tds_val = ((remaining_amount / 1.15) * tds_rate ) / 100 ;
						 total_settlement_amount = remaining_amount - tds_val;	 
						 total_amount = total_settlement_amount + tds_val;
						 $('.tds_'+i).val(0);
						 $('.stl_'+i).val(remaining_amount.toFixed(2));
						 $('.ttl_stl_'+i).val(remaining_amount.toFixed(2));
						
					
					});
    		}	
    
     })
    
		 $('#OPERATOR_NAME, #from_date , #to_date , #tds_rate').on('change',function(){ 
				
				var tds_rate = $('#tds_rate').val();
				$('.remaining_amount').each(function(i){
						var remaining_amount = $(this).data('invc_'+i);
						 tds_val = ((remaining_amount / 1.15) * tds_rate ) / 100 ;
						 total_settlement_amount = remaining_amount - tds_val;	 
						 total_amount = total_settlement_amount + tds_val;
					if($("#isSelected").is(':checked')){	 
						$('.tds_'+i).val(tds_val);
						$('.stl_'+i).val(total_settlement_amount.toFixed(2));
						$('.ttl_stl_'+i).val(total_amount.toFixed(2));
					}else{
						$('.tds_'+i).val(0);
						$('.stl_'+i).val(remaining_amount.toFixed(2));
						$('.ttl_stl_'+i).val(remaining_amount.toFixed(2));
						
					}
					});
				
			})
			var total_payable_amount = 0;
			$(document.body).on('change',".invoice_checker",function() {
				total_payable_amount = 0;
				total_settlement = 0;
				total_remaining = 0;
				total_payable_amount = calculate_total_payable_amt();
				calculate_remaining_amount(total_payable_amount,$('#CHEQUE_AMOUNT').val());
				//sabina
				total_payable_tds_amount = 0;
				total_payable_tds_amount = calculate_total_payable_tds_amt();
				calculate_remaining_tds_amount(total_payable_tds_amount,$('#CHEQUE_AMOUNT').val());
				
				
				calculate_total_setelment_remaining_amount(total_payable_tds_amount, total_payable_amount, $('#CHEQUE_AMOUNT').val());
				
				//-sabina
				
			});
			function calculate_total_payable_amt(){
				$(".invoice_checker").each(function(){
						if($(this).is(':checked')){
							var selected_chkbox = $(this).val();
							total_payable_amount = parseFloat(total_payable_amount) + parseFloat($('.stl_'+selected_chkbox).val());
						}
					});
					return total_payable_amount;
			}
			
			//sabina
			function calculate_total_payable_tds_amt(){
				$(".invoice_checker").each(function(){
						if($(this).is(':checked')){
							var selected_chkbox = $(this).val();
							total_payable_tds_amount = parseFloat(total_payable_tds_amount) + parseFloat($('.tds_'+selected_chkbox).val());
						}
					});
					return total_payable_tds_amount;
			}
			
			//-sabina
			
			$('#CHEQUE_AMOUNT').on('keyup',function(){
				var chk_amount = $(this).val();
				calculate_remaining_amount(total_payable_amount,chk_amount);
				calculate_remaining_tds_amount(total_payable_tds_amount,chk_amount);
				calculate_total_setelment_remaining_amount(total_payable_tds_amount,total_payable_amount, chk_amount);
			});
			
			function calculate_remaining_amount(total_payable,total_paid){
				total_paid = (!parseFloat(total_paid))  ? 0 : total_paid;
				var remaining_amt =  parseFloat(total_paid) - parseFloat(total_payable);
				$('#cheque_amount_remaining').val(remaining_amt.toFixed(2));
				$('#cheque_amount_settlement').val(total_payable.toFixed(2));
			}
			//sabina
			function calculate_remaining_tds_amount(total_tds,total_paid){
				total_paid = (!parseFloat(total_paid))  ? 0 : total_paid;
				var remaining_amt = parseFloat(total_tds) - parseFloat(total_paid);
				//$('#tds_remaining').val(remaining_amt.toFixed(2));
				$('#tds_settlement').val(total_tds.toFixed(2));
			}
			function calculate_total_setelment_remaining_amount(total_tds,total_payable,total_paid){
				total_paid = (!parseFloat(total_paid))  ? 0 : total_paid;
				var total_settlement = total_tds + total_payable;
				var remaining_tds_amt = parseFloat(total_tds) - parseFloat(total_paid);
				var remaining_amt = parseFloat(total_payable) - parseFloat(total_paid);
				var total_remaining = remaining_tds_amt + remaining_amt;
				$('#total_settlement').val(total_settlement.toFixed(2));
				//$('#total_remaining').val(total_remaining);
			}
			
			//-sabina
    	
	  });
	</script>	
</body>
</html>