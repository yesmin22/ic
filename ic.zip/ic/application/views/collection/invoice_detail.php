<table class="table table-hover table-condensed table-striped table-bordered">
	<tr>
		<th>SL</th>
		<th>Bill Period</th>
		<th>Invoice Number</th>
  	<th>Invoice Amount</th>
  	<th>Remaining Amount</th>
		<th>Settlement Amount</th>
		<th>TDS</th>
		<!--<th>DISPUTE</th>-->
		
		<th>Total Settlement</th>
		<th>AIT Remarks</th>
		<th>Full/Partial</th>
		<th>Include TDS?</th>
		<th>Action Select All<input type="checkbox" class="selectall" /> </th>
	</tr>
	<input type="hidden" id="tds_rate_hidden" name="tds_rate_hidden" value="<?php echo $tds_rate; ?>" />
	<?php
	
	foreach($invoice as $bk => $bv){
		if($bv->REMAINING_AMOUNT<0)continue;
		$is_checkbox = false;
  	$row_class = $rec_class = $pay_class = $rate_class = $ar_sdr_tip = $ap_sdr_tip = null;
  	$is_net = '<option value="NO">Partial</option> <option value="YES" selected>Full</option>';
  	$invoice_amount = $bv->INVOICE_AMOUNT;
  	$remaining_amount=$bv->REMAINING_AMOUNT;
	if($tds_rate!=''){
  		//$tds=((($remaining_amount)/1.15)*$tds_rate)/100;
  		$tds=((($remaining_amount))*$tds_rate)/100;
  		$satelment_amount=$remaining_amount-$tds-$bv->DISPUTE;
  		$dispute = $bv->DISPUTE;
  		$total_amount=$tds+$satelment_amount+$dispute;
  	}else{
  		$satelment_amount = $remaining_amount-$bv->DISPUTE; 
  		$total_amount = $invoice_amount;
  		$tds = 0;
  		$dispute = $bv->DISPUTE;
  		$remaining_amount=$bv->REMAINING_AMOUNT;
  	}
	//$satelment_amount = $invoice_amount-$remaining_amount-$bv->DISPUTE; 
	?>
	
	<tr>
		<td>
			<input type="hidden" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][INVOICE_ID]" value="<?php echo $bv->ID; ?>" />
			<input type="hidden" name="final_total" id="final_total" value="" />
			<!--<input type="hidden" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][PAY_ID]" value="<?php echo $bv->PAY_ID; ?>" />-->
			<?php // echo ($bk+1);
			 ?>
		</td>
		
		<input type="hidden" class="remaining_amount_new_for_calculation" id= "<?php echo 'remaining_amount_new_for_calculation'.($bk+1);?>" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][REMAINING_AMOUNT_NEW_FOR_CALCULATION]" value="<?php echo round($remaining_amount,2); ?>" />
		<input type="hidden" class="remaining_amount_new" id= "<?php echo 'remaining_amount_new'.($bk+1);?>" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][REMAINING_AMOUNT_NEW]" value="<?php echo $remaining_amount; ?>" />
		<td><input type="hidden" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][BILL_PERIOD]" value="<?php echo $bv->BILL_PERIOD; ?>" /><?php echo date("M, Y",strtotime($bv->BILL_PERIOD)); ?></td>
		<td><input class="invoice_number" type="hidden" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][INVOICE_NUMBER]" value="<?php echo $bv->INVOICE_NUMBER; ?>" /><?php echo $bv->INVOICE_NUMBER; ?></td>
		<td><input class="input_text invoice_amount" id= "<?php echo 'invoice'.($bk+1);?>" style="width:130px;" type="text" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][INVOICE_AMOUNT]" value="<?php echo round($invoice_amount,2); ?>" readonly /></td>
		<td><input class="remaining_amount" id= "<?php echo 'remaining'.($bk+1);?>" style="width:130px;" type="text" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][REMAINING_AMOUNT]" value="<?php echo round($remaining_amount,2); ?>" readonly /></td>
		<td><input class="input_text settlement" style="width:130px" type="text" id='<?php echo 'sattled'.($bk+1);?>' name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][SETTLEMENT]" value="" disabled /></td>
		<td><input class="new_input_text tds" style="width:130px" id= "<?php echo 'tds'.($bk+1);?>" type="text" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][TDS]" value=""  disabled /></td>
		<td><input class="input_text total_satelment" style="width:130px" type="text" id='<?php echo 'total_sattled'.($bk+1);?>' name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][TOTAL_SETTELEMANT]" value="" disabled /></td>
		<td>
		<input class="input_text dispute" type="hidden" id='<?php echo 'dispute'.($bk+1);?>' name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][DISPUTE]" value="" disabled />
		
		<input  style="width:130px" type="text" id='<?php echo 'comment'.($bk+1);?>' name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][COMMENT]" value=""/>
		</td>
		<td><select style="width:50px;"  disabled class="full_partial cheack_all_class" id= "<?php echo 'full_partial'.($bk+1)?>" id_for_val="<?php echo ($bk+1); ?>" class="is_full" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][IS_FULL]"><?php echo $is_net; ?></select></td>
		<td><input class="include_tax cheack_all_class" type="checkbox" id="<?php echo 'include_tax'.($bk+1)?>" name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][INCLUDE_TAX]" value="<?php echo ($bk+1); ?>" disabled></td>
		<td><input class="type_checkbox individual" type="checkbox"  name="ALLOCATED_DATA[<?php echo ($bk+1); ?>][SEQ_ID]" value="<?php echo ($bk+1); ?>" ></td>
	
	</tr>
	<?php } ?>
</table>

	<script type="text/javascript">
		$(document).ready(function(){
			var stlmnt_amt = 0;
		  $("input").focus(function(){
		  	$(this).css("text-align","left");
		  	var temp = $(this).val();
		  	$(this).val("").val(temp);
		  }).focusout(function(){
		  	$(this).css("text-align","right");
		  });
	  
			var $chkboxes = $('.type_checkbox');
			var lastChecked = null;
			
			$chkboxes.click(function(e){
				if(!lastChecked) {
					lastChecked = this;
					return;
				}
				if(e.shiftKey) {
					var start = $chkboxes.index(this);
					var end = $chkboxes.index(lastChecked);
					$chkboxes.slice(Math.min(start,end), Math.max(start,end)+ 1).prop('checked', lastChecked.checked);
				}
				lastChecked = this;
			});
	
	
	
			$(".new_input_text").click(function(){
				new_tds = $(this).val();
				cheque_amount_remaining=$("#cheque_amount_remaining").val();
				if(cheque_amount_remaining!='' || cheque_amount_remaining!=0){
				new_tds_amount=parseFloat(cheque_amount_remaining)+parseFloat(new_tds);
				//alert('It should be '+new_tds_amount.toFixed(2)+' for full settlement');
			 }
			})
			
		 $('.full_partial').on('change',function(){
		 	var full_partial = $(this).val();
			var id_for_val = $(this).attr('id_for_val');
		 	$("#sattled"+id_for_val).removeAttr('disabled');	
			$("#tds"+id_for_val).removeAttr('disabled');
			$("#tds_remaining"+id_for_val).removeAttr('disabled');
			$("#dispute"+id_for_val).removeAttr('disabled');
			$("#total_sattled"+id_for_val).removeAttr('disabled');
			var remaining_temp = $("#remaining"+id_for_val).val();
			if(remaining_temp==''){remaining_temp=0;}
		 	remaining = $("#remaining_amount_new_for_calculation"+id_for_val).val();
		 	if(remaining==''){remaining=0;}
		 	if(remaining_temp==0){
					$("#remaining"+id_for_val).val(remaining);
				}
			var tds = $("#tds_rate_hidden").val();
			if(tds==''){tds=0;}
			var dispute = $("#dispute"+id_for_val).val();		
			if(dispute==''){
				dispute=0;
			}	
			if(full_partial!=''){
			if(full_partial=='YES' ){
				if ( $("#include_tax"+id_for_val).is(":checked")){
					var remaining_tds=(remaining * tds)/100;
					var sattled = (remaining - remaining_tds) - dispute; 
					var total_sattlement=parseFloat(remaining)- parseFloat(dispute);
					remaining_amount=remaining-(parseFloat(sattled)+parseFloat(remaining_tds));
					$("#remaining"+id_for_val).val(parseFloat(0));
					$("#sattled"+id_for_val).val(sattled.toFixed(2));
					$("#tds"+id_for_val).val(remaining_tds.toFixed(2));
					$("#dispute"+id_for_val).val(dispute);
					$("#total_sattled"+id_for_val).val(total_sattlement.toFixed(2));
				}else{
					var sattled = remaining - dispute; 
					remaining_amount=remaining-sattled;
					$("#remaining"+id_for_val).val(remaining_amount);
					$("#sattled"+id_for_val).val(sattled.toFixed(2));
					$("#tds"+id_for_val).val(parseFloat(0));
					$("#dispute"+id_for_val).val(dispute);
					$("#total_sattled"+id_for_val).val(sattled.toFixed(2));	
				}
				
			}else{
					if ( $("#include_tax"+id_for_val).is(":checked")){
						var remaining_tds=(remaining * tds)/100;
						var sattled = (remaining - remaining_tds) - dispute; 
						var total_sattlement=parseFloat(remaining)-parseFloat(dispute);
						$("#sattled"+id_for_val).val(sattled.toFixed(2));
						$("#tds"+id_for_val).val(remaining_tds.toFixed(2));
						$("#dispute"+id_for_val).val(dispute);
						$("#total_sattled"+id_for_val).val(total_sattlement.toFixed(2));
						//sabina today
						remaining_for_patial=remaining-total_sattlement;
						$("#remaining"+id_for_val).val(remaining_for_patial.toFixed(2));	
					}else{
						var sattled = remaining - dispute; 
						$("#sattled"+id_for_val).val(sattled.toFixed(2));
						$("#tds"+id_for_val).val(parseFloat(0));
						$("#dispute"+id_for_val).val(dispute);
						$("#total_sattled"+id_for_val).val(sattled.toFixed(2));	
						//sabina today
						remaining_for_patial=remaining-dispute-sattled;
						$("#remaining"+id_for_val).val(remaining_for_patial.toFixed(2));
					}
				}
			
			var cheque_amount = $("#CHEQUE_AMOUNT").val();
			if(cheque_amount==''){
				cheque_amount=0;
			}
			total_payable_amount=calculate_total_payable_amt();
			total_payable_amount_tds = calculate_total_payable_tds();
			cheque_remaining=cheque_amount-total_payable_amount;
			$("#cheque_amount_remaining").val(cheque_remaining.toFixed(2));
			$("#cheque_amount_settlement").val(total_payable_amount.toFixed(2));
			$("#tds_settlement").val(total_payable_amount_tds.toFixed(2));	
			total_tds_amount=parseFloat(total_payable_amount)+parseFloat(total_payable_amount_tds);
			$("#total_settlement").val(total_tds_amount.toFixed(2));
			}else{
				$("#sattled"+id_for_val).val(parseFloat(0));
				$("#tds"+id_for_val).val(parseFloat(0));
				$("#dispute"+id_for_val).val(parseFloat(0));
				$("#total_sattled"+id_for_val).val(parseFloat(0));
				
				}	
		 })
		 

		  $('.include_tax').on('click',function(){
		 	var id_for_val = $(this).val();
			var remaining_temp = $("#remaining"+id_for_val).val();
			if(remaining_temp==''){remaining_temp=0;}
		 	remaining = $("#remaining_amount_new_for_calculation"+id_for_val).val();
		 	if(remaining==''){remaining=0;}
		 	if(remaining_temp==0){
					$("#remaining"+id_for_val).val(remaining);
				}
				
			var tds = $("#tds_rate_hidden").val();
			if(tds==''){tds=0;}
			var dispute = $("#dispute"+id_for_val).val();		
			full_partial= $("#full_partial"+id_for_val).val();	
			if(dispute==''){
				dispute=0;
			}		
			if(full_partial!=''){
			if(full_partial=='YES' ){
				if ( $("#include_tax"+id_for_val).is(":checked")){
					var remaining_tds=(remaining * tds)/100;
					var sattled = (remaining - remaining_tds) - dispute; 
					var total_sattlement=parseFloat(remaining)- parseFloat(dispute);
					remaining_amount=remaining-(parseFloat(sattled)+parseFloat(remaining_tds));
					$("#remaining"+id_for_val).val(parseFloat(0));
					$("#sattled"+id_for_val).val(sattled.toFixed(2));
					$("#tds"+id_for_val).val(remaining_tds.toFixed(2));
					$("#dispute"+id_for_val).val(dispute);
					$("#total_sattled"+id_for_val).val(total_sattlement.toFixed(2));
				}else{
					var sattled = remaining - dispute; 
					remaining_amount=remaining-sattled;
					$("#remaining"+id_for_val).val(remaining_amount);
					$("#sattled"+id_for_val).val(sattled.toFixed(2));
					$("#tds"+id_for_val).val(parseFloat(0));
					$("#dispute"+id_for_val).val(dispute);
					$("#total_sattled"+id_for_val).val(sattled.toFixed(2));	
				}
				
			}else{
					if ( $("#include_tax"+id_for_val).is(":checked")){
						//remove
						ttl_stl=$("#total_sattled"+id_for_val).val();
						if(ttl_stl==remaining){
							//end remove

						
						var remaining_tds=(remaining * tds)/100;
						var sattled = (remaining - remaining_tds) - dispute; 
						var total_sattlement=parseFloat(remaining)-parseFloat(dispute);
						$("#sattled"+id_for_val).val(sattled.toFixed(2));
						$("#tds"+id_for_val).val(remaining_tds.toFixed(2));
						$("#dispute"+id_for_val).val(dispute);
						$("#total_sattled"+id_for_val).val(total_sattlement.toFixed(2));	
						total_remaining=remaining-sattled-remaining_tds-dispute;
						$("#remaining"+id_for_val).val(total_remaining.toFixed(2));
						//remove
							}else{
								var remaining_tds=(ttl_stl * tds)/100;
								var total_sattlement=parseFloat(ttl_stl)+parseFloat(remaining_tds)+parseFloat(dispute);
								var remaining_new=parseFloat(remaining)-parseFloat(total_sattlement);
							  $("#remaining"+id_for_val).val(remaining_new.toFixed(2));
							  $("#total_sattled"+id_for_val).val(total_sattlement.toFixed(2));
							  $("#tds"+id_for_val).val(remaining_tds.toFixed(2));
								}
								//end remove
					}else{
						
						//remove
						ttl_stl=$("#total_sattled"+id_for_val).val();
						if(ttl_stl==remaining){
						//end rmove
						var sattled = remaining - dispute; 
						$("#sattled"+id_for_val).val(sattled.toFixed(2));
						$("#tds"+id_for_val).val(parseFloat(0));
						$("#dispute"+id_for_val).val(dispute);
						$("#total_sattled"+id_for_val).val(sattled.toFixed(2));	
						total_remaining=remaining-sattled-dispute;
						$("#remaining"+id_for_val).val(total_remaining.toFixed(2));
						//remove
					}else{
					  
					var remaining_tds=(ttl_stl * tds)/100;
								var settled_new=$("#sattled"+id_for_val).val();
								var dispute_new=$("#dispute"+id_for_val).val();
								if(settled_new==''){settled_new=0;}
								if(dispute_new==''){dispute_new=0;}
							  var total_settlement=parseFloat(settled_new)+parseFloat(dispute_new);
							  var remaining_new=remaining-total_settlement;
							  $("#total_sattled"+id_for_val).val(total_settlement.toFixed(2));
							  $("#tds"+id_for_val).val(parseFloat(0));
					      $("#remaining"+id_for_val).val(remaining_new.toFixed(2));
						
					}
					//end remove
					}
				}	
			var cheque_amount = $("#CHEQUE_AMOUNT").val();
			if(cheque_amount==''){
				cheque_amount=0;
				
			}
			total_payable_amount=calculate_total_payable_amt();
			total_payable_amount_tds = calculate_total_payable_tds();
			cheque_remaining=cheque_amount-total_payable_amount;
			$("#cheque_amount_remaining").val(cheque_remaining.toFixed(2));
			$("#cheque_amount_settlement").val(total_payable_amount.toFixed(2));
			$("#tds_settlement").val(total_payable_amount_tds.toFixed(2));	
			total_tds_amount=parseFloat(total_payable_amount)+parseFloat(total_payable_amount_tds);
			$("#total_settlement").val(total_tds_amount.toFixed(2));
			}else{
				$("#sattled"+id_for_val).val(parseFloat(0));
				$("#tds"+id_for_val).val(parseFloat(0));
				$("#dispute"+id_for_val).val(parseFloat(0));
				$("#total_sattled"+id_for_val).val(parseFloat(0));
				}
		 })
		 
		 
		 
		 
		$(".input_text").keyup(function(){
			var cur_tr = $(this).parent().parent();	
			var remaining_amount = cur_tr.find('.remaining_amount_new_for_calculation').val();
			if(remaining_amount==''){
				remaining_amount=0;
			}
			var remaining_amount_temp = cur_tr.find('.remaining_amount').val();
			if(remaining_amount_temp==''){
				remaining_amount_temp=0;
			}
			var full_partial = cur_tr.find('.full_partial').val();
			var dispute = cur_tr.find('.dispute').val();
			if(dispute==''){
				dispute=0;
			}
			var settlement = cur_tr.find('.settlement').val();
			if(settlement==''){
				settlement=0;
			}
			var include_tax = cur_tr.find('.include_tax').val();
			
			var tds = cur_tr.find('.tds').val();
			if(tds==''){
				tds=0;
			}
			var tds_rate = $("#tds_rate_hidden").val();
			if ( $("#include_tax"+include_tax).is(":checked")){
				var tds_par=(settlement*tds_rate)/100;
				settlement=parseFloat(settlement)+parseFloat(tds_par);
			}
			if(parseFloat(settlement) > parseFloat(remaining_amount)){
				if(stlmnt_amt==''){
					settlement =0;
					}else{
					settlement = stlmnt_amt;
				}
					if(full_partial=='YES'){
					if ( $("#include_tax"+include_tax).is(":checked")){
						var tds = remaining_amount - settlement - dispute;
						var total_settlement=parseFloat(settlement)+parseFloat(tds)+parseFloat(dispute);
						cur_tr.find('.settlement').val(settlement);
						cur_tr.find('.tds').val(tds.toFixed(2));
						cur_tr.find('.total_satelment').val(total_settlement.toFixed(2));
						 stlmnt_amt=0;
					}else{
						var tds=0;
						settlement=cur_tr.find('.remaining_amount_new_for_calculation').val();
						cur_tr.find('.settlement').val(settlement);
						cur_tr.find('.tds').val(parseFloat(tds));
						cur_tr.find('.total_satelment').val(settlement.toFixed(2));
					   stlmnt_amt=0;
					}
				
			  }else{
	 				if ( $("#include_tax"+include_tax).is(":checked")){
						var tds_par=(settlement*tds_rate)/100;
						var new_remaining_amount=remaining_amount-settlement-tds_par-dispute;
						var total_satelment=parseFloat(tds_par)+parseFloat(settlement)+parseFloat(dispute);
						cur_tr.find('.settlement').val(settlement.toFixed(2));
						cur_tr.find('.remaining_amount').val(new_remaining_amount.toFixed(2));
						cur_tr.find('.tds').val(tds_par.toFixed(2));
						cur_tr.find('.total_satelment').val(total_satelment.toFixed(2));
						 stlmnt_amt=0;
					}else{
					  var tds_par=0;
					  var new_remaining_amount=remaining_amount-settlement-dispute;
						var total_satelment=parseFloat(new_remaining_amount);
						cur_tr.find('.settlement').val(settlement.toFixed(2));
						cur_tr.find('.remaining_amount').val(new_remaining_amount.toFixed(2));
						cur_tr.find('.tds').val(parseFloat(tds_par));
						cur_tr.find('.total_satelment').val(settlement.toFixed(2));
						 stlmnt_amt=0;
				 }	
				 
				 
				} 
					alert('Settlement Amount shoud be equal or less than Remaining Amount!');	
					
			}else{
			  
				if(full_partial=='YES' ){
					if ( $("#include_tax"+include_tax).is(":checked")){
						var tds = remaining_amount - settlement - dispute;
						cur_tr.find('.sattled').val(settlement.toFixed(2));
						cur_tr.find('.tds').val(tds.toFixed(2));
						new_settelement=cur_tr.find('.settlement').val();
						if(new_settelement==''){new_settelement=0;}
						var total_settlement=parseFloat(new_settelement)+parseFloat(tds)+parseFloat(dispute);
						cur_tr.find('.total_satelment').val(total_settlement.toFixed(2));
						 stlmnt_amt=0; 
					}else{
						var tds=0;
						cur_tr.find('.sattled').val(remaining_amount);
						cur_tr.find('.tds').val(parseFloat(tds));
						new_settlement=cur_tr.find('.settlement').val();
						if(new_settlement==''){new_settlement=0;}
						cur_tr.find('.total_satelment').val(new_settlement.toFixed(2));
						 stlmnt_amt=0;
					}
				
			  }else{
			  	//settlement;
			  	if ( $("#include_tax"+include_tax).is(":checked")){
			  	settlement=cur_tr.find('.settlement').val();
			  	if(settlement==''){settlement=0;}
					var tds_par=(settlement*tds_rate)/100;
					var new_remaining_amount=remaining_amount-settlement-tds_par-dispute;
					var total_satelment=parseFloat(tds_par)+parseFloat(settlement)+parseFloat(dispute);
					cur_tr.find('.remaining_amount').val(new_remaining_amount.toFixed(2));
					cur_tr.find('.tds').val(tds_par.toFixed(2));
					cur_tr.find('.total_satelment').val(total_satelment.toFixed(2));
					 stlmnt_amt=0;
				}else{
					//alert(settlement);
				  var tds_par=0;
				  var new_remaining_amount=remaining_amount-settlement-dispute;
					var total_satelment=parseFloat(new_remaining_amount.toFixed(2));
					cur_tr.find('.remaining_amount').val(new_remaining_amount.toFixed(2));
					cur_tr.find('.tds').val(parseFloat(tds_par));
					cur_tr.find('.total_satelment').val(settlement);
					 stlmnt_amt=0;
				  }			  	
			  }
			  
			}
			stlmnt_amt = cur_tr.find('.settlement').val();
			var cheque_amount = $("#CHEQUE_AMOUNT").val();
			if(cheque_amount==''){
				cheque_amount=0;
				
			}
			total_payable_amount=calculate_total_payable_amt();
			total_payable_amount_tds = calculate_total_payable_tds();
			cheque_remaining=cheque_amount-total_payable_amount;
			$("#cheque_amount_remaining").val(cheque_remaining.toFixed(2));
			$("#cheque_amount_settlement").val(total_payable_amount.toFixed(2));
			$("#tds_settlement").val(total_payable_amount_tds.toFixed(2));	
			total_tds_amount=parseFloat(total_payable_amount)+parseFloat(total_payable_amount_tds);
			$("#total_settlement").val(total_tds_amount.toFixed(2));
	
		}) 

		function calculate_total_payable_amt(){
                var total_settlement=0;
                $(".type_checkbox").each(function(){
                        if($(this).is(':checked')){
                            var cur_tr = $(this).parent().parent();
                            var settlement = cur_tr.find('.settlement').val();
                            if(settlement==''){settlement=0;}
														total_settlement=parseFloat(total_settlement) + parseFloat(settlement);
														//alert(total_settlement);
                        }
                    });
				return total_settlement;
                    
        } 
		function calculate_total_payable_tds(){
                var total_tds=0;
                $(".type_checkbox").each(function(){
                        if($(this).is(':checked')){
                            var cur_tr = $(this).parent().parent();
                            var tds = cur_tr.find('.tds').val();
                            if(tds==''){tds=0;}
							total_tds=parseFloat(total_tds) + parseFloat(tds);
							//alert(total_settlement);
                        }
                    });
				return total_tds;
                    
       } 
		 
		});
	</script>
	
	
	
	
	
	
	
	<!--it should be new in input text class of dispute-->