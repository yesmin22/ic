<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Manage Interconnect Revenue Sharing Report for LTFS</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_full_month_ltfs">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_full_month_ltfs/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_full_month_ltfs/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<div style="overflow-x:auto" class="table-responsive">
				<table id="" class="table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th>SL</th>
						<th>Operator Name</th>
						<th>Pre\Post</th>
						<th>No of Calls</th>
						<th>Duration (In Min.)</th>
						<th>Rate Per Min.(BDT)</th>
						<th>Revenue</th>
						<th>SD Rate</th>
						<th>SD Amount</th>
						<th>SC Rate</th>
						<th>SC Amount</th>
						<th>VAT on (Revenue+SD)</th>
						<th>Total</th>
						<th>Created Date</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->OPERATOR_NAME; ?></td> 
						<td><?php echo $v->PRE_POST; ?></td> 
						<td><?php echo $v->NO_OF_CALLS; ?></td>
						<td><?php echo $v->DURATION_IN_MIN; ?></td>
						<td><?php echo $v->RATE_PER_MIN_BDT; ?></td>
						<td><?php echo $v->REVENUE; ?></td> 
						<td><?php echo $v->SD_RATE; ?></td> 
						<td><?php echo $v->SD_AMOUNT ?></td> 
						<td><?php echo $v->SC_RATE; ?></td> 
						<td><?php echo $v->SC_AMOUNT; ?></td> 
						<td><?php echo $v->VAT_ON_REVENUE_SD; ?></td> 
						<td><?php echo $v->TOTAL; ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
				
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				</div>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>