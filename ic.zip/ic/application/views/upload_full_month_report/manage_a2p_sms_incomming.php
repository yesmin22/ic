<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Manage A2P SMS Incomming</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
							
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_a2p_sms_incomming">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_a2p_sms_incomming/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_a2p_sms_incomming/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<div style="overflow-x:auto" class="table-responsive">
				<table id="" class="table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th>SL</th>
						<th>Name</th>
						<th>Call Type Description</th>
						<th>No of SMS</th>
						<th>Report Date</th>
						<th>Created Date</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->NAME; ?></td> 
						<td><?php echo $v->CALL_TYPE_DESCRIPTION; ?></td>
						<td><?php echo $v->NO_OF_SMS; ?></td>
						<td><?php echo $this->webspice->formatted_date($v->REPORT_DATE); ?></td>  
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>