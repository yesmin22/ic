<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Manage Interconnect Revenue Sharing Report for IPTSP</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
							<td>Operator</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
							<td>
								<select name="OPERATOR" class="input_full">
									<?php echo $this->webspice->option_by_field("TBL_FULL_MONTH_IPTSP", "OPERATOR_NAME", "ID", "option_value"); ?>
								</select>
							</td>
							
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_full_month_iptsp">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_full_month_iptsp/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_full_month_iptsp/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<div style="overflow-x:auto" class="table-responsive">
				<table id="" class="table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th>SL</th>
						<th>Operator Name</th>
						<th>ICX Route</th>
						<th>No of Calls</th>
						<th>Duration (In Min.)</th>
						<th>Created Date</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->OPERATOR_NAME; ?></td> 
						<td><?php echo $v->ICX_ROUTE; ?></td> 
						<td><?php echo $v->NO_OF_CALLS; ?></td>
						<td><?php echo $v->DURATION; ?></td>
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			  </div>
			  <div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>