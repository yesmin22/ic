<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
	<style>
		label {
		    font-weight: normal !important;
		    cursor:pointer;
		}
	</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_upload_ic_data" class="main_container page_identifier">
			<div class="page_caption">Upload Interconnect Revenue Sharing Report for MTSMS</div>
			<div class="page_body stamp">
				
				<!--file upload error-->
				<?php if( isset($error) && $error ): ?>
				<div class="message_board"><?php echo $error; ?></div>
				<?php endif; ?>
					
				<div class="left_section">
					<fieldset class="divider"><legend>Please select a file!</legend></fieldset>
					
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_upload_ic_data" method="post" action="" enctype="multipart/form-data" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
		            
						<table width="100%">
							<tr>
								<td colspan=2>
									<br />
									<div class="form_label">Actual/Provision*</div>
									<div>
										<input type="radio" id="actual" name="actual_provision" value="actual" checked="checked" required /> <label for="actual">Actual</label>
										
									</div>
								</td>
							</tr>
						<tr>
								<td>
									<div class="form_label">Month*</div>
									<div class="month_picker_container">
		              	<input type="text" name="CALCULATIVE_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<br />
									<div class="form_label">Remove and Insert/Newly Add*</div>
									<div>
										<input type="radio" id="data_remove_insert" name="data_insert" value="data_remove_insert" required /> <label for="data_remove_insert">Remove and Insert</label>
										<input type="radio" id="data_newly_add" name="data_insert" value="data_newly_add" required /> <label for="data_newly_add">Newly Add</label>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<br />
									<div class="form_label">Select File* <small>Format (.xml)</small></div>
									<div>
										<input type="file" id="sap_file" name="sap_file" accept=".xml" required />
									</div>
								</td>
							</tr>
							<tr>
								<td colspan=2>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
</body>
</html>