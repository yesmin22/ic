<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Payment Summery Details</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						
						<tr>
							<td colspan="10">
								<a class="btn_gray" href="<?php echo $url_prefix; ?>payment_summery_report/<?php echo $this->webspice->encrypt_decrypt($data[0]->VENDOR_NAME,'encrypt').'/'.$this->webspice->encrypt_decrypt($data[0]->REPORT_DATE,'encrypt');?>/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>payment_summery_report/<?php echo $this->webspice->encrypt_decrypt($data[0]->VENDOR_NAME,'encrypt').'/'.$this->webspice->encrypt_decrypt($data[0]->REPORT_DATE,'encrypt');?>/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<div style="overflow-x:auto" class="table-responsive">
				<table class="table table-bordered table-striped new_table_sm" style="overflow-x:auto">
					<tr>
						<th>ID</th>
						<th>Check Date</th>
						<th>Bank Account Name</th>
						<th>Check Series</th>
						<th>Check Number</th>
						<th>Pay Currency</th>
						<th>Entered Payment Amount</th>
						<th>Payment Amount BDT</th>
						<th>Payment Type</th>
						<th>Payment Status</th>
						<th>Payment Created User</th>
						<th>Vendor Code</th>
						<th>Vendor Name</th>
						<th>Invoice Number</th>
						<th>Invoice Date</th>
						<th>Description</th>
						<th>Invoice Amount</th>
						<th>Invoice Pay Amount</th>
						<th>Invoice Pay Amount BDT</th>
						<th>WHT Amount</th>
						<th>WHV Amount</th>
						<th>WHT Total Amount</th>
						<th>PO Number</th>
					</tr>
					<?php $i=1; foreach($data as $k=>$v): ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php echo $v->CHECK_DATE;?></td>
						<td><?php echo $v->BANK_ACCOUNT_NAME;?></td>
						<td><?php echo $v->CHECK_SERIES;?></td>
						<td><?php echo $v->CHECK_NUMBER;?></td>
						<td><?php echo $v->PAY_CURRENCY;?></td>
						<td><?php echo $v->ENTERED_PAYMENT_AMOUNT;?></td>
						<td><?php echo $v->PAYMENT_AMOUNT_BDT;?></td>
						<td><?php echo $v->PAYMENT_TYPE;?></td>
						<td><?php echo $v->PAYMENT_STATUS;?></td>
						<td><?php echo $v->PAYMENT_CREATED_USER;?></td>
						<td><?php echo $v->VENDOR_CODE;?></td>
						<td><?php echo $v->VENDOR_NAME;?></td>
						<td><?php echo $v->INVOICE_NUMBER;?></td>
						<td><?php echo $v->INVOICE_DATE;?></td>
						<td><?php echo $v->DESCRIPTION;?></td>
						<td><?php echo $v->INVOICE_AMOUNT;?></td>
						<td><?php echo $v->INVOICE_PAY_AMOUNT;?></td>
						<td><?php echo $v->INVOICE_PAY_AMOUNT_BDT;?></td>
						<td><?php echo $v->WHT_AMOUNT;?></td>
						<td><?php echo $v->WHV_AMOUNT;?></td>
						<td><?php echo $v->WHT_TOTAL_AMOUNT;?></td>
						<td><?php echo $v->PO_NUMBER;?></td>
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				</div>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>