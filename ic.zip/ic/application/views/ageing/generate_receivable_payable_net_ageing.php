


<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Option</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />

	
	<?php include(APPPATH."views/global.php"); ?>
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo $url_prefix; ?>global/jquery-ui/jquery-ui.min.css" />
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/jquery-ui/jquery-ui.min.js"></script>
	
	<style>
	.table-condensed>thead>tr>th, .table-condensed>tbody>tr>th, .table-condensed>tfoot>tr>th, .table-condensed>thead>tr>td, .table-condensed>tbody>tr>td, .table-condensed>tfoot>tr>td{
		padding: 5px;
	}
	.table td { font-size:80%; padding:2px !important; }
</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_ageing_report" class="main_container page_identifier">
			<div class="page_caption">Ageing Report</div>
			<div class="page_body" class="table-responsive">
				<!--custom message board-->
				<?php if( $this->webspice->message_board(null, 'get') ): ?>
					<div id="message_board">
						<?php echo $this->webspice->message_board(null,'get_and_destroy'); ?>
					</div>
				<?php endif; ?>
				<!--end custom message board-->
				
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" id="token" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					<table style="width:auto;">
					<tr>
						<td colspan="10">
							<a class="btn_gray" href="<?php echo $url_prefix; ?>generate_recevable_ageing">Refresh</a>
							<a class="btn_gray" href="<?php echo $url_prefix; ?>generate_recevable_ageing/print" target="_blank">Print</a>
							<a class="btn_gray" href="<?php echo $url_prefix; ?>generate_recevable_ageing/csv" target="_blank">Export</a>
						</td>
					</tr>
				</table>
			</form>
			
			<br />
			<div id="accordion">
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<h3>Payable Ageing</h3>
				<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0" style="overflow:auto;" style="overflow:auto;">
					<tr>
						<th colspan=2>Operator</th>
						<th>OPTYPE</th>
						<th>Accrued</th>
						<th>Unexpired</th>
						<th class="text-center">(0-30)</th>
						<th class="text-center">31-60</th>
						<th class="text-center">61-90</th>
						<th class="text-center">91-120</th>
						<th class="text-center">121-150</th>
						<th class="text-center">151-180</th>
						<th class="text-center">180-365</th>
						<th class="text-center">365+ Days</th>
						<th class="text-center">Total</th>
					</tr>
					
					<?php 		
					$total_slab_unexpired=0;
					$total_slab_0_30=0;		
					$total_slab_31_60=0;
					$total_slab_61_90=0;
					$total_slab_91_120=0;
					$total_slab_121_150=0;
					$total_slab_151_180=0;
					$total_slab_181_365=0;
					$total_slab_365_more=0;
					$main_total=0;
					$accrued=0;
					$total_accrued=0;
					foreach($get_record as $k=>$v): 
					
					foreach($accrude_result as $ak=>$av){
						if($v->SUPPLIER_NAME==$av->OPERATOR_NAME && $v->SUPPLIER_NAME==$av->OPERATOR_TYPE){
							$accrued=$av->AMOUNT;
							break;
						}else{
							$accrued=0;
						}
					}
					?>
					<tr>
						<td colspan=2><?php echo $v->SUPPLIER_NAME; ?></td>
						<td><?php echo $v->OPERATOR_TYPE; ?></td>
						<td><?php echo number_format($accrued,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_UNEXPIRED,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_0_30,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_31_60,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_61_90,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_91_120,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_121_150,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_151_180,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_181_365,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_365_more,2);?></td>
						<td style="text-align:right;"><?php $total=$v->SLAB_UNEXPIRED+$v->SLAB_0_30+$v->SLAB_31_60+$v->SLAB_61_90+$v->SLAB_91_120+$v->SLAB_121_150+$v->SLAB_151_180+$v->SLAB_181_365+$v->SLAB_365_more; echo number_format($total,2);?></td>
					</tr>
					<?php 
					$total_accrued=$total_accrued+$accrued;
					$total_slab_unexpired=$total_slab_unexpired+$v->SLAB_UNEXPIRED;
					$total_slab_0_30=$total_slab_0_30+$v->SLAB_0_30;		
					$total_slab_31_60=$total_slab_31_60+$v->SLAB_31_60;
					$total_slab_61_90=$total_slab_61_90+$v->SLAB_61_90;
					$total_slab_91_120=$total_slab_91_120+$v->SLAB_91_120;
					$total_slab_121_150=$total_slab_121_150+$v->SLAB_121_150;
					$total_slab_151_180=$total_slab_151_180+$v->SLAB_151_180;
					$total_slab_181_365=$total_slab_181_365+$v->SLAB_181_365;
					$total_slab_365_more=$total_slab_365_more+$v->SLAB_365_more;
					$main_total=$main_total+$v->SLAB_UNEXPIRED+$v->SLAB_0_30+$v->SLAB_31_60+$v->SLAB_61_90+$v->SLAB_91_120+$v->SLAB_121_150+$v->SLAB_151_180+$v->SLAB_181_365+$v->SLAB_365_more;
					endforeach;
					
					?>
					<tr>
						<td colspan=2>Total</td>
						<td></td>
						<td style="text-align:right;"><?php echo number_format($total_accrued,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_unexpired,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_0_30,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_31_60,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_61_90,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_91_120,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_121_150,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_151_180,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_181_365,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_365_more,2);?></td>
						<td style="text-align:right;"><?php echo number_format($main_total,2);?></td>
					</tr>
				</table>
				<h3>Receiveable Ageing</h3>
				<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0" style="overflow:auto;">
					<tr>
						<th>Operator</th>
						<th>OPTYPE</th>
						<th>Accrued</th>
						<th>Unexpired</th>
						<th class="text-center">(0-30)</th>
						<th class="text-center">31-60</th>
						<th class="text-center">61-90</th>
						<th class="text-center">91-120</th>
						<th class="text-center">121-150</th>
						<th class="text-center">151-180</th>
						<th class="text-center">180-365</th>
						<th class="text-center">365+ Days</th>
						<th class="text-center">Total</th>
					</tr>
					
					<?php 		
					$total_slab_unexpired=0;
					$total_slab_0_30=0;		
					$total_slab_31_60=0;
					$total_slab_61_90=0;
					$total_slab_91_120=0;
					$total_slab_121_150=0;
					$total_slab_151_180=0;
					$total_slab_181_365=0;
					$total_slab_365_more=0;
					$main_total=0;
					$accrued=0;
					$total_accrued=0;
					foreach($get_record_receiveable as $k=>$v): 
					if($v->OPERATOR_NAME =='') continue;
					foreach($accrude_result_receiveable as $ak=>$av){
						if($v->OPERATOR_NAME==$av->OPERATOR_NAME && $v->OPERATOR_TYPE==$av->OPERATOR_TYPE){
							$accrued=$av->AMOUNT;
							break;
						}else{
							$accrued=0;
						}
					}
					
					foreach($receiveable_result_big_365 as $ab=>$bv){
						if($v->OPERATOR_NAME==$bv->OPERATOR_NAME && $v->OPERATOR_TYPE==$bv->OPERATOR_TYPE){
							$slab_365_more=$bv->SLAB_BIG_365;
							break;
						}else{
							$slab_365_more=0;
						}
					}
					//dd($accrued);
					?>
					<tr>
						<td><?php echo $v->OPERATOR_NAME; ?></td>
						<td><?php echo $v->OPERATOR_TYPE; ?></td>
						<td><?php echo number_format($accrued,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_UNEXPIRED,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_0_30,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_31_60,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_61_90,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_91_120,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_121_150,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_151_180,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_181_365,2);?></td>
						<td style="text-align:right;"><?php echo number_format($slab_365_more,2);?></td>
						<td style="text-align:right;"><?php $total=$v->SLAB_UNEXPIRED + $v->SLAB_0_30+$v->SLAB_31_60+$v->SLAB_61_90+$v->SLAB_91_120+$v->SLAB_121_150+$v->SLAB_151_180+$v->SLAB_181_365+$slab_365_more; echo number_format($total,2);?></td>
					</tr>
					<?php 
					$total_accrued=$total_accrued+$accrued;
					$total_slab_unexpired=$total_slab_unexpired+$v->SLAB_UNEXPIRED;
					$total_slab_0_30=$total_slab_0_30+$v->SLAB_0_30;		
					$total_slab_31_60=$total_slab_31_60+$v->SLAB_31_60;
					$total_slab_61_90=$total_slab_61_90+$v->SLAB_61_90;
					$total_slab_91_120=$total_slab_91_120+$v->SLAB_91_120;
					$total_slab_121_150=$total_slab_121_150+$v->SLAB_121_150;
					$total_slab_151_180=$total_slab_151_180+$v->SLAB_151_180;
					$total_slab_181_365=$total_slab_181_365+$v->SLAB_181_365;
					$total_slab_365_more=$total_slab_365_more+$slab_365_more;
					$main_total=$main_total+$total;
					endforeach;
					
					?>
					<tr>
						<td>Total</td>
						<td></td>
						<td style="text-align:right;"><?php echo number_format($total_accrued,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_unexpired,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_0_30,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_31_60,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_61_90,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_91_120,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_121_150,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_151_180,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_181_365,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_365_more,2);?></td>
						<td style="text-align:right;"><?php echo number_format($main_total,2);?></td>
					</tr>
				</table>
				
				
				
				
				
				<h3>NET Ageing</h3>
				<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0" style="overflow:auto;">
					<tr>
						<th>Operator</th>
						<th>OPTYPE</th>
						<th>Accrued</th>
						<th>Unexpired</th>
						<th class="text-center">(0-30)</th>
						<th class="text-center">31-60</th>
						<th class="text-center">61-90</th>
						<th class="text-center">91-120</th>
						<th class="text-center">121-150</th>
						<th class="text-center">151-180</th>
						<th class="text-center">180-365</th>
						<th class="text-center">365+ Days</th>
						<th class="text-center">Total</th>
					</tr>
					
					<?php 		
					$total_slab_unexpired=0;
					$total_slab_0_30=0;		
					$total_slab_31_60=0;
					$total_slab_61_90=0;
					$total_slab_91_120=0;
					$total_slab_121_150=0;
					$total_slab_151_180=0;
					$total_slab_181_365=0;
					$total_slab_365_more=0;
					$main_total=0;
					$accrued=0;
					$total_accrued=0;
					foreach($get_record_nat as $k=>$v): 
					if($v->OPERATOR_NAME =='') continue;
					
					foreach($receiveable_result_big_365 as $ab=>$bv){
						if($v->OPERATOR_NAME==$bv->OPERATOR_NAME && $v->OPERATOR_TYPE==$bv->OPERATOR_TYPE){
							$slab_365_more=$bv->SLAB_BIG_365;
							break;
						}else{
							$slab_365_more=0;
						}
					}
					$more_of_365 = $slab_365_more - $v->VALUE_181_365_DIFF;
					//dd($accrued);
					?>
					<tr>
						<td><?php echo $v->OPERATOR_NAME; ?></td>
						<td><?php echo $v->OPERATOR_TYPE; ?></td>
						<td></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_UNEXPECTED_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_0_30_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_31_60_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_61_90_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_91_120_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_121_150_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_151_180_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->VALUE_181_365_DIFF,2);?></td>
						<td style="text-align:right;"><?php echo number_format($more_of_365,2);?></td>
						<td style="text-align:right;"><?php $total=$v->VALUE_UNEXPECTED_DIFF + $v->VALUE_0_30_DIFF+$v->VALUE_31_60_DIFF+$v->VALUE_61_90_DIFF+$v->VALUE_91_120_DIFF+$v->VALUE_121_150_DIFF+$v->VALUE_151_180_DIFF+$v->VALUE_181_365_DIFF+$more_of_365; echo number_format($total,2);?></td>
					</tr>
					<?php 
					$total_accrued=$total_accrued+$accrued;
					$total_slab_unexpired=$total_slab_unexpired+$v->VALUE_UNEXPECTED_DIFF;
					$total_slab_0_30=$total_slab_0_30+$v->VALUE_0_30_DIFF;		
					$total_slab_31_60=$total_slab_31_60+$v->VALUE_31_60_DIFF;
					$total_slab_61_90=$total_slab_61_90+$v->VALUE_61_90_DIFF;
					$total_slab_91_120=$total_slab_91_120+$v->VALUE_91_120_DIFF;
					$total_slab_121_150=$total_slab_121_150+$v->VALUE_121_150_DIFF;
					$total_slab_151_180=$total_slab_151_180+$v->VALUE_151_180_DIFF;
					$total_slab_181_365=$total_slab_181_365+$v->VALUE_181_365_DIFF;
					$total_slab_365_more=$total_slab_365_more+$more_of_365;
					$main_total=$main_total+$total;
					endforeach;
					
					?>
					<tr>
						<td>Total</td>
						<td></td>
						<td style="text-align:right;"><?php echo number_format($total_accrued,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_unexpired,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_0_30,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_31_60,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_61_90,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_91_120,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_121_150,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_151_180,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_181_365,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_365_more,2);?></td>
						<td style="text-align:right;"><?php echo number_format($main_total,2);?></td>
					</tr>
				</table>
				
				
				<!-- <div id="pagination"><?php //echo $pager; ?><div class="float_clear_full">&nbsp;</div></div> -->
				
			</div><!--end .page_body-->

		</div>
	</div>
	<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
</div>
<script type="text/javascript">
		// $('select').chosen('destroy');
		$( function() {
			$( "#accordion" ).accordion({
				heightStyle: "content",
				collapsible: true,
				active: false
			});
		});
	</script>
</body>
</html>



