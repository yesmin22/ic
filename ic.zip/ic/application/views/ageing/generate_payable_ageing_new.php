﻿

<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 13 ;
if(isset($report_name)){
	$report_name = $report_name;
}else{
	$report_name = "Payable Ageing";
}

# don't edit the below area (csv)
if( $action_type == 'csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		
		
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?>&nbsp; </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			
			<div style="font-weight:bold; text-align:center;"></div>
			<br />
				<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0" style="overflow:auto;" style="overflow:auto;">
					<tr>
						<th colspan=2>Operator</th>
						<th>OPTYPE</th>
						<th>Accrued</th>
						<th>Unexpired</th>
						<th class="text-center">(0-30)</th>
						<th class="text-center">31-60</th>
						<th class="text-center">61-90</th>
						<th class="text-center">91-120</th>
						<th class="text-center">121-150</th>
						<th class="text-center">151-180</th>
						<th class="text-center">180-365</th>
						<th class="text-center">365+ Days</th>
						<th class="text-center">Total</th>
					</tr>
					
					<?php 		
					$total_slab_unexpired=0;
					$total_slab_0_30=0;		
					$total_slab_31_60=0;
					$total_slab_61_90=0;
					$total_slab_91_120=0;
					$total_slab_121_150=0;
					$total_slab_151_180=0;
					$total_slab_181_365=0;
					$total_slab_365_more=0;
					$main_total=0;
					$accrued=0;
					$total_accrued=0;
					foreach($get_record as $k=>$v): 
					
					foreach($accrude_result as $ak=>$av){
						if($v->SUPPLIER_NAME==$av->OPERATOR_NAME && $v->SUPPLIER_NAME==$av->OPERATOR_TYPE){
							$accrued=$av->AMOUNT;
							break;
						}else{
							$accrued=0;
						}
					}
					?>
					<tr>
						<td colspan=2><?php echo $v->SUPPLIER_NAME; ?></td>
						<td><?php echo $v->OPERATOR_TYPE; ?></td>
						<td><?php echo number_format($accrued,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_UNEXPIRED,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_0_30,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_31_60,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_61_90,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_91_120,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_121_150,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_151_180,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_181_365,2);?></td>
						<td style="text-align:right;"><?php echo number_format($v->SLAB_365_more,2);?></td>
						<td style="text-align:right;"><?php $total=$v->SLAB_UNEXPIRED+$v->SLAB_0_30+$v->SLAB_31_60+$v->SLAB_61_90+$v->SLAB_91_120+$v->SLAB_121_150+$v->SLAB_151_180+$v->SLAB_181_365+$v->SLAB_365_more; echo number_format($total,2);?></td>
					</tr>
					<?php 
					$total_accrued=$total_accrued+$accrued;
					$total_slab_unexpired=$total_slab_unexpired+$v->SLAB_UNEXPIRED;
					$total_slab_0_30=$total_slab_0_30+$v->SLAB_0_30;		
					$total_slab_31_60=$total_slab_31_60+$v->SLAB_31_60;
					$total_slab_61_90=$total_slab_61_90+$v->SLAB_61_90;
					$total_slab_91_120=$total_slab_91_120+$v->SLAB_91_120;
					$total_slab_121_150=$total_slab_121_150+$v->SLAB_121_150;
					$total_slab_151_180=$total_slab_151_180+$v->SLAB_151_180;
					$total_slab_181_365=$total_slab_181_365+$v->SLAB_181_365;
					$total_slab_365_more=$total_slab_365_more+$v->SLAB_365_more;
					$main_total=$main_total+$v->SLAB_UNEXPIRED+$v->SLAB_0_30+$v->SLAB_31_60+$v->SLAB_61_90+$v->SLAB_91_120+$v->SLAB_121_150+$v->SLAB_151_180+$v->SLAB_181_365+$v->SLAB_365_more;
					endforeach;
					
					?>
					<tr>
						<td colspan=2>Total</td>
						<td></td>
						<td style="text-align:right;"><?php echo number_format($total_accrued,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_unexpired,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_0_30,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_31_60,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_61_90,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_91_120,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_121_150,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_151_180,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_181_365,2);?></td>
						<td style="text-align:right;"><?php echo number_format($total_slab_365_more,2);?></td>
						<td style="text-align:right;"><?php echo number_format($main_total,2);?></td>
					</tr>
				</table>
		</div>
	</body>
</html>

