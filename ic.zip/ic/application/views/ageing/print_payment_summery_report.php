<?php 

$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 9;
$report_name = 'Vendor Wise Revenue Cost Report'.' '.$report_type;

# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Vendor Wise Revenue and Cost Report <?php echo $report_type ?></title>
	<style type="text/css">
	#printArea { width:1024px; margin:auto; }
	body, table {font-family:tahoma; font-size:13px;}
	table td { padding:8px; }
</style>
<?php if( $action_type=='print'): ?>
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
	<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>
	<!-- print plugin -->
	<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#printArea').jqprint();
			$('#print_icon').click(function(){
				$('#printArea').jqprint();
			});
		});
	</script>
<?php endif; ?>
<?php if($action_type=='view'): ?>
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>
<?php endif; ?>
</head>
<body>
	<div id="printArea">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td align="center" colspan="<?php echo $total_column; ?>">
					<div style="font-size:150%;"><?php echo $domain_name; ?></div>
				</td>
			</tr>
		</table>
		
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
			<tr style="border-top:1px solid #ccc;">
				<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?></td>
			</tr>
			<tr>
				<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Report Date: <?php echo date("d F, Y"); ?></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
		</table>
		<?php if(count($data) > 0): ?>
		<table class="table table-bordered table-striped" border="1" style="overflow:auto;">
			<tr>
				<th >Vendor Name</th>
				<th class="text-center">Payment Amount</th>
				<th>Action</th>
			</tr>
			
			
			
			<?php foreach($data as $k=>$v){?>
			
			
			
			
			
			
			<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			<?php if(isset($data[$k + 1]) && $data[$k]->VENDOR_NAME != $data[$k + 1]->VENDOR_NAME){ ?>
					<tr style="background-color:#FFED4A;">
						<td><?php echo $data[$k]->VENDOR_NAME;?></td> 
						<td align="right"><?php $invoice_amount=$data[$k]->INVOICE_AMOUNT + $data[$k+1]->INVOICE_AMOUNT; echo number_format($invoice_amount,2);?></td>
						<td>
							<a href="<?php echo $url_prefix; ?>payment_summery_report/<?php echo $this->webspice->encrypt_decrypt($data[$k]->VENDOR_NAME,'encrypt').'/'.$this->webspice->encrypt_decrypt($data[$k]->REPORT_DATE,'encrypt'); ?>" class="btn_orange">Details</a>
						</td>
					</tr>
				<?php } ?>
				<?php if(!isset($data[$k + 1])){ ?>
				 <tr style="background-color:#FFED4A;">
						<td><?php echo $data[$k]->VENDOR_NAME;?></td> 
						<td align="right"><?php $invoice_amount=$data[$k]->INVOICE_AMOUNT; echo number_format($invoice_amount,2);?></td>
						<td>
							<a href="<?php echo $url_prefix; ?>payment_summery_report/<?php echo $this->webspice->encrypt_decrypt($data[$k]->VENDOR_NAME,'encrypt').'/'.$this->webspice->encrypt_decrypt($data[$k]->REPORT_DATE,'encrypt'); ?>" class="btn_orange">Details</a>
						</td>
				
					</tr>
					
				    <?php }?>
			<?php } ?>
			
		</table>
	<?php endif; ?>
	</div>
</body>
</html>





