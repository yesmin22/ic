<div id="page_footer" class="text-center">
	Copyright &copy; Banglalink Limited, 2017
</div>