<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Option</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_customer" class="main_container page_identifier">
			<div class="page_caption">Manage Domestic Cost GL Mapping</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>    
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_domestic_cost_gl_mapping">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_domestic_cost_gl_mapping/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_domestic_cost_gl_mapping/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<div >
					<table id=""  class="table table-bordered" width="100%" cellspacing="0" >
						<thead>
							<tr >
								<th style="text-align:left">SL</th>
								<th style="text-align:left">Operator Name</th>
								<th style="text-align:left">Acrued GL</th>
								<th style="text-align:left">Post Voice GL</th>
								<th style="text-align:left">Pre Voice GL</th>
								<th style="text-align:left">Post SMS GL</th>
								<th style="text-align:left">Pre SMS GL</th>
								<th style="text-align:left">Action</th>
							</tr>
						</thead>	
						<tbody>
						<?php $i=0;foreach($get_record as $k=> $v):
							#dd($v,4);
						 ?>
								<tr >
									<td><?php echo ++$i;?></td>
									<td><?php echo $v->OPERATOR_NAME;?></td>
									<td><?php echo $v->ACCURED;?></td>
									<td><?php echo $v->POST_VOICE;?></td>
									<td><?php echo $v->PRE_VOICE;?></td>
									<td><?php echo $v->POST_SMS;?></td>
									<td><?php echo $v->PRE_SMS;?></td>   
									<td><a class="btn btn-warning btn-xs" href="<?php echo $url_prefix.'manage_domestic_cost_gl_mapping/edit/'.$this->webspice->encrypt_decrypt($v->ID,'encrypt');?>">Edit</a></td>
								</tr>
							<?php endforeach;?>	
					</tbody>
					</table>
				</div>	
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
		</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>