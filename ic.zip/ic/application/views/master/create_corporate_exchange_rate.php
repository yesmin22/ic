<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_corporate_exchange_rate" class="main_container page_identifier">
			<?php if( isset($edit['ID']) && $edit['ID'] ):?>
				<div class="page_caption">Edit Corporate Exchange Rate</div>
			<?php else:?>
				<div class="page_caption">Create Corporate Exchange Rate</div>
			<?php endif;?>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter Corporate Exchange Rate information</legend></fieldset>

					<div class="stitle">* Mandatory Field</div>
					
					<form id="page_create_corporate_exchange_rate" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="exchange_rate_id" name="exchange_rate_id" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />

						<table width="100%">
							<tr>
								<td colspan=3>
									<div class="form_label">Month*</div>
									<div class="month_picker_container">
		              	<input type="text" name="REPORT_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('REPORT_MONTH',strtotime($edit['REPORT_MONTH'])); ?>" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
									<tr>
										<td>
											<div class="form_label">USD to BDT*</div>
											<div>
												<input type="text"  class="input_full input_style" id="USD_TO_BDT" name="USD_TO_BDT" value="<?php echo set_value('USD_TO_BDT',$edit['USD_TO_BDT']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('USD_TO_BDT'); ?></span>
											</div>
										</td>
										<td>
											<div class="form_label">EURO to BDT*</div>
											<div>
												<input type="text"  class="input_full input_style" id="EURO_TO_BDT" name="EURO_TO_BDT" value="<?php echo set_value('EURO_TO_BDT',$edit['EURO_TO_BDT']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('EURO_TO_BDT'); ?></span>
											</div>
										</td>
										<td>
											<div class="form_label">GBP to BDT*</div>
											<div>
												<input type="text"  class="input_full input_style" id="GBP_TO_BDT" name="GBP_TO_BDT" value="<?php echo set_value('GBP_TO_BDT',$edit['GBP_TO_BDT']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('GBP_TO_BDT'); ?></span>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<div><input id="btn_submit" type="submit" class="btn_gray" value="Submit Data" /></div>
										</td>
									</tr>
								</table>
							</form>
						</div>

						<div class="right_section">

						</div>
						<div class="float_clear_full">&nbsp;</div>


					</div>

				</div>

			</div>
	</body>
</html>