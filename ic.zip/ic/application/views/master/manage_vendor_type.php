<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Option</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_customer" class="main_container page_identifier">
			<div class="page_caption">Manage Vendor Type Code</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
				
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>    
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_vendor_type">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_vendor_type/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_vendor_type/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<div >
					<table id="data_table_new"  class="table table-bordered" width="50%" cellspacing="0">
						<thead>
							<tr >
								<th style="text-align:left">SL</th>
								<th style="text-align:left">Vendor Type Code</th>
								<th style="text-align:left">Status</th>
								<th style="text-align:left">Action</th>
							</tr>
						</thead>	
						<tbody>
						<?php $i=0;foreach($get_record as $k=> $v):
						 ?>
								<tr >
									<td><?php echo ++$i;?></td>
									<td><?php echo $v->VENDOR_TYPE;?></td>
									<td><?php echo $this->webspice->static_status($v->STATUS); ?></td>
									<td>
								     <?php if( $this->webspice->permission_verify('manage_vendor_type',true) ): ?>
								     <a href="<?php echo $url_prefix.'manage_vendor_type/edit/'.$this->webspice->encrypt_decrypt($v->ID,'encrypt');?>" class="btn_orange">Edit</a>
								     <?php endif; ?>
								
								     <?php if( $this->webspice->permission_verify('manage_vendor_type',true) && $v->STATUS==7 ): ?>
								     <a href="<?php echo $url_prefix; ?>manage_vendor_type/inactive/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Inactive</a>
								     <?php endif; ?>
								
								     <?php if( $this->webspice->permission_verify('manage_vendor_type',true) && $v->STATUS==-7 ): ?>
								     <a href="<?php echo $url_prefix; ?>manage_vendor_type/active/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Active</a>
								     <?php endif; ?>
							    </td>
									
								</tr>
							<?php endforeach;?>	
					</tbody>
					</table>
				</div>	
		</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>