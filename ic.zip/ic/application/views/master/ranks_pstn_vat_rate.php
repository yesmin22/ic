<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: PSTN VAT Rate</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>
<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_company" class="main_container page_identifier">
		<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update Ranks PSTN VAT Rate</div>
       <?php }else{ ?>
        <div class="page_caption">Create Ranks PSTN VAT Rate</div>
       <?php } ?>
			<div class="page_body stamp">	
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
				
						<table width="100%">
								<tr>
									<td>
										<div class="form_label">Ranks PSTN VAT Rate*</div>
										<div>
											<input type="text"  class="input_full input_style" id="ranks_pstn_vat_rate" name="ranks_pstn_vat_rate" value="<?php echo set_value('ranks_pstn_vat_rate',html_entity_decode($edit['RATE'])); ?>"  data-parsley-type="number" required />
											<span class="fred"><?php echo form_error('ranks_pstn_vat_rate'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
								<td>
									<div class="form_label">Calculative Month*</div>
									<div class="month_picker_container">
										<input type="text" name="calculative_month" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php if($edit['BILL_MONTH']){$new_date=strtotime($edit['BILL_MONTH']);}echo set_value('calculative_month',html_entity_decode($new_date)); ?>" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
							 <tr>
								   <td>
									    <div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								   </td>
							  </tr>
						</table>
					</form>
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
		</div>		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>		
	</div>
</body>
</html>












