<?php #dd($edit);?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Create Option</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_create_company" class="main_container page_identifier">
			<div class="page_caption">Create/Update Company</div>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
				
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_create_customer" method="post" action="<?php echo $url_prefix; ?>create_name_alternative" data-parsley-validate>
						<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="attribute" value="<?php echo $edit['attribute']?>" />
						<input type="hidden" name="original_key" value="<?php echo $edit['key']?>" />
						<table width="100%">
							<tr>
								<td>	
									<div class="col-md-12" style="margin:0;padding:0">
										<label>Please select an option?*</label>
										<table style="width:auto;">
											<tr>
												<td valign="middle" id="core"><div><input style="margin:0px;" type="radio" name="type" value="core" <?php echo ($edit['attribute']=='cName') ?'checked' :'';?> required ><label for="core">&nbsp;Core/Main Name</label></div></td>
												<td width="30">&nbsp;</td>
												<td valign="middle" id="alternative"><div><input style="margin:0px;" type="radio" name="type" value="alias" <?php echo ( $edit['attribute'] && $edit['attribute']!='cName') ?'checked' :'';?>><label for="alternative">&nbsp;Name Alternative</div></td>
											</tr>
										</table>
									</div>
								</td>
								
							</tr>
							<tr class="core_name hide">
								<td>
									<div class="form_label">Core/Main Name*</div>
									<div>
		               <select name="key" id="key" class="input_full " >
				              <option value="" >Select One</option>
				              <?php $cName = 'cName'; foreach($get_record as $k => $v):?>
				              	<?php foreach($v as $key=> $val):?>
				              		<?php if( $key == 'cName'):?>
														<option value="<?php echo $k; ?>" <?php echo ($edit['core']==$val)? 'selected="selected"' : '';?>><?php echo $v->$cName;?></option>
													<?php endif;?>	
												<?php endforeach;?>	
				              <?php endforeach;?>
	             			</select>
	            			<span class="fred"><?php echo form_error('key'); ?></span> 
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Value (Enter Core/Alternative Name)*</div>
									<div>
										<input type="text"  class="input_full input_style" id="value" name="value" value="<?php echo $edit['value']; ?>"  required />
										<span class="fred"><?php echo form_error('value'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
				
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
	<script>
		$(document).ready(function(){
			$("#key").prop('required',false);
			if($('input[name=type]:checked').val()=='alias'){
					$('.core_name').removeClass('hide');
        	$('select').chosen('destroy'); 
					$("select").chosen({ width: '100%' });
        	$("#key").prop('required',true);
			}
			$('input[type=radio][name=type]').change(function() {
				$('.core_name').addClass('hide');
				$("#key").prop('required',false);
        var val = $(this).val();
        if( val == 'alias'){
        	$('.core_name').removeClass('hide');
        	$('select').chosen('destroy'); 
					$("select").chosen({ width: '100%' });
        	$("#key").prop('required',true);
        }
    });
			
		});
	</script>
</body>
</html>