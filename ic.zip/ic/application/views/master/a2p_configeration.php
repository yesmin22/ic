<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Create</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">

	   <?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update A2P Data</div>
       <?php }else{ ?>
        <div class="page_caption">Create A2P Data</div>
       <?php } ?>
		<div class="page_body">
		  <form id="frm_filter" method="post" action="" data-parsley-validate>
			 <div class="left_section">
				<fieldset class="divider"><legend>Please enter A2P information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
				
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<fieldset>
	  					<legend>Basic Information:</legend>
							<table width="100%">

								<tr>
									<td>
										<div class="form_label">Total sms commitment per month</div>
										<div>
											<input type="text"  class="input_full input_style" id="TOTAL_SMS_COMMITMENT_PER_MONTH" name="TOTAL_SMS_COMMITMENT_PER_MONTH" value="<?php echo set_value('TOTAL_SMS_COMMITMENT_PER_MONTH',$edit['TOTAL_SMS_COMMITMENT_PER_MONTH']); ?>"   />
											<span class="fred"><?php echo form_error('TOTAL_SMS_COMMITMENT_PER_MONTH'); ?></span>
										</div>
									</td>
								</tr>
						    <tr>
									<td>
										<div class="form_label">Agreed Rate*</div>
										<div>
											<input type="text"  class="input_full input_style" id="AGREED_RATE" name="AGREED_RATE" value="<?php echo set_value('AGREED_RATE',$edit['AGREED_RATE']); ?>"  required />
											<span class="fred"><?php echo form_error('AGREED_RATE'); ?></span>
										</div>
									</td>
								</tr>
								 <tr>
									<td>
										<div class="form_label">Ratio*</div>
										<div>
											<input type="text"  class="input_full input_style" id="RATIO" name="RATIO" value="<?php echo set_value('RATIO',$edit['RATIO']); ?>"  required />
											<span class="fred"><?php echo form_error('RATIO'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">USD to BDT Rate*</div>
										<div>
											<input type="text"  class="input_full input_style" id="USD_TO_BDT_RATE" name="USD_TO_BDT_RATE" value="<?php echo set_value('USD_TO_BDT_RATE',$edit['USD_TO_BDT_RATE']); ?>"  required />
											<span class="fred"><?php echo form_error('USD_TO_BDT_RATE'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">USD Amount*</div>
										<div>
											<input type="text"  class="input_full input_style" id="USD_AMOUNT" name="USD_AMOUNT" value="<?php echo set_value('USD_AMOUNT',$edit['USD_AMOUNT']); ?>"  required />
											<span class="fred"><?php echo form_error('USD_AMOUNT'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Deal period*</div>
										<div>
											<input type="text"  class="input_full input_style" id="DEAL_PERIOD" name="DEAL_PERIOD" value="<?php echo set_value('DEAL_PERIOD',$edit['DEAL_PERIOD']); ?>"  required />
											<span class="fred"><?php echo form_error('DEAL_PERIOD'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">From Date*</div>
										<div class="month_picker_container">
		            	  	<input type="text" name="FROM_DATE" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('FROM_DATE',strtotime($edit['FROM_DATE'])); ?>" required />
										</div>
										<div class="p_error_container">&nbsp;</div>
									</td>
							  </tr>
							  <tr>
									<td>
										<div class="form_label">To Date*</div>
										<div class="month_picker_container">
		            	  	<input type="text" name="TO_DATE" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('TO_DATE',strtotime($edit['FROM_DATE'])); ?>" required />
										</div>
										<div class="p_error_container">&nbsp;</div>
									</td>
							  </tr>
								
								<tr>
									<td>
								     <div><input type="submit" class="btn_gray" value="Submit Data" /></div>
									</td>
							</table>
							
						</fieldset>
				</div>
				
			</form>
			<div class="float_clear_full">&nbsp;</div>
		</div>
			
		</div><!--end #page_create_role -->
	
		<div><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
 <script>
 		$(document).ready(function(){
 			$('#TOTAL_SMS_COMMITMENT_PER_MONTH,#AGREED_RATE').on('change',function(){
 				var total_sms_commitment_per_month = $("#TOTAL_SMS_COMMITMENT_PER_MONTH").val();
		 		var agreed_rate = $('#AGREED_RATE').val();		
		 		if(total_sms_commitment_per_month && agreed_rate){
		 			usd_amount=total_sms_commitment_per_month*agreed_rate;
		 		}else{
		 			usd_amount=0;
		 		}
		 		$("#USD_AMOUNT").val(usd_amount.toFixed(2));
 			})
 		})
 </script>
</body>
</html>