<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column =12;
$report_name = 'Manage Data for ISMS Journal';
if( $this->uri->segment(2)=='csv' ){
	$file_name = strtolower(str_replace(array('_',' '),'',$report_name)).'_'.date('Y_m_d_H_i_s').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $report_name; ?></title>

		<style type="text/css">
			#printArea { width:80%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
			}
		</style>
		   <?php if( $this->uri->segment(2)=='print'): ?>
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
		
    <!-- Bootstrap -->
		<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo $url_prefix; ?>global/bootstrap_3_2/css/bootstrap-theme.min.css">
		<script src="<?php echo $url_prefix; ?>global/bootstrap_3_2/js/bootstrap.min.js"></script>
		
		<!-- print plugin -->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>

  </head>
  
  <body>
		<!--<a id="print_icon" href="#">Print</a>-->
		
		<div id="printArea">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" colspan="<?php echo $total_column; ?>">
						<div style="font-size:150%;"><?php echo $domain_name; ?></div>
					</td>
				</tr>
			</table>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;"><?php echo $report_name; ?>
				</tr>
		
				<tr><td>&nbsp;</td></tr>
			</table>
			<br />

			<table class="table table-bordered table-striped new_table_sm">
					<tr>
						<th>ID</th>
						<th>Country</th>
						<th>Operator</th>
						<th>Unit Price (EUR)</th>
						<th>Amount (EUR) to SAP</th>
						<th>Customer Receives From</th>
						<th>Customer's Zone</th>
						<th>Unit Price (EUR)</th>
						<th>Amount  (EUR) from SAP</th>
						<th>MCC</th>
						<th>MNC</th>
						<th>TAP Code</th>
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php if($v->COUNTRY){ echo $v->COUNTRY;}?></td>
						<td><?php if($v->OPERATOR){ echo $v->OPERATOR;}?></td>
						<td><?php if($v->UNIT_PRICE_EUR_2){ echo $v->UNIT_PRICE_EUR_2;}?></td>
						<td><?php if($v->AMOUNT_TO_SAP){ echo $v->AMOUNT_TO_SAP;}?></td>
						<td><?php if($v->CUSTOMER_RECEIVES_FROM){ echo $v->CUSTOMER_RECEIVES_FROM;}?></td>
						<td><?php if($v->ZONE_2){ echo $v->ZONE_2;}?></td>
						<td><?php if($v->UNIT_PRICE){ echo $v->UNIT_PRICE;}?></td>
						<td><?php if($v->AMOUNT_FROM_SAP){ echo $v->AMOUNT_FROM_SAP;}?></td>
						<td><?php if($v->MCC){ echo $v->MCC;}?></td>
						<td><?php if($v->MNC){ echo $v->MNC;}?></td>
						<td><?php if($v->TAP_CODE){ echo $v->TAP_CODE;}?></td>
					</tr>
					<?php $i++; endforeach; ?>
				</table>
			
		</div>
	</body>
</html>