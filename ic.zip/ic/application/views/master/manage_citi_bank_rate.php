<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_citi_bank_exchange_rate" class="main_container page_identifier">
			<div class="page_caption">Manage Citi Bank Exchange Rate</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
								<td>Start Date</td>
							<td>End Date</td>
						</tr>
						<tr>
							<td>
								<input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_citi_bank_rate">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_citi_bank_rate/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_citi_bank_rate/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>

				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>

				<table class="table table-bordered table-striped new_table_sm">
					<tr>
						<th>Sl NO.</th>
						<th>Buying TT Clean</th>
						<th>Selling BC</th>
						<th>Report Month</th>
						<th>Action</th>
					</tr>
					<?php foreach($get_record as $k=>$v): ?>
						<tr>
							<td><?php echo $k + 1; ?></td>
							<td><?php echo $v->BUYING_TT_CLEAN; ?></td>
							<td><?php echo $v->SELLING_BC; ?></td>
							<td><?php echo $v->REPORT_MONTH; ?></td>  
							<td class="field_button">
								<?php if( $this->webspice->permission_verify('manage_city_bank_rate',true)): ?>
									<a href="<?php echo $url_prefix; ?>manage_citi_bank_rate/edit/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Edit</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>