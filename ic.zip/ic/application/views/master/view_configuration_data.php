<?php #dd($this->webspice->encrypt_decrypt('0','encrypt')); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Option</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_option" class="main_container page_identifier">
			<div class="page_caption">Configuration Data</div>
			<div class="page_body table-responsive">
				<br />
				<div >
					<table id="print_area"  class="table table-bordered" width="100%" cellspacing="0" >
						<thead>
							<tr >
								<th style="text-align:left">SL</th>
								<th style="text-align:left">Name</th>
								<th style="text-align:left">Value</th>
								<th style="text-align:left">Action</th>
							</tr>
						</thead>	
						<tbody>
						<?php $i=0;foreach($get_record as $k=> $v):?>
							<?php foreach($v as $key=> $val):?>
								<tr >
									<td><?php echo ++$i;?></td>
									<td><?php echo ucwords(str_replace('_',' ',$key));?></td>
									<td><?php echo $val;?></td>
									<td><a class="btn btn-warning btn-xs" href="<?php echo $url_prefix.'view_configuration_data/edit/'.$k.'/'.$this->webspice->encrypt_decrypt($key,'encrypt');?>">Edit</a></td>
								</tr>
							<?php endforeach;?>	
						<?php endforeach; ?>
					</tbody>
					</table>
				</div>	
		</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
	<script>
		$(document).ready(function() {
    $('#print_area').DataTable( {
        dom: 'Bfrtip',
        buttons: [
					{
						extend: 'colvis'
					}
	            
            
        ]
	    } );
		});
	</script>
</body>
</html>