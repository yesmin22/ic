
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: GL Mapping</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_create_company" class="main_container page_identifier">
			
			
			<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update Common GL Mapping</div>
       <?php }else{ ?>
        <div class="page_caption">Create Common GL Mapping</div>
       <?php } ?>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
				
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<table width="100%">
								<tr>
									<td>
										<div class="form_label">VAT*</div>
										<div>
											<input type="text"  class="input_full input_style" id="vat" name="vat" value="<?php echo set_value('vat',$edit['VAT']); ?>"  required />
											<span class="fred"><?php echo form_error('vat'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">TF Invoice*</div>
										<div>
											<input type="text"  class="input_full input_style" id="tf_invoice" name="tf_invoice" value="<?php echo set_value('tf_invoice',$edit['TF_INVOICE']); ?>" required />
											<span class="fred"><?php echo form_error('tf_invoice'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">TF Revenue*</div>
										<div>
											<input type="text"  class="input_full input_style" id="tf_revenue" name="tf_revenue" value="<?php echo set_value('tf_revenue',$edit['TF_REVENUE']); ?>"  required />
											<span class="fred"><?php echo form_error('tf_revenue'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">TF SD*</div>
										<div>
											<input type="text"  class="input_full input_style" id="tf_sd" name="tf_sd" value="<?php echo set_value('tf_sd',$edit['TF_SD']); ?>" required  />
											<span class="fred"><?php echo form_error('tf_sd'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">TF_SC*</div>
										<div>
											<input type="text"  class="input_full input_style" id="tf_sc" name="tf_sc" value="<?php echo set_value('tf_sc',$edit['TF_SC']); ?>"  required />
											<span class="fred"><?php echo form_error('tf_sc'); ?></span>
										</div>
									</td>
								</tr>
								
								
								<tr>
									<td>
										<div class="form_label">Cost International Postpaid*</div>
										<div>
											<input type="text"  class="input_full input_style" id="cost_internal_post" name="cost_internal_post" value="<?php echo set_value('cost_internal_post',$edit['COST_INTN_POST']); ?>" required  />
											<span class="fred"><?php echo form_error('cost_internal_post'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Cost International Prepaid*</div>
										<div>
											<input type="text"  class="input_full input_style" id="cost_internal_pre" name="cost_internal_pre" value="<?php echo set_value('cost_internal_pre',$edit['COST_INTN_PRE']); ?>"  required />
											<span class="fred"><?php echo form_error('cost_internal_pre'); ?></span>
										</div>
									</td>
								</tr>
								
								
								<tr>
									<td>
										<div class="form_label">ICX Portion*</div>
										<div>
											<input type="text"  class="input_full input_style" id="icx_portion" name="icx_portion" value="<?php echo set_value('icx_portion',$edit['ICX_PORTION']); ?>" required  />
											<span class="fred"><?php echo form_error('icx_portion'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">BTRC Portion*</div>
										<div>
											<input type="text"  class="input_full input_style" id="btrc_portion" name="btrc_portion" value="<?php echo set_value('btrc_portion',$edit['BTRC_PORTION']); ?>"  required />
											<span class="fred"><?php echo form_error('btrc_portion'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">IGW Portion*</div>
										<div>
											<input type="text"  class="input_full input_style" id="igw_portion" name="igw_portion" value="<?php echo set_value('igw_portion',$edit['IGW_PORTION']); ?>"  required />
											<span class="fred"><?php echo form_error('igw_portion'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">International Rev Invoice*</div>
										<div>
											<input type="text"  class="input_full input_style" id="intn_rev_invoice" name="intn_rev_invoice" value="<?php echo set_value('intn_rev_invoice',$edit['INTN_REV_INVOICE']); ?>"  required />
											<span class="fred"><?php echo form_error('intn_rev_invoice'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">International Rev Post Debit*</div>
										<div>
											<input type="text"  class="input_full input_style" id="intn_rev_post_debit" name="intn_rev_post_debit" value="<?php echo set_value('intn_rev_post_debit',$edit['INTN_REV_POST_DEBIT']); ?>"  required />
											<span class="fred"><?php echo form_error('intn_rev_post_debit'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">International Rev Pre Debit*</div>
										<div>
											<input type="text"  class="input_full input_style" id="intn_rev_pre_debit" name="intn_rev_pre_debit" value="<?php echo set_value('intn_rev_pre_debit',$edit['INTN_REV_PRE_DEBIT']); ?>"  required />
											<span class="fred"><?php echo form_error('intn_rev_pre_debit'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">International Rev Post Credit*</div>
										<div>
											<input type="text"  class="input_full input_style" id="intn_rev_post_credit" name="intn_rev_post_credit" value="<?php echo set_value('intn_rev_post_credit',$edit['INTN_REV_POST_CREDIT']); ?>"  required />
											<span class="fred"><?php echo form_error('intn_rev_post_credit'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">International Rev Pre Credit*</div>
										<div>
											<input type="text"  class="input_full input_style" id="intn_rev_pre_credit" name="intn_rev_pre_credit" value="<?php echo set_value('intn_rev_pre_credit',$edit['INTN_REV_PRE_CREDIT']); ?>"  required />
											<span class="fred"><?php echo form_error('intn_rev_pre_credit'); ?></span>
										</div>
									</td>
								</tr>
							<tr>
								<td>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
				
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>

</body>
</html>