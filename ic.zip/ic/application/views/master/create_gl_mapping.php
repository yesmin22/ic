<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">

	   <?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update GL Mapping</div>
       <?php }else{ ?>
        <div class="page_caption">Create GL Mapping</div>
       <?php } ?>

			<div class="page_body">
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter GL information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_filter" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						
						<table width="100%">
							<tr>
								<td>
									<div class="form_label">Operator Name*</div>
									<div>
		               <select name="operator_name" class="input_full input_style" required>
				              <option value="">Select One</option>
				              <?php if( set_value('operator_id', $edit['OPERATOR_NAME']) ): ?>
				              <?php echo str_replace('value="'.set_value('user_role', $edit['OPERATOR_NAME']).'"','value="'.set_value('user_role', $edit['OPERATOR_NAME']).'" selected="selected"', $this->customcache->get_operator()); ?>
				              <?php else: ?>
				              <?php echo $this->customcache->get_operator(); ?>
				              <?php endif; ?>
	             			</select>
										<span	class="fred"><?php echo form_error('operator_name'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">GL Type*</div>
									<div>
		               <select name="gl_type" class="input_full input_style" required>
		               	<option value=''>Select One</option>
				            <option value='Prepaid' <?php if($edit['GL_TYPE']=='Prepaid'){echo 'selected';}?>>Prepaid</option>
				            <option value='Postpaid' <?php if($edit['GL_TYPE']=='Postpaid'){echo 'selected';}?>>Postpaid</option>
				            <option value='Accrued' <?php if($edit['GL_TYPE']=='Accrued'){echo 'selected';}?>>Accrued</option>
	             			</select>
										<span	class="fred"><?php echo form_error('gl_type'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Report Type*</div>
									<div>
		               <select name="report_type" class="input_full input_style" required>
				            <option value='Actual' >Actual</option>
				            <option value='Provision' >Provision</option>
	             			</select>
										<span	class="fred"><?php echo form_error('report_type'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Debit/Credit*</div>
									<div>
		               <select name="debit_credit" class="input_full input_style" required>
				            <option value='Debit' >Debit</option>
				            <option value='Credit' >Credit</option>
	             			</select>
										<span	class="fred"><?php echo form_error('debit_credit'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
							  <td>
							  <div class="form_label">GL Code*</div>
							  <div>
							  	<input type="text"	class="input_full	input_style" id="gl_code" name="gl_code" value="<?php	
							  	echo set_value('gl_code',$edit['GL_CODE']);	
							  	?>"	 required	/>
							  	<span	class="fred"><?php 
							  		echo form_error('gl_code'); 
							  		?></span>
							  </div>
								</td>
							</tr>
							<tr>
								<td>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>

				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
			
		</div><!--end #page_create_role -->
	
		<div><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
 
</body>
</html>