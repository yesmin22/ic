<?php
	date_default_timezone_set('Asia/Dhaka');
	
	ob_start();
	system("mode COM1:2400,s,8,1",$output);
	$result = ob_get_contents();
	ob_end_clean();
	
	#system("echo 12345678>COM1");
	#exit;
	$order_details = json_decode($_POST['order_data']);
	
	design_and_print($order_details);
	
	function design_and_print($order_details){
		if(!$order_details){
			return false;
		}
		
		#$img_path = $this->webspice->get_path('img_full');
		$img_path = null;
		$return_order_id = array();
		$handle = printer_open("w80");
		
		$y_position = 0;
		printer_start_doc($handle, "My Order");
		printer_start_page($handle);
		$grand_total = 0;
		#system("echo     0.00 >COM1");
		#exit;
		foreach($order_details as $order){
			/* Information for the receipt */
			$order_date = $order->OrderedDate;
			$order_id = $order->ID;
			$employee_name = $order->EmployeeName;
			$phone_number = $order->PhoneNumber;
			#set_barcode($order_id);
			$return_order_id[] = $order_id;
			$cafe_name = $order->CafeteriaName;
			
			$order_details = json_decode($order->OrderDetails);
			
			$menu = $order_details->menu;
			$item = $order_details->item;
		
			printer_draw_bmp($handle, $img_path."fsd_logo.bmp", 200, $y_position);
			#consolas
			$font_face = "consolas";
			$font = printer_create_font($font_face, 20, 15, 700, false, false, false, 0);
			printer_select_font($handle, $font);
			printer_draw_text($handle, "Name: ".$employee_name, 20, $y_position+60);
			printer_draw_text($handle, "Mobile No: ".$phone_number, 20, $y_position+90);
			printer_draw_text($handle, "Order ID: ".$order_id, 20, $y_position+120);
			printer_draw_text($handle, "Order Date: ".date("d F Y",strtotime($order_date)), 20, $y_position+150);
			printer_delete_font($font);
			
			$font = printer_create_font($font_face, 20, 15, 300, false, false, false, 0);
			printer_select_font($handle, $font);
			$text = '';
			$total = 0;
			$menu_details_start = $y_position+210;
			
			foreach($menu as $mk => $mv){
				$text = string_align( ((strlen($mv->MenuName) > 12) ? substr($mv->MenuName,0,11).'..' : $mv->MenuName).' '.$mv->Qty.' X '.$mv->UnitPrice, number_format($mv->UnitPrice*$mv->Qty,2));
				$total += $mv->UnitPrice*$mv->Qty;
				printer_draw_text($handle, $text, 20, $menu_details_start);
				$menu_details_start = $menu_details_start + 30;
			}
			printer_delete_font($font);
			
			$font = printer_create_font($font_face, 20, 15, 300, false, false, false, 0);
			printer_select_font($handle, $font);
			
			foreach($item as $ik => $iv){
				$text1 = string_align(((strlen($iv->ItemName) > 12) ? substr($iv->ItemName,0,11).'..' : $iv->ItemName).' '.$iv->Qty.' X '.$iv->UnitPrice, number_format($iv->UnitPrice*$iv->Qty,2));
				$total += $iv->UnitPrice*$iv->Qty;
				printer_draw_text($handle, $text1, 20, $menu_details_start);
				$menu_details_start = $menu_details_start + 30;
			}
			
			printer_delete_font($font);
			$menu_details_start = $menu_details_start+30;
			
			printer_draw_line($handle, 10, $menu_details_start, 2000, $menu_details_start);
			
			$font = printer_create_font($font_face, 20, 15, 700, false, false, false, 0);
			printer_select_font($handle, $font);
			$grand_total += $total;
			$total = string_align('Total', number_format($total,2));
			printer_draw_text($handle, $total, 20, $menu_details_start+30);
			$menu_details_start = $menu_details_start+30;
			
			printer_draw_text($handle, $cafe_name, 20, $menu_details_start+30);
			$menu_details_start = $menu_details_start+30;
			printer_delete_font($font);
			
			#printer_draw_bmp($handle, $img_path."barcode.bmp", 150, $menu_details_start+60);
			$y_position = $menu_details_start + 140;
			
		}
		
		printer_end_page($handle);
		printer_end_doc($handle);
		$printer_status = printer_close($handle);
		
		$display_dgt = 7;
		$total_dgt = strlen($grand_total.".00");
		
		$space = $display_dgt - $total_dgt;
		$white_space = str_repeat(" ",$space);
		$final_str = $white_space.$grand_total;
		
		#system("echo $final_str>COM1");
		
		$response['message'] = 'success';
		$response['order_id'] = $return_order_id;
		echo json_encode($response);
		exit;
	}
	
	function string_align($name = '', $price = '', $dollarSign = false){
		$rightCols = 10;
		$leftCols = 25;
		if ($dollarSign) {
		  $leftCols = $leftCols / 2 - $rightCols / 2;
		}
		$left = str_pad($name, $leftCols);
		
		$sign = ($dollarSign ? '$ ' : '');
		$right = str_pad($sign . $price, $rightCols, ' ', STR_PAD_LEFT);
		return "$left$right\n";
	}
	
	function set_barcode($code){
		require_once('barcodegen/class/BCGFontFile.php');
		require_once('barcodegen/class/BCGColor.php');
		require_once('barcodegen/class/BCGDrawing.php');

		require_once('barcodegen/class/BCGcode128.barcode.php');

		#header('Content-Type: image/png');

		$color_white = new BCGColor(255, 255, 255);

		$code = new BCGcode128();
		$code->parse($code);

		$drawing = new BCGDrawing('', $color_white);
		$drawing->setBarcode($code);

		$drawing->draw();
		$drawing->finish(BCGDrawing::IMG_FORMAT_PNG);

		$drawing = new BCGDrawing('barcode.png', $color_white);
		
		require_once('ToBmp.php');
		
		// intialize the class
		$ToBMP = new ToBmp();

		//======= convert jpg to bmp
		$ToBMP->image_info('barcode.png');
		#$ToBMP->new_width  = 100;
		#$ToBMP->new_height = 100;
		$ToBMP->imagebmp("barcode.bmp");
		
	}
	

	function dd($data, $flow=null){
		print ("<pre>");
			print_r($data);
		print ("</pre>");
		if($flow){ 
			# continue
			return true;
		}
		exit;
	}
	
?>