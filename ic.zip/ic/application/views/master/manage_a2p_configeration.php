<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Manage A2P Configuation Data</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
		           <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_operator">Refresh</a>
								<!--<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_operator/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_operator/csv" target="_blank">Export</a>-->
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table class="table table-bordered table-striped new_table_sm">
					<tr>
						<th>ID</th>
						<th>Total SMS Commitment Per Month</th>
						<th>Agreed Rate</th>
						<th>Ratio</th>
						<th>USD to BDT Rate</th>
						<th>Usd Amount</th>
						<th>Deal Period</th>
						<th>From Date</th>
						<th>To Date</th>
						<th>Action</th>
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php if($v->TOTAL_SMS_COMMITMENT_PER_MONTH){ echo $v->TOTAL_SMS_COMMITMENT_PER_MONTH;}?></td>
						<td><?php if($v->AGREED_RATE){ echo $v->AGREED_RATE;}?></td>
						<td><?php if($v->RATIO){ echo $v->RATIO;}?></td>
						<td><?php if($v->USD_TO_BDT_RATE){ echo $v->USD_TO_BDT_RATE;}?></td>
						<td><?php if($v->USD_AMOUNT){ echo $v->USD_AMOUNT;}?></td>
						<td><?php if($v->DEAL_PERIOD){ echo $v->DEAL_PERIOD;}?></td>
						<td><?php if($v->FROM_DATE){ echo $v->FROM_DATE;}?></td>
						<td><?php if($v->TO_DATE){ echo $v->TO_DATE;}?></td>
							
						<td class="field_button">
							<?php if( $this->webspice->permission_verify('manage_operator',true) && $v->STATUS!=9 ): ?>
							<a href="<?php echo $url_prefix; ?>manage_a2p_configeration/edit/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Edit</a>
							<?php endif; ?>
						</td>
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>