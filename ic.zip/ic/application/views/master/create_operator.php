<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_vehicle" class="main_container page_identifier">

	   <?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update Operator</div>
       <?php }else{ ?>
        <div class="page_caption">Create Operator</div>
       <?php } ?>

		<div class="page_body">
		  <form id="frm_filter" method="post" action="" data-parsley-validate>
			 <div class="left_section">
				<fieldset class="divider"><legend>Please enter Operator information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
				
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<fieldset>
	  					<legend>Basic Information:</legend>
							<table width="100%">
								<tr>
									<td>
										<div class="form_label">Operator Name*</div>
										<div>
											<input type="text"  class="input_full input_style" id="operator_name" name="operator_name" value="<?php echo set_value('operator_name',html_entity_decode($edit['OPERATOR_NAME'])); ?>"  required />
											<span class="fred"><?php echo form_error('operator_name'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Short Code</div>
										<div>
											<input type="text"  class="input_full input_style" id="short_code" name="short_code" value="<?php echo set_value('short_code',$edit['OPERATOR_SHORT_CODE']); ?>"   />
											<span class="fred"><?php echo form_error('short_code'); ?></span>
										</div>
									</td>
								</tr>
						    <tr>
									<td>
										<div class="form_label">Project Code*</div>
										<div>
											<input type="text"  class="input_full input_style" id="projrct_code" name="projrct_code" value="<?php echo set_value('projrct_code',$edit['PROJECT_CODE']); ?>"  required />
											<span class="fred"><?php echo form_error('projrct_code'); ?></span>
										</div>
									</td>
								</tr>
								 <tr>
									<td>
										<div class="form_label">Supplier Code*</div>
										<div>
											<input type="text"  class="input_full input_style" id="supplier_code" name="supplier_code" value="<?php echo set_value('supplier_code',$edit['SUPPLIER_CODE']); ?>"  required />
											<span class="fred"><?php echo form_error('supplier_code'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Operator Type*</div>
										<div>
			               <select name="operator_type" class="input_full input_style" required>
			               	<option value=''>SELECT ONE</option>
					            <option value='BTRC' <?php if($edit['OPERATOR_TYPE']=='BTRC'){echo 'selected';}?>>BTRC</option>
					            <option value='ICX' <?php if($edit['OPERATOR_TYPE']=='ICX'){echo 'selected';}?>>ICX</option>
					            <option value='IGW' <?php if($edit['OPERATOR_TYPE']=='IGW'){echo 'selected';}?>>IGW</option>
					            <option value='IPTSP' <?php if($edit['OPERATOR_TYPE']=='IPTSP'){echo 'selected';}?>>IPTSP</option>
					            <option value='ISMS' <?php if($edit['OPERATOR_TYPE']=='ISMS'){echo 'selected';}?>>ISMS</option>
					            <option value='MOBILE' <?php if($edit['OPERATOR_TYPE']=='MOBILE'){echo 'selected';}?>>MOBILE</option>
					            <option value='PSTN' <?php if($edit['OPERATOR_TYPE']=='PSTN'){echo 'selected';}?>>PSTN</option>
					            <option value='LTFS' <?php if($edit['OPERATOR_TYPE']=='LTFS'){echo 'selected';}?>>LTFS</option>
					            <option value='ITFS' <?php if($edit['OPERATOR_TYPE']=='ITFS'){echo 'selected';}?>>ITFS</option>
								 <option value='A2P' <?php if($edit['OPERATOR_TYPE']=='A2P'){echo 'selected';}?>>A2P</option>
		             			</select>
											<span	class="fred"><?php echo form_error('operator_type'); ?></span>
										</div>
									</td>
								</tr>
							</table>
						</fieldset>
				</div>
				<div class="right_section">
						<fieldset>
	  					<legend>Invoice Information:</legend>
							<table width="100%">
								<tr>
									<td>
										<div class="form_label">Attention*</div>
										<div>
											<input type="text"  class="input_full input_style" id="attention" name="attention" value="<?php echo set_value('attention',$edit['ATTENTION']); ?>"  required/>
											<span class="fred"><?php echo form_error('attention'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Address*</div>
										<div>
											<input type="text"  class="input_full input_style" id="address" name="address" value="<?php echo set_value('address',$edit['ADDRESS']); ?>"  required/>
											<span class="fred"><?php echo form_error('address'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Email Address*</div>
										<div>
											<input type="text"  class="input_full input_style" id="email_address" name="email_address" value="<?php echo set_value('email_address',$edit['EMAIL_ADDRESS']); ?>"  required/>
											<span class="fred"><?php echo form_error('email_address'); ?></span>
										</div>
									</td>
								</tr>
						    <tr>
									<td>
										<div class="form_label">Telephone No:*</div>
										<div>
											<input type="text"  class="input_full input_style" id="tel_no" name="tel_no" value="<?php echo set_value('tel_no',$edit['TEL_NO']); ?>"  required/>
											<span class="fred"><?php echo form_error('tel_no'); ?></span>
										</div>
									</td>
								</tr>
						    <tr>
									<td>
										<div class="form_label">VAT Registration No:*</div>
										<div>
											<input type="text"  class="input_full input_style" id="vat_reg_no" name="vat_reg_no" value="<?php echo set_value('vat_reg_no',$edit['VAT_REG_NO']); ?>"   required/>
											<span class="fred"><?php echo form_error('vat_reg_no'); ?></span>
										</div>
									</td>
								</tr>	
						   <!-- <tr>
									<td>
										<div class="form_label">Area Code:*</div>
										<div>
											<input type="text"  class="input_full input_style" id="area_code" name="area_code" value="<?php echo set_value('area_code',$edit['AREA_CODE']); ?>"  />
											<span class="fred"><?php echo form_error('area_code'); ?></span>
										</div>
									</td>
								</tr>	-->		
						    <tr>
									<td>
										<div class="form_label">Reference :*</div>
										<div>
											<input type="text"  class="input_full input_style" id="ref_no" name="ref_no" value="<?php echo set_value('ref_no',$edit['REF_NO']); ?>" required />
											<span class="fred"><?php echo form_error('ref_no'); ?></span>
										</div>
									</td>
								</tr>					
							</table>
						</fieldset>
				</div>
				<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
			</form>
			<div class="float_clear_full">&nbsp;</div>
		</div>
			
		</div><!--end #page_create_role -->
	
		<div><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
 
</body>
</html>