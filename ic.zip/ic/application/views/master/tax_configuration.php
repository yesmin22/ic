<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_corporate_exchange_rate" class="main_container page_identifier">
			<?php if( isset($edit['ID']) && $edit['ID'] ):?>
				<div class="page_caption">Edit TAX Configuration</div>
			<?php else:?>
				<div class="page_caption">TAX Configuration</div>
			<?php endif;?>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter TAX Configuration.</legend></fieldset>

					<div class="stitle">* Mandatory Field</div>
					
					<form id="page_tax_configuration" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="configuration_id" name="configuration_id" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />

						<table width="100%">
							<tr>
									<td>
										<div class="form_label">Operator Type*</div>
										<div>
			               <select name="OPERATOR_TYPE" class="input_full input_style" required>
			               	<option value=''>SELECT ONE</option>
					            <option value='BTRC' <?php if($edit['OPERATOR_TYPE']=='BTRC'){echo 'selected';}?>>BTRC</option>
					            <option value='ICX' <?php if($edit['OPERATOR_TYPE']=='ICX'){echo 'selected';}?>>ICX</option>
					            <option value='IGW' <?php if($edit['OPERATOR_TYPE']=='IGW'){echo 'selected';}?>>IGW</option>
					            <option value='IPTSP' <?php if($edit['OPERATOR_TYPE']=='IPTSP'){echo 'selected';}?>>IPTSP</option>
					            <option value='ISMS' <?php if($edit['OPERATOR_TYPE']=='ISMS'){echo 'selected';}?>>ISMS</option>
					            <option value='MOBILE' <?php if($edit['OPERATOR_TYPE']=='MOBILE'){echo 'selected';}?>>MOBILE</option>
					            <option value='PSTN' <?php if($edit['OPERATOR_TYPE']=='PSTN'){echo 'selected';}?>>PSTN</option>
		             			</select>
											<span	class="fred"><?php echo form_error('operator_type'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Rate (%)*</div>
										<div>
											<input type="text"  class="input_full input_style" id="RATE" name="RATE" value="<?php echo set_value('RATE',$edit['RATE']); ?>" maxlength="50" data-parsley-type="number" required />
											<span class="fred"><?php echo form_error('RATE'); ?></span>
										</div>
									</td>
								</tr>
									<tr>
										<td>
											<div><input id="btn_submit" type="submit" class="btn_gray" value="Submit Data" /></div>
										</td>
									</tr>
								</table>
							</form>
						</div>

						<div class="right_section">

						</div>
						<div class="float_clear_full">&nbsp;</div>


					</div>

				</div>

			</div>
	</body>
</html>