<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Manage Ranks PSTN Data</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:50%;">
						<tr>
							<td width="150px">Keyword</td>
							<td colspan=8>Bill Month</td>
						</tr>
						<tr>
							<td>
								<input type="text" name="SearchKeyword" class="input_style" />
							</td>
							<td colspan=8>
								<div class="month_picker_container">
									<input type="text" name="BILL_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="" />
								</div>
							</td>
						</tr>
						<tr>
							<td colspan=9>
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_ranks_pstn_accrued_data">Refresh</a>
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table class="table table-bordered table-striped new_table_sm">
					<tr>
						<th>ID</th>
						<th>Electricity Rate</th>
						<th>Electricity Number of Site</th>
						<th>Electricity Amount</th>
						<th>BTS</th>
						<th>PSTN Fixed</th>
						<th>Accrued Data</th>
						<th>Bill Month</th>
						<th>Action</th>
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php  echo $v->ELECTRICITY_RATE;?></td>
						<td><?php  echo $v->NUMBER_OF_SITE;?></td>
						<td><?php  echo $v->ELECTRICITY_AMOUNT;?></td>
						<td><?php  echo $v->BTS_DATA;?></td>
						<td><?php  echo $v->ACCRUED_DATA;?></td>
						<td><?php  echo $v->PSTN_FIXED;?></td>
						<td><?php  echo $v->BILL_MONTH;?></td>
						<td class="field_button">
							<?php if( $this->webspice->permission_verify('manage_ranks_pstn_accrued_data',true) ): ?>
							<a href="<?php echo $url_prefix; ?>manage_ranks_pstn_accrued_data/edit/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Edit</a>
							<?php endif; ?>
						</td>
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>