<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_corporate_exchange_rate" class="main_container page_identifier">
			<?php if( isset($edit['ID']) && $edit['ID'] ):?>
				<div class="page_caption">Edit Sonali Bank Exchange Rate</div>
			<?php else:?>
				<div class="page_caption">Create Sonali Bank Exchange Rate</div>
			<?php endif;?>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please Sonali Bank Exchange Rate information</legend></fieldset>

					<div class="stitle">* Mandatory Field</div>
					
					<form id="page_create_corporate_exchange_rate" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="rate_id" name="rate_id" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />

						<table width="100%">
							<tr>
								<td colspan=3>
									<div class="form_label">Month*</div>
									<div class="month_picker_container">
		              	<input type="text" name="REPORT_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('REPORT_MONTH',strtotime($edit['REPORT_MONTH'])); ?>" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
									<tr>
										<td>
											<div class="form_label">Buying TT Clean*</div>
											<div>
												<input type="text"  class="input_full input_style" id="BUYING_TT_CLEAN" name="BUYING_TT_CLEAN" value="<?php echo set_value('BUYING_TT_CLEAN',$edit['BUYING_TT_CLEAN']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('BUYING_TT_CLEAN'); ?></span>
											</div>
										</td>
										<td>
											<div class="form_label">SELLING BC*</div>
											<div>
												<input type="text"  class="input_full input_style" id="SELLING_BC" name="SELLING_BC" value="<?php echo set_value('SELLING_BC',$edit['SELLING_BC']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('SELLING_BC'); ?></span>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<div><input id="btn_submit" type="submit" class="btn_gray" value="Submit Data" /></div>
										</td>
									</tr>
								</table>
							</form>
						</div>

						<div class="right_section">

						</div>
						<div class="float_clear_full">&nbsp;</div>


					</div>

				</div>

			</div>
	</body>
</html>