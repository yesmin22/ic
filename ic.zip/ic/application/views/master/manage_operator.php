<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Manage Operator</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
		           <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_operator">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_operator/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_operator/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table class="table table-bordered table-striped new_table_sm">
					<tr>
						<th>ID</th>
						<th>Operator Name</th>
						<th>Operator Short Code</th>
						<th>Operator Type</th>
						<th>Project Code</th>
						<th>Attention</th>
						<th>Address</th>
						<th>Tel No</th>
						<th>Vat Reg No</th>
						<th>Area Code</th>
						<th>Ref No</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php if($v->OPERATOR_NAME){ echo $v->OPERATOR_NAME;}?></td>
						<td><?php if($v->OPERATOR_SHORT_CODE){ echo $v->OPERATOR_SHORT_CODE;}?></td>
						<td><?php if($v->OPERATOR_TYPE){ echo $v->OPERATOR_TYPE;}?></td>
						<td><?php if($v->PROJECT_CODE){ echo $v->PROJECT_CODE;}?></td>
						<td><?php if($v->ATTENTION){ echo $v->ATTENTION;}?></td>
						<td><?php if($v->ADDRESS){ echo $v->ADDRESS;}?></td>
						<td><?php if($v->TEL_NO){ echo $v->TEL_NO;}?></td>
						<td><?php if($v->VAT_REG_NO){ echo $v->VAT_REG_NO;}?></td>
						<td><?php if($v->AREA_CODE){ echo $v->AREA_CODE;}?></td>
						<td><?php if($v->REF_NO){ echo $v->REF_NO;}?></td>
						<td><?php echo $this->webspice->static_status($v->STATUS);?></td>		
						<td class="field_button">
							<?php if( $this->webspice->permission_verify('manage_operator',true) && $v->STATUS!=9 ): ?>
							<a href="<?php echo $url_prefix; ?>manage_operator/edit/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Edit</a>
							<?php endif; ?>
							
							<?php if( $this->webspice->permission_verify('manage_operator',true) && $v->STATUS==7 ): ?>
							<a href="<?php echo $url_prefix; ?>manage_operator/inactive/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Inactive</a>
							<?php endif; ?>
							
							<?php if( $this->webspice->permission_verify('manage_operator',true) && $v->STATUS==-7 ): ?>
							<a href="<?php echo $url_prefix; ?>manage_operator/active/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Active</a>
							<?php endif; ?>
						</td>
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>