<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Manage TAX Configuration</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
		           <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_data_for_isms_journal">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_data_for_isms_journal/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_data_for_isms_journal/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table class="table table-bordered table-striped new_table_sm">
					<tr>
						<th>ID</th>
						<th>Country</th>
						<th>Operator</th>
						<th>Unit Price (EUR)</th>
						<th>Amount (EUR) to SAP</th>
						<th>Customer Receives From</th>
						<th>Customer's Zone</th>
						<th>Unit Price (EUR)</th>
						<th>Amount  (EUR) from SAP</th>
						<th>MCC</th>
						<th>MNC</th>
						<th>TAP Code</th>
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php if($v->COUNTRY){ echo $v->COUNTRY;}?></td>
						<td><?php if($v->OPERATOR){ echo $v->OPERATOR;}?></td>
						<td><?php if($v->UNIT_PRICE_EUR_2){ echo $v->UNIT_PRICE_EUR_2;}?></td>
						<td><?php if($v->AMOUNT_TO_SAP){ echo $v->AMOUNT_TO_SAP;}?></td>
						<td><?php if($v->CUSTOMER_RECEIVES_FROM){ echo $v->CUSTOMER_RECEIVES_FROM;}?></td>
						<td><?php if($v->ZONE_2){ echo $v->ZONE_2;}?></td>
						<td><?php if($v->UNIT_PRICE){ echo $v->UNIT_PRICE;}?></td>
						<td><?php if($v->AMOUNT_FROM_SAP){ echo $v->AMOUNT_FROM_SAP;}?></td>
						<td><?php if($v->MCC){ echo $v->MCC;}?></td>
						<td><?php if($v->MNC){ echo $v->MNC;}?></td>
						<td><?php if($v->TAP_CODE){ echo $v->TAP_CODE;}?></td>
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>