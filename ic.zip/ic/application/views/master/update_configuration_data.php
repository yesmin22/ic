<?php #dd($edit);?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Create Option</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_create_configuration" class="main_container page_identifier">
			<div class="page_caption">Update Configuration Data</div>
			<div class="page_body">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
				
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_create_configuration" method="post" action="<?php echo $url_prefix.'update_configuration_data';?>" data-parsley-validate>
						<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
  					<input type="hidden" name="key" id="key" value="<?php echo $edit['key'];?>"/>
						<table width="100%">
							<tr>
								<td>
									<div class="form_label">Group Name*</div>
									<div>
		               <select name="attribute" id="attribute" class="input_full input_style" required>
				              <option value="" data-key="">Select One</option>
				              <?php foreach($get_record as $k => $v):?>
				              	<?php foreach($v as $key=> $val):?>
													<option value="<?php echo $key; ?>" <?php echo ($edit['attribute']== $key) ? 'selected="selected"': '';?> data-key="<?php echo $k;?>"><?php echo ucwords(str_replace('_',' ',$key));?></option>
												<?php endforeach;?>	
				              <?php endforeach;?>
	             			</select>
	            			<span class="fred"><?php echo form_error('attribute'); ?></span> 
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="form_label">Value*</div>
									<div>
										<input type="text"  class="input_full input_style" id="value" name="value" value="<?php echo $edit['value']; ?>"  required />
										<span class="fred"><?php echo form_error('value'); ?></span>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
				
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
	<script>
		$(document).ready(function(){
			$('#attribute').on('change',function(){
				var token = $('#token').val();
				var attribute = $('#attribute').val();
				var selected = $(this).find('option:selected');
				var key = selected.data('key');
				/*set to input key*/
				$('#key').val(key);
				if( attribute ){
					var jqxhr = $.ajax({
						 type: "POST",
						 url: url_prefix + "update_configuration_data",
						 data: {ajax_call: 'yes',attribute: attribute, csrf_webspice_tkn: token }
						}).done(function(msg){
								var obj = JSON.parse(msg);
								$('#value').val(obj[0]);
						}).fail(function() {
							alert( "We could not execute your request. Please try again later or report to authority." );
						});
				}
				
			});
			
		});
	</script>
</body>
</html>