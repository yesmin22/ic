<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Manage User</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input id="token" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_user">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_user/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_user/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				
				<table class="table table-bordered table-striped new_table">
					<tr>
						<th>User Name</th>
						<th>Designation</th>
						<th>Department/Division</th>
						<th>User Email</th>
						<th>User Phone</th>
						<th>Created Date</th>
						<th>User Role</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $v->USER_NAME; ?></td>
						<td><?php echo $v->DESIGNATION; ?></td>
						<td><?php echo $v->DEPARTMENT_DIVISION; ?></td>
						<td><?php echo $v->USER_EMAIL; ?></td>
						<td><?php echo $v->USER_PHONE; ?></td>
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
						<td><?php echo ucwords(str_replace('_',' ',$v->ROLE_NAME)); ?></td>
						<td><?php if($v->STATUS==9){echo 'ADMIN';} else {echo $this->webspice->static_status($v->STATUS);} ?></td>
						<td class="field_button">
							<?php if( $this->webspice->permission_verify('manage_user',true) && $v->STATUS!=9 ): ?>
							<a href="#" data-link="<?php echo $url_prefix; ?>manage_user/edit/<?php echo $this->webspice->encrypt_decrypt($v->USER_ID,'encrypt'); ?>" class="btn_edit btn_orange">Edit</a>
							<?php endif; ?>
							
							<?php if( $this->webspice->permission_verify('manage_user',true) && $v->STATUS==7 ): ?>
							<a href="<?php echo $url_prefix; ?>manage_user/inactive/<?php echo $this->webspice->encrypt_decrypt($v->USER_ID,'encrypt').'/pg/'.$this->uri->segment(3); ?>" class="btn_orange">Inactive</a>
							<?php endif; ?>
							
							<?php if( $this->webspice->permission_verify('manage_user',true) && $v->STATUS==-7 ): ?>
							<a href="<?php echo $url_prefix; ?>manage_user/active/<?php echo $this->webspice->encrypt_decrypt($v->USER_ID,'encrypt').'/pg/'.$this->uri->segment(3); ?>" class="btn_orange">Active</a>
							<?php endif; ?>
						</td>
					</tr>
					<?php endforeach; ?>
				</table>
				
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
				<div id="ajax_edit_container" style="z-index:10000; width:60%; height:300px; position:absolute; left:20%; top:0px; display:none; overflow:auto;"></div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
	
	<script type="text/javascript">
		$(document).ready(function(){
			$('.btn_edit').on('click', function(){
          var token = $('#token').val();
          var spinner = $(this).parent().parent().find('.spinner');
          var me = $(this);
          spinner.show();
          
          var jqxhr = $.ajax({
           type: "POST",
           url: url_prefix + "ajax_edit",
           data: { call_type: 'edit', csrf_webspice_tkn: token }
          }).done(function(msg){
              $('#ajax_edit_container').html(msg).show('slow');
           
          }).fail(function() {
              alert( "We could not execute your request. Please try again later or report to authority.dgfdg" );
              spinner.hide();
          });
          
          return false;
    	});
    	
			$(document).on('submit', '#frm_create_user', function(){
				alert('here');
          var spinner = $(this).parent().parent().find('.spinner');
          var me = $(this);
          spinner.show();
          
          var jqxhr = $.ajax({
           type: "POST",
           url: url_prefix + "ajax_edit",
           data: $('#frm_create_user').serialize()
          }).done(function(msg){
              $('#ajax_edit_container').html(msg).show('slow');
           
          }).fail(function() {
              alert( "We could not execute your request. Please try again later or report to authority.dgfdg" );
              spinner.hide();
          });
          
          return false;
    	});
        
		});
	</script>
</body>
</html>