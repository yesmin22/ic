<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_corporate_exchange_rate" class="main_container page_identifier">
			<?php if( isset($edit['ID']) && $edit['ID'] ):?>
				<div class="page_caption">Edit MT Rate</div>
			<?php else:?>
				<div class="page_caption">MT Rate</div>
			<?php endif;?>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter Mt Rate</legend></fieldset>

					<div class="stitle">* Mandatory Field</div>
					<div style="color:red">Enter the value without %</div>
					
					<form id="page_create_mt_rate_rate" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" id="mt_rate_id" name="mt_rate_id" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $this->webspice->encrypt_decrypt($edit['ID'], 'encrypt');} ?>" />

						<table width="100%">
							<tr>
								<td colspan=3>
									<div class="form_label">Month*</div>
									<div class="month_picker_container">
		              	<input type="text" name="REPORT_MONTH" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" value="<?php echo set_value('REPORT_MONTH',strtotime($edit['REPORT_MONTH'])); ?>" required />
									</div>
									<div class="p_error_container">&nbsp;</div>
								</td>
							</tr>
									<tr>
										
										<td>
											<div class="form_label">B2B Ratio Revenue*</div>
											<div>
												<input type="text"  class="input_full input_style" id="B2B_RATIO" name="B2B_RATIO" value="<?php echo set_value('B2B_RATIO',$edit['B2B_RATIO']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('B2B_RATIO'); ?></span>
											</div>
										</td>
										<td>
											<div class="form_label">B2C Ratio Revenue*</div>
											<div>
												<input type="text"  class="input_full input_style" id="B2C_RATIO" name="B2C_RATIO" value="<?php echo set_value('B2C_RATIO',$edit['B2C_RATIO']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('B2C_RATIO'); ?></span>
											</div>
										</td>
									</tr>
									<tr>
										
										<td>
											<div class="form_label">B2B Ratio Cost*</div>
											<div>
												<input type="text"  class="input_full input_style" id="B2B_RATIO_COST" name="B2B_RATIO_COST" value="<?php echo set_value('B2B_RATIO_COST',$edit['B2B_RATIO_COST']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('B2B_RATIO_COST'); ?></span>
											</div>
										</td>
										<td>
											<div class="form_label">B2C Ratio Cost*</div>
											<div>
												<input type="text"  class="input_full input_style" id="B2C_RATIO_COST" name="B2C_RATIO_COST" value="<?php echo set_value('B2C_RATIO_COST',$edit['B2C_RATIO_COST']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('B2C_RATIO_COST'); ?></span>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<div class="form_label">AIT*</div>
											<div>
												<input type="text"  class="input_full input_style" id="AIT" name="AIT" value="<?php echo set_value('AIT',$edit['AIT']); ?>" maxlength="50" data-parsley-type="number" required />
												<span class="fred"><?php echo form_error('AIT'); ?></span>
											</div>
										</td>
									</tr>
								
									<tr>
										<td>
											<div><input id="btn_submit" type="submit" class="btn_gray" value="Submit Data" /></div>
										</td>
									</tr>
								</table>
							</form>
						</div>

						<div class="right_section">

						</div>
						<div class="float_clear_full">&nbsp;</div>


					</div>

				</div>

			</div>
	</body>
</html>