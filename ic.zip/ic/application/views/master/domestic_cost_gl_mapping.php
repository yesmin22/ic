
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Create Option</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_create_company" class="main_container page_identifier">
			
			
			<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update Domestic Cost GL Mapping</div>
       <?php }else{ ?>
        <div class="page_caption">Create Domestic Cost GL Mapping</div>
       <?php } ?>
			<div class="page_body stamp">
				
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
				
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<table width="100%">
							<tr>
								    <td>
								   	<div class="form_label">Operator Name*</div>
								   	<div>
		                  <select name="operator_name" class="input_full input_style" required>
				                 <option value="">Select One</option>
				                 <?php if( set_value('operator_name', $edit['OPERATOR_NAME']) ): ?>
				                 <?php echo str_replace('value="'.set_value('operator_name', $edit['OPERATOR_NAME']).'"','value="'.set_value('user_role', $edit['OPERATOR_NAME']).'" selected="selected"', $this->customcache->get_operator('option_name')); ?>
				                 <?php else: ?>
				                 <?php echo $this->customcache->get_operator('option_name'); ?>
				                 <?php endif; ?>
	             	   		</select>
								   		<span	class="fred"><?php echo form_error('operator_name'); ?></span>
								   	</div>
								   </td>
								</tr>
								
								
								<tr>
									<td>
										<div class="form_label">Post Voice*</div>
										<div>
											<input type="text"  class="input_full input_style" id="post_voice" name="post_voice" value="<?php echo set_value('post_voice',$edit['POST_VOICE']); ?>" required />
											<span class="fred"><?php echo form_error('post_voice'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Pre Voice*</div>
										<div>
											<input type="text"  class="input_full input_style" id="pre_voice" name="pre_voice" value="<?php echo set_value('pre_voice',$edit['PRE_VOICE']); ?>"  required />
											<span class="fred"><?php echo form_error('pre_voice'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Acrued*</div>
										<div>
											<input type="text"  class="input_full input_style" id="accrued" name="accrued" value="<?php echo set_value('accrued',$edit['ACCURED']); ?>"  required />
											<span class="fred"><?php echo form_error('accrued'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Post SMS*</div>
										<div>
											<input type="text"  class="input_full input_style" id="post_sms" name="post_sms" value="<?php echo set_value('post_sms',$edit['POST_SMS']); ?>" required  />
											<span class="fred"><?php echo form_error('post_sms'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Pre SMS*</div>
										<div>
											<input type="text"  class="input_full input_style" id="pre_sms" name="pre_sms" value="<?php echo set_value('pre_sms',$edit['PRE_SMS']); ?>"  required />
											<span class="fred"><?php echo form_error('pre_sms'); ?></span>
										</div>
									</td>
								</tr>
							<tr>
								<td>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				
				<div class="right_section">
					
				</div>
				<div class="float_clear_full">&nbsp;</div>
				
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>

</body>
</html>