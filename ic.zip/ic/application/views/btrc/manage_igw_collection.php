<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_product" class="main_container page_identifier">
			<div class="page_caption">Manage IGW Collection</div>

			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" data-parsley-validate>
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
						</tr>
						<tr>
							<td>
		           <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_igw_collection">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_igw_collection/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_igw_collection/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
				</form>
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table class="table table-bordered table-striped new_table_sm">
					<tr>
						<th>Id</th>
						<th>Report Date</th>
						<th>Operators Name</th>
						<th>Value</th>
						<th>Created Date</th>
						<th>Action</th>
					</tr>
					<?php $i=1; foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><?php if($v->REPORT_DATE){echo $this->webspice->formatted_date($v->REPORT_DATE);}?></td>
						<td><?php if($v->OPERATORS_NAME){ echo $v->OPERATORS_NAME;}?></td>
						<td><?php if($v->VALUE){ echo $v->VALUE;}?></td>
						<td><?php if($v->CREATED_DATE){echo $this->webspice->formatted_date($v->CREATED_DATE);}?></td>
						<td class="field_button">
							<?php if( $this->webspice->permission_verify('manage_igw_collection',true) && $v->STATUS!=9 ): ?>
							<a href="<?php echo $url_prefix; ?>manage_igw_collection/edit/<?php echo $this->webspice->encrypt_decrypt($v->ID,'encrypt'); ?>" class="btn_orange">Edit</a>
							<?php endif; ?>
						</td>
					</tr>
					<?php $i++; endforeach; ?>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>