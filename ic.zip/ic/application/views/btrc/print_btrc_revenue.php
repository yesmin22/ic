<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 5;
$report_name = "Btrc Revenue";
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BTRC Revenue</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin-->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;">Banglalink Digital Communications Limited</td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Revenue as per BTRC Format of <?php echo (date("M-Y", strtotime($date[0])));?> to <?php echo (date("M-Y", strtotime($date[2])));?> </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			<br />
			
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">				
				<tr>
					<th>Revenue</th>
					<th><?php echo (date("M-Y", strtotime($date[0])));?></th>
					<th><?php echo (date("M-Y", strtotime($date[1])));?></th>
					<th><?php echo (date("M-Y", strtotime($date[2])));?></th>
					<th><?php echo 'Q-3-'.(date("Y", strtotime($date[2]))).' Total'; ?></th>
				</tr>
				<?php foreach($revenue as $key => $value): ?>
					<?php if($value['TITLE']=="SMS/EMS/VMS - Incoming"): ?>
						<tr>
							<td><?php echo $value["TITLE"]; ?></td>
							<td style="text-align:right;"><?php echo $value["MTSMS_FIRST_MONTH_VALUE"] + $value["ISMS_FIRST_MONTH_VALUE"]; ?></td>
							<td style="text-align:right;"><?php echo $value["MTSMS_SECOND_MONTH_VALUE"] + $value["ISMS_SECOND_MONTH_VALUE"]; ?></td>
							<td style="text-align:right;"><?php echo $value["MTSMS_THIRD_MONTH_VALUE"] + $value["ISMS_THIRD_MONTH_VALUE"]; ?></td>
							<td style="text-align:right;">&nbsp;</td>
						</tr>
					<?php else: ?>
						<tr>
							<td><?php echo $value["TITLE"]; ?></td>
							<td style="text-align:right;"><?php echo $value["FIRST_MONTH_VALUE"]; ?></td>
							<td style="text-align:right;"><?php echo $value["SECOND_MONTH_VALUE"]; ?></td>
							<td style="text-align:right;"><?php echo $value["THIRD_MONTH_VALUE"]; ?></td>
							<td style="text-align:right;">&nbsp;</td>
						</tr>
					<?php endif; ?>
				<?php endforeach; ?>
			</table>
		</div>
	</body>
</html>