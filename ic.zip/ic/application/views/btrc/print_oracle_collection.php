<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 8;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oracle Collection</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
		</style>
			<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin-->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;">Banglalink Digital Communications Limited</td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Oracle Collection Calculation for the period of <?php echo (date("M-Y", strtotime($date[0])));?> to <?php echo (date("M-Y", strtotime($date[2])));?> </td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			<br />
			
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">				
				<tr>
					<td>&nbsp;</td>
					<td>G/L Account</td>
					<td>Description</td>
					<td><?php echo (date("M-Y", strtotime($date[0])));?></td>
					<td><?php echo (date("M-Y", strtotime($date[1])));?></td>
					<td><?php echo (date("M-Y", strtotime($date[2])));?></td>
					<td><?php echo 'Q-3-'.(date("Y", strtotime($date[2]))).' Total';?></td>
				</tr>
				<?php
				$net_postpaid_one = array_sum(array_column($get_record,"NET_POSTPAID_ONE"));
				$net_postpaid_two = array_sum(array_column($get_record,"NET_POSTPAID_TWO"));
				$net_postpaid_three = array_sum(array_column($get_record,"NET_POSTPAID_THREE"));
				$value_one = 0;
				$value_two = 0;
				$value_three = 0;
				#dd($get_record);
			  if($get_record){
			  	foreach($get_record as $key => $value){
						$value_one = round($value['TB_VALUE_ONE']);
						$value_two = round($value['TB_VALUE_TWO']);
						$value_three = round($value['TB_VALUE_THREE']);
			  		if(in_array($value['GL_CODE'], array("4012101","4012153","4012202","4012203","4012204","4012206","4012501","4012607","4012608","4012609","4012610","4012651","4012652","4012653","4012659","4012660","4012663","4012664","4012665","4012666","4012667","4012669","4012670","4012671","4012672","4012673","4012674","4012676","4012677","4012751","4012754","4012756","4017101","4017151","4017201","4017202","4017203","4017301","4017351","4017352","4017353","4017354","4017401","4017402","4017403","4017405","4017406","4017409","4017410","4017411","4017412","4017413","4017414","4017415","4017417","4017418","4017419","4017421","4017422","4017451","4017454","4017456"))){
			  			$value_one = -round((($value['NET_POSTPAID_ONE']/$net_postpaid_one) * $value['POSTPAID_COLLECTION_ONE']) + $value['CNC_VALUE_ONE']);
			  			$value_two = -round((($value['NET_POSTPAID_TWO']/$net_postpaid_two) * $value['POSTPAID_COLLECTION_TWO']) + $value['CNC_VALUE_TWO']);
			  			$value_three = -round((($value['NET_POSTPAID_THREE']/$net_postpaid_three) * $value['POSTPAID_COLLECTION_THREE']) + $value['CNC_VALUE_THREE']);
			  			$total = ($value_one + $value_two + $value_three);
			  		}
			  		$total = ($value_one + $value_two + $value_three);
			  		
			  		?>
			  	<tr>
			  		<td><?php echo $value['SUB_TYPE']; ?></td>
			  		<td><?php echo $value['GL_CODE']; ?></td>
			  		<td><?php echo $value['GL_DESCRIPTION']; ?></td>
			  		<td style="text-align:right"><?php echo $value_one; ?></td>
			  		<td style="text-align:right"><?php echo $value_two; ?></td>
			  		<td style="text-align:right"><?php echo $value_three; ?></td>
			  		<td style="text-align:right"><?php echo $total; ?></td>
			  		<td style="text-align:left"><?php echo $value['TYPE'] ; ?></td>
			  	</tr>
			  <?php	
			  		$total=0; 
			  	}	
				}
				?>
			</table>
		</div>
	</body>
</html>