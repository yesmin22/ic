<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 20;
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BTRC Revenue Sharing</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.text-center{text-align:center;}
			.text-left{text-align:left;}
			.text-right{text-align:right;}
		</style>
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin-->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;">Banglalink Digital Communications Limited</td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Revenue Sharing Calculation for the period of <?php echo (date("M-Y", strtotime($date[0])));?> to <?php echo (date("M-Y", strtotime($date[2])));?> </td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:10px; text-align:center; padding:0px;">Template for Revenue Sharing (as par new Licensing Guideline)</td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			<br />
			<?php $blank_td = "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";?>
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
				<tr>
					<td class="text-center">A</td>
					<td class="text-center">B</td>
					<td class="text-center">C</td>
					<td class="text-center">D</td>
					<td class="text-center">E</td>
					<td class="text-center">F</td>
					<td class="text-center">G</td>
					<td class="text-center">H</td>
					<td class="text-center">I</td>
					<td class="text-center">J</td>
					<td class="text-center">K</td>
					<td class="text-center">L</td>
					<td class="text-center">M</td>
					<td class="text-center">N</td>
					<td class="text-center">O</td>
					<td class="text-center">P</td>
					<td class="text-center">Q</td>
					<td class="text-center">R</td>
					<td class="text-center">S</td>
					<td class="text-center">T</td>
				</tr>
				<tr>
					<td class="text-left" colspan=2 >Date: <?php echo date("d-m-Y"); ?></td>
					<td class="text-center" >&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center" colspan=2>01-Jul-17</td>
					<td class="text-center" colspan=2>01-Aug-17</td>
					<td class="text-center" colspan=2>01-Sep-17</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<tr>
					<td class="text-center">Sl No</td>
					<td class="text-center">Particulars</td>
					<td class="text-center">Jul-17</td>
					<td class="text-center">Aug-17</td>
					<td class="text-center">Sep-17</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Gross Receipts</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Revenue Share for BTRC</td>
					<td class="text-center">30% of Z value</td>
					<td class="text-center">Total Sharing 5.5%</td>
					<td class="text-center">SOF @1%</td>
					<td class="text-center">Total BTRC sharing</td>
					<td class="text-center">Remarks</td>
				</tr>
				
				<tr>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">1</td>
					<td class="text-center">2</td>
					<td class="text-center">3</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">9</td>
					<td class="text-center">A=(1+2+3)</td>
					<td class="text-center">B</td>
					<td class="text-center">C=(A-B)</td>
					<td class="text-center">D= (5.5% of C)</td>
					<td class="text-center">E</td>
					<td class="text-center">F=D+E</td>
					<td class="text-center">G</td>
					<td class="text-center">H=F+G</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<tr>
					<td class="text-center">&nbsp;</td>
					<td class="text-left">Subscriber Information</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<!-- No of Subscriber: Total Subscriber -->
				<tr>
					<td class="text-center">1</td>
					<td class="text-left">No of Subscriber: Total Subscriber</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_ONE"))?></td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_TWO"))?></td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_THREE"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_ONE"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_TWO"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_THREE"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<?php foreach($subscriber_data as $skey => $sval): ?>
				<tr>
					<td class="text-center"><?php echo $skey+2; ?></td>
					<td class="text-left"><?php echo $sval['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_ONE']; ?></td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_TWO']; ?></td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_THREE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_ONE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_TWO']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_THREE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php endforeach; ?>
				
				<!-- Intra-operator domestic service Voice Calls  -->
				<?php if(!empty($intra_dom_calls)): ?>
				<tr>
					<td class="text-center">1</td>
					<td class="text-left"><?php echo $intra_dom_calls['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo abs($intra_dom_calls['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo abs($intra_dom_calls['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['FIRST_MONTH_VALUE']) + abs($intra_dom_calls['SECOND_MONTH_VALUE']) + abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = abs($intra_dom_calls['FIRST_MONTH_VALUE']) + abs($intra_dom_calls['SECOND_MONTH_VALUE']) + abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center" >1</td>
					<td>Intra-operator domestic service Voice Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Inter-operator domestic service Voice Calls  -->
				<?php if(!empty($inter_dom_calls)): ?>
				<tr>
					<td class="text-center">1</td>
					<td class="text-left"><?php echo $inter_dom_calls['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['FIRST_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['SECOND_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $inter_dom_calls['FIRST_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $inter_dom_calls['SECOND_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['FIRST_MONTH_VALUE'] + $inter_dom_calls['SECOND_MONTH_VALUE'] + $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $inter_dom_calls['FIRST_MONTH_VALUE'] + $inter_dom_calls['SECOND_MONTH_VALUE'] + $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">2</td>
					<td>Inter-operator domestic service Voice Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Off Net Call (Outgoing)  -->
				<?php if(!empty($voice_outgoing_revenue)): ?>
				<tr>
					<td class="text-center">i</td>
					<td class="text-left"><?php echo $voice_outgoing_revenue['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_rev = abs($voice_outgoing_revenue['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_rev = abs($voice_outgoing_revenue['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_rev = abs($voice_outgoing_revenue['THIRD_MONTH_VALUE']); ?></td>
					
					<td class="text-right"><?php echo $first_other = abs($voice_outgoing_revenue['FIRST_MONTH_OTHERS']); ?></td>
					<td class="text-right"><?php echo $first_other + $first_rev; ?></td>
					
					<td class="text-right"><?php echo $second_other = abs($voice_outgoing_revenue['SECOND_MONTH_OTHERS']); ?></td>
					<td class="text-right"><?php echo $second_other + $second_rev; ?></td>
					
					<td class="text-right"><?php echo $third_other = abs($voice_outgoing_revenue['THIRD_MONTH_OTHERS']); ?></td>
					<td class="text-right"><?php echo $third_other + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_rev = $first_rev + $second_rev + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_other = $first_other + $second_other + $third_other; ?></td>
					
					<td class="text-right"><?php echo $total = $total_rev - $total_other; ?></td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-right"><?php echo round($total * .01); ?></td>
					<td class="text-right"><?php echo round($total * .055) + round($total * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">i</td>
					<td>Off Net Call (Outgoing)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Inter-operator domestic service Voice Calls  -->
				<?php if(!empty($mtc)): ?>
				<tr>
					<td class="text-center">1</td>
					<td class="text-left"><?php echo $mtc['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($mtc['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($mtc['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($mtc['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">2</td>
					<td>Off Net Call (Incoming)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				<tr>
					<td class="text-center">3</td>
					<td>Intra-operator domestic service Video Calls On-Net</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center">4</td>
					<td>Inter-operator domestic service Video Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center"></td>
					<td>Off Net Call (Outgoing)</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center"></td>
					<td>Off Net Call (Incoming)</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center">5</td>
					<td>International long distance Voice Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- International Incoming  -->
				<?php if(!empty($igw_data)): ?>
				<tr>
					<td class="text-center">i</td>
					<td class="text-left"><?php echo $igw_data['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = round(abs($igw_data['FIRST_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $second_month = round(abs($igw_data['SECOND_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $third_month = round(abs($igw_data['THIRD_MONTH_VALUE'])); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">i</td>
					<td>International Incoming</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- International Outgoing  -->
				<?php if(!empty($int_outgoing_revenue)): ?>
				<tr>
					<td class="text-center">ii</td>
					<td class="text-left"><?php echo $int_outgoing_revenue['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_rev = round(abs($int_outgoing_revenue['FIRST_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $second_rev = round(abs($int_outgoing_revenue['SECOND_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $third_rev = round(abs($int_outgoing_revenue['THIRD_MONTH_VALUE'])); ?></td>
					
					<td class="text-right"><?php echo $first_other = round(abs($int_outgoing_revenue['FIRST_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo  ($first_rev - $first_other) * .40; ?></td>
					
					<td class="text-right"><?php echo $second_other = round(abs($int_outgoing_revenue['SECOND_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo ($second_rev + $second_other) * .40;; ?></td>
					
					<td class="text-right"><?php echo $third_other = round(abs($int_outgoing_revenue['THIRD_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo ($third_rev + $third_other) * .40; ?></td>
					
					<td class="text-right"><?php echo $total_rev = $first_rev + $second_rev + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_other = $first_other + $second_other + $third_other; ?></td>
					
					<td class="text-right"><?php echo $total = $total_rev - $total_other; ?></td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-right"><?php echo round($total * .01); ?></td>
					<td class="text-right"><?php echo round($total * .055) + round($total * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">i</td>
					<td>Off Net Call (Outgoing)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
			</table>
		</div>
	</body>
</html>