<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: <?php if( isset($page_title) ){ echo $page_title; } ?></title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
	<style>label{cursor:pointer}</style>
</head>

<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_upload_sale_batch" class="main_container page_identifier">
			<div class="page_caption"><?php if( isset($page_title) ){ echo $page_title; } ?></div>
			<div class="page_body stamp">
				
				<!--file upload error-->
				<?php if( isset($error) && $error ): ?>
				<div class="message_board"><?php echo $error; ?></div>
				<?php endif; ?>
					
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter sale information</legend></fieldset>
				
					<div class="stitle">* Mandatory Field</div>
					
					<form id="frm_upload_sale_batch" method="post" action="" enctype="multipart/form-data" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
		         
						<table class="table" width="100%">
							<tr>
								<td>
									<div class="form_label">Data Phase*</div>
									<div>
										<input type="radio" id="phase_one" name="data_phase" value="phase_one" required /> <label for="phase_one">Phase One</label>
										<input type="radio" id="phase_two" name="data_phase" value="phase_two" required /> <label for="phase_two">Phase Two</label>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan=3 >
									<div class="form_label">Upload File*</div>
									<div>
										<input type="file" class="" id="sap_file" name="sap_file" accept=".xlsx" required />
									</div>
								</td>
							</tr>
							<tr>
								<td colspan=3 >
									<div>
										<input type="checkbox" id="Yes" name="agreement" required /> <label for="Yes">Agree with this rate & ratio ?</label>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan=3 >
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				
				<div class="right_section">
					<fieldset class="divider"><legend>Please download the formatted file</legend></fieldset>
					<a href="<?php echo $this->webspice->get_path('custom'); ?>upload_sale_batch_format.xlsx">Download</a>
					
					<fieldset class="divider"><legend>Updated Rate</legend></fieldset>
					
					<table class="table" style="width:60%">
							<!--<tr><th>Title</th><th>Value</th><th>Date</th></tr>-->
							<?php foreach($Configuration as $k=> $v): $attribute= null; ?>
							 <tr>
								<?php foreach($v as $key => $val):?>
									<?php if($key == 'updated_date'){continue;} ?>
									<td><?php echo ucwords(str_replace('_',' ',$key)); ?></td>
									<td style="text-align:right"><?php echo $val;?></td>
									<?php $attribute = $key; ?>
								<?php endforeach;?>
									<td style="text-align:right" ><?php echo $v->updated_date; ?></td>
								</tr>
							<?php endforeach; ?>
						</table>
				</div>
				<div class="float_clear_full">&nbsp;</div>
				
				
			</div>

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
		
	</div>
</body>
</html>