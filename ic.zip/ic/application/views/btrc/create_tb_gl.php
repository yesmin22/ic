
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: GL Mapping</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>
<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_company" class="main_container page_identifier">
			<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update TB GL</div>
       <?php }else{ ?>
        <div class="page_caption">Create TB GL</div>
       <?php } ?>
			<div class="page_body stamp">	
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<table width="100%">
								<tr>
									<td>
										<div class="form_label">GL CODE*</div>
										<div>
											<input type="text"  class="input_full input_style" id="GL_CODE" name="GL_CODE" value="<?php echo set_value('GL_CODE',$edit['GL_CODE']); ?>"  required />
											<span class="fred"><?php echo form_error('GL_CODE'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">GL Description</div>
										<div>
											<input type="text"  class="input_full input_style" id="GL_DESCRIPTION" name="GL_DESCRIPTION" value="<?php echo set_value('GL_DESCRIPTION',$edit['GL_DESCRIPTION']); ?>"   />
											<span class="fred"><?php echo form_error('GL_DESCRIPTION'); ?></span>
										</div>
									</td>
								</tr>
						    <tr>
									<td>
										<div class="form_label">GL Subtype*</div>
										<div>
											<input type="text"  class="input_full input_style" id="SUB_TYPE" name="SUB_TYPE" value="<?php echo set_value('SUB_TYPE',$edit['SUB_TYPE']); ?>"  required />
											<span class="fred"><?php echo form_error('SUB_TYPE'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Type*</div>
										<div>
											<input type="text"  class="input_full input_style" id="TYPE" name="TYPE" value="<?php echo set_value('TYPE',$edit['TYPE']); ?>"  required />
											<span class="fred"><?php echo form_error('TYPE'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
								   <td>
									    <div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								   </td>
							  </tr>
							</table>
					</form>
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
		</div>		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>		
	</div>
</body>
</html>