
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: MIS Revenue & GL Mapping</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>
<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_company" class="main_container page_identifier">
			<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update MIS Revenue & GL Mapping</div>
       <?php }else{ ?>
        <div class="page_caption">MIS Revenue & GL Mapping</div>
       <?php } ?>
			<div class="page_body stamp">	
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<table width="100%">
							 	<tr>
							     <td>
								      <div class="form_label">Bill Month*</div>
											<div class="month_picker_container">
												<input type="text" name="REPORT_MONTH" value="<?php echo set_value('REPORT_MONTH',strtotime($edit['REPORT_MONTH'])); ?>" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
											</div>
											<div class="p_error_container">&nbsp;</div>
									 </td>
								</tr>
								<tr>
									<td>
										<div class="form_label">X Value*</div>
										<div>
											<input type="text"  class="input_full input_style" id="X_VALUE" name="X_VALUE" value="<?php echo set_value('X_VALUE',$edit['X_VALUE']); ?>"  required />
											<span class="fred"><?php echo form_error('X_VALUE'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Y Value*</div>
										<div>
											<input type="text"  class="input_full input_style" id="Y_VALUE" name="Y_VALUE" value="<?php echo set_value('Y_VALUE',$edit['Y_VALUE']); ?>"   />
											<span class="fred"><?php echo form_error('Y_VALUE'); ?></span>
										</div>
									</td>
								</tr>
						    <tr>
									<td>
										<div class="form_label">Z Value*</div>
										<div>
											<input type="text"  class="input_full input_style" id="Z_VALUE" name="Z_VALUE" value="<?php echo set_value('Z_VALUE',$edit['Z_VALUE']); ?>"  required />
											<span class="fred"><?php echo form_error('Z_VALUE'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
								   <td>
									    <div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								   </td>
							  </tr>
							</table>
					</form>
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
		</div>		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>		
	</div>
</body>
</html>