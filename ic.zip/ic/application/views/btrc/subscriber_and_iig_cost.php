
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Subscriber and IIG Cost</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>
<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_company" class="main_container page_identifier">
			<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update Subscriber and IIG Cost</div>
       <?php }else{ ?>
        <div class="page_caption">Subscriber and IIG Cost</div>
       <?php } ?>
			<div class="page_body stamp">	
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<table width="100%">
							 	<tr>
							     <td>
								      <div class="form_label">Bill Month*</div>
											<div class="month_picker_container">
												<input type="text" name="REPORT_MONTH" value="<?php echo set_value('REPORT_MONTH',strtotime($edit['REPORT_MONTH'])); ?>" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
											</div>
											<div class="p_error_container">&nbsp;</div>
									 </td>
								</tr>
								<tr>
									<td>
										<div class="form_label">No of 3G subscriber*</div>
										<div>
											<input type="text"  class="input_full input_style" id="NO_OF_3G_SUBSCRIBER" name="NO_OF_3G_SUBSCRIBER" value="<?php echo set_value('NO_OF_3G_SUBSCRIBER',$edit['NO_OF_3G_SUBSCRIBER']); ?>"  required />
											<span class="fred"><?php echo form_error('NO_OF_3G_SUBSCRIBER'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">No of 2G subscriber*</div>
										<div>
											<input type="text"  class="input_full input_style" id="NO_OF_2G_SUBSCRIBER" name="NO_OF_2G_SUBSCRIBER" value="<?php echo set_value('NO_OF_2G_SUBSCRIBER',$edit['NO_OF_2G_SUBSCRIBER']); ?>"  required />
											<span class="fred"><?php echo form_error('NO_OF_2G_SUBSCRIBER'); ?></span>
										</div>
									</td>
								</tr>
						    <tr>
									<td>
										<div class="form_label">IIG Cost*</div>
										<div>
											<input type="text"  class="input_full input_style" id="IIG_COST" name="IIG_COST" value="<?php echo set_value('IIG_COST',$edit['IIG_COST']); ?>"  required />
											<span class="fred"><?php echo form_error('IIG_COST'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Postpaid Collection*</div>
										<div>
											<input type="text"  class="input_full input_style" id="POSTPAID_COLLECTION" name="POSTPAID_COLLECTION" value="<?php echo set_value('POSTPAID_COLLECTION',$edit['POSTPAID_COLLECTION']); ?>"  required />
											<span class="fred"><?php echo form_error('POSTPAID_COLLECTION'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
								   <td>
									    <div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								   </td>
							  </tr>
							</table>
					</form>
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
		</div>		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>		
	</div>
</body>
</html>