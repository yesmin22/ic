<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "parent_controller";
$route['confirmation'] = "parent_controller/show_confirmation";
$route['test'] = "parent_controller/test";

$route['user_login_time_update'] = "parent_controller/user_login_time_update";

# user authentication
$route['login'] = 'parent_controller/login';
$route['logout'] = 'parent_controller/logout';
$route['change_password'] = 'parent_controller/change_password';
$route['change_password/:any'] = 'parent_controller/change_password';
$route['forgot_password'] = 'parent_controller/forgot_password';

$route['cache_group_remove_remotly'] = "parent_controller/cache_group_remove_remotly";
$route['cache_group_remove_remotly/:any'] = "parent_controller/cache_group_remove_remotly";

# user management
$route['create_user']='master_controller/create_user';
$route['manage_user']='master_controller/manage_user';
$route['manage_user/:any']='master_controller/manage_user';
$route['create_role']='master_controller/create_role';
$route['manage_role']='master_controller/manage_role';
$route['manage_role/:any']='master_controller/manage_role';

# configuration
$route['create_option']='master_controller/create_option';
$route['manage_option']='master_controller/manage_option';
$route['manage_option/:any']='master_controller/manage_option';
$route['create_service']='master_controller/create_service';
$route['manage_service']='master_controller/manage_service';
$route['manage_service/:any']='master_controller/manage_service';

# bundle
$route['create_bundle']='hafiz_controller/create_bundle';
$route['manage_bundle']='hafiz_controller/manage_bundle';
$route['manage_bundle/:any']='hafiz_controller/manage_bundle';
$route['details_bundle/:any']='hafiz_controller/details_bundle';

$route['create_bundle_forecast']='hafiz_controller/create_bundle_forecast';
$route['print_bundle_forecast']='hafiz_controller/print_bundle_forecast';
$route['bundle_forecast/:any']='hafiz_controller/bundle_forecast';
$route['view_forecast_data']='hafiz_controller/view_forecast_data';
$route['details_forecast_data/:any']='hafiz_controller/details_forecast_data';

$route['upload_sale_batch']='hafiz_controller/upload_sale_batch';
$route['upload_sale_batch_without_agree']='hafiz_controller/upload_sale_batch_without_agree';
$route['manage_sale']='hafiz_controller/manage_sale';
$route['manage_sale/:any']='hafiz_controller/manage_sale';
$route['update_sale_price']='hafiz_controller/update_sale_price';
$route['update_sale_price/:any']='hafiz_controller/update_sale_price';
$route['upload_sale_individual']='hafiz_controller/upload_sale_individual';

# report
$route['fv_allocation']='report_controller/fv_allocation';
$route['pv_calculation']='report_controller/pv_calculation';
$route['individual_jv']='report_controller/individual_jv';
$route['summary_jv']='report_controller/summary_jv';
$route['formatted_summary_jv_erp']='report_controller/formatted_summary_jv_erp';
$route['sim_sales_corp_jv']='hafiz_controller/sim_sales_corp_jv';
$route['sim_sales_sme_jv']='hafiz_controller/sim_sales_sme_jv';
$route['sim_sales_icon_jv']='hafiz_controller/sim_sales_icon_jv';
$route['sim_sales_swap_jv']='hafiz_controller/sim_sales_swap_jv';
$route['sim_sales_router_jv']='hafiz_controller/sim_sales_router_jv';
$route['revenue_landing_journal_for_all_emi']='report_controller/revenue_landing_journal_for_all_emi';
$route['receivable_journal_for_all_emi']='report_controller/receivable_journal_for_all_emi';
$route['sim_sales_migration']='hafiz_controller/sim_sales_migration';
$route['previous_landing_journal']='report_controller/previous_landing_journal';
$route['entyr_cf_ccc_sd']='hafiz_controller/entyr_cf_ccc_sd';
$route['manage_cf_ccc_sd']='hafiz_controller/manage_cf_ccc_sd';
$route['manage_cf_ccc_sd/:any']='hafiz_controller/manage_cf_ccc_sd';
$route['sim_sales_report_finance_corp_swap']='hafiz_controller/sim_sales_report_finance_corp_swap';
$route['sim_sales_corp_swap_jv']='hafiz_controller/sim_sales_corp_swap_jv';


#invoice
$route['generate_invoice']='hafiz_controller/generate_invoice';
$route['generate_invoice/:any']='hafiz_controller/generate_invoice';
$route['invoice_configuration']='master_controller/invoice_configuration';
$route['manage_invoice_configuration']='master_controller/manage_invoice_configuration';
$route['manage_invoice_configuration/:any']='master_controller/manage_invoice_configuration';

#configuration
$route['view_configuration_data'] = 'master_controller/view_configuration_data';
$route['view_configuration_data/:any'] = 'master_controller/view_configuration_data';
$route['update_configuration_data'] = 'master_controller/update_configuration_data';
$route['manage_rate_ratio'] = 'master_controller/manage_rate_ratio';
$route['manage_rate_ratio/:any'] = 'master_controller/manage_rate_ratio';

#customer
$route['create_customer'] = 'master_controller/create_customer';
$route['manage_customer'] = 'master_controller/manage_customer';
$route['manage_customer/:any'] = 'master_controller/manage_customer';
$route['create_customer_info'] = 'master_controller/create_customer_info';
$route['manage_customer_info'] = 'master_controller/manage_customer_info';
$route['manage_customer_info/:any'] = 'master_controller/manage_customer_info';

#ageing
$route['upload_ageing_data'] = 'ageing_controller/upload_ageing_data';
$route['manage_uploaded_data'] = 'ageing_controller/manage_uploaded_data';
$route['manage_uploaded_data/:any'] = 'ageing_controller/manage_uploaded_data';
$route['generate_ageing'] = 'ageing_controller/generate_ageing';
$route['generate_ageing/:any'] = 'ageing_controller/generate_ageing';

$route['sim_sales_report_finance_sme'] = 'hafiz_controller/sim_sales_report_finance_sme';
$route['sim_sales_report_finance_corp'] = 'hafiz_controller/sim_sales_report_finance_corp';
# $route[':any'] = "parent_controller/index";

$route['sim_sales_report_finance_icon'] = 'hafiz_controller/sim_sales_report_finance_icon';
$route['sim_sales_report_finance_swap'] = 'hafiz_controller/sim_sales_report_finance_swap';
$route['bl_router_data'] = 'hafiz_controller/bl_router_data';
$route['sim_sales_report_finance_migration'] = 'hafiz_controller/sim_sales_report_finance_migration';
$route['create_sale'] = 'hafiz_controller/create_sale';
$route['router_and_modem_data_upload'] = 'hafiz_controller/router_and_modem_data_upload';


# Manage Sim Sales data
$route['manage_sim_sales_finance_corp']='hafiz_controller/manage_sim_sales_finance_corp';
$route['manage_sim_sales_finance_corp/:any']='hafiz_controller/manage_sim_sales_finance_corp';
$route['manage_sim_sales_finance_sme']='hafiz_controller/manage_sim_sales_finance_sme';
$route['manage_sim_sales_finance_sme/:any']='hafiz_controller/manage_sim_sales_finance_sme';
$route['manage_sim_sales_finance_icon']='hafiz_controller/manage_sim_sales_finance_icon';
$route['manage_sim_sales_finance_icon/:any']='hafiz_controller/manage_sim_sales_finance_icon';
$route['manage_sim_sales_corp_swap']='hafiz_controller/manage_sim_sales_corp_swap';
$route['manage_sim_sales_corp_swap/:any']='hafiz_controller/manage_sim_sales_corp_swap';
$route['manage_sim_sales_swap']='hafiz_controller/manage_sim_sales_swap';
$route['manage_sim_sales_swap/:any']='hafiz_controller/manage_sim_sales_swap';
$route['manage_sim_sales_report_migration']='hafiz_controller/manage_sim_sales_report_migration';
$route['manage_sim_sales_report_migration/:any']='hafiz_controller/manage_sim_sales_report_migration';
$route['manage_router_and_modem_data']='hafiz_controller/manage_router_and_modem_data';
$route['manage_router_and_modem_data/:any']='hafiz_controller/manage_router_and_modem_data';
$route['get_bundles']='hafiz_controller/get_bundles';
$route['get_bundle_agreement']='hafiz_controller/get_bundle_agreement';
$route['get_bundle_data']='hafiz_controller/get_bundle_data';


/* End of file routes.php */
/* Location: ./application/config/routes.php */