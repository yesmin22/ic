
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: GL Mapping</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>
<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_company" class="main_container page_identifier">
			<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update C&C Revenue</div>
       <?php }else{ ?>
        <div class="page_caption">Create TB GL</div>
       <?php } ?>
			<div class="page_body stamp">	
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<table width="100%">
								<tr>
									<td>
										<div class="form_label">GL CODE*</div>
										<div>
											<input type="text"  class="input_full input_style" id="GL" name="GL" value="<?php echo set_value('GL',$edit['GL']); ?>"  required />
											<span class="fred"><?php echo form_error('GL'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Value</div>
										<div>
											<input type="text"  class="input_full input_style" id="VALUE" name="VALUE" value="<?php echo set_value('VALUE',$edit['VALUE']); ?>"   />
											<span class="fred"><?php echo form_error('VALUE'); ?></span>
										</div>
									</td>
								</tr>
						     <tr>
							     <td>
								      <div class="form_label">Bill Month*</div>
											<div class="month_picker_container">
												<input type="text" name="REPORT_DATE" value="<?php echo set_value('REPORT_DATE',strtotime($edit['REPORT_DATE'])); ?>" class="month_picker input_style" data-parsley-errors-container=".p_error_container" data-parsley-error-message="" required />
											</div>
											<div class="p_error_container">&nbsp;</div>
									 </td>
								</tr>
								<tr>
								   <td>
									    <div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								   </td>
							  </tr>
							</table>
					</form>
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
		</div>		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>		
	</div>
</body>
</html>