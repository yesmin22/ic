<?php 
$url_prefix = $this->webspice->settings()->site_url_prefix;
$site_url = $this->webspice->settings()->site_url;
$domain_name = $this->webspice->settings()->domain_name;
$total_column = 20;
$report_name = "BTRC Revenue Sharing";
# don't edit the below area (csv)
if( $action_type=='csv' ){
	$file_name = strtolower(str_replace(array(' '),'_',$report_name)).'_'.date('Y_m_d_h_i').'.xls';
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Pragma: no-cache");
	header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BTRC Revenue Sharing</title>
		<style type="text/css">
			#printArea { width:100%; margin:auto; }
			body, table {font-family:tahoma; font-size:13px;}
			.table { border-color:#cccccc; border-collapse:collapse; }
			table td { padding:2px 4px !important; }
			.table th, .table td{
				border-color:#cccccc;
				vertical-align:middle !important;
				white-space:nowrap;
			}
			.text-center{text-align:center;}
			.text-left{text-align:left;}
			.text-right{text-align:right;}
		</style>
		<script type="text/javascript" src="<?php echo $url_prefix; ?>global/js/jquery-1.8.0.min.js"></script>
    
    <?php if( $action_type=='print'): ?>
		<!-- print plugin-->
		<script src="<?php echo $url_prefix; ?>global/js/jquery.jqprint.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$('#printArea').jqprint();
				$('#print_icon').click(function(){
					$('#printArea').jqprint();
				});
			});
		</script>
		<?php endif; ?>
  </head>
  <body>
		<div id="printArea">
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr style="border-top:1px solid #ccc;">
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:17px; font-weight:bold; color:red; text-align:center; padding:0px;">Banglalink Digital Communications Limited</td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="text-align:center; padding:0px;">Revenue Sharing Calculation for the period of <?php echo (date("M-Y", strtotime($date[0])));?> to <?php echo (date("M-Y", strtotime($date[2])));?> </td>
				</tr>
				<tr>
					<td colspan="<?php echo $total_column; ?>" align="center" style="font-size:10px; text-align:center; padding:0px;">Template for Revenue Sharing (as par new Licensing Guideline)</td>
				</tr>
				<tr><td>&nbsp;</td></tr>
			</table>
			<br />
			<?php $blank_td = "<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";?>
			<table class="table" width="100%" border="1" cellpadding="0" cellspacing="0">
				<tr>
					<td class="text-center">A</td>
					<td class="text-center">B</td>
					<td class="text-center">C</td>
					<td class="text-center">D</td>
					<td class="text-center">E</td>
					<td class="text-center">F</td>
					<td class="text-center">G</td>
					<td class="text-center">H</td>
					<td class="text-center">I</td>
					<td class="text-center">J</td>
					<td class="text-center">K</td>
					<td class="text-center">L</td>
					<td class="text-center">M</td>
					<td class="text-center">N</td>
					<td class="text-center">O</td>
					<td class="text-center">P</td>
					<td class="text-center">Q</td>
					<td class="text-center">R</td>
					<td class="text-center">S</td>
					<td class="text-center">T</td>
				</tr>
				<tr>
					<td class="text-left" colspan=2 >Date: <?php echo date("d-m-Y"); ?></td>
					<td class="text-center" >&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center" colspan=2>01-Jul-17</td>
					<td class="text-center" colspan=2>01-Aug-17</td>
					<td class="text-center" colspan=2>01-Sep-17</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<tr>
					<td class="text-center">Sl No</td>
					<td class="text-center">Particulars</td>
					<td class="text-center">Jul-17</td>
					<td class="text-center">Aug-17</td>
					<td class="text-center">Sep-17</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Gross Receipts</td>
					<td class="text-center">Recipts for others</td>
					<td class="text-center">Gross Revenue for ANS</td>
					<td class="text-center">Revenue Share for BTRC</td>
					<td class="text-center">30% of Z value</td>
					<td class="text-center">Total Sharing 5.5%</td>
					<td class="text-center">SOF @1%</td>
					<td class="text-center">Total BTRC sharing</td>
					<td class="text-center">Remarks</td>
				</tr>
				
				<tr>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">1</td>
					<td class="text-center">2</td>
					<td class="text-center">3</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">9</td>
					<td class="text-center">A=(1+2+3)</td>
					<td class="text-center">B</td>
					<td class="text-center">C=(A-B)</td>
					<td class="text-center">D= (5.5% of C)</td>
					<td class="text-center">E</td>
					<td class="text-center">F=D+E</td>
					<td class="text-center">G</td>
					<td class="text-center">H=F+G</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<tr>
					<td class="text-center">&nbsp;</td>
					<td class="text-left">Subscriber Information</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<!-- No of Subscriber: Total Subscriber -->
				<tr>
					<td class="text-center">1</td>
					<td class="text-left">No of Subscriber: Total Subscriber</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_ONE"))?></td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_TWO"))?></td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_THREE"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_ONE"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_TWO"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo array_sum(array_column($subscriber_data, "NO_OF_SUBSCRIBER_THREE"))?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				
				<?php foreach($subscriber_data as $skey => $sval): ?>
				<tr>
					<td class="text-center"><?php echo $skey+2; ?></td>
					<td class="text-left"><?php echo $sval['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_ONE']; ?></td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_TWO']; ?></td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_THREE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_ONE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_TWO']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $sval['NO_OF_SUBSCRIBER_THREE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php endforeach; ?>
				
				<!-- Intra-operator domestic service Voice Calls  -->
				<?php if(!empty($intra_dom_calls)): ?>
				<tr>
					<td class="text-center">1</td>
					<td class="text-left"><?php echo $intra_dom_calls['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo abs($intra_dom_calls['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo abs($intra_dom_calls['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo abs($intra_dom_calls['FIRST_MONTH_VALUE']) + abs($intra_dom_calls['SECOND_MONTH_VALUE']) + abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = abs($intra_dom_calls['FIRST_MONTH_VALUE']) + abs($intra_dom_calls['SECOND_MONTH_VALUE']) + abs($intra_dom_calls['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center" >1</td>
					<td>Intra-operator domestic service Voice Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Inter-operator domestic service Voice Calls  -->
				<?php if(!empty($inter_dom_calls)): ?>
				<tr>
					<td class="text-center">1</td>
					<td class="text-left"><?php echo $inter_dom_calls['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['FIRST_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['SECOND_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $inter_dom_calls['FIRST_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $inter_dom_calls['SECOND_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo $inter_dom_calls['FIRST_MONTH_VALUE'] + $inter_dom_calls['SECOND_MONTH_VALUE'] + $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $inter_dom_calls['FIRST_MONTH_VALUE'] + $inter_dom_calls['SECOND_MONTH_VALUE'] + $inter_dom_calls['THIRD_MONTH_VALUE']; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">2</td>
					<td>Inter-operator domestic service Voice Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Off Net Call (Outgoing)  -->
				<?php if(!empty($voice_outgoing_revenue)): ?>
				<tr>
					<td class="text-center">i</td>
					<td class="text-left"><?php echo $voice_outgoing_revenue['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_rev = abs($voice_outgoing_revenue['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_rev = abs($voice_outgoing_revenue['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_rev = abs($voice_outgoing_revenue['THIRD_MONTH_VALUE']); ?></td>
					
					<td class="text-right"><?php echo $first_other = abs($voice_outgoing_revenue['FIRST_MONTH_OTHERS']); ?></td>
					<td class="text-right"><?php echo $first_rev + $first_other; ?></td>
					
					<td class="text-right"><?php echo $second_other = abs($voice_outgoing_revenue['SECOND_MONTH_OTHERS']); ?></td>
					<td class="text-right"><?php echo $second_rev + $second_other; ?></td>
					
					<td class="text-right"><?php echo $third_other = abs($voice_outgoing_revenue['THIRD_MONTH_OTHERS']); ?></td>
					<td class="text-right"><?php echo $third_other + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_rev = $first_rev + $second_rev + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_other = $first_other + $second_other + $third_other; ?></td>
					
					<td class="text-right"><?php echo $total = $total_rev - $total_other; ?></td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-right"><?php echo round($total * .01); ?></td>
					<td class="text-right"><?php echo round($total * .055) + round($total * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">i</td>
					<td>Off Net Call (Outgoing)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Inter-operator domestic service Voice Calls  -->
				<?php if(!empty($mtc)): ?>
				<tr>
					<td class="text-center">1</td>
					<td class="text-left"><?php echo $mtc['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($mtc['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($mtc['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($mtc['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">2</td>
					<td>Off Net Call (Incoming)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="text-center">3</td>
					<td>Intra-operator domestic service Video Calls On-Net</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center">4</td>
					<td>Inter-operator domestic service Video Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center"></td>
					<td>Off Net Call (Outgoing)</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center"></td>
					<td>Off Net Call (Incoming)</td>
					<?php echo $blank_td; ?>
				</tr>
				<tr>
					<td class="text-center">5</td>
					<td>International long distance Voice Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- International Incoming  -->
				<?php if(!empty($igw_data)): ?>
				<tr>
					<td class="text-center">i</td>
					<td class="text-left"><?php echo $igw_data['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = round(abs($igw_data['FIRST_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $second_month = round(abs($igw_data['SECOND_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $third_month = round(abs($igw_data['THIRD_MONTH_VALUE'])); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">i</td>
					<td>International Incoming</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- International Outgoing (Note: 1)  -->
				<?php if(!empty($int_outgoing_revenue)): ?>
				<tr>
					<td class="text-center">ii</td>
					<td class="text-left"><?php echo $int_outgoing_revenue['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_rev = round(abs($int_outgoing_revenue['FIRST_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $second_rev = round(abs($int_outgoing_revenue['SECOND_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $third_rev = round(abs($int_outgoing_revenue['THIRD_MONTH_VALUE'])); ?></td>
					
					<td class="text-right"><?php echo $first_other = round(abs($int_outgoing_revenue['FIRST_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo  ($first_rev - $first_other) * .40; ?></td>
					
					<td class="text-right"><?php echo $second_other = round(abs($int_outgoing_revenue['SECOND_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo ($second_rev - $second_other) * .40; ?></td>
					
					<td class="text-right"><?php echo $third_other = round(abs($int_outgoing_revenue['THIRD_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo ($third_rev - $third_other) * .40; ?></td>
					
					<td class="text-right"><?php echo $total_rev = $first_rev + $second_rev + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_other = $first_other + $second_other + $third_other; ?></td>
					
					<td class="text-right"><?php echo $total = $total_rev - $total_other; ?></td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-right"><?php echo round($total * .01); ?></td>
					<td class="text-right"><?php echo round($total * .055) + round($total * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">i</td>
					<td>International Outgoing (Note: 1)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="text-center">6</td>
					<td>International long distance Video Calls</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<tr>
					<td class="text-center">&nbsp;</td>
					<td>International Incoming</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<tr>
					<td class="text-center">&nbsp;</td>
					<td>International Outgoing</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<tr>
					<td class="text-center">7</td>
					<td>International Roaming Services</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- In-Bound  -->
				<?php if(!empty($in_bound)): ?>
				<tr>
					<td class="text-center">(i)</td>
					<td class="text-left"><?php echo $in_bound['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($in_bound['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($in_bound['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($in_bound['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(i)</td>
					<td>Off Net Call (Incoming)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Out-Bound  -->
				<?php if(!empty($out_bound)): ?>
				<tr>
					<td class="text-center">(ii)</td>
					<td class="text-left"><?php echo $out_bound['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_rev = round(abs($out_bound['FIRST_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $second_rev = round(abs($out_bound['SECOND_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $third_rev = round(abs($out_bound['THIRD_MONTH_VALUE'])); ?></td>
					
					<td class="text-right"><?php echo $first_other = round(abs($out_bound['FIRST_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo  $first_rev - $first_other; ?></td>
					
					<td class="text-right"><?php echo $second_other = round(abs($out_bound['SECOND_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo $second_rev - $second_other; ?></td>
					
					<td class="text-right"><?php echo $third_other = round(abs($out_bound['THIRD_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo $third_rev - $third_other; ?></td>
					
					<td class="text-right"><?php echo $total_rev = $first_rev + $second_rev + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_other = $first_other + $second_other + $third_other; ?></td>
					
					<td class="text-right"><?php echo $total = $total_rev - $total_other; ?></td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-right"><?php echo round($total * .01); ?></td>
					<td class="text-right"><?php echo round($total * .055) + round($total * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(ii)</td>
					<td>Out-Bound</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>				
				
				<!-- Intra-operator SMS/EMS/VMS  -->
				<?php if(!empty($intra_operator_sms_ems_vms)): ?>
				<tr>
					<td class="text-center">8</td>
					<td class="text-left"><?php echo $intra_operator_sms_ems_vms['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($intra_operator_sms_ems_vms['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($intra_operator_sms_ems_vms['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($intra_operator_sms_ems_vms['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">8</td>
					<td>Intra-operator SMS/EMS/VMS</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="text-center">9</td>
					<td>Inter-operator SMS/EMS/VMS</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- Off Net (Outgoing)  -->
				<?php if(!empty($off_net_outgoing)): ?>
				<tr>
					<td class="text-center">(i)</td>
					<td class="text-left"><?php echo $off_net_outgoing['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_rev = round(abs($off_net_outgoing['FIRST_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $second_rev = round(abs($off_net_outgoing['SECOND_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $third_rev = round(abs($off_net_outgoing['THIRD_MONTH_VALUE'])); ?></td>
					
					<td class="text-right"><?php echo $first_other = round(abs($off_net_outgoing['FIRST_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo  $first_rev - $first_other; ?></td>
					
					<td class="text-right"><?php echo $second_other = round(abs($out_bound['SECOND_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo $second_rev - $second_other; ?></td>
					
					<td class="text-right"><?php echo $third_other = round(abs($out_bound['THIRD_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo $third_rev - $third_other; ?></td>
					
					<td class="text-right"><?php echo $total_rev = $first_rev + $second_rev + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_other = $first_other + $second_other + $third_other; ?></td>
					
					<td class="text-right"><?php echo $total = $total_rev - $total_other; ?></td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-right"><?php echo round($total * .01); ?></td>
					<td class="text-right"><?php echo round($total * .055) + round($total * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(i)</td>
					<td>Off Net (Outgoing)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Off Net (Incoming)  -->
				<?php if( !empty($off_net_incoming_mtsms) && !empty($off_net_incoming_isms) ): ?>
				<tr>
					<td class="text-center">(ii)</td>
					<td class="text-left"><?php echo $off_net_incoming_mtsms['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs(-$off_net_incoming_mtsms['FIRST_MONTH_VALUE'] - $off_net_incoming_isms['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs(-$off_net_incoming_mtsms['SECOND_MONTH_VALUE'] - $off_net_incoming_isms['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs(-$off_net_incoming_mtsms['THIRD_MONTH_VALUE'] - $off_net_incoming_isms['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(ii)</td>
					<td>Off Net (Incoming)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				
				<!-- Mobile Internet  -->
				<?php if(!empty($mobile_internet)): ?>
				<tr>
					<td class="text-center">9</td>
					<td class="text-left"><?php echo $mobile_internet['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($mobile_internet['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($mobile_internet['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($mobile_internet['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">9</td>
					<td>Mobile Internet</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="text-center">(i)</td>
					<td>Internet Service - Pay as you Go</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- Internet Service 2G  -->
				<?php if( !empty($internet_service_2g) ): ?>
				<tr>
					<td class="text-center">(ii)</td>
					<td class="text-left"><?php echo $internet_service_2g['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($internet_service_2g['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($internet_service_2g['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($internet_service_2g['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(ii)</td>
					<td>Internet Service 2G</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Internet Service - 2G Bundle  -->
				<?php if( !empty($internet_service_2g_bundle) ): ?>
				<tr>
					<td class="text-center">(iii)</td>
					<td class="text-left"><?php echo $internet_service_2g_bundle['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($internet_service_2g_bundle['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($internet_service_2g_bundle['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($internet_service_2g_bundle['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(iii)</td>
					<td>Internet Service - 2G Bundle</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Out-Bound  -->
				<?php if(!empty($internet_service_3g)): ?>
				<tr>
					<td class="text-center">(iv)</td>
					<td class="text-left"><?php echo $internet_service_3g['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_rev = round(abs($internet_service_3g['FIRST_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $second_rev = round(abs($internet_service_3g['SECOND_MONTH_VALUE'])); ?></td>
					<td class="text-right"><?php echo $third_rev = round(abs($internet_service_3g['THIRD_MONTH_VALUE'])); ?></td>
					
					<td class="text-right"><?php echo $first_other = round(abs($internet_service_3g['FIRST_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo  $first_rev - $first_other; ?></td>
					
					<td class="text-right"><?php echo $second_other = round(abs($internet_service_3g['SECOND_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo $second_rev - $second_other; ?></td>
					
					<td class="text-right"><?php echo $third_other = round(abs($internet_service_3g['THIRD_MONTH_OTHERS'])); ?></td>
					<td class="text-right"><?php echo $third_rev - $third_other; ?></td>
					
					<td class="text-right"><?php echo $total_rev = $first_rev + $second_rev + $third_rev; ?></td>
					
					<td class="text-right"><?php echo $total_other = $first_other + $second_other + $third_other; ?></td>
					
					<td class="text-right"><?php echo $total = $total_rev - $total_other; ?></td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total * .055); ?></td>
					<td class="text-right"><?php echo round($total * .01); ?></td>
					<td class="text-right"><?php echo round($total * .055) + round($total * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(iv)</td>
					<td>Internet Service - 3G (Note: 2)</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>		
				
				<!-- Mobile Internet  -->
				<?php if(!empty($mobile_internet)): ?>
				<tr>
					<td class="text-center">(v)</td>
					<td class="text-left"><?php echo $mobile_internet['PARTICULARS2']; ?></td>
					<td class="text-right"><?php echo $first_month = abs(($mobile_internet['FIRST_MONTH_VALUE'] - $mobile_internet['FIRST_MONTH_VALUE_3G'])); ?></td>
					<td class="text-right"><?php echo $second_month = abs(($mobile_internet['SECOND_MONTH_VALUE'] - $mobile_internet['SECOND_MONTH_VALUE_3G'])); ?></td>
					<td class="text-right"><?php echo $third_month = abs(($mobile_internet['THIRD_MONTH_VALUE'] - $mobile_internet['THIRD_MONTH_VALUE_3G'])); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-right">&nbsp;</td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center">(v)</td>
					<td>Internet Service - 3G Bundle</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="text-center">10</td>
					<td>Value Added Services (VAS) - 2G & 3G</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- VAS Service 2G  -->
				<?php if(!empty($value_added_service)): ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-left"><?php echo $value_added_service['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = round(abs($value_added_service['FIRST_MONTH_VALUE'] * (($internet_service_2g['FIRST_MONTH_VALUE'] + $internet_service_2g_bundle['FIRST_MONTH_VALUE']) / ($internet_service_2g['FIRST_MONTH_VALUE'] + $internet_service_2g_bundle['FIRST_MONTH_VALUE'] + $internet_service_3g['FIRST_MONTH_VALUE'] + ($mobile_internet['FIRST_MONTH_VALUE'] - $mobile_internet['FIRST_MONTH_VALUE_3G']) )))); ?></td>
					<td class="text-right"><?php echo $second_month = round(abs($value_added_service['SECOND_MONTH_VALUE'] * (($internet_service_2g['SECOND_MONTH_VALUE'] + $internet_service_2g_bundle['SECOND_MONTH_VALUE']) / ($internet_service_2g['SECOND_MONTH_VALUE'] + $internet_service_2g_bundle['SECOND_MONTH_VALUE'] + $internet_service_3g['SECOND_MONTH_VALUE'] + ($mobile_internet['SECOND_MONTH_VALUE'] - $mobile_internet['SECOND_MONTH_VALUE_3G']) )))); ?></td>
					<td class="text-right"><?php echo $third_month = round(abs($value_added_service['THIRD_MONTH_VALUE'] * (($internet_service_2g['THIRD_MONTH_VALUE'] + $internet_service_2g_bundle['THIRD_MONTH_VALUE']) / ($internet_service_2g['THIRD_MONTH_VALUE'] + $internet_service_2g_bundle['THIRD_MONTH_VALUE'] + $internet_service_3g['THIRD_MONTH_VALUE'] + ($mobile_internet['THIRD_MONTH_VALUE'] - $mobile_internet['THIRD_MONTH_VALUE_3G']) )))); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center"></td>
					<td>VAS Service 2G</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- VAS Service 3G -->
				<?php if(!empty($value_added_service)): ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-left"><?php echo $value_added_service['PARTICULARS2']; ?></td>
					<td class="text-right"><?php echo $first_month = round(abs($value_added_service['FIRST_MONTH_VALUE'] * (($internet_service_3g['FIRST_MONTH_VALUE'] + ($mobile_internet['FIRST_MONTH_VALUE'] - $mobile_internet['FIRST_MONTH_VALUE_3G'])) / ($internet_service_2g['FIRST_MONTH_VALUE'] + $internet_service_2g_bundle['FIRST_MONTH_VALUE'] + $internet_service_3g['FIRST_MONTH_VALUE'] + ($mobile_internet['FIRST_MONTH_VALUE'] - $mobile_internet['FIRST_MONTH_VALUE_3G']) )))); ?></td>
					<td class="text-right"><?php echo $second_month = round(abs($value_added_service['SECOND_MONTH_VALUE'] * (($internet_service_3g['SECOND_MONTH_VALUE'] + ($mobile_internet['SECOND_MONTH_VALUE'] - $mobile_internet['SECOND_MONTH_VALUE_3G'])) / ($internet_service_2g['SECOND_MONTH_VALUE'] + $internet_service_2g_bundle['SECOND_MONTH_VALUE'] + $internet_service_3g['SECOND_MONTH_VALUE'] + ($mobile_internet['SECOND_MONTH_VALUE'] - $mobile_internet['SECOND_MONTH_VALUE_3G']) )))); ?></td>
					<td class="text-right"><?php echo $third_month = round(abs($value_added_service['THIRD_MONTH_VALUE'] * (($internet_service_3g['THIRD_MONTH_VALUE'] + ($mobile_internet['THIRD_MONTH_VALUE'] - $mobile_internet['THIRD_MONTH_VALUE_3G'])) / ($internet_service_2g['THIRD_MONTH_VALUE'] + $internet_service_2g_bundle['THIRD_MONTH_VALUE'] + $internet_service_3g['THIRD_MONTH_VALUE'] + ($mobile_internet['THIRD_MONTH_VALUE'] - $mobile_internet['THIRD_MONTH_VALUE_3G']) )))); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center"></td>
					<td>VAS Service 3G</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Others -->
				<tr>
					<td class="text-center">11</td>
					<td>Others</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- Customer Support Service -->
				<tr>
					<td class="text-center"></td>
					<td>Customer Support Service</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- Fiber Optic Network -->
				<?php if(!empty($fiber_optic_network)): ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-left"><?php echo $fiber_optic_network['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($fiber_optic_network['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($fiber_optic_network['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($fiber_optic_network['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center"></td>
					<td>Fiber Optic Network</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Infrastructure -->
				<?php if(!empty($infrastructure)): ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-left"><?php echo $infrastructure['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($infrastructure['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($infrastructure['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($infrastructure['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center"></td>
					<td>Infrastructure</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- Itemised bill -->
				<?php if(!empty($itemized_billing)): ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-left"><?php echo $itemized_billing['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($itemized_billing['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($itemized_billing['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($itemized_billing['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center"></td>
					<td>Itemised bill</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<!-- M-Commerce & Toll Free -->
				<?php if(!empty($mcommerce_toll_free)): ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-left"><?php echo $mcommerce_toll_free['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($mcommerce_toll_free['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($mcommerce_toll_free['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($mcommerce_toll_free['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center"></td>
					<td>M-Commerce & Toll Free</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="text-center"></td>
					<td>Mobile Number/SIM Ownership Transfer Fee</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<!-- Monthly Access Fee -->
				<?php if(!empty($monthy_access_fee)): ?>
				<tr>
					<td class="text-center"></td>
					<td class="text-left"><?php echo $monthy_access_fee['PARTICULARS']; ?></td>
					<td class="text-right"><?php echo $first_month = abs($monthy_access_fee['FIRST_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $second_month = abs($monthy_access_fee['SECOND_MONTH_VALUE']); ?></td>
					<td class="text-right"><?php echo $third_month = abs($monthy_access_fee['THIRD_MONTH_VALUE']); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $first_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $second_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $third_month; ?></td>
					<td class="text-right"><?php echo $first_month + $second_month + $third_month; ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo $total_rev = $first_month + $second_month + $third_month; ?></td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-center">&nbsp;</td>
					<td class="text-right"><?php echo round($total_rev * .055); ?></td>
					<td class="text-right"><?php echo round($total_rev * .01); ?></td>
					<td class="text-right"><?php echo round($total_rev * .055) + round($total_rev * .01); ?></td>
					<td class="text-center">&nbsp;</td>
				</tr>
				<?php else: ?>
				<tr>
					<td class="text-center"></td>
					<td>Monthly Access Fee</td>
					<?php echo $blank_td; ?>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="text-center"></td>
					<td>Toll Free Calls/SMS</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<tr>
					<td class="text-center"></td>
					<td>Others/Miscellaneous</td>
					<?php echo $blank_td; ?>
				</tr>
				
				<tr>
					<td class="text-center"></td>
					<td>Less: Q1-2017 adjustment</td>
					<?php echo $blank_td; ?>
				</tr>
				
			</table>
		</div>
	</body>
</html>