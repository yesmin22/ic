<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Manage Int Toll Free Data</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
							<td>Operator Name</td>
							<td>Post/Pre</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
							<td>
								<select name="OPERATOR_NAME" class="input_full">
									<?php echo $this->webspice->option_by_field("TBL_INT_TOLL_FREE_DATA", "OPERATOR_NAME", "ID", "option_value"); ?>
								</select>
							</td>
							<td>
								<select name="PREPOST_FLAG" class="input_full">
									<option value="">Select One</option>
									<option value="PREP">Prepaid</option>
									<option value="POST">Postpaid</option>
								</select>
							</td>
						</tr>
						<tr>
							<td colspan="20">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_ro_daily_itfs_data">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_ro_daily_itfs_data/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_ro_daily_itfs_data/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table id="" class="table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th>SL</th>
						<th>Date Time</th>
						<th>Operator Name</th>
						<th>Prepost Flag</th>
						<th>Number Of Calls</th>
						<th>Duration Min</th>
						<th>USD Rate</th>
						<th>Ter Charge Usd</th>
						<th>USD BDT</th>
						<th>Ter Charge Bdt</th>
						<th>Bl Revenue</th>
						<th>Created Date</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->DATE_TIME; ?></td>
						<td><?php echo $v->OPERATOR_NAME; ?></td>
						<td><?php echo $v->PREPOST_FLAG; ?></td>
						<td><?php echo $v->NUMBER_OF_CALLS; ?></td> 
						<td><?php echo $v->DURATION_MIN; ?></td> 
						<td><?php echo $v->USD_RATE; ?></td> 
						<td><?php echo $v->TER_CHARGE_USD; ?></td> 
						<td><?php echo $v->USD_BDT; ?></td> 
						<td><?php echo $v->TER_CHARGE_BDT; ?></td> 
						<td><?php echo $v->BL_REVENUE; ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
					<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>