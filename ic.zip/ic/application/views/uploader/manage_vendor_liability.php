<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Manage Vendor Liability</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
								<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
							</td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_vendor_liability">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_vendor_liability/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_vendor_liability/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<div style="overflow-x:auto" class="table-responsive">
				<table id="" class="table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th style="text-align:left">SL</th>
						<th>Account</th>
						<th>Accountt Description</th>
						<th style="text-align:left">Accounting Liability</th>
						<th style="text-align:left">Accounting Liability Desc</th>
						<th style="text-align:left">Invoice Liability Type</th>
						<th style="text-align:left">Vendor Number</th>
						<th style="text-align:left" >Supplier Name</th>
						<th>Vendor Type Code</th>
						<th>Batch Name</th>
						<th style="text-align:left">Vendor Site Code</th>
						<th style="text-align:left">Invoice Type</th>
						<th style="text-align:left">Vendor Sub Type</th>
						<th style="text-align:left">Invoice Currency</th>
						<th style="text-align:left" >Invoice Currency Rate</th>
						<th>Invoice Number</th>
						<th>Invoice Date</th>
						<th style="text-align:left">Bill Month</th>
						<th style="text-align:left">GL Date</th>
						<th style="text-align:left">Invoice Description</th>
						<th style="text-align:left">Due Date</th>
						<th style="text-align:left" >Invoice Curr Amount</th>
						<th>Invoice Amount - BDT</th>
						<th>Invoice Curr Remain</th>
						<th style="text-align:left">Remaining Amount - BDT</th>
						<th style="text-align:left">Po Number</th>
						<th style="text-align:left">Revaluation Amount</th>
						<th style="text-align:left">Net Balance</th>
						<th>Report Date</th>
						<th>Created Date</th>
						<!--<th>Action</th>-->
					</tr>
					</thead>
					<tbody>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->ACCOUNT; ?></td> 
						<td><?php echo $v->ACCOUNT_DESCRIPTION; ?></td> 
						<td><?php echo $v->ACCOUNTING_LIABILITY; ?></td>
						<td><?php echo $v->ACCOUNTING_LIABILITY_DESC; ?></td>
						<td><?php echo $v->INVOICE_LIABILITY_TYPE; ?></td>
						<td><?php echo $v->VENDOR_NUMBER; ?></td> 
						<td><?php echo $v->SUPPLIER_NAME; ?></td> 
						<td><?php echo $v->BATCH_NAME; ?></td> 
						<td><?php echo $v->VENDOR_SITE_CODE; ?></td> 
						<td><?php echo $v->VENDOR_TYPE_CODE; ?></td>
						<td><?php echo $v->INVOICE_TYPE; ?></td>
						<td><?php echo $v->VENDOR_SUB_TYPE; ?></td>
						<td><?php echo $v->INVOICE_CURRENCY; ?></td> 
						<td><?php echo $v->INVOICE_CURRENCY_RATE; ?></td> 
						<td><?php echo $v->INVOICE_NUMBER; ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->INVOICE_DATE); ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->BILL_MONTH); ?></td>
						<td><?php echo $this->webspice->formatted_date($v->GL_DATE); ?></td>
						<td><?php echo $v->INVOICE_DESCRIPTION; ?></td>
						<td><?php echo $v->DUE_DATE; ?></td> 
						<td><?php echo $v->INVOICE_CURR_AMOUNT; ?></td>
						<td><?php echo $v->INVOICE_AMOUNT_BDT; ?></td> 
						<td><?php echo $v->INVOICE_CURR_REMAIN; ?></td> 
						<td><?php echo $v->REMAINING_AMOUNT_BDT; ?></td>
						<td><?php echo $v->PO_NUMBER; ?></td>
						<td><?php echo $v->REVALUATION_AMOUNT; ?></td>
						<td><?php echo $v->NET_BALANCE; ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->REPORT_DATE); ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
						<!--<td><a class="btn btn-warning btn-xs" href="<?php echo $url_prefix.'manage_vendor_liability/edit/'.$this->webspice->encrypt_decrypt($v->ID,'encrypt');?>">Edit</a></td>-->
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				</div>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>