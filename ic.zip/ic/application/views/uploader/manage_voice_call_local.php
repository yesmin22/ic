<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_user" class="main_container page_identifier">
			<div class="page_caption">Manage Voice Call Local</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_ro_daily_data_local">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_ro_daily_data_local/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_ro_daily_data_local/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				
				<!--
				/*
				<table id="data_table_no" class="table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th>SL</th>
						<th>Date Time</th>
						<th>Report Type</th>
						<th>Call Type</th>
						<th>Prepost Flag</th>
						<th>Operator</th>
						<th>ICX</th>
						<th>Number Of Calls</th>
						<th>Minutes</th>
						<th>Rate Per Minutes</th>
						<th>Amount Excluding Vat</th>
						<th>Created Date</th>
						<th>Status</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->DATE_TIME; ?></td>
						<td><?php echo $v->REPORT_TYPE; ?></td>
						<td><?php echo $v->CALL_TYPE; ?></td>
						<td><?php echo $v->PREPOST_FLAG; ?></td> 
						<td><?php echo $v->OPERATOR; ?></td> 
						<td><?php echo $v->ICX; ?></td> 
						<td><?php echo $v->NUMBER_OF_CALLS; ?></td> 
						<td><?php echo $v->MINUTES; ?></td> 
						<td><?php echo $v->RATE_PER_MINUTES; ?></td> 
						<td><?php echo $v->AMOUNT_EXCLUDING_VAT; ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
						<td><?php echo $this->webspice->static_status($v->STATUS); ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				*/
				-->
				
    		<div id="jsGrid"></div>
				
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
	
	
	<link type="text/css" rel="stylesheet" href="<?php echo $url_prefix; ?>global/jsgrid-1.5.3/jsgrid.min.css" />
	<link type="text/css" rel="stylesheet" href="<?php echo $url_prefix; ?>global/jsgrid-1.5.3/jsgrid-theme.min.css" />
	<script type="text/javascript" src="<?php echo $url_prefix; ?>global/jsgrid-1.5.3/jsgrid.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			var clients = <?php echo json_encode($get_record); ?>;
			/*
	    var clients = [
	        { "Name": "Otto Clay", "Age": 25, "Country": 1, "Address": "Ap #897-1459 Quam Avenue", "Married": false },
	        { "Name": "Connor Johnston", "Age": 45, "Country": 2, "Address": "Ap #370-4647 Dis Av.", "Married": true },
	        { "Name": "Lacey Hess", "Age": 29, "Country": 3, "Address": "Ap #365-8835 Integer St.", "Married": false },
	        { "Name": "Timothy Henson", "Age": 56, "Country": 1, "Address": "911-5143 Luctus Ave", "Married": true },
	        { "Name": "Ramona Benton", "Age": 32, "Country": 3, "Address": "Ap #614-689 Vehicula Street", "Married": false }
	    ];*/
	    
	    var new_status = [
         { Name: "Active", Id: "7" },
         { Name: "Unknown", Id: "1" }
	   	];
	 
	    $("#jsGrid").jsGrid({
	        width: "100%",
	        height: "400px",
	 				
	        filtering: true,
	        sorting: true,
	        paging: true,
	        autoload: true,
	 
	        pageSize: 15,
	        pageButtonCount: 5,
	 
	        /*data: clients,*/

	        fields: [
	            { name: "DATE_TIME", type: "text", title:"Date Time" },
	            { name: "REPORT_TYPE", type: "text", title:"Report Type" },
	            { name: "CALL_TYPE", type: "text", title:"Call Type" },
	            { name: "PREPOST_FLAG", type: "text", title:'PREPOST Flag' },
	            { name: "OPERATOR", type: "text", title:'Operator' },
	            { name: "ICX", type: "text" },
	            { name: "NUMBER_OF_CALLS", type: "text", title:"Number Of Calls", filtering: false },
	            { name: "MINUTES", type: "text", title:"Minutes", filtering: false },
	            { name: "RATE_PER_MINUTES", type: "text", title:"Rate per Minutes", filtering: false },
	            { name: "AMOUNT_EXCLUDING_VAT", type: "text", title:"Amount Excluding VAT", filtering: false },
	            { name: "CREATED_BY", type: "text", title:"Created By", filtering: false },
	            { name: "CREATED_DATE", type: "text", title:"Created Date" },
	            { name: "STATUS", type: "select", items: new_status, title:"Status", valueField: "Id", textField: "Name", autosearch: true },
	            { type: "control", filtering: true, editButton: false, deleteButton:false, inserting: false, editing: false }
	        ],
	        controller: {
	            data:clients,
	            loadData: function (filter) {
	            	
	                return $.grep(this.data, function (item) {
	                		//console.log(item);
	                    return (!filter.DATE_TIME || item.DATE_TIME.toLowerCase().indexOf(filter.DATE_TIME.toLowerCase()) >= 0)
	                    && (!filter.REPORT_TYPE || item.REPORT_TYPE.toLowerCase().indexOf(filter.REPORT_TYPE.toLowerCase()) >= 0)
	                    && (!filter.CALL_TYPE || item.CALL_TYPE.toLowerCase().indexOf(filter.CALL_TYPE.toLowerCase()) >= 0)
	                    && (!filter.PREPOST_FLAG || item.PREPOST_FLAG.toLowerCase().indexOf(filter.PREPOST_FLAG.toLowerCase()) >= 0)
	                    && (!filter.OPERATOR || item.OPERATOR.toLowerCase().indexOf(filter.OPERATOR.toLowerCase()) >= 0)
	                    && (!filter.ICX || item.ICX.toLowerCase().indexOf(filter.ICX.toLowerCase()) >= 0)
	                    && (!filter.STATUS || item.STATUS.toLowerCase().indexOf(filter.STATUS.toLowerCase()) >= 0);
	                });
	            },          
	        }
	    });
		});
	</script>
</body>
</html>