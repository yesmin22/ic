<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Welcome</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	
	<?php include(APPPATH."views/global.php"); ?>
</head>

<body>
	<div id="wrapper">
		<div id="header_container"><?php include(APPPATH."views/header.php"); ?></div>
		
		<div id="page_manage_no_cli" class="main_container page_identifier">
			<div class="page_caption">Manage No CLI data</div>
			<div class="page_body table-responsive">
				<!--filter section-->
				<form id="frm_filter" method="post" action="" >
					<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
					
					<table style="width:auto;">
						<tr>
							<td>Keyword</td>
							<td>Date From</td>
							<td>Date End</td>
						</tr>
						<tr>
							<td>
	              <input type="text" name="SearchKeyword" class="input_style input_full" />
							</td>
							<td><input type="text" class="date_picker input_style" id="date_from" name="date_from" /></td>
							<td><input type="text" class="date_picker input_style" id="date_end" name="date_end" /></td>
						</tr>
						<tr>
							<td colspan="10">
								<input type="submit" name="filter" class="btn_gray" value="Filter Data" />
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_no_cli">Refresh</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_no_cli/print" target="_blank">Print</a>
								<a class="btn_gray" href="<?php echo $url_prefix; ?>manage_no_cli/csv" target="_blank">Export</a>
							</td>
						</tr>
					</table>
          
				</form>
				
				<br />
				<?php if( !isset($filter_by) || !$filter_by ){$filter_by = 'All Data';} ?>
				<div class="breadcrumb">Filter By: <?php echo $filter_by; ?></div>
				<table id="" class="table table-bordered table-striped new_table">
					<thead>
					<tr>
						<th>SL</th>
						<th>Report Date</th>
						<th>Date Time</th>
						<th>ICX</th>
						<th>Opearator</th>
						<th>Calls</th>
						<th>Seconds</th>
						<th>Minutes</th>
						<th>Rate per Mintues</th>
						<th>Amount</th>
						<th>VAT</th>
						<th>Total</th>
						<th>Created Date</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($get_record as $k=>$v): ?>
					<tr>
						<td><?php echo $k+1; ?></td>
						<td><?php echo $v->REPORT_DATE; ?></td>
						<td><?php echo $v->DATE_TIME; ?></td>
						<td><?php echo $v->ICX; ?></td>
						<td><?php echo $v->OPERATOR; ?></td>
						<td><?php echo $v->CALLS; ?></td> 
						<td><?php echo $v->SECONDS; ?></td> 
						<td><?php echo $v->MINUTES; ?></td> 
						<td><?php echo $v->RATE_PER_MIN; ?></td> 
						<td><?php echo $v->AMOUNT; ?></td> 
						<td><?php echo $v->VAT; ?></td> 
						<td><?php echo $v->TOTAL; ?></td> 
						<td><?php echo $this->webspice->formatted_date($v->CREATED_DATE); ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<div id="pagination"><?php echo $pager; ?><div class="float_clear_full">&nbsp;</div></div>
			</div><!--end .page_body-->

		</div>
		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>
	</div>
</body>
</html>