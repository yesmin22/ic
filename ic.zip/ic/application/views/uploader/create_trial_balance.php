<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $this->webspice->settings()->domain_name; ?>: Update Trial Balance</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<?php include(APPPATH."views/global.php"); ?>
</head>
<body>
	<div id="wrapper">
		<div><?php include(APPPATH."views/header.php"); ?></div>
		<div id="page_create_company" class="main_container page_identifier">
			<?php if(isset($edit['ID']) && $edit['ID']){?>
        <div class="page_caption">Update Trial Balance</div>
       <?php }else{ ?>
        <div class="page_caption">Create Trial Balance</div>
       <?php } ?>
			<div class="page_body stamp">	
				<div class="left_section">
					<fieldset class="divider"><legend>Please enter relevent information</legend></fieldset>
					<div class="stitle">* Mandatory Field</div>
					<form id="frm_create_customer" method="post" action="" data-parsley-validate>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
						<input type="hidden" name="ID" value="<?php if( isset($edit['ID']) && $edit['ID'] ){echo $edit['ID'];} ?>" />
						<table width="100%">
								<tr>
									<td>
										<div class="form_label">Account*</div>
										<div>
											<input type="text"  class="input_full input_style" id="account" name="account" value="<?php echo set_value('account',$edit['ACCOUNT']); ?>"  required />
											<span class="fred"><?php echo form_error('account'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Description*</div>
										<div>
											<input type="text"  class="input_full input_style" id="description" name="description" value="<?php echo set_value('description',$edit['DESCRIPTION']); ?>"  required />
											<span class="fred"><?php echo form_error('description'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Begin Balance*</div>
										<div>
											<input type="text"  class="input_full input_style" id="begin_balance" name="begin_balance" value="<?php echo set_value('begin_balance',$edit['BEGIN_BALANCE']); ?>"  required />
											<span class="fred"><?php echo form_error('begin_balance'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Period Dr Amount*</div>
										<div>
											<input type="text"  class="input_full input_style" id="period_dr_amount" name="period_dr_amount" value="<?php echo set_value('period_dr_amount',$edit['PERIOD_DR_AMOUNT']); ?>"  required />
											<span class="fred"><?php echo form_error('period_dr_amount'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Period Cr Amount*</div>
										<div>
											<input type="text"  class="input_full input_style" id="period_cr_amount" name="period_cr_amount" value="<?php echo set_value('period_cr_amount',$edit['PERIOD_CR_AMOUNT']); ?>"  required />
											<span class="fred"><?php echo form_error('period_cr_amount'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Period Net Balance*</div>
										<div>
											<input type="text"  class="input_full input_style" id="period_net_balance" name="period_net_balance" value="<?php echo set_value('period_net_balance',$edit['PERIOD_NET_BALANCE']); ?>"  required />
											<span class="fred"><?php echo form_error('period_net_balance'); ?></span>
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<div class="form_label">Period End Balance*</div>
										<div>
											<input type="text"  class="input_full input_style" id="period_end_balance" name="period_end_balance" value="<?php echo set_value('period_end_balance',$edit['PERIOD_END_BALANCE']); ?>"  required />
											<span class="fred"><?php echo form_error('period_end_balance'); ?></span>
										</div>
									</td>
								</tr>
							  <tr>
									<td>
										<div class="form_label">Report Date*</div>
										<div>
											<input type="text"  class="date_picker input_style input_full" id="report_date" name="report_date" value="<?php echo set_value('report_date',$edit['REPORT_DATE']); ?>"  required />
											<span class="fred"><?php echo form_error('report_date'); ?></span>
										</div>
									</td>
								</tr>
		
							<tr>
								<td>
									<div><input type="submit" class="btn_gray" value="Submit Data" /></div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				<div class="float_clear_full">&nbsp;</div>
			</div>
		</div>		
		<div id="footer_container"><?php include(APPPATH."views/footer.php"); ?></div>		
	</div>
</body>
</html>